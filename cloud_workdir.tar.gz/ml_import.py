#!/usr/bin/env python3
"""Import the ML curriculum (unified_curriculum.md) into the cloud curriculum as Part G (D24-D41) and capstones U13.11-U13.17.
Writes units_ml/*.md, assign_ml/*.md and merge_ledger.json.  Deterministic; re-run after changing demand.py or the drop lists."""
import re, sys, json, pickle, glob, collections
sys.path.insert(0, '/home/claude/work/ml'); sys.path.insert(0, '/home/claude/work/cloud2')
from mlparse import domains as MD
import mlsrc
import ledger2
import build as B
from demand import DEMAND

OUT_U = '/home/claude/work/cloud2/units_ml/'
OUT_A = '/home/claude/work/cloud2/assign_ml/'

from idmap import dnew, unew, anew, remap, nrewrites

# ---------- cloud side ----------
cunits, cdoms, _ = B.load_units(sorted(glob.glob('/home/claude/work/cloud2/units/*.md')))
CU = {u.uid: u for u in cunits}
def short(title, n=78):
    t = title.replace('Bridge: ', '')
    t = re.split(r':| — ', t)[0]
    if len(t) > n:
        t = t[:n].rsplit(',', 1)[0] if ',' in t[:n] else t[:n].rsplit(' ', 1)[0]
    return t.strip()

# ---------- ML side: ids, titles ----------
MU = {}   # old id -> unit
ORDER_NEW = []
for d in MD:
    for u in d['units']:
        MU[u['id']] = u
OLD2NEW = {}
for oid in MU:
    a, b = oid[1:].split('.')
    OLD2NEW[oid] = unew(int(a), int(b))
NEW2OLD = {v: k for k, v in OLD2NEW.items()}
NEWTITLE = {OLD2NEW[o]: remap(MU[o]['title']) for o in MU}

# ---------- demand inverse ----------
for c, ms in DEMAND.items():
    for m in ms:
        assert m in NEW2OLD, (c, m)
CALLERS = collections.defaultdict(list)
for c, ms in DEMAND.items():
    for m in ms:
        CALLERS[m].append(c)
def ukey(u):
    a, b = u[1:].split('.')
    return (int(a), int(b))

# ---------- dedupe: drops ----------
KEEP_PREFIX = [('U9.5', 'support vector machines (SVM) for classification'), ('U9.10', 'GP posterior mean')]
DROP_EXTRA_OWNED = [
    ('U1.2', 'inclusion–exclusion [P]', 'U21.4'), ('U1.5', 'correctness of RSA [P]', 'U5.14'), ('U1.6', "Lagrange's theorem [P]", 'U5.5'),
    ('U5.8', "Little's law [P]", 'U2.1'), ('U8.6', 'Weak duality [P]', 'U4.5'), ('U8.6', 'LP strong duality [P]', 'U4.5'),
    ('U4.4', 'Gram–Schmidt produces an orthonormal basis [P]', 'U18.2'),
    ('U1.4', "Euler's circuit theorem [P]", 'U21.5'),
    ('U1.4', 'graph class with adjacency/incidence matrices, BFS/DFS', 'U21.5', 0.3),
    ('U9.12', 'Apriori anti-monotonicity (downward closure) [P]', 'U19.11'), ('U9.12', 'support, confidence and lift [Def]', 'U19.11'),
]
DROP_EXTRA = [
    ('U4.4', 'Gram–Schmidt orthogonalization and process'), ('U4.4', 'inner product and vector norm'),
    ('U4.5', 'properties of determinants and adjoint'), ('U4.9', 'compare with `numpy.linalg.svd`'),
    ('U4.10', 'optimal linear MMSE estimation'), ('U4.10', 'least squares by normal equations, QR and SVD'),
    ('U4.11', 'convergence of the power method and PageRank damping'),
    ('U5.3', 'discrete and continuous distribution functions'), ('U5.3', 'Poisson process and exponential distribution'),
    ('U5.4', 'Box–Muller and inverse-CDF samplers from scratch'),
    ('U6.1', 'box plots and histograms by hand'), ('U6.2', 'sampling techniques (random, stratified)'),
    ('U7.5', 'FFT (radix-2) from scratch'), ('U8.6', 'an algorithm for the max-flow problem'),
    ('U8.12', 'water-filling power allocation'), ('U8.12', 'OMP recovery experiments (phase transition)'),
    ('U9.7', 'regression and classification via decision trees'), ('U9.7', 'decision-tree-based inductive learning'),
    ('U9.8', 'principal component analysis (PCA)'), ('U9.9', 'Gaussian mixture model (GMM)'),
    ('U9.9', 'hierarchical agglomerative clustering'), ('U9.9', 'centroid-based and probabilistic model-based clustering'),
    ('U9.11', 'the Netflix problem and data completion'), ('U9.12', 'data mining as an interdisciplinary topic'),
]
def seg_split(text):
    return re.split(r'(;\s*|\.\s+(?=[A-Z]))', text)

drops = []   # ledger entries
ov = pickle.load(open('/home/claude/work/ml/overlap.pkl', 'rb'))
auto, kept = ledger2.run(0.8)
sel = []
for e in auto:
    if any(e['ml'] == m and e['raw'].startswith(p) for m, p in KEEP_PREFIX):
        e['why'] = 'kept: spurious match, the owner does not teach it'; kept.append(e); continue
    if e['owner'] == 'U11.8' and e['ml'].startswith('U9.'):
        e['why'] = 'kept: U11.8 is the compact bridge, this unit is its full treatment'; kept.append(e); continue
    sel.append(e)
# extra drops: find owner by best match among candidates >= 0.12
for mid, pref in DROP_EXTRA:
    if any(e['ml'] == mid and e['raw'].startswith(pref) for e in sel):
        continue
    found = None
    for fld in ledger2.FIELDS:
        for p, c, t in ledger2.raw_atoms(MU[mid]['fields'].get(fld, '')):
            if p.startswith(pref):
                found = (fld, p, c, t)
    assert found, (mid, pref)
    fld, p, c, t = found
    tk = set(B.toks(c))
    best = (0, None)
    for cc, o in ov[mid]:
        if cc < 0.12: continue
        for f, oc, ot, otk in ledger2.cloud_raw(o):
            if not otk: continue
            r = len(tk & otk) / max(1, len(tk))
            if r > best[0]: best = (r, (o, f, oc, ot))
    o, f, oc, ot = best[1]
    sel.append(dict(ml=mid, field=fld, raw=p, atom=c, tag=t, owner=o, ofield=f, oatom=oc, otag=ot, r=round(best[0], 2), manual=True))
for item in DROP_EXTRA_OWNED:
    mid, pref, own = item[:3]; minr = item[3] if len(item) > 3 else 0.5
    if any(e['ml'] == mid and e['raw'].startswith(pref) for e in sel):
        continue
    found = None
    for fld in ledger2.FIELDS:
        for p, c, t in ledger2.raw_atoms(MU[mid]['fields'].get(fld, '')):
            if p.startswith(pref): found = (fld, p, c, t)
    assert found, (mid, pref)
    fld, p, c, t = found
    tk = set(B.toks(c)); best = (0, None)
    for f, oc, ot, otk in ledger2.cloud_raw(own):
        if not otk: continue
        r = len(tk & otk) / max(1, len(tk))
        if r > best[0]: best = (r, (own, f, oc, ot))
    assert best[1] and best[0] >= minr, (mid, pref, own, best[0])
    o, f, oc, ot = best[1]
    sel.append(dict(ml=mid, field=fld, raw=p, atom=c, tag=t, owner=o, ofield=f, oatom=oc, otag=ot, r=round(best[0], 2), manual=True))
DROP = collections.defaultdict(list)
for e in sel:
    DROP[(e['ml'], e['field'])].append(e)

def apply_drops(mid, fld, text):
    es = DROP.get((mid, fld))
    if not es:
        return text
    parts = seg_split(text)
    segs = parts[0::2]; dels = parts[1::2]
    keep = []
    removed = 0
    for i, s in enumerate(segs):
        key = s.strip(' .')
        if any(e['raw'] == key for e in es):
            removed += 1
            continue
        keep.append((s, dels[i] if i < len(dels) else ''))
    assert removed == len(es), (mid, fld, removed, len(es), [e['raw'] for e in es])
    out = ''
    for j, (s, d) in enumerate(keep):
        out += s + (d if j < len(keep) - 1 else '')
    out = out.rstrip('; ').rstrip()
    if text.rstrip().endswith('.') and not out.endswith('.'):
        out += '.'
    return out

# ---------- build unit text ----------
BUL = re.compile(r'^- \*\*(Topics|Results|Build|Gap-fills):\*\* (.*)$')
def tag_of(oid):
    return OLD2NEW[oid]

OVERRIDE = {
    ('U9.12', 'Topics'): 'taught in the cloud units U19.11 (introduction to data mining, preprocessing, association rule mining, classification basics) and U19.13 (evaluation, visualisation, sequence mining, case studies and implementations in open-source software), and not repeated here; what this unit adds is the frequent-pattern algorithm FP-growth and the PrefixSpan sketch for sequences, the link from clustering to outlier detection (clusters are U19.9 and U33.9), and the assignment A33.12, which is set after those units.',
    ('U9.12', 'Results'): 'FP-growth correctness [S]; (the downward-closure property and the measures support, confidence and lift are proved and defined in U19.11).',
    ('U9.12', 'Build'): 'FP-growth and a PrefixSpan sketch, then an end-to-end mining pipeline (clean, mine, evaluate, visualize) on top of the Apriori of U19.11.',
}
def build_unit(oid):
    u = MU[oid]; nid = OLD2NEW[oid]
    core = list(u['core'])
    srcline = core[0]
    assert srcline.startswith('**Sources:**'), oid
    body = []
    for ln in core[1:]:
        m = BUL.match(ln)
        if m:
            if (oid, m.group(1)) in OVERRIDE:
                ln = '\x00- **%s:** %s' % (m.group(1), OVERRIDE[(oid, m.group(1))])
            else:
                ln = '- **%s:** %s' % (m.group(1), apply_drops(oid, m.group(1), m.group(2)))
        body.append(ln)
    while body and not body[-1].strip():
        body.pop()
    text = '\n'.join(l[1:] if l.startswith('\x00') else remap(l) for l in body)
    text = text.replace('Closes the whole course and assembles parts the learner built in every earlier capstone', 'Closes Part G and assembles parts the learner built in U13.11 to U13.16')
    return nid, srcline, text

units_out = {}
rel = {}      # new id -> dict(info)
for oid in MU:
    nid, srcline, text = build_unit(oid)
    # internal refs to earlier ML units
    refs = collections.Counter(r for r in re.findall(r'\bU\d+\.\d+\b', text) if r in NEW2OLD and ukey(r) < ukey(nid) and not r.startswith('U13.'))
    back = [r for r, _ in sorted(refs.items(), key=lambda kv: (-kv[1], ukey(kv[0])))[:6]]
    back.sort(key=ukey)
    # cloud owners: overlap >= 0.15 or drop owners
    own = collections.OrderedDict()
    for c, o in ov.get(oid, []):
        if c >= 0.15: own[o] = []
    for fld in ledger2.FIELDS:
        for e in DROP.get((oid, fld), []):
            own.setdefault(e['owner'], []).append(e['atom'])
    rel[nid] = dict(old=oid, back=back, owners=own, srcline=srcline, text=text)

def sentence_list(items):
    items = [i for i in items if i]
    return '; '.join(items)

def first_line(nid):
    r = rel[nid]
    cs = sorted(CALLERS.get(nid, []), key=lambda x: (int(x[1:].split('.')[0]), int(x[1:].split('.')[1])))
    parts = []
    if nid.startswith('U13.'):
        return ('Integration unit (Part H): entered after the domains it closes, which it names; built from your own components first and defended against the acceptance criteria of this domain.', '')
    if cs:
        parts.append('Bridge for: ' + ', '.join('%s (%s)' % (c, short(CU[c].title)) for c in cs) + '.')
    else:
        if r['back']:
            parts.append('On demand (Part G): no cloud unit calls on this unit directly; enter it from ' + ', '.join(r['back'][:4]) + ' or when a later unit of the part needs it.')
        else:
            parts.append('On demand (Part G): no cloud unit calls on this unit directly; enter it when a unit of this domain or a capstone needs it.')
    bits = []
    if r['owners']:
        names = ['%s (%s)' % (o, short(CU[o].title, 60)) for o in r['owners']]
        listing = names[0] if len(names) == 1 else ', '.join(names[:-1]) + ' and ' + names[-1]
        bits.append('Shares ground with the cloud unit%s %s; where they overlap the cloud unit owns the topic and this unit goes further (the proofs, the abstract setting or the extra cases listed below).' % ('s' if len(names) > 1 else '', listing))
        nr = ['%s: %s' % (o, '; '.join(remap(a.rstrip('.').strip()) for a in atoms)) for o, atoms in r['owners'].items() if atoms]
        if nr:
            bits.append('Not repeated here, because the cloud unit teaches it: ' + '. '.join(nr) + '.')
    if r['back']:
        bits.append('Builds on ' + ', '.join('%s' % b for b in r['back']) + '.')
    return parts[0], '\n'.join(bits)

# corrections found by the independent recomputation of the numeric keys (verify_keys.py)
KEY_FIXES = [dict(unit='U40.1', old='- **Q3:** 170.7 FLOP/byte (tolerance ±0.01).', new='- **Q3:** 170.67 FLOP/byte (tolerance ±0.01).',
                  why='2 N^3 / (12 N^2) = N/6 = 170.667 for N = 1024; the old key 170.7 was 0.033 away, outside its own tolerance of 0.01, so a correct answer of 170.67 would have been marked wrong'),
    dict(unit='U35.5', old='(D) SHAP values ignore feature correlations by construction', new='(D) Shapley values violate the efficiency axiom',
         why='option D of Q2 was debatable (interventional SHAP does treat features as independent), so the key rationale did not settle it; D is now plainly false'),
    dict(unit='U35.5', old='- **Q2:** ABC. Handling correlation is an open issue.', new='- **Q2:** ABC. D is false: efficiency is one of the defining Shapley axioms.',
         why='key rationale matching the reworded option D'),
    dict(unit='U32.12', old='Predict the water level.', new='Take each channel\'s noise level to be 1/gain and predict the water level.',
         why='the Q5 question gave gains but no noise model, so the water level was undetermined; it now states noise level = 1/gain'),
    dict(unit='U32.12', old='- **Q5 (what a passing submission shows):** Water level between the channel noise levels; the weakest channel gets zero power if its level exceeds the water level.',
         new='- **Q5 (what a passing submission shows):** Noise levels 1, 1/2, 1/4, 1/8; all four channels are active (the water level exceeds the largest noise level), so the water level is (4 + 1.875)/4 = 1.469 and the powers are 0.469, 0.969, 1.219, 1.344. A channel gets zero power only if its noise level exceeds the water level, which none does here.',
         why='the reference run gives water level 1.469 with all four channels active; the old key only described a conditional case that does not occur'),
    dict(unit='U28.1', old='error about 1e-10 despite tiny residual.', new='the residual is near 1e-16 but the error is about 1e-12 to 1e-11 (bounded by condition number times machine epsilon, about 5e-11), many orders larger than the residual.',
         why='a reference run of the 5x5 Hilbert system gives error 2e-12, not 1e-10'),
    dict(unit='U28.8', old='Smallest eigenvalue is nonnegative up to about -1e-12; Cholesky succeeds after adding a tiny jitter.',
         new='The smallest eigenvalue is at rounding level, about 1e-15 in magnitude (machine epsilon times the largest eigenvalue) and often slightly negative although the exact value is positive; plain Cholesky can fail, and a diagonal jitter of about 1e-8 makes it succeed.',
         why='a reference run gives -3e-16 and -1e-15 with Cholesky failing, not about -1e-12'),
    dict(unit='U28.11', old='OMP success in the high 80s to 90s percent.', new='OMP recovers the support in about 85 percent of trials (a band of 80 to 90 percent).',
         why='a reference run (three seeds, 200 trials each) gives 84, 86 and 86.5 percent, not the high 80s to 90s')]
# write unit files per domain
ledger_units = {}
def write_domain(d):
    k = int(d['id'][1:])
    nd = dnew(k)
    lines = []
    if nd == 'D13':
        lines.append('## D13+. Added capstones (from the machine-learning curriculum)')
        lines.append(remap('\n'.join(d['intro'])).strip().replace('Aim: each stretch of the course closes with', 'The Part G capstones (U13.11 to U13.17) in detail: each stretch of Part G closes with') + '\n')
    else:
        lines.append('## %s. %s' % (nd, remap(d['title'])))
        intro = remap('\n'.join(d['intro'])).strip()
        intro = intro.replace('It is printed first because every later domain may call it.', 'It is printed first in Part G because every later domain, in this part and in the cloud parts, may call it.')
        if intro: lines.append(intro + '\n')
    for u in d['units']:
        oid = u['id']; nid = OLD2NEW[oid]
        r = rel[nid]
        lines.append('### %s %s' % (nid, NEWTITLE[nid]))
        cells = mlsrc.parse_sources(r['srcline'][len('**Sources:**'):].strip()) if not r['srcline'].replace('**Sources:**', '').strip().startswith('none') else []
        cells = [(('DMK' if k == 'DM' else k), c) for k, c in cells]
        if cells:
            lines.append('mlsrc: ' + '; '.join('%s:%s' % (k, c) for k, c in cells))
        else:
            lines.append('mlsrc: ' + r['srcline'][len('**Sources:**'):].strip())
        fl, bl = first_line(nid)
        lines.append(fl)
        if bl: lines.append(bl)
        lines.append(r['text'] + '\n')
        ledger_units[nid] = dict(old=oid, title=NEWTITLE[nid], cells=len(cells), callers=CALLERS.get(nid, []), back=r['back'], owners={o: a for o, a in r['owners'].items()})
        # assignment
        if u['asg']:
            ablock = remap('\n'.join(u['asg'])).rstrip() + '\n'
            for kf in KEY_FIXES:
                if kf['unit'] == nid:
                    assert kf['old'] in ablock, kf; ablock = ablock.replace(kf['old'], kf['new'])
            open(OUT_A + nid + '.md', 'w').write(ablock)
    fn = OUT_U + ('D13_add.md' if nd == 'D13' else '%s.md' % nd)
    open(fn, 'w').write('\n'.join(lines) + '\n')

import os
for f in glob.glob(OUT_U + '*.md') + glob.glob(OUT_A + '*.md'):
    os.remove(f)
for d in MD:
    write_domain(d)

led = dict(
    drops=[dict(ml_old=e['ml'], ml_new=OLD2NEW[e['ml']], field=e['field'], atom=e['raw'], owner=e['owner'], owner_field=e['ofield'], owner_atom=e['oatom'], containment=e['r'], ml_tag=e['tag'], owner_tag=e['otag'], manual=e.get('manual', False)) for e in sel],
    kept=[dict(ml_old=e['ml'], ml_new=OLD2NEW[e['ml']], field=e['field'], atom=e['raw'], owner=e['owner'], why=e.get('why', '')) for e in kept],
    units=ledger_units, demand=DEMAND,
    rewrites=dict(nrewrites), key_fixes=KEY_FIXES)
json.dump(led, open('/home/claude/work/cloud2/merge_ledger.json', 'w'), indent=1, ensure_ascii=False)
print('units', len(ledger_units), 'drops', len(sel), 'kept', len(kept), 'rewrites', dict(nrewrites))
print('with cloud callers', sum(1 for n in ledger_units if CALLERS.get(n)), 'assignments', len(glob.glob(OUT_A + '*.md')))
