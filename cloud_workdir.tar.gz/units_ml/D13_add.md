## D13+. Added capstones (from the machine-learning curriculum)
The Part G capstones (U13.11 to U13.17) in detail: each stretch of Part G closes with one integrated, learner-built deliverable defended end to end (Master Rules 9.6). The tutor reviews and questions; the learner writes everything (Master Rules 9.4). **Acceptance criteria common to every capstone (written before work starts, Master Rules 9.3):** required behaviour with automated tests; one number predicted, then measured; one injected failure detected and recovered from; cost estimated, then read from the actual bill (local labs: zero); a threat model; a decision record for each major choice (the judgment turn, Master Rules 10.4); a clean teardown; an oral defence against adversarial questions. Capstone code follows the NumPy-first tooling guideline of the course profile (standard library + NumPy + Matplotlib by default, libraries as oracles in tests, other tools where they serve the deliverable); record each such choice in the decision record. A capstone never replaces unit-by-unit mastery; domain exit audits (Master Rules 8.7) run first.

### U13.11 Capstone A: the mathematics of machine learning, end to end
mlsrc: none (integration unit; assembles earlier units)
Integration unit (Part H): entered after the domains it closes, which it names; built from your own components first and defended against the acceptance criteria of this domain.
- **Topics:** Closes D25–D32. A qualifying-examination-level unseen problem set (at least one proof or derivation and one computational problem per domain, key written first) plus a small reproduction: implement PCA via SVD, ridge/lasso regression, logistic regression by Newton/IRLS, SGD with momentum and Adam, an SVM dual solver and a simple LP/QP solver, each checked against a hand computation and against the professional library.
- **Predict then measure:** the number of Newton iterations to convergence and the condition number of the Hessian; the SGD error floor for a given step size.
- **Injected failure:** an ill-conditioned design matrix; diagnose by SVD and fix by regularization.
- **Defence:** derive the SVD-based PCA, the KKT conditions of the SVM and the convergence rate of gradient descent on a quadratic.
- **Tooling:** capstone code follows the course's NumPy-first guideline; record any other choice in the decision record.

### U13.12 Capstone B: a classical-ML library from scratch
mlsrc: none (integration unit; assembles earlier units)
Integration unit (Part H): entered after the domains it closes, which it names; built from your own components first and defended against the acceptance criteria of this domain.
- **Topics:** Closes D33–D34. A NumPy library (kNN, naive Bayes, CART and random forest, AdaBoost and gradient boosting, kernel SVM, k-means, GMM-EM, PCA, HMM, UCB and Thompson-sampling bandits, tabular Q-learning) with a uniform fit/predict interface, a benchmark harness against scikit-learn on at least five datasets, and a written learning-theory note (PAC/VC bound versus observed generalization gap).
- **Predict then measure:** test-accuracy gap versus scikit-learn for each algorithm; regret slope of UCB versus Thompson sampling.
- **Injected failure:** label noise and covariate shift; detect with the evaluation tools of U33.2.
- **Tooling:** capstone code follows the course's NumPy-first guideline; record any other choice in the decision record.

### U13.13 Capstone C: a deep-learning framework from scratch
mlsrc: none (integration unit; assembles earlier units)
Integration unit (Part H): entered after the domains it closes, which it names; built from your own components first and defended against the acceptance criteria of this domain.
- **Topics:** Closes D35. A reverse-mode autodiff engine with Linear, Conv2d, RNN/LSTM, LayerNorm, Dropout, attention layers; SGD/Adam; a gradient checker; training an MLP, a CNN, an LSTM and a small Transformer on real data; every layer's gradient verified against PyTorch to 1e-5; explanation maps (U35.5) on the CNN.
- **Predict then measure:** parameter counts, FLOPs and the training loss at step 100.
- **Injected failure:** exploding gradients in the LSTM; fix with clipping and initialization changes.
- **Tooling:** capstone code follows the course's NumPy-first guideline; record any other choice in the decision record.

### U13.14 Capstone D: an LLM application platform (RAG + agents + safety)
mlsrc: none (integration unit; assembles earlier units)
Integration unit (Part H): entered after the domains it closes, which it names; built from your own components first and defended against the acceptance criteria of this domain.
- **Topics:** Closes D36, D38 and D39. A grounded multi-agent support/DevOps assistant: ingestion and chunking, hybrid retrieval with reranking, query routing, planner–executor agents in a state machine with human-in-the-loop, episodic and semantic memory, citations with a verifier, semantic caching, observability, an evaluation harness (retrieval metrics, RAGAS-style faithfulness, LLM-as-judge with debiasing) and a red-team/blue-team report covering prompt injection, indirect injection and leakage.
- **Predict then measure:** recall@k, answer faithfulness, p95 latency and cost per request.
- **Injected failure:** poisoned document in the corpus; detect with provenance checks and contain with least-privilege tools.
- **Cost tag:** live API calls only after recorded-response replay and under a spend cap (Master Rules 11.2).
- **Tooling:** capstone code follows the course's NumPy-first guideline; record any other choice in the decision record.

### U13.15 Capstone E: generative models
mlsrc: none (integration unit; assembles earlier units)
Integration unit (Part H): entered after the domains it closes, which it names; built from your own components first and defended against the acceptance criteria of this domain.
- **Topics:** Closes D37. Small-scale GAN (WGAN-GP), VAE/VQ-VAE and DDPM with classifier-free guidance on the same dataset, compared by sample quality (FID proxy), likelihood bound, sampling cost and failure modes (mode collapse, posterior collapse, sampling slowness).
- **Predict then measure:** ELBO versus bits per dimension; sampling steps versus quality curve.
- **Injected failure:** mode collapse in the GAN; diagnose and apply gradient penalty.
- **Tooling:** capstone code follows the course's NumPy-first guideline; record any other choice in the decision record.

### U13.16 Capstone F: ML systems and efficiency
mlsrc: none (integration unit; assembles earlier units)
Integration unit (Part H): entered after the domains it closes, which it names; built from your own components first and defended against the acceptance criteria of this domain.
- **Topics:** Closes D40. Serve a small Transformer with a KV cache, continuous batching and quantization; load-test with a Poisson arrival process against the M/M/c prediction of U29.8; simulate data-parallel training with ring-allreduce and checkpoint recovery; run a federated-averaging experiment with non-IID clients and one malicious client.
- **Predict then measure:** tokens/s versus batch size, memory per request and queueing delay at 70% utilization.
- **Injected failure:** a worker crash mid-training; recover from checkpoint and quantify lost work.
- **Tooling:** capstone code follows the course's NumPy-first guideline; record any other choice in the decision record.

### U13.17 Final integrated capstone: train, align, compress, serve, evaluate and secure a small language model
mlsrc: none (integration unit; assembles earlier units)
Integration unit (Part H): entered after the domains it closes, which it names; built from your own components first and defended against the acceptance criteria of this domain.
- **Topics:** Closes Part G and assembles parts the learner built in U13.11 to U13.16: pretrain a tiny decoder-only Transformer from scratch (U36.3, U13.13), align it with SFT plus DPO/PPO (U36.8, U34.5), adapt it with LoRA (U36.9), quantize and serve it (U40.3, U40.4), put it behind the RAG-agent platform (U13.14), and evaluate and red-team the full system (U39.1–U39.6). Defended as a professional design review with a decision record for each major choice.
- **Predict then measure:** perplexity versus scaling-law prediction (U36.5); win-rate against the base model; end-to-end latency and cost; attack success rate before and after defenses.
- **Injected failure:** reward hacking in the preference stage or a jailbreak that bypasses the system prompt; detect, patch and re-test.
- **Tooling:** capstone code follows the course's NumPy-first guideline; record any other choice in the decision record.


---

