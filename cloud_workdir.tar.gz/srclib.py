"""Cell table for cloud-computing.txt (13 course outlines)."""
import re
SRC = open('/home/claude/work/cloud2/src.txt').read().split('\n')
GEN = {}   # no second source; kept for compatibility with build.py


def R(a, b=None):
    return list(range(a, (b or a) + 1))


def wk(first_line_by_week):
    return {f'W{k}': v for k, v in first_line_by_week.items()}


COURSES = {}


def course(key, title, who, cells, pre=None, books=None, note=''):
    COURSES[key] = dict(title=title, who=who, cells=cells, pre=pre or [], books=books or [], inline=None, note=note)


course('GCF', 'Google Cloud Computing Foundations', 'Soumya Kanti Ghosh, IIT Kharagpur (NPTEL 106105223); file header says IIT Guwahati',
       {'o': R(21, 24), 'W0': R(8), 'W1': R(9), 'W2': R(10), 'W3': R(11), 'W4': R(12), 'W5': R(13), 'W6': R(14), 'W7': R(15), 'W8': R(16)},
       pre=R(25, 28),
       note='lines 1-28 are repeated verbatim at lines 30-57 (duplicate block); the 26 Qwiklabs labs are mentioned but not listed')
course('CN', 'Computer Networks and Internet Protocol', 'Soumya Kanti Ghosh and Sandip Chakraborty, IIT Kharagpur (NPTEL 106105183)',
       {'o': R(69, 77), **{f'W{i}': R(78 + i) for i in range(1, 13)}})
course('ACN', 'Advanced Computer Networks', 'Neminath Hubballi, IIT Indore and Sameer G. Kulkarni, IIT Gandhinagar',
       {'o': R(105, 109), 'W1': R(111), 'W2': R(112), 'W3': R(113), 'W4': R(114), 'W5': R(115), 'W6': R(116, 117),
        'W7': R(118), 'W8': R(119), 'W9': R(120), 'W10': R(121), 'W11': R(122), 'W12': R(123)},
       pre=R(99, 100))
course('PCS', 'Practical Cyber Security for Cyber Security Practitioners', 'Sandeep K. Shukla, IIT Kanpur',
       {'o': R(135, 146), **{f'W{i}': R(147 + i) for i in range(1, 13)}}, pre=R(130, 131))
course('CSP', 'Cyber Security and Privacy', 'Saji K. Mathew, IIT Madras (NPTEL 106106248)',
       {'o': R(178, 186), **{f'W{i}': R(195 + i) for i in range(1, 13)}}, pre=R(188, 189), books=R(209, 232))
course('EH', 'Ethical Hacking', 'Indranil Sengupta, IIT Kharagpur (NPTEL 106105217)',
       {'o': R(251), **{f'W{i}': R(262 + i) for i in range(1, 13)}}, pre=R(255, 256), books=R(276, 281))
course('CNS', 'Cryptography and Network Security', 'Sourav Mukhopadhyay, IIT Kharagpur',
       {'o': R(290, 299), 'W1': R(301), 'W2': R(302), 'W3': R(303), 'W4': R(304, 305), 'W5': R(306, 307), 'W6': R(308, 309),
        'W7': R(310), 'W8': R(311), 'W9': R(312), 'W10': R(313), 'W11': R(314, 315), 'W12': R(316, 317)})
course('TPMC', 'Theory and Practice of Modern Cryptography', 'Sourav Mukhopadhyay, IIT Kharagpur (NPTEL 106105002)',
       {'o': R(336), **{f'W{i}': R(347 + i) for i in range(1, 13)}}, pre=R(340, 341), books=R(361, 363))
course('FOC', 'Foundations of Cryptography', 'Ashish Choudhury, IIIT Bangalore',
       {'o': R(377, 381), 'W1': R(389), 'W2': R(390), 'W3': R(391, 392), 'W4': R(393, 394), 'W5': R(395), 'W6': R(396, 397),
        'W7': R(398, 399), 'W8': R(400, 401), 'W9': R(402, 403), 'W10': R(404, 405), 'W11': R(406, 407), 'W12': R(408)},
       pre=R(370, 373))
course('ADS', 'Advanced Distributed Systems', 'Smruti Ranjan Sarangi, IIT Delhi (NPTEL 106102237)',
       {'o': R(428), **{f'W{i}': R(439 + i) for i in range(1, 13)}}, pre=R(433), books=R(453))
course('CCDS', 'Cloud Computing and Distributed Systems', 'Rajiv Misra, IIT Patna',
       {'o': R(468, 480), 'W1': R(482, 493), 'W2': R(494, 501), 'W3': R(502, 509), 'W4': R(510, 518),
        'W5': R(519, 526), 'W6': R(527, 532), 'W7': R(533, 534), 'W8': R(535, 541)}, pre=R(460, 464),
       note='source has 8 weeks')
course('DS', 'Distributed Systems', 'Rajiv Misra, IIT Patna (NPTEL 106106168)',
       {'o': R(560), **{f'W{i}': R(571 + i) for i in range(1, 9)}}, pre=R(564, 565))
course('BDC', 'Big Data Computing', 'Rajiv Misra, IIT Patna (NPTEL 106104189)',
       {'o': R(598), **{f'W{i}': R(608 + i) for i in range(1, 9)}}, pre=R(601), books=R(618, 628))


def cell_text(key, cid):
    return '\n'.join(SRC[i - 1] for i in COURSES[key]['cells'][cid])


def cell_ids(key):
    return list(COURSES[key]['cells'].keys())


def all_cells():
    return [(k, c) for k in COURSES for c in cell_ids(k)]


def text_of(k, cid):
    return cell_text(k, cid)


if __name__ == '__main__':
    n = 0
    for k, cid in all_cells():
        t = text_of(k, cid).replace('\n', ' | ')
        n += 1
        print(f"{k}:{cid:4s} {t[:105]}")
    print('cells', n)

# Append this block to the end of srclib.py to join the architecture source (tested).
import srclib_arch as _A
_OFF = len(SRC)                       # 630 (629 lines plus the empty string after the final newline; the shift is consistent)
SRC.extend(_A.SRC)
for _k, _c in _A.COURSES.items():
    _cells = {cid: [i + _OFF for i in ls] for cid, ls in _c['cells'].items()}
    COURSES[_k] = dict(_c, cells=_cells, pre=[i + _OFF for i in _c['pre']],
                       books=[i + _OFF for i in _c['books']], inline=None,
                       file='cloud-computing2.txt', off=_OFF)

# Third source: dbms.txt (3 database-systems outlines), read from the cleaned copy src3.txt.
import srclib_dbms as _B3
_OFF3 = len(SRC)
SRC.extend(_B3.SRC)
for _k, _c in _B3.COURSES.items():
    _cells = {cid: [i + _OFF3 for i in ls] for cid, ls in _c['cells'].items()}
    COURSES[_k] = dict(_c, cells=_cells, pre=[i + _OFF3 for i in _c['pre']],
                       books=[i + _OFF3 for i in _c['books']], inline=None,
                       file='dbms.txt (cleaned copy src3.txt)', off=_OFF3)

import srclib_design as _B4
_OFF4 = len(SRC)
SRC.extend(_B4.SRC)
for _k, _c in _B4.COURSES.items():
    _cells = {cid: [i + _OFF4 for i in ls] for cid, ls in _c['cells'].items()}
    COURSES[_k] = dict(_c, cells=_cells, pre=[], books=[], inline=None,
                       file='src4.txt (generated from the cloned READMEs; see Appendix A)', off=_OFF4)

# Fifth source: data-analytics.txt (eight new outlines; Big Data Computing there duplicates BDC), copied as src5.txt.
import srclib_data as _B5
_OFF5 = len(SRC)
SRC.extend(_B5.SRC)
for _k, _c in _B5.COURSES.items():
    _cells = {cid: [i + _OFF5 for i in ls] for cid, ls in _c['cells'].items()}
    COURSES[_k] = dict(_c, cells=_cells, pre=[i + _OFF5 for i in _c['pre']],
                       books=[i + _OFF5 for i in _c['books']], inline=None,
                       file='data-analytics.txt (copied as src5.txt)', off=_OFF5)
