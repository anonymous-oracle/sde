# PROGRESS: architecture unification (runbook /workspace/sde/cloud_curriculum_unification_runbook.md)

Environment: workspace /workspace/cloud; outputs /workspace/sde/out/ (originals in /workspace/sde untouched).
Merge patch appended to srclib.py (backup srclib_pre_merge.py.bak). Formula checks in verify/v_b*.py.

| Batch | Status | Checks after batch |
|---|---|---|
| B1 U14.1-U14.5 | done | build check: 232 cells, cited 173 (MCA:W2 atoms pending U14.6); chk_assign units 137 bad 0; NAT dump read; verify/v_b1.py all pass |
| B2 U14.6-U14.9 | done | build check: cited 192, no arch MISS; chk_assign units 141 bad 0; NAT dump read; verify/v_b2.py all pass |
| B3 U14.10-U14.13 | done | build check: cited 202, missing 114 (baseline), no arch MISS with -o; chk_assign units 145 bad 0; NAT dump read; verify/v_b3.py all pass (one script expectation corrected: FR-FCFS example 17 -> 9) |
| B4 U14.14-U14.16 | done | build check: cited 217, missing 114 (baseline), no arch MISS with -o; chk_assign units 148 bad 0; NAT dump read; verify/v_b4.py all pass (MSI/MESI model checker 6/11, 8/14 states; litmus enumerator; CDG checker) |
| B5 U14.17-U14.20 | done | build check: cited 230 (MCA:W12 QoS atoms pending U14.21), no other arch MISS with -o; chk_assign units 152 bad 0; NAT dump read; verify/v_b5.py all pass (SIMT, coalescing, systolic simulator, quantiser) |
| B6 U14.21, U14.22, U13.7, section 5 pointers | done | build check: cells cited 232/232, missing 114 (baseline, no architecture MISS); chk_assign units 154 bad 0; verify/v_b6.py all pass (UCP partition, fairness metrics, WRR, CV^2f/DVFS, SECDED (72,64) fault injection, FIT/MTTF, TMR, cache-channel model); pointer edits to U4.1, U9.16, U9.9, U11.8, U11.9, U12.3 appended to Gap-fills (no text moved or deleted) |
| B7 front matter, assembler, index, acceptance | done | front_cloud.md and assemble_cloud.py edited per section 8; build check cited 232/232 uncited 0; chk_assign units 154 bad 0; assemble: units 161 domains 14 with assignments 154; index regenerated (14/161/154/17 bridges/7 capstones/232 cells/19 courses); no dangling U refs; 154 collapsed keys; NAT dump 154 lines read; overlap greps done (U14.9 and U14.16 ownership wording corrected to U3.11/U10.6 and U3.2/U3.3/U3.10); D1-D13 diff = six pointer sentences only |

## D15 (dbms.txt) addition, 2026-11-05
| Batch | Status | Checks |
|---|---|---|
| D1 U15.1-U15.6 | done | verify/v_d1.py, ra.py pass |
| D2 U15.7-U15.13 | done | verify/v_d2.py, dbx.py pass |
| D3-D5 U15.14-U15.23 | done | verify/v_d3-v_d5b.py, bpt.py pass |
| D6 U15.24-U15.27, U13.8 | done | verify/v_d6.py, v_d7.py pass; assign/20_D15e.txt |
| Assembly | done | cells 306, cited 306, uncited 0; chk_assign units 181 bad 0; dangling refs none; 15 domains, 189 units, 181 assignments, 20 bridges, 8 capstones |
Edits: pointers in U10.1 and U9.17; front_cloud.md (counts, standing instruction 10, stage 7, tooling numbering fixed); assemble_cloud.py (ORDER, HANDLED, App A note, E.1, F, D.3 item 9); gen_index.py writes index_cloud.md.

## D16 (design patterns and System Design Primer) addition, 2026-11-06
| Batch | Status | Checks |
|---|---|---|
| Sources | done | cloned primer (ae9bbd7) and python-patterns (a8e4090); `design_src/mk_src4.py` writes `src4.txt` (54 cells: SDP, PYP, GOF) and `table.json`; `srclib_design.py` and a patch in `srclib.py` |
| U16.1-U16.7 (OO bridge, GoF and python-patterns, OO exercises) | done | `units/22_D16a.md`; coverage passes |
| U16.8-U16.13 (estimation, scalability, availability, data tier, caching, asynchronism) | done | `units/23_D16b.md`; `verify/v_e1.py` to `v_e4.py` pass |
| U16.14-U16.16 (worked designs, scaling story, reading lists) | done | `units/24_D16c.md`; `verify/v_e5.py` passes; min-hash figure corrected to 0.795 |
| Assignments A16.1-A16.16 | done | `assign/21_D16a.txt` to `23_D16c.txt`; chk_assign units 197 bad 0; NAT dump read, all 16 recomputed |
| Capstone U13.9 | done | in `units/14_D12_D13.md`; D13 Aim says nine |
| Assembly | done | cells 360, cited 360, uncited 0; no dangling U-references; 16 domains, 206 units, 197 assignments, 21 bridges, 9 capstones, 25 courses |
Edits: pointers added to U2.4, U3.11, U4.8, U6.7, U9.5, U9.13, U9.15, U9.16, U10.6, U11.6, U14.9, U15.20; `front_cloud.md` (counts, standing instruction 11, stage 9, capstones); `assemble_cloud.py` (ORDER with D16 after D12, Part D renamed, Appendix A licence note, D.1, D.3 item 10, E.1 rows, F rows); `gen_index.py`.
