# PROGRESS: architecture unification (runbook /workspace/sde/cloud_curriculum_unification_runbook.md)

Environment: workspace /workspace/cloud; outputs /workspace/sde/out/ (originals in /workspace/sde untouched).
Merge patch appended to srclib.py (backup srclib_pre_merge.py.bak). Formula checks in verify/v_b*.py.

| Batch | Status | Checks after batch |
|---|---|---|
| B1 U14.1-U14.5 | done | build check: 232 cells, cited 173 (MCA:W2 atoms pending U14.6); chk_assign units 137 bad 0; NAT dump read; verify/v_b1.py all pass |
| B2 U14.6-U14.9 | done | build check: cited 192, no arch MISS; chk_assign units 141 bad 0; NAT dump read; verify/v_b2.py all pass |
| B3 U14.10-U14.13 | done | build check: cited 202, missing 114 (baseline), no arch MISS with -o; chk_assign units 145 bad 0; NAT dump read; verify/v_b3.py all pass (one script expectation corrected: FR-FCFS example 17 -> 9) |
| B4 U14.14-U14.16 | done | build check: cited 217, missing 114 (baseline), no arch MISS with -o; chk_assign units 148 bad 0; NAT dump read; verify/v_b4.py all pass (MSI/MESI model checker 6/11, 8/14 states; litmus enumerator; CDG checker) |
| B5 U14.17-U14.20 | done | build check: cited 230 (MCA:W12 QoS atoms pending U14.21), no other arch MISS with -o; chk_assign units 152 bad 0; NAT dump read; verify/v_b5.py all pass (SIMT, coalescing, systolic simulator, quantiser) |
| B6 U14.21, U14.22, U13.7, section 5 pointers | done | build check: cells cited 232/232, missing 114 (baseline, no architecture MISS); chk_assign units 154 bad 0; verify/v_b6.py all pass (UCP partition, fairness metrics, WRR, CV^2f/DVFS, SECDED (72,64) fault injection, FIT/MTTF, TMR, cache-channel model); pointer edits to U4.1, U9.16, U9.9, U11.8, U11.9, U12.3 appended to Gap-fills (no text moved or deleted) |
| B7 front matter, assembler, index, acceptance | done | front_cloud.md and assemble_cloud.py edited per section 8; build check cited 232/232 uncited 0; chk_assign units 154 bad 0; assemble: units 161 domains 14 with assignments 154; index regenerated (14/161/154/17 bridges/7 capstones/232 cells/19 courses); no dangling U refs; 154 collapsed keys; NAT dump 154 lines read; overlap greps done (U14.9 and U14.16 ownership wording corrected to U3.11/U10.6 and U3.2/U3.3/U3.10); D1-D13 diff = six pointer sentences only |

## D15 (dbms.txt) addition, 2026-11-05
| Batch | Status | Checks |
|---|---|---|
| D1 U15.1-U15.6 | done | verify/v_d1.py, ra.py pass |
| D2 U15.7-U15.13 | done | verify/v_d2.py, dbx.py pass |
| D3-D5 U15.14-U15.23 | done | verify/v_d3-v_d5b.py, bpt.py pass |
| D6 U15.24-U15.27, U13.8 | done | verify/v_d6.py, v_d7.py pass; assign/20_D15e.txt |
| Assembly | done | cells 306, cited 306, uncited 0; chk_assign units 181 bad 0; dangling refs none; 15 domains, 189 units, 181 assignments, 20 bridges, 8 capstones |
Edits: pointers in U10.1 and U9.17; front_cloud.md (counts, standing instruction 10, stage 7, tooling numbering fixed); assemble_cloud.py (ORDER, HANDLED, App A note, E.1, F, D.3 item 9); gen_index.py writes index_cloud.md.
