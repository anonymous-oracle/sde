import sys,glob,math,collections,re,json
sys.path.insert(0,'/home/claude/work/cloud2')
import build as B, mlload
cu,_,_=B.load_units(sorted(glob.glob('units/*.md')))
mu,_=mlload.load_ml()
def body(u):
    ls=[l for l in u.lines if l.startswith('- **') and not l.startswith('- **On demand (Part G)') and not l.startswith('- **Go track')]
    return u.title+' '+' '.join(ls)
cl={u.uid:B.toks(body(u)) for u in cu}
ml={u.uid:B.toks(body(u)) for u in mu}
N=len(cl)+len(ml)
df=collections.Counter()
for v in list(cl.values())+list(ml.values()):
    for t in set(v): df[t]+=1
def vec(tk):
    c=collections.Counter(tk); v={t:(1+math.log(n))*math.log(N/df[t]) for t,n in c.items()}
    nr=math.sqrt(sum(x*x for x in v.values())) or 1
    return {t:x/nr for t,x in v.items()}
cv={k:vec(v) for k,v in cl.items()}; mv={k:vec(v) for k,v in ml.items()}
def cos(a,b):
    if len(a)>len(b): a,b=b,a
    return sum(x*b.get(t,0) for t,x in a.items())
res={}
for k,v in mv.items():
    sc=sorted(((cos(v,c),cid) for cid,c in cv.items()),reverse=True)[:3]
    res[k]=[(round(s,3),c) for s,c in sc]
json.dump(res,open('merge_residual.json','w'))
if __name__=='__main__':
    pairs=[(s,k,c) for k,v in res.items() for s,c in v if s>=0.25]
    pairs.sort(reverse=True)
    print(len(pairs))
    T={u.uid:u.title for u in cu}; M={u.uid:u.title for u in mu}
    for s,k,c in pairs: print(f'{s:.2f} {k:7} {M[k][:48]:48} <> {c:7} {T[c][:55]}')
