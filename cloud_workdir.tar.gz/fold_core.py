"""Fold: parse the audited merged document (F space) into parts, domains and units, rearrange them by subject,
and provide the F-to-X identifier map. Text rewriting lives in fold.py."""
import re
# ---- identifier map F -> X
DOM = {24: 21, 25: 21, 26: 24, 27: 24, 28: 18, 29: 19, 30: 19, 31: 24, 32: 25, 33: 26, 34: 27, 35: 28, 36: 29, 37: 30, 38: 31, 39: 32, 40: 33, 41: 17}
OFF = {24: (21, 6), 25: (21, 11), 26: (24, 0), 27: (24, 5), 31: (24, 10), 28: (18, 13), 29: (19, 17), 30: (19, 26), 32: (25, 0),
       33: (26, 0), 34: (27, 0), 35: (28, 0), 36: (29, 0), 37: (30, 0), 38: (31, 0), 39: (32, 0), 40: (33, 0), 41: (17, 17)}
def mapD(d):
    return DOM.get(d, d)
def mapU(d, n):
    if d in OFF:
        x, o = OFF[d]; return x, n + o
    return d, n
PROT = r'S50 D\d+(?:[,–-] ?D\d+)*'
PAT = re.compile(r'(' + PROT + r')|(?<![@\w])([UA])(\d+)\.(\d+)\b|(?<![@\w])D(\d+)\b')
def fx(text):
    def f(m):
        if m.group(1): return m.group(1)
        if m.group(5) is not None:
            return 'D%d' % mapD(int(m.group(5)))
        d, n = mapU(int(m.group(3)), int(m.group(4)))
        return '%s%d.%d' % (m.group(2), d, n)
    t = PAT.sub(f, text)
    return t.replace('@', '') if False else t
def unat(text):
    """remove the '@' marker that protects identifiers already in X space"""
    return re.sub(r'@(?=[UAD]\d)', '', text)
def fid(u):
    d, n = u[1:].split('.'); x, o = mapU(int(d), int(n)); return 'U%d.%d' % (x, o)

# ---- parse F document
def parse(F):
    L = F.split('\n')
    i0 = next(i for i, l in enumerate(L) if l.startswith('# PART A'))
    iA = next(i for i, l in enumerate(L) if l.startswith('# APPENDICES'))
    # the '---' separator before APPENDICES
    sep = iA
    while sep > 0 and L[sep - 1].strip() in ('', '---'): sep -= 1
    front = '\n'.join(L[:i0])
    appx = '\n'.join(L[iA:])
    body = L[i0:sep]
    parts, cur_part, cur_dom, cur_unit = [], None, None, None
    doms = {}
    for l in body:
        if l.startswith('# PART '):
            cur_part = dict(title=l[2:], intro=[], doms=[]); parts.append(cur_part); cur_dom = cur_unit = None
        elif re.match(r'## D\d+\. ', l):
            m = re.match(r'## (D\d+)\. (.*)', l)
            cur_dom = dict(id=m.group(1), title=m.group(2), intro=[], units=[]); cur_part['doms'].append(cur_dom); doms[cur_dom['id']] = cur_dom; cur_unit = None
        elif re.match(r'### U\d+\.\d+ ', l):
            m = re.match(r'### (U\d+\.\d+) (.*)', l)
            cur_unit = dict(id=m.group(1), title=m.group(2), lines=[l]); cur_dom['units'].append(cur_unit)
        elif cur_unit is not None: cur_unit['lines'].append(l)
        elif cur_dom is not None: cur_dom['intro'].append(l)
        elif cur_part is not None: cur_part['intro'].append(l)
    return front, parts, doms, appx

def emit(front, parts, appx):
    out = [front]
    for p in parts:
        out.append('# ' + p['title'] if not p['title'].startswith('#') else p['title'])
        out.extend(p['intro'])
        for d in p['doms']:
            out.append('## %s. %s' % (d['id'], d['title']))
            out.extend(d['intro'])
            for u in d['units']:
                out.extend(u['lines'])
    return '\n'.join(out), appx
