"""Sections of the merged document that come from the machine-learning curriculum (Part G) and the merge record (Appendix H)."""
import os
import re, json, sys, glob, collections
sys.path.insert(0, '/home/claude/work/cloud2'); sys.path.insert(0, '/home/claude/work/ml')
from idmap import remap
import mlsrc, mlload
import build as B

T = open('/home/claude/work/ml/ml_orig.md').read()
def between(a, b=None):
    i = T.index(a); j = T.index(b, i + len(a)) if b else len(T)
    return T[i:j]
def fixkeys(t):
    return re.sub(r'\bDM\b', 'DMK', t)

PART_G_INTRO = """Part G is the earlier machine-learning curriculum (`unified_curriculum.md`: mathematics for machine learning, machine learning, deep learning, large language models, retrieval and agents, evaluation and safety, ML systems, approximation algorithms), merged into this document on 2026-11-06 and renumbered: its domains D0 to D17 are D24 to D41 here, its units keep their number inside the domain (U5.1 is U29.1), its assignments follow (A5.1 is A29.1), and its seven capstones are U13.11 to U13.17 in Part H. Appendix H lists every identifier and what changed.

**How Part G is entered.** This document is primary and Part G is on demand. Nobody reads Part G from its first unit. A cloud unit that needs something from it carries an **On demand (Part G)** line naming the units, and each such Part G unit begins with a **Bridge for:** line naming the cloud units that call on it: take the named unit, then return to the exact point you left. A Part G unit that no cloud unit calls on says so and names the units it builds on; the order inside Part G (the stage table in the default order, below) applies only when you choose to study it for its own sake.

**Five sections.** A. Mathematical foundations: D24 (pre-calculus bridge), D25 (discrete mathematics), D26 and D27 (calculus), D28 (linear algebra), D29 (probability), D30 (statistics), D31 (differential equations, complex analysis, transforms, numerics) and D32 (optimization). B. Machine learning: D33 (classical machine learning, data mining and learning theory) and D34 (bandits and reinforcement learning). C. Deep learning and generative AI: D35 (deep learning), D36 (NLP, the Transformer and large language models) and D37 (deep generative models). D. LLM applications, evaluation and safety: D38 (retrieval-augmented generation and agents) and D39 (evaluation, safety and responsible AI). E. Algorithms and systems: D40 (ML systems, efficiency, distributed and federated learning) and D41 (approximation algorithms and computational complexity).

**One owner per topic.** Where a Part G unit and a cloud unit teach the same ground, the cloud unit owns it: Part G units say which cloud units they share ground with, list the atoms that were removed because the cloud unit already teaches them, and keep only what goes further (the proofs, the abstract setting, the extra cases). The same-subject pairs that remain on purpose, a compact or applied unit in the cloud parts and the full theory in Part G, are declared in Appendix G.2 and Appendix H.5. Every removal is recorded in Appendix H.4."""

def order_table():
    t = between('## Default order', '## Coverage guarantee').strip()
    t = remap(t)
    t = t.replace('## Default order (a plan, not a cage: Master Rules 3.3)', '')
    t = t.replace('| D40; U32.14; D13 |', '| D40; U32.14; U13.11–U13.17 |')
    return t.strip()

def appendix_a_rows():
    rows = []
    for k, c in mlsrc.COURSES.items():
        key = 'DMK' if k == 'DM' else k
        f = 'iit-genai.md' if k == 'GEN' else 'nptel.txt'
        who = '`iit-genai.md`' if k == 'GEN' else c['who']
        title = c['title'].replace('Discrete Mathematics (title not', 'Discrete Mathematics (title not')
        rows.append(f"| {key} | {title} (Part G) | {who} | `{f}` {c['lines']} | {c['n']} |")
    return rows

def natkey(c):
    if c == 'o': return (-1, ())
    m = re.match(r'W(\d+)$', c)
    if m: return (0, (int(m.group(1)),))
    m = re.match(r'^[\d.]+$', c)
    if m: return (1, tuple(int(x) for x in c.split('.') if x))
    return (2, (c,))

def appendix_b(mu):
    by = collections.defaultdict(lambda: collections.defaultdict(list))
    for u in mu:
        for k, c in u.ml_src:
            if u.uid not in by[k][c]: by[k][c].append(u.uid)
    out = []; n = 0
    for k0, c0 in mlsrc.COURSES.items():
        k = 'DMK' if k0 == 'DM' else k0
        cells = by[k]
        assert len(cells) == c0['n'], (k, len(cells), c0['n'])
        parts = []
        for cid in sorted(cells, key=natkey):
            n += 1
            parts.append(f"{cid} → {', '.join(cells[cid])}")
        out.append(f"**{k}** ({c0['title']}): " + '; '.join(parts) + '\n')
    return out, n

def appendix_c_ml():
    c = between('### C.1 Prerequisite claims', '## Appendix D.')
    c = fixkeys(remap(c))
    c = c.replace('### C.1 Prerequisite claims made by the sources (to verify, not trust)', '### C.3 Prerequisite claims made by the Part G sources (to verify, not trust)')
    c = c.replace('### C.2 Prerequisite chain to L0, as concrete topics', '### C.4 Prerequisite chain of Part G down to school level, as concrete topics')
    c = c.replace('**Remedial rule (Master Rules II.3):**', '**Remedial rule (Master Rules II.3), as carried from the merged curriculum:**')
    return c.strip() + '\n'

def appendix_d_ml():
    d = between('### D.1 What was checked, and what it changed', '## Appendix E.')
    d = fixkeys(remap(d))
    d = d.replace('### D.1 What was checked, and what it changed', '### D.4 Part G: what was checked against the listed books and references, and what it changed')
    d = d.replace('### D.2 Gap candidates (not added; need your agreement per Master Rules 7.4)', '### D.5 Part G: gap candidates (not added; need your agreement per Master Rules 7.4)')
    d = d.replace('Listed as a gap candidate in D.2, pending your agreement.', 'Listed as a gap candidate in D.5, pending your agreement.')
    d = d.replace('→ gap candidate E.3.', '→ gap candidate in D.5.')
    d = d.replace('new D12-X', 'new domain after D36').replace('Would sit in', 'Would sit in')
    d = re.sub(r'\| D12 \|\s*$', '| D36 |', d, flags=re.M)
    return d.strip() + '\n'

def appendix_e_ml():
    e = between('### E.1 Anomalies in the sources', '## Appendix F.')
    e = fixkeys(remap(e))
    e = e.replace('### E.1 Anomalies in the sources (kept visible, not silently fixed)', '### E.3 Anomalies in the Part G sources (kept visible, not silently fixed)')
    e = e.replace('Recorded in Appendix C.', 'Recorded in Appendix C.3.').replace('(Appendix F.2)', '(Appendix D.3, item 21)')
    e = e.replace('Prerequisites go to Appendix C;', 'Prerequisites go to Appendix C.3;').replace('Flagged in Appendix F.', 'Flagged in E.5.')
    e = e.replace('### E.2 Atoms the word-level check still flags, reviewed by hand', '### E.4 Part G: atoms the word-level check flagged when Part G was built, reviewed by hand')
    e = e.replace('- **Outline-prose atoms flagged:** 272.', '- **Outline-prose atoms flagged (as reported for the machine-learning curriculum before the merge):** 272.')
    e = e.replace('- **Non-outline atoms flagged:** 52.', '- **Non-outline atoms flagged (before the merge):** 52.')
    f = between('## Appendix F. Notes found inside the source file, and decisions needed', '### F.1 Assignment status')
    f = fixkeys(remap(f))
    f = f.replace('## Appendix F. Notes found inside the source file, and decisions needed', '### E.5 Notes found inside `nptel.txt` (none acted on)')
    f = f.replace('**Unification done.** Authoring missing assignments is a next step (below).', '**Unification done**, and the missing assignments were authored (one per Part G content unit).')
    f = f.replace('They are reported here so you can decide.', 'They are reported here so you can decide (Appendix D.3, item 18).')
    return e.strip() + '\n\n' + f.strip() + '\n'

def front_g_rows():
    return None

COMPACT_FULL = [
 ("Trigonometry, complex numbers, Euler's formula, phasors", "U18.1 and U21.2", "U24.1 to U24.5", "angle sums derived, the law of cosines, De Moivre and the roots of unity proved, Euler's formula, aliasing and the DFT as roots of unity"),
 ("Counting, induction, proof techniques", "U21.4 and U17.1", "U25.1 and U25.2", "formal languages, generating functions and the wider combinatorics"),
 ("Graph theory", "U21.5", "U25.4", "Hall's, König's and the five-colour theorem proved, Kuratowski stated, DSATUR and Held–Karp builds"),
 ("Number theory and groups for cryptography", "U5.2, U5.5 and U5.12", "U25.5 and U25.6", "the abstract algebra behind it: orbit counting, codes over finite fields"),
 ("Single-variable and multivariable calculus for statistics and optimisation", "U19.1 and U21.2", "U26.1 to U27.5", "real analysis, Taylor and power series, Lagrange multipliers, vector calculus, matrix calculus"),
 ("Vectors, inner products, norms, projections, Gram–Schmidt and QR", "U18.2", "U28.4", "abstract inner-product spaces, best approximation, Householder and Givens QR, loss of orthogonality"),
 ("Matrices, rank, null spaces, rank–nullity, linear maps", "U18.3", "U28.1 to U28.3", "vector spaces and bases in the abstract, duality and quotient spaces"),
 ("Eigenvalues, diagonalisation, the spectral theorem", "U18.4", "U28.6 to U28.8", "canonical forms (Jordan and rational), normal operators, positive semi-definite matrices and kernels"),
 ("The singular value decomposition and low-rank approximation", "U18.5", "U28.9", "LU, conditioning, the pseudo-inverse, perturbation of the SVD"),
 ("Least squares, ridge regression and MMSE estimation", "U18.6 and U18.7", "U28.10", "constrained and regularised least squares in full"),
 ("Probability: events, conditioning, Bayes, random variables, standard distributions, limit theorems", "U21.6 and U19.3", "U29.1 to U29.7", "σ-fields and measure-theoretic foundations, transformations and order statistics, the multivariate normal, characteristic functions, Hoeffding and Chernoff proofs"),
 ("Markov chains, queues, stationary distributions, PageRank", "U11.10, U2.1 and U18.13", "U29.8 and U28.11", "Perron–Frobenius, reliability, convergence rates"),
 ("Descriptive statistics, sampling, confidence intervals, tests, regression", "U19.2 to U19.7", "U30.1 to U30.4", "the Neyman–Pearson lemma, estimation theory, multivariate analysis"),
 ("Bayesian inference and MCMC", "U19.14 and U19.15", "U30.5", "conjugacy proofs and posterior asymptotics"),
 ("Optimisation: LP and flows, convexity, duality", "U4.5 and U20.1", "U32.1 to U32.7", "convex analysis, KKT, strong duality, simplex and interior-point methods"),
 ("SGD, first-order methods and distributed optimisation (ADMM)", "U20.7 and U20.8", "U32.8 to U32.17", "convergence rates, acceleration, proximal and adaptive methods, stochastic approximation"),
 ("Machine-learning foundations (the compact bridge)", "U11.8", "U33.1 to U33.4", "the statistical framework, bias–variance proofs, regularisation, estimation"),
 ("Logistic regression, ROC and AUC, evaluation of classifiers", "U19.8 and U19.13", "U33.2 and U33.3", "model selection theory, softmax regression, Newton and IRLS"),
 ("SVM, kernels and the perceptron", "U18.6 and U18.12", "U33.5", "the representer theorem, universal kernels, kernel machines"),
 ("Decision trees and ensembles", "U19.10 and U19.12", "U33.7", "bagging, boosting and random forests in full"),
 ("Clustering, Gaussian mixtures and the EM algorithm", "U18.11 and U19.9", "U33.9", "EM monotonicity proof, model-based and spectral clustering"),
 ("PCA and dimensionality reduction", "U18.4 and U20.5", "U33.8", "feature learning, probabilistic PCA, manifold methods"),
 ("Collaborative filtering and the Netflix problem", "U18.8 and U11.9", "U33.11", "instance-based learning and recommendation in general"),
 ("Data mining", "U19.11 and U19.13", "U33.12", "FP-growth and PrefixSpan only (the rest is owned by the cloud units)"),
 ("Accelerators, quantisation and CNN computation", "U14.20", "U40.1 and U40.4", "pruning and distillation, the dataflow analysis of CNN accelerators"),
 ("NP-completeness and approximation algorithms", "U17.14 and U17.17", "U41.1 to U41.7", "LP rounding, the primal–dual method, SDP rounding, hardness of approximation"),
 ("The DFT and the FFT", "U18.9", "U31.5", "Laplace, Z and Fourier transforms, with the divide-and-conquer recurrence derived"),
]

def appendix_h(mu, ledger, residual, cu, counts):
    CU = {u.uid: u for u in cu}
    M = {u.uid: u for u in mu}
    out = []
    out.append("## Appendix H. Merge record: the machine-learning curriculum merged into this document (2026-11-06)\n")
    out.append("### H.1 What was done\n")
    out.append("- **Direction.** This document is primary. `unified_curriculum.md` (19 domains D0 to D18, 160 units, 153 assignments, 564 source cells) was merged into it completely: no unit, assignment or source cell was dropped. Its identifiers were renumbered (H.2); its text is otherwise carried over, with the cloud references and the \"Bridge for\" and \"Shares ground with\" lines added and the atoms listed in H.4 removed.")
    out.append("- **On demand.** Every cloud unit that needs something from the old curriculum carries an **On demand (Part G)** line (H.3 lists all %d of them, with %d links), and each Part G unit that a cloud unit calls on begins with a **Bridge for:** line naming its callers (%d of the 160 units; the others name the Part G units they build on). Part G is never read as a block." % (counts['demand_units'], counts['demand_links'], counts['callers']))
    out.append("- **Deduplication.** Cloud units are source-cited and are never trimmed, so the cloud unit owns every overlapping topic. In each Part G unit (a) atoms (topics, results, builds) that a cloud unit already states at the same or a stronger proof status were removed and listed (H.4: %d atoms), (b) results where the Part G unit proves more than the cloud unit were kept (H.5: %d candidates kept, with the reason), and (c) one unit that was almost entirely duplicated (U33.12, data mining) was cut down to its increment. Same-subject pairs that remain on purpose are declared in G.2 and H.5. Where the cloud unit is the compact version and the Part G unit the full one, the cloud unit's On demand line points at the full one." % (len(ledger['drops']), len(ledger['kept'])))
    out.append("- **Capstones.** The seven capstones of the old curriculum are U13.11 to U13.17 in D13 (Part H), so all capstones are together. D13 now has 17 units.")
    out.append("- **Collisions resolved.** The old course key DM (Discrete Mathematics, Kanpur) is DMK here because DM is the Data Mining key of D19. All other course keys were unique. The old cell `S50 D1`–`D4` keep their names.")
    _ms = open('/home/claude/work/cloud2/mlcheck_summary.txt').read().strip() if os.path.exists('/home/claude/work/cloud2/mlcheck_summary.txt') else 'not yet run'
    out.append("- **Source files and word-level coverage.** `nptel.txt` and `iit-genai.md` were not at hand when the merge was first assembled, so it was first checked at the level of cells (every cell is cited by a Part G unit: Appendix B) and of atoms (every removed atom has a named cloud owner that contains its words). They were supplied afterwards and the word-level check was run on the assembled document (`mlcheck.py`, the same rule as the cloud check: each source atom must have at least 75 % of its content stems in the units that cite its cell, the words of any removed atom counting through its cloud owner). Result: " + _ms + ". The flagged atoms are generic prose fragments (for example learning-outcome sentences) and misspellings in the sources (liner, Seidal, Grpah, Dula, diinensionality); none names a technical topic that is not taught. About-text atoms (audience, prerequisites, industry support, instructor biography) are not required content and are counted separately. The coverage of the 478 cloud cells is unchanged and was re-run: all cited, same 27 residual flags.\n")
    _vk = open('/home/claude/work/cloud2/verify_keys.out').read().strip() if os.path.exists('/home/claude/work/cloud2/verify_keys.out') else 'not yet run'
    _kf = '; '.join('%s: %s' % (k['unit'], k['why']) for k in ledger.get('key_fixes', []))
    out.append("- **Answer keys: how they were checked.** The 153 Part G assignments carry over unchanged apart from renumbering and the corrections listed below. (1) All 153 Q3 numeric keys were recomputed independently of the printed key (`verify_keys.py` writes its own value from the question text): " + _vk + " (2) All 306 multiple-choice and multiple-select keys (Q1 and Q2) were read one by one against their options. (3) All 153 Q4 derivation outlines were read against their questions. (4) The checkable Q5 predictions (about sixty numeric or countable claims such as iteration counts, convergence ratios, event probabilities, condition numbers, Himmelblau's stationary points, water-filling, OMP success, Runge error) were run with reference code, and the formula-based ones (confidence-interval half-widths, sample sizes, traffic and parameter ratios, call counts) were recomputed by hand. Q5 is a programming task graded on the learner's own code, so its key states what a passing submission shows; it was not run as a whole. Corrections made: " + _kf + ".\n")
    out.append("### H.2 Identifier map: old (machine-learning curriculum) to new\n")
    out.append("Domains: D0→D24, D1→D25, D2→D26, D3→D27, D4→D28, D5→D29, D6→D30, D7→D31, D8→D32, D9→D33, D10→D34, D11→D35, D12→D36, D13→D37, D14→D38, D15→D39, D16→D40, D17→D41, D18→D13 (capstones). Units keep their number inside the domain: U<d>.<n> → U<d+24>.<n> for d ≤ 17, and U18.<n> → U13.<10+n>. Assignments follow the units: A<d>.<n> → A<d+24>.<n>.\n")
    out.append("| Old | New | Title |"); out.append("|---|---|---|")
    for new, info in ledger['units'].items():
        out.append(f"| {info['old']} | {new} | {info['title'][:110].replace('|','/')} |")
    out.append("")
    out.append("### H.3 On-demand map: which cloud unit calls on which Part G units\n")
    out.append("| Cloud unit | Part G units, entered only when needed |"); out.append("|---|---|")
    def key(u):
        a, b = u[1:].split('.'); return (int(a), int(b))
    for c in sorted(ledger['demand'], key=key):
        ms = sorted(ledger['demand'][c], key=key)
        out.append(f"| {c} {B_short(CU[c].title)} | " + '; '.join(f"{m} {B_short(M[m].title)}" for m in ms) + " |")
    out.append("")
    out.append("### H.4 Duplicates removed from Part G units, with the cloud owner that already teaches each\n")
    out.append("| Part G unit | Field | Removed atom | Cloud owner and field |"); out.append("|---|---|---|---|")
    for e in sorted(ledger['drops'], key=lambda e: (key(e['ml_new']) if not e['ml_new'].startswith('U13.') else (99, 0), e['field'])):
        atom = remap(e['atom']).replace('|', '/')
        out.append(f"| {e['ml_new']} | {e['field']} | {atom[:100]} | {e['owner']} {e['owner_field']} |")
    out.append("")
    out.append("### H.5 Overlaps kept on purpose\n")
    out.append("**Candidates that matched a cloud atom but were kept.** Results that the Part G unit proves more fully than the cloud unit (stronger proof status) and a few matches that were spurious or that point from the full treatment to a compact bridge:\n")
    out.append("| Part G unit | Field | Atom kept | Cloud unit | Reason |"); out.append("|---|---|---|---|---|")
    for e in ledger['kept']:
        out.append(f"| {e['ml_new']} | {e['field']} | {remap(e['atom'])[:90].replace('|','/')} | {e['owner']} | {e['why']} |")
    out.append("")
    out.append("**Same-subject unit pairs that remain** (cosine similarity of the unit texts after trimming, 0.25 or more; the cloud unit is the compact or applied version, the Part G unit the fuller treatment, entered on demand):\n")
    out.append("| Part G unit | Cloud unit | Similarity |"); out.append("|---|---|---|")
    pairs = sorted(((s, k, c) for k, v in residual.items() for s, c in v if s >= 0.25), reverse=True)
    for s, k, c in pairs:
        out.append(f"| {k} {B_short(M[k].title)} | {c} {B_short(CU[c].title)} | {s:.2f} |")
    out.append("")
    out.append("### H.6 Audit\n")
    out.append("The audit of this merge is delivered as `merge_audit_report.md` (counts, identifier and reference checks, coverage, the dedupe ledger re-verified against the owners, the assignments, stale-wording scans, and the limitations). Result of the last run: %s\n" % counts['audit_line'])
    return out

def B_short(t, n=70):
    t = t.replace('Bridge: ', '')
    t = re.split(r':| — ', t)[0]
    if len(t) > n:
        t = t[:n].rsplit(',', 1)[0] if ',' in t[:n] else t[:n].rsplit(' ', 1)[0]
    return t.strip()

def appendix_g2():
    out = ["### G.2 Compact versus full treatment: pairs of units that teach the same subject at two depths\n",
           "These pairs remain on purpose. The cloud unit is the compact or applied version, inside its own domain, and is where to start; the Part G unit is the full treatment, entered on demand from the cloud unit's On demand line. Atoms that both would state identically were removed from the Part G unit (Appendix H.4); the right-hand column says what the full unit adds.\n",
           "| Concept | Compact (cloud) | Full (Part G, on demand) | What the full unit adds |", "|---|---|---|---|"]
    for a, b, c, d in COMPACT_FULL:
        out.append(f"| {a} | {b} | {c} | {d} |")
    out.append("")
    return out
