import glob, math, sys
import numpy as np
import build as B

def load():
    units, domains, _ = B.load_units(sorted(glob.glob('/home/claude/work/cloud/units/*.md')))
    U = {u.uid: u for u in units}
    items, cur = {}, None
    for f in sorted(glob.glob('/home/claude/work/cloud/assign/*.txt')):
        for ln in open(f).read().split('\n'):
            if not ln.strip():
                continue
            if ln.startswith('## '):
                cur = ln[3:].strip(); items[cur] = {}; continue
            kind, _, rest = ln.partition('|')
            items[cur][kind.strip()] = [p.strip() for p in rest.split('|')]
    out = {}
    for uid, it in items.items():
        assert len(it) == 5 and uid in U, uid
        q, k = [], []
        aid = 'A' + uid[1:]
        q.append(f"**Assignment {aid}** (10 marks; pass at 7/10 with Q4 and Q5 accepted)\n")
        t, a, b, c, d, ans, why = it['MCQ']
        q.append(f"**Q1 (1 mark, multiple choice).** {t}\n\n(A) {a}  \n(B) {b}  \n(C) {c}  \n(D) {d}\n")
        k.append(f"- **Q1:** {ans}. {why}")
        t, a, b, c, d, ans, why = it['MSQ']
        q.append(f"**Q2 (2 marks, multiple select; all correct options and no wrong option).** {t}\n\n(A) {a}  \n(B) {b}  \n(C) {c}  \n(D) {d}\n")
        k.append(f"- **Q2:** {ans}. {why}")
        t, expr, tol, unit, why = it['NAT']
        val = eval(expr, {'np': np, 'math': math})
        if isinstance(val, (int, np.integer)) or abs(val - round(val)) < 1e-9:
            vs = str(int(round(val)))
        else:
            vs = f'{val:.4g}'
        un = f' ({unit})' if unit and unit != '-' else ''
        q.append(f"**Q3 (2 marks, numerical answer{un}).** {t}\n")
        k.append(f"- **Q3:** {vs}{' ' + unit if unit != '-' else ''} (tolerance ±{tol}). {why}")
        t, outline = it['PRF']
        q.append(f"**Q4 (2 marks, prove or derive; every step with its reason).** {t}\n")
        k.append(f"- **Q4 (marking outline):** {outline}")
        t, expect = it['COD']
        q.append(f"**Q5 (3 marks, programming).** {t}\n")
        k.append(f"- **Q5 (what a passing submission shows):** {expect}")
        block = '\n'.join(q) + f"\n<details><summary>Key for {aid} (open only after your attempt)</summary>\n\n" + '\n'.join(k) + "\n\n</details>\n"
        out[uid] = block
    return out
