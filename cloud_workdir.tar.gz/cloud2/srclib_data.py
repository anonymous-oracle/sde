"""Cell table for data-analytics.txt (nine NPTEL outlines; Big Data Computing is an exact duplicate of BDC and gets no cells).
Cell Wn is the course-plan line for week n; 'o' is the course description and audience; 'pre' the prerequisite lines."""
SRC = open('/home/claude/work/cloud2/src5.txt').read().split('\n')
def R(a, b=None): return list(range(a, (b or a) + 1))
COURSES = {}
def course(key, title, who, cells, pre=None, books=None, note=''):
    COURSES[key] = dict(title=title, who=who, cells=cells, pre=pre or [], books=books or [], note=note)
course('DAP', 'Data Analytics with Python', 'A. Ramesh, Department of Management Studies, IIT Roorkee',
       {'o': R(6, 14), **{f'W{i}': R(15 + i) for i in range(1, 13)}}, pre=R(5))
course('AGDS', 'Algorithmic Graph Theory and Data Structures', 'Sourav Mukhopadhyay, Department of Mathematics, IIT Kharagpur',
       {'o': R(36, 48), **{f'W{i}': R(49 + i) for i in range(1, 13)}}, pre=R(34, 35))
course('SDS', 'Scalable Data Science', 'Anirban Dasgupta, IIT Gandhinagar, and Sourangshu Bhattacharya, IIT Kharagpur (NPTEL 106105186)',
       {'o': [80, 82, 86], **{f'W{i}': R(91 + i) for i in range(1, 9)}}, pre=[84], books=R(101, 104))
course('DBMS', 'Data Base Management System', 'Partha Pratim Das and Samiran Chattopadhyay, IIT Kharagpur (NPTEL 106105175)',
       {'o': [123, 125, 128], **{f'W{i}': R(132 + i) for i in range(1, 9)}}, pre=[128], books=[143, 146],
       note='the prerequisite and industry lines are one line in the source')
course('BDA', 'Bayesian Data Analysis for the Behavioral Sciences', 'Himanshu Yadav, Department of Cognitive Science, IIT Kanpur',
       {'o': R(207, 214), **{f'W{i}': R(222 + i) for i in range(1, 13)}}, pre=R(203, 206))
course('ALA', 'Applied Linear Algebra for Signal Processing, Data Analytics and Machine Learning', 'Aditya K. Jagannatham, IIT Kanpur (NPTEL 108104174)',
       {'o': R(252, 259) + [262, 264], **{f'W{i}': R(268 + i) for i in range(1, 13)}}, books=R(282, 283),
       note='week 9 repeats the second half of the week 8 line')
course('DM', 'Data Mining (title inferred; the source gives only the instructor)', 'Pabitra Mitra, IIT Kharagpur',
       {'o': R(289, 298), **{f'W{i}': R(299 + i) for i in range(1, 9)}})
course('DSAD', 'Data Structures and Algorithms Design', 'Nitin Saxena, IIT Kanpur (NPTEL 106104697)',
       {'o': [326, 327, 328, 331, 335], **{f'W{i}': R(339 + i) for i in range(1, 13)}}, pre=[333], books=R(353, 355))
