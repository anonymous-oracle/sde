import glob,sys
want={'MCQ':7,'MSQ':7,'NAT':5,'PRF':2,'COD':2}
bad=0; cur=None; seen={}
for f in sorted(glob.glob('/home/claude/work/cloud2/assign/*.txt')):
    for n,ln in enumerate(open(f).read().split('\n'),1):
        if not ln.strip(): continue
        if ln.startswith('## '):
            cur=ln[3:].strip(); seen[cur]=[]; continue
        k,_,rest=ln.partition('|'); parts=rest.split('|')
        seen[cur].append(k)
        if k not in want or len(parts)!=want[k]:
            print(f'{f.split("/")[-1]}:{n} {cur} {k} has {len(parts)} fields (want {want.get(k)})'); bad+=1
        if k in('MCQ','MSQ'):
            ans=parts[5].strip()
            if k=='MCQ' and ans not in 'ABCD': print(cur,'MCQ ans',ans); bad+=1
for u,ks in seen.items():
    if sorted(ks)!=sorted(want): print(u,'kinds',ks); bad+=1
print('units',len(seen),'bad',bad)
