import re, srclib_arch as S
exec(open('plan_arch.py').read().split("cov = {}")[0])
cov={}
for u,t,k,src,*_ in P:
    for part in filter(None, src.split(';')):
        key, cs = part.split(':')
        for c in cs.split(','):
            c = 'W'+c.lstrip('W') if c != 'o' else c
            cov.setdefault((key, c), []).append(u)
o=[]
o.append("# Ingestion note 2: computer-architecture source (`cloud-computing2.txt`), for the unified cloud curriculum\n")
o.append("**Status:** ingested and analysed on 2026-11-04 (UTC); **not yet authored into units**. This note holds everything needed to resume: the cell table, the overlap analysis, the planned domain D14 with its units, source cells and assignment focus, the open decisions and the anomalies. The unified file `unified_cloud_curriculum.md` is unchanged (13 domains, 138 units, 132 assignments).\n")
o.append("**Source:** `cloud-computing2.txt`, 247 lines, **6 NPTEL course outlines, all on computer architecture** (the file name says cloud computing; the content is not). 78 cells (6 outlines and 72 weeks), every one mapped to at least one planned unit (checked by script).\n")
o.append("## 1. Source course index\n")
o.append("| Key | Course | Instructor / institution (course id) | Source lines | Cells |\n|---|---|---|---|---|")
for k,c in S.COURSES.items():
    allr=[x for v in c['cells'].values() for x in v]
    o.append(f"| {k} | {c['title']} | {c['who']} | {min(allr)}–{max(allr)} | {len(c['cells'])} |")
o.append("\nThe keys do not clash with the 13 existing keys (ACA is Advanced Computer Architecture and ADS stays Advanced Distributed Systems).\n")
o.append("## 2. What the six courses cover, and how they overlap\n")
o.append("- **Three layers of the same subject.** Introductory (CA, CAO): number systems, assembly, arithmetic, datapath and control, pipelining, caches, virtual memory, I/O. Advanced (MCA, ACA, PCA): out-of-order cores and speculation, cache design and coherence, memory models and synchronisation, DRAM, on-chip networks, power and reliability. Accelerators (GPU, plus MCA weeks 5 and 12): SIMT, CUDA, OpenCL, neural-network kernels.")
o.append("- **Heaviest overlaps (merge into one unit each, every week cited):** pipelining and hazards (MCA 2–3, CAO 11, CA 9–10, ACA 1–3, GPU 1); caches (MCA 6–7, CAO 5–6, CA 11, ACA 7, PCA 3); cache coherence (MCA 8, ACA 10, PCA 4–9); memory consistency (ACA 9, PCA 10, MCA 8); on-chip networks (MCA 10–12, ACA 8, PCA 12); ISA and assembly (MCA 1, CAO 2, CA 4–5); GPU architecture (MCA 5, GPU 2, 5).")
o.append("- **Already partly in the unified file** (the new units extend or link, not repeat): U4.1 (operating systems and architecture bridge, with the TLB and effective-access-time formula), U3.3 (switch fabrics), U3.10 (fat trees and Clos), U9.9 and U9.16 (distributed shared memory and consistency), U10.6 (cache hit ratio under Zipf), U11.1 (Amdahl and Gustafson), U6.9 and U5.20 (hardware and side-channel security), U3.6 (QoS), U12.3 (machine learning on the cloud).")
o.append("- **Where it belongs.** Appending as **D14** (Part F) keeps every existing identifier stable. Read it after U4.1; the on-chip-network unit reuses U2.7 and U3.3, the coherence and consistency units pair with U9.16, and the GPU units pair with U11.9 and U12.3. If you prefer it beside compute, the same units can move into Part A at the next merge.\n")
o.append("## 3. Cell table (line ranges in `cloud-computing2.txt`)\n")
o.append("| Cell | Lines | Text (first words) | Planned unit(s) |\n|---|---|---|---|")
for k,c in S.COURSES.items():
    for cid,ls in c['cells'].items():
        txt=S.cell_text(k,cid).replace('|','/')[:70]
        rng=f"{ls[0]}" if len(ls)==1 else f"{ls[0]}–{ls[-1]}"
        o.append(f"| {k}:{cid} | {rng} | {txt} | {', '.join(cov[(k,cid)])} |")
o.append("\n## 4. Planned domain D14: Computer architecture and parallel hardware\n")
o.append("**Aim:** from the gate and the instruction to the multicore chip, the memory system, the on-chip network, the GPU and the accelerator, with every mechanism built as a simulator in Python and checked against hand calculation or a library. Benchmarks (recalled, not checked), taken from the sources' own lists: Hennessy and Patterson, *Computer Architecture: A Quantitative Approach* (5th ed.) and *Computer Organization and Design*; Jacob, Ng and Wang, *Memory Systems*; Dally and Towles, *Principles and Practices of Interconnection Networks*; Stallings; Hamacher, Vranesic and Zaky; Hayes; Sarangi, *Computer Organisation and Architecture*.\n")
o.append("**Assignments:** every unit below except the capstone will carry the same five-question NPTEL-style assignment as the existing 132 (MCQ, multiple select, numerical computed by script, prove or derive, programming; 10 marks; pass at 7/10; key collapsed), numbered A14.1 to A14.22. The assignment focus for each unit is fixed in the table so the authoring can start directly.\n")
o.append("| Unit | Title | Type | Source cells | Links | Assignment focus (A14.n) | Build (all [local] unless stated) |\n|---|---|---|---|---|---|---|")
for u,t,k,src,links,focus,build in P:
    o.append(f"| {u} | {t} | {k} | {src or 'none (assembles earlier units)'} | {links} | {focus} | {build} |")
nb=sum(1 for p in P if p[2]=='bridge'); nu=sum(1 for p in P if p[2]!='capstone')
o.append(f"\nTotals: {len(P)} units ({nb} bridge, {len(P)-nb-1} content, 1 capstone) and {nu} assignments planned. After authoring the corpus becomes 14 domains, {138+len(P)} units and {132+nu} assignments.\n")
o.append("Just-in-time bridges: U14.1 (binary and logic) before the first unit; probability for predictors and performance reuses U2.1; graph facts for topologies reuse U2.7; partial orders for memory models reuse U9.1. No further bridge is expected.\n")
o.append("## 5. Safety, tooling and cost\n")
o.append("- All builds are simulators in Python (the default toolbox), so **[local]** throughout. CUDA and OpenCL units run through Numba's CUDA simulator or PyOpenCL on a CPU device; a real GPU is optional and tagged **[credit]**, with a budget alert and the teardown written first.")
o.append("- Hardware security in U14.22 is defensive: cache side channels and fault models appear as simulations only, never against real hardware or any system you do not own (Master Rules 11). No exploit code.")
o.append("- The sources list C or C++ as a prerequisite; the builds use Python, and CUDA units use Python bindings (inferred, as for the earlier DS source).\n")
o.append("## 6. Anomalies in the source (kept visible)\n")
o.append("| Where | Issue | Handling |\n|---|---|---|")
for a,b,c in [
 ("File name","`cloud-computing2.txt` holds computer-architecture courses, not cloud courses","Treated as the architecture extension of the cloud curriculum; confirm the placement in section 7."),
 ("MCA:W5","Week 5 mentions GPU architectures; the GPU course also covers them","Merged in U14.17 with both cited."),
 ("CAO:W11","Titled 'Instruction Set Pipelining'; instruction pipelining is meant","Taught in U14.6; the source wording is quoted."),
 ("PCA:W6, W7","'muliprocessor' typo","Meaning taken from context."),
 ("PCA outline","'networkon-chip', 'specically' (typos) and an instructor biography at lines 190–201 that is not course content","Biography not cited as content; typos read from context."),
 ("CAO books","'Morgan Koffman' for Morgan Kaufmann","Spelled correctly in the unit; source spelling noted."),
 ("ACA prerequisites","Lists Python, Java and generic data-structures NPTEL courses as prerequisites","Recorded in the prerequisite map; Python is the build language here."),
 ("GPU:W11, W12","Same title twice ('contd.')","One unit, both weeks cited."),
]: o.append(f"| {a} | {b} | {c} |")
o.append("")
o.append("## 7. Decisions I need from you\n")
o.append("1. **Placement:** append as D14 (recommended, keeps IDs stable), or move beside Part A at the next merge.")
o.append("2. **Scope of the GPU units:** simulator-only (recommended, no spend), or include optional real-GPU labs on credit.")
o.append("3. **Assembly language:** MIPS-like, RISC-V-like or a custom small ISA for U14.2 and the simulators (the sources use a generic RISC; the IIT Kharagpur course says a popular RISC platform without naming it).")
o.append("4. **Authoring:** unit files, the 22 assignments with scripted numerical keys, and the final coverage check are the remaining work; they were deferred because of your usage limit.\n")
o.append("## 8. Weekly assignments: how the cadence works\n")
o.append("NPTEL sets one assignment per week. Here each unit carries one assignment, and a unit spans one to several source weeks, so every source week is covered by at least one assignment: Appendix B of the unified file maps each source week to its units, and each unit ends with its assignment. For this source, section 3 above gives the same map in advance (cell to unit; assignment A14.n for unit U14.n). If you want a strict one-assignment-per-week layout for any course, say which and it can be generated from the cell table without changing the units.\n")
open('cloud_ingest_2_architecture.md','w').write('\n'.join(o)+'\n')
print(len('\n'.join(o)))
