# checks behind the pattern and OO-design units (U16.1 to U16.7)
import copy, itertools, random, collections, functools
random.seed(5)
# Singleton vs Borg: identity vs shared state
class Borg:
    _s = {}
    def __init__(self): self.__dict__ = self._s
a, b = Borg(), Borg(); a.x = 1
print('borg: different objects', a is not b, 'shared state', b.x == 1)
# Flyweight: n glyph occurrences share k distinct intrinsic states
class Glyph:
    _pool = {}
    def __new__(cls, ch):
        return cls._pool.setdefault(ch, super().__new__(cls))
text = random.choices('abcdefghij', k=10000)
objs = [Glyph(c) for c in text]
print('flyweight: 10000 occurrences use', len({id(o) for o in objs}), 'objects')
# Decorator order matters
def bold(f): return lambda: '<b>' + f() + '</b>'
def upper(f): return lambda: f().upper()
base = lambda: 'hi'
print('decorator order:', bold(upper(base))(), upper(bold(base))())
# Chain of responsibility: first handler that accepts
def chain(handlers, x):
    for h in handlers:
        r = h(x)
        if r is not None: return r
print('chain:', chain([lambda x: 'small' if x < 10 else None, lambda x: 'medium' if x < 100 else None, lambda x: 'large'], 55))
# Visitor double dispatch: count of (visitor, element) method bodies
class Circle:
    def accept(self, v): return v.visit_circle(self)
class Square:
    def accept(self, v): return v.visit_square(self)
class AreaV:
    def visit_circle(self, c): return 'circle area'
    def visit_square(self, s): return 'square area'
print('visitor:', [e.accept(AreaV()) for e in (Circle(), Square())])
# Memento: undo stack restores states exactly
class Editor:
    def __init__(s): s.text = ''; s._h = []
    def type(s, t): s._h.append(s.text); s.text += t
    def undo(s): s.text = s._h.pop()
e = Editor(); [e.type(t) for t in ('ab', 'cd', 'ef')]; e.undo(); e.undo(); print('memento:', e.text)
# State pattern: traffic light cycle returns to start after 3 steps
S = {'green': 'yellow', 'yellow': 'red', 'red': 'green'}
s0 = 'green'; s = s0
for _ in range(3): s = S[s]
print('state cycle:', s == s0)
# Specification: combine with boolean logic
class Spec:
    def __init__(s, f): s.f = f
    def __call__(s, x): return s.f(x)
    def __and__(s, o): return Spec(lambda x: s(x) and o(x))
    def __or__(s, o): return Spec(lambda x: s(x) or o(x))
    def __invert__(s): return Spec(lambda x: not s(x))
even, big = Spec(lambda n: n % 2 == 0), Spec(lambda n: n > 5)
print('spec:', [n for n in range(10) if (even & ~big)(n)])
# Observer: notified exactly once per subscriber per change
class Subject:
    def __init__(s): s.obs = []; s.v = 0
    def set(s, v):
        s.v = v
        for o in s.obs: o(v)
log = []; sub = Subject(); sub.obs += [lambda v: log.append(('a', v)), lambda v: log.append(('b', v))]; sub.set(3); sub.set(4)
print('observer notifications:', len(log))
# Pool: bounded instances reused
class Pool:
    def __init__(s, n): s.free = [object() for _ in range(n)]; s.made = n
    def get(s): return s.free.pop()
    def put(s, o): s.free.append(o)
p = Pool(2); seen = set()
for _ in range(50):
    o = p.get(); seen.add(id(o)); p.put(o)
print('pool: distinct objects over 50 uses', len(seen))
# Prototype: clone is a deep copy independent of the original
proto = {'cfg': [1, 2]}; c = copy.deepcopy(proto); c['cfg'].append(3); print('prototype independent:', proto['cfg'] == [1, 2])
# Composite: total size of a tree
tree = ('dir', [('file', 3), ('dir', [('file', 4), ('file', 5)])])
def size(n): return n[1] if n[0] == 'file' else sum(size(c) for c in n[1])
print('composite size:', size(tree))
# Proxy lazy load: loaded once
calls = []
class LazyProxy:
    def __init__(s): s._r = None
    def get(s):
        if s._r is None: calls.append(1); s._r = 'big'
        return s._r
lp = LazyProxy(); [lp.get() for _ in range(5)]; print('proxy loads:', len(calls))
# OOD: LRU cache with dict + doubly linked list vs OrderedDict, random ops
class Node:
    def __init__(s, k, v): s.k, s.v, s.p, s.n = k, v, None, None
class LRU:
    def __init__(s, cap):
        s.cap = cap; s.m = {}; s.h = Node(0, 0); s.t = Node(0, 0); s.h.n = s.t; s.t.p = s.h
    def _rm(s, x): x.p.n, x.n.p = x.n, x.p
    def _front(s, x): x.n, x.p = s.h.n, s.h; s.h.n.p = x; s.h.n = x
    def get(s, k):
        if k not in s.m: return None
        x = s.m[k]; s._rm(x); s._front(x); return x.v
    def put(s, k, v):
        if k in s.m: s._rm(s.m[k])
        elif len(s.m) == s.cap: y = s.t.p; s._rm(y); del s.m[y.k]
        s.m[k] = x = Node(k, v); s._front(x)
ref = collections.OrderedDict(); L = LRU(5); ok = True
for _ in range(20000):
    k = random.randint(0, 11)
    if random.random() < .5:
        g = L.get(k); r = ref.get(k)
        if k in ref: ref.move_to_end(k)
        ok &= g == r
    else:
        L.put(k, k * 7)
        if k in ref: ref.move_to_end(k)
        ref[k] = k * 7
        if len(ref) > 5: ref.popitem(last=False)
print('LRU matches OrderedDict:', ok)
# OOD: hash map with chaining vs dict
class HM:
    def __init__(s, n=16): s.b = [[] for _ in range(n)]
    def set(s, k, v):
        row = s.b[hash(k) % len(s.b)]
        for i, (kk, _) in enumerate(row):
            if kk == k: row[i] = (k, v); return
        row.append((k, v))
    def get(s, k):
        for kk, v in s.b[hash(k) % len(s.b)]:
            if kk == k: return v
    def rem(s, k):
        row = s.b[hash(k) % len(s.b)]; s.b[hash(k) % len(s.b)] = [x for x in row if x[0] != k]
h = HM(); d = {}; ok = True
for _ in range(20000):
    k = random.randint(0, 200); op = random.random()
    if op < .4: h.set(k, op); d[k] = op
    elif op < .6: h.rem(k); d.pop(k, None)
    else: ok &= h.get(k) == d.get(k)
print('hash map matches dict:', ok)
# OOD: blackjack hand value (soft aces)
def bj(cards):
    t = sum(10 if c in 'JQK' else (1 if c == 'A' else int(c)) for c in cards)
    return t + 10 if 'A' in cards and t + 10 <= 21 else t
print('blackjack: A,A,9 =', bj(['A', 'A', '9']), ' A,K =', bj(['A', 'K']), ' A,5,K =', bj(['A', '5', 'K']), ' deck size', len(list(itertools.product('A23456789TJQK', 'SHDC'))))
# OOD: parking lot: assignment by size (motorcycle->any, car->compact/large, bus->5 consecutive large)
spots = ['M'] * 2 + ['C'] * 3 + ['L'] * 6
fits = {'moto': {'M', 'C', 'L'}, 'car': {'C', 'L'}, 'bus': {'L'}}
print('parking: spots', len(spots), 'a bus needs 5 consecutive large spots; with 6 large spots there are', 6 - 5 + 1, 'start positions')
# OOD: call center: escalation operator -> supervisor -> director
def route(free):
    for r in ('operator', 'supervisor', 'director'):
        if free[r] > 0: free[r] -= 1; return r
free = {'operator': 2, 'supervisor': 1, 'director': 1}; print('call center order:', [route(free) for _ in range(5)])
# Circular array rotate: index arithmetic
n = 5; arr = list(range(n)); k = 7; print('circular rotate by 7 of 5:', [arr[(i - k) % n] for i in range(n)])
