class Rect:
    def __init__(s, w, h): s.w, s.h = w, h
    def set_w(s, w): s.w = w
    def set_h(s, h): s.h = h
    def area(s): return s.w * s.h
class Square(Rect):
    def set_w(s, w): s.w = s.h = w
    def set_h(s, h): s.w = s.h = h
def test(r): r.set_w(3); r.set_h(4); return r.area()
print('Rect', test(Rect(1, 1)), 'Square', test(Square(1, 1)))
print('2^5 inheritance combos', 2**5, 'composition', 5)
print('abstract factory: 3 themes x 4 widgets =', 3 * 4, 'products from 3 factories')
n = 10; print('mediator links', n * (n - 1) // 2, 'vs', n)
m, k = 4, 5; print('bridge', m + k, 'vs', m * k)
