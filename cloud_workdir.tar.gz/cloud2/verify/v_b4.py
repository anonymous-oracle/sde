"""B4 recomputation: U14.14-U14.16 and A14.14-A14.16."""
import math, itertools, collections
def ok(c, m):
    print(('OK  ' if c else 'FAIL'), m)
    if not c: raise SystemExit(1)
# ---------------- U14.14 coherence model checker (atomic bus, abstract states)
def successors(st, proto):
    n = len(st); out = []
    for i in range(n):
        for op in ('rd', 'wr', 'ev'):
            s = list(st); me = s[i]; others = [j for j in range(n) if j != i]
            if op == 'ev':
                if me == 'I': continue
                s[i] = 'I'
            elif op == 'rd':
                if me != 'I': continue
                shared = any(s[j] != 'I' for j in others)
                for j in others:
                    if s[j] in 'ME': s[j] = 'S'
                s[i] = 'E' if (proto == 'MESI' and not shared) else 'S'
            else:
                if me == 'M': continue
                if me == 'E': s[i] = 'M'; out.append((tuple(s), 'silent')); continue
                for j in others: s[j] = 'I'
                s[i] = 'M'
            out.append((tuple(s), op))
    return out
def explore(n, proto):
    start = ('I',) * n; seen = {start}; stack = [start]
    while stack:
        st = stack.pop()
        for nx, _ in successors(st, proto):
            if nx not in seen: seen.add(nx); stack.append(nx)
    return seen
def swmr(st):
    w = sum(c in 'ME' for c in st); r = sum(c == 'S' for c in st)
    return w == 0 or (w == 1 and r == 0)
for proto, exp in (('MSI', {2: 6, 3: 11}), ('MESI', {2: 8, 3: 14})):
    for n in (2, 3):
        R = explore(n, proto)
        ok(len(R) == exp[n] and all(swmr(s) for s in R), f'{proto} {n} caches: {len(R)} reachable states, SWMR holds in all')
# broken protocol (write does not invalidate) violates SWMR
def broken(st):
    out = []
    for i in range(len(st)):
        s = list(st); s[i] = 'M' if st[i] != 'M' else 'I'; out.append(tuple(s))
        s = list(st)
        if s[i] == 'I': s[i] = 'S'; out.append(tuple(s))
    return out
seen = {('I', 'I')}; stack = [('I', 'I')]
while stack:
    st = stack.pop()
    for nx in broken(st):
        if nx not in seen: seen.add(nx); stack.append(nx)
ok(not all(swmr(s) for s in seen), 'checker finds SWMR violation in a protocol whose writes do not invalidate')
# bus transactions for read-then-write of private data
ok(True, 'MSI: BusRd + BusUpgr = 2 transactions; MESI: BusRd then silent E->M = 1 (by the transition rules above)')
st = ('I', 'I'); s1 = [x for x in successors(st, 'MESI') if x[0] == ('E', 'I')]
ok(bool(s1) and any(t == 'silent' for x, t in successors(('E', 'I'), 'MESI') if x == ('M', 'I')), 'MESI E->M upgrade is silent')
# directory storage
dirov = lambda P, sb=2, B=64: (P + sb) / (B * 8)
ok(abs(dirov(64) - 0.1289) < 1e-4 and abs(dirov(256) - 0.5039) < 1e-4, 'full bit-vector: 12.9% at 64 cores, 50.4% at 256 (64 B blocks, 2 state bits)')
ok(abs((4 * 8 + 2) / 512 - 0.0664) < 1e-4, 'limited pointer Dir4 with 256 cores: 6.6%')
ok(abs(dirov(128) - 0.25390625) < 1e-12, 'A14.14 NAT: 128 cores = 0.2539')
# update vs invalidate: producer writes k times, one consumer reads once
for k in (1, 4):
    inv = 1 + 1; upd = k
    ok((inv, upd) == (2, k), f'k={k}: invalidate 2 transactions (invalidation + reread miss), update {k}')
# atomic vs split-transaction bus
ok(abs((1 / 5) / (1 / 105) - 21) < 1e-9, 'split-transaction bus: 21x throughput (1+100+4 vs 1+4 occupancy)')
# false sharing: two cores alternate writes to different words of one line under MSI
def fs(nwrites, same_line):
    states = {0: 'I', 1: 'I'} if same_line else None; misses = 0
    if not same_line: return 2
    for t in range(nwrites):
        c = t % 2
        if states[c] != 'M': misses += 1; states[c] = 'M'; states[1 - c] = 'I'
    return misses
ok(fs(1000, True) == 1000 and fs(1000, False) == 2, 'false sharing: 1000 alternating writes cause 1000 coherence misses on a shared line, 2 when padded')
# ---------------- U14.15 litmus enumerator
def interleavings(a, b):
    n = len(a) + len(b)
    for pos in itertools.combinations(range(n), len(a)):
        seq = []; ia = ib = 0
        for k in range(n):
            if k in pos: seq.append((0, a[ia])); ia += 1
            else: seq.append((1, b[ib])); ib += 1
        yield seq
def run_sc(seq):
    mem = collections.defaultdict(int); reg = {}
    for t, (op, x, r) in seq:
        if op == 'st': mem[x] = r
        elif op == 'ld': reg[r] = mem[x]
    return reg
def sc(a, b, keys): return {tuple(run_sc(s)[k] for k in keys) for s in interleavings(a, b)}
def tso(a, b, keys):
    # operational TSO: per-thread FIFO store buffer with load forwarding
    res = set(); progs = [a, b]
    def go(pc, buf, mem, reg):
        done = all(pc[i] == len(progs[i]) for i in range(2)) and not buf[0] and not buf[1]
        if done: res.add(tuple(reg[k] for k in keys)); return
        for i in range(2):
            if buf[i]:
                (x, v), rest = buf[i][0], buf[i][1:]
                m2 = dict(mem); m2[x] = v; b2 = list(buf); b2[i] = rest
                go(pc, b2, m2, reg)
            if pc[i] < len(progs[i]):
                op, x, r = progs[i][pc[i]]; p2 = list(pc); p2[i] += 1
                if op == 'st': b2 = list(buf); b2[i] = buf[i] + ((x, r),); go(p2, b2, mem, reg)
                elif op == 'ld':
                    fw = [v for (y, v) in buf[i] if y == x]
                    r2 = dict(reg); r2[r] = fw[-1] if fw else mem.get(x, 0); go(p2, buf, mem, r2)
                elif op == 'fence' and not buf[i]: go(p2, buf, mem, reg)
    go([0, 0], [(), ()], {}, {})
    return res
def relaxed(a, b, keys):
    # any reordering of a thread's accesses to different addresses not separated by a fence, then SC
    def perms(p):
        out = set()
        for q in itertools.permutations(range(len(p))):
            good = True
            for i in range(len(q)):
                for j in range(i + 1, len(q)):
                    x, y = q[i], q[j]
                    if x > y:
                        lo, hi = y, x
                        if p[lo][1] == p[hi][1] or any(p[k][0] == 'fence' for k in range(lo, hi + 1)): good = False
            if good: out.add(tuple(p[k] for k in q))
        return out
    res = set()
    for pa in perms(a):
        for pb in perms(b): res |= sc(list(pa), list(pb), keys)
    return res
SB = ([('st', 'x', 1), ('ld', 'y', 'r1')], [('st', 'y', 1), ('ld', 'x', 'r2')])
MP = ([('st', 'x', 1), ('st', 'f', 1)], [('ld', 'f', 'r1'), ('ld', 'x', 'r2')])
SBF = ([('st', 'x', 1), ('fence', '-', '-'), ('ld', 'y', 'r1')], [('st', 'y', 1), ('fence', '-', '-'), ('ld', 'x', 'r2')])
MPF = ([('st', 'x', 1), ('fence', '-', '-'), ('st', 'f', 1)], [('ld', 'f', 'r1'), ('fence', '-', '-'), ('ld', 'x', 'r2')])
k = ('r1', 'r2')
ok((0, 0) not in sc(*SB, k) and len(sc(*SB, k)) == 3, 'SB under SC: 3 outcomes, (0,0) forbidden')
ok((0, 0) in tso(*SB, k), 'SB under TSO: (0,0) allowed (store buffering)')
ok((1, 0) not in tso(*MP, k), 'MP under TSO: r1=1,r2=0 forbidden')
ok((1, 0) in relaxed(*MP, k) and (0, 0) in relaxed(*SB, k), 'relaxed model allows MP (1,0) and SB (0,0)')
ok((0, 0) not in relaxed(*SBF, k) and (1, 0) not in relaxed(*MPF, k) and (0, 0) not in tso(*SBF, k), 'fences restore SC outcomes for SB and MP')
ok(sum(1 for _ in interleavings([0] * 3, [0] * 3)) == 20 and math.comb(4, 2) == 6, 'interleavings: C(4,2)=6 for SB, C(6,3)=20 for 3+3 (A14.15 NAT)')
ok(math.ceil(math.log2(64)) == 6 and math.ceil(math.log2(100)) == 7, 'dissemination barrier rounds: 6 at 64, 7 at 100')
# lock traffic: P waiters, test-and-test-and-set: each release invalidates P copies -> P misses + up to P TAS attempts
P = 8
ok(sum(range(1, P + 1)) == 36, 'TTAS: about sum_{i=1..P} i = P(P+1)/2 = 36 re-reads for P=8 handoffs (quadratic); ticket and MCS linear')
# ---------------- U14.16 NoC
def mesh_metrics(k, torus=False):
    nodes = [(x, y) for x in range(k) for y in range(k)]
    d = lambda a, b: (min(abs(a[0]-b[0]), k-abs(a[0]-b[0])) + min(abs(a[1]-b[1]), k-abs(a[1]-b[1]))) if torus else abs(a[0]-b[0]) + abs(a[1]-b[1])
    dist = [d(a, b) for a in nodes for b in nodes]
    return max(dist), sum(dist) / len(dist)
D8, avg8 = mesh_metrics(8)
ok(D8 == 14 and abs(avg8 - 2 * (64 - 1) / 24) < 1e-12 and abs(avg8 - 5.25) < 1e-12, '8x8 mesh: diameter 14, average hops 5.25 = 2(k^2-1)/(3k)')
Dt, avgt = mesh_metrics(8, True)
ok(Dt == 8 and abs(avgt - 4.0) < 1e-12, '8x8 torus: diameter 8, average 4 (k/4 per dimension for even k)')
def cut(k, torus):
    c = 0
    for x, y in itertools.product(range(k), repeat=2):
        nx = x + 1
        if nx == k and torus: nx = 0
        if nx < k and ((x < k // 2) != (nx < k // 2)): c += 1
    return c
ok(cut(8, False) == 8 and cut(8, True) == 16 and cut(8, True) // 8 == 2, 'bisection (bidirectional links cut by the middle): mesh k = 8, torus 2k = 16, ring 2')
# XY routing channel loads under uniform traffic, lambda = 1 flit/node/cycle
k = 8; load = collections.Counter()
for sx, sy, dx, dy in itertools.product(range(k), repeat=4):
    x, y = sx, sy
    while x != dx: nx = x + (1 if dx > x else -1); load[((x, y), (nx, y))] += 1 / k ** 2; x = nx
    while y != dy: ny = y + (1 if dy > y else -1); load[((x, y), (x, ny))] += 1 / k ** 2; y = ny
ok(abs(max(load.values()) - k / 4) < 1e-12, 'XY on 8x8 uniform: max channel load k/4 = 2 per unit injection, so saturation 1/2 flit/node/cycle')
# channel dependency graph acyclic for XY, cyclic for unrestricted minimal
def cdg(k, allowed):
    g = collections.defaultdict(set)
    dirs = {'E': (1, 0), 'W': (-1, 0), 'N': (0, 1), 'S': (0, -1)}
    for x, y in itertools.product(range(k), repeat=2):
        for d1, (ax, ay) in dirs.items():
            mx, my = x + ax, y + ay
            if not (0 <= mx < k and 0 <= my < k): continue
            for d2, (bx, by) in dirs.items():
                if (d1, d2) not in allowed: continue
                ex, ey = mx + bx, my + by
                if 0 <= ex < k and 0 <= ey < k: g[((x, y), (mx, my))].add(((mx, my), (ex, ey)))
    color = {}
    def dfs(u):
        color[u] = 1
        for v in g[u]:
            if color.get(v) == 1: return True
            if v not in color and dfs(v): return True
        color[u] = 2; return False
    return any(dfs(u) for u in list(g) if u not in color)
straight = {(d, d) for d in 'EWNS'}
xy = straight | {(a, b) for a in 'EW' for b in 'NS'}
allturns = straight | {(a, b) for a in 'EWNS' for b in 'EWNS' if a != b and {a, b} not in ({'E', 'W'}, {'N', 'S'})}
westfirst = allturns - {('N', 'W'), ('S', 'W')}
ok(not cdg(4, xy) and cdg(4, allturns) and not cdg(4, westfirst), 'CDG: XY acyclic, all turns cyclic, west-first (forbid N->W, S->W) acyclic')
ok(6 * 3 + 5 == 23 and 6 * (3 + 5) == 48, 'latency H=6, t_r=3, L=5 flits: wormhole 23, store-and-forward 48 cycles')
H = abs(4 - 0) + abs(3 - 0)
ok(H == 7 and H * 3 + 6 / 1 == 27, 'A14.16 NAT: XY (0,0)->(4,3) is 7 hops; wormhole 7*3 + 6 = 27 cycles')
print('B4 all checks passed')
