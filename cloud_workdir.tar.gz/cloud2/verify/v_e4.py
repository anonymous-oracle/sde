import random, math, collections, heapq
random.seed(21)
# stale replica reads: Poisson writes rate w, replication lag L, reads see stale if a write happened in the last L
w, L = 0.5, 0.2; N = 200000; t = 0; wr = []
while t < 20000: t += random.expovariate(w); wr.append(t)
import bisect
st = 0
for _ in range(N):
    x = random.uniform(10, 19990); i = bisect.bisect(wr, x) - 1
    st += i >= 0 and x - wr[i] < L
print('stale fraction sim %.4f formula %.4f' % (st / N, 1 - math.exp(-w * L)))
# fail-over downtime
print('failover: detect 3 missed 1 s beats + 5 s hot switch =', 3 * 1 + 5, 's; 4 failures/yr', 4 * 8, 's; cold standby 5 min x 4 =', 20, 'min; four-nines budget 52.6 min')
# M/M/1 wait in system sim: lag of a single-thread applier at rho
def mm1(rho, mu=1.0, n=200000):
    lam = rho * mu; t = 0; free = 0; tot = 0
    for _ in range(n):
        t += random.expovariate(lam); start = max(t, free); free = start + random.expovariate(mu); tot += free - t
    return tot / n
for rho in (.9, .3): print('M/M/1 mean time in system rho', rho, 'sim %.2f formula %.2f (units of 1/mu)' % (mm1(rho), 1 / (1 - rho)))
print('mean wait in queue ratio 0.9 vs 0.3: ', (.9 / (1 - .9)) / (.3 / (1 - .3)))
# hot shard under Zipf load: hash users to S shards, load of user i ~ 1/i
for S in (4, 16):
    U = 100000; load = [0.0] * S
    for i in range(1, U + 1): load[hash(('u', i)) % S] += 1 / i
    print('shards', S, 'max/mean load (Zipf 1.0, hash by user)', round(max(load) / (sum(load) / S), 3))
# the single hottest user vs a shard's fair share
print('hottest user share of total load:', round(1 / sum(1 / i for i in range(1, 100001)), 4), 'vs fair share per shard of 16:', round(1 / 16, 4))
# pull CDN origin load: each of E edges refetches an object every TTL when popular
for E, ttl in ((100, 60), (100, 3600)): print('edges', E, 'ttl', ttl, 's: origin fetches per hour per popular object <=', E * 3600 // ttl)
# servers needed
print('servers:', math.ceil(40000 / (500 * .7)))
# LB availability
print('2 servers 99%% parallel: %.4f; behind one LB 99.99%%: %.8f' % (1 - .01 ** 2, (1 - .01 ** 2) * .9999))
# connection pool via Little
print('pool size = 2000 req/s x 5 ms =', 2000 * 0.005)
# AMAT
tc, td = .5, 5.0
for h in (.9, .5, .99): print('hit', h, 'cache-aside mean ms %.3f' % (h * tc + (1 - h) * (tc + td + tc)), ' read-through-like (2 trips on miss) %.3f' % (h * tc + (1 - h) * (tc + td)))
# at-least-once delivery with duplicates; idempotent consumer
msgs = list(range(1000)); delivered = []
for m in msgs:
    delivered.append(m)
    if random.random() < .05: delivered.append(m)
seen = set(); applied = []
for m in delivered:
    if m not in seen: seen.add(m); applied.append(m)
print('deliveries', len(delivered), 'after dedupe', len(applied), 'exactly once effect', applied == msgs)
# TTL sensitivity: expected staleness after an update with TTL T and reads uniformly after the cached copy was loaded at a random time
for T in (10, 60, 600): print('ttl', T, 's: mean staleness window of a cached copy after an update ~', T / 2, 's')
# token bucket cap: rate limiter allows burst b and rate r: max requests in window t = b + r t
b, r, tt = 10, 5, 4; print('token bucket max requests in', tt, 's:', b + r * tt)
