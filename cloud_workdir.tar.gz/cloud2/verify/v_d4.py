import math, random, itertools, heapq, collections, sqlite3
random.seed(11)
# 1. disk
rpm = 7200; rot = 0.5 * 60 / rpm * 1000; print('avg rot latency ms', round(rot, 3))
print('random 8KB read ms', round(9 + rot + 8 / (150 * 1024) * 1000, 3), 'sequential 8KB ms', round(8 / (150 * 1024) * 1000, 4))
# 2. external merge sort passes by simulation (page counts)
def ems(N, M):
    runs = math.ceil(N / M); io = 2 * N; passes = 1
    while runs > 1: runs = math.ceil(runs / (M - 1)); io += 2 * N; passes += 1
    return passes, io
print('ems N=10000 M=100', ems(10000, 100), 'formula', 1 + math.ceil(math.log(math.ceil(10000 / 100), 99)))
# replacement selection run length ~ 2M
def rs_runs(n, M):
    data = [random.random() for _ in range(n)]; heap = data[:M]; heapq.heapify(heap); nxt = M; frozen = []; runs = []; cur = 0; last = -1
    while heap:
        x = heapq.heappop(heap); cur += 1; last = x
        if nxt < n:
            y = data[nxt]; nxt += 1
            if y >= last: heapq.heappush(heap, y)
            else: frozen.append(y)
        if not heap:
            runs.append(cur); cur = 0; heap = frozen; heapq.heapify(heap); frozen = []
    return runs
r = rs_runs(200000, 1000); print('replacement selection avg run / M', round(sum(r[:-1]) / len(r[:-1]) / 1000, 3))
# 3. MRU vs LRU, cyclic scan over b+1 blocks with b buffers
def sim(policy, b, nblocks, rounds):
    buf = []; hits = 0; tot = 0
    for _ in range(rounds):
        for blk in range(nblocks):
            tot += 1
            if blk in buf:
                hits += 1; buf.remove(blk); buf.append(blk)
            else:
                if len(buf) == b: buf.pop(0 if policy == 'LRU' else -1)
                buf.append(blk)
    return hits / tot
print('cyclic scan hit rate LRU', sim('LRU', 10, 11, 20), 'MRU', round(sim('MRU', 10, 11, 20), 3))
# 4. extensible hashing buckets
class EH:
    def __init__(s, b): s.b = b; s.gd = 1; s.dir = [{'ld': 1, 'k': []}, {'ld': 1, 'k': []}]
    def ins(s, key):
        h = hash(key) & 0xFFFFFFFF; h = (h * 2654435761) & 0xFFFFFFFF
        while True:
            bk = s.dir[h & ((1 << s.gd) - 1)]
            if len(bk['k']) < s.b: bk['k'].append(key); return
            if bk['ld'] == s.gd: s.dir = s.dir + s.dir; s.gd += 1
            bk['ld'] += 1; new = {'ld': bk['ld'], 'k': []}; old = bk['k']; bk['k'] = []
            for i in range(len(s.dir)):
                if s.dir[i] is bk and (i >> (bk['ld'] - 1)) & 1: s.dir[i] = new
            for k in old: s.dir[((k * 2654435761) & 0xFFFFFFFF) & ((1 << s.gd) - 1)]['k'].append(k)
for b in (4, 8, 16):
    e = EH(b); n = 40000
    for k in range(n): e.ins(random.getrandbits(60))
    nb = len({id(x) for x in e.dir}); print('EH b', b, 'buckets', nb, 'n/(b ln2)', round(n / (b * math.log(2))), 'ratio', round(nb / (n / (b * math.log(2))), 3), 'dir', len(e.dir), 'gd', e.gd)
    assert all(bk['ld'] <= e.gd for bk in e.dir)
# 5. B+-tree heights
def hmin(n, m): return math.ceil(math.log(n + 1, m))
def hmax(n, m): return 1 + math.floor(math.log((n + 1) / 2, math.ceil(m / 2)))
print('B+ n=1e6 m=100 hmin', hmin(10 ** 6, 100), 'hmax', hmax(10 ** 6, 100), ' n=1e9 m=200', hmin(10 ** 9, 200), hmax(10 ** 9, 200))
# 6. multilevel index
recs = 1_000_000; bfr = 10; b1 = recs // bfr; fo = 100; lv = 0; blocks = b1
while blocks > 1: blocks = math.ceil(blocks / fo); lv += 1
print('data blocks', b1, 'index levels', lv, 'accesses', lv + 1)
# 7. join costs
br, bs, M = 100, 400, 22
bnl_r = br + math.ceil(br / (M - 2)) * bs; bnl_s = bs + math.ceil(bs / (M - 2)) * br; hj = 3 * (br + bs)
print('BNL r outer', bnl_r, 's outer', bnl_s, 'hash', hj, 'hash min M', math.ceil(math.sqrt(1.2 * br)) + 1)
print('NLJ tuple-level n_r=10000, b_s=400', 10000 * 400 + 100)
# 8. join order counts
def bushy(n): return math.factorial(2 * n - 2) // math.factorial(n - 1)
print('left-deep 4,5:', math.factorial(4), math.factorial(5), 'bushy 4,5:', bushy(4), bushy(5))
def count_trees(rels):
    if len(rels) == 1: return 1
    tot = 0
    rels = list(rels); n = len(rels)
    for k in range(1, n):
        for L in itertools.combinations(rels, k):
            R = [x for x in rels if x not in L]; tot += count_trees(L) * count_trees(R)
    return tot  # ordered pairs: counts commutative variants
print('enumerated ordered bushy trees n=4,5:', count_trees(range(4)), count_trees(range(5)))
# 9. Selinger DP vs brute force (cost = sum of intermediate result sizes, left-deep)
def instance(n):
    card = [random.randint(10, 1000) for _ in range(n)]; sel = {}
    for i, j in itertools.combinations(range(n), 2): sel[(i, j)] = random.choice([1, 0.5, 0.1, 0.01, 0.001])
    return card, sel
def size(S, card, sel):
    s = 1.0
    for i in S: s *= card[i]
    for i, j in itertools.combinations(sorted(S), 2): s *= sel[(i, j)]
    return s
def brute(n, card, sel):
    best = 1e300
    for p in itertools.permutations(range(n)):
        c = sum(size(p[:k], card, sel) for k in range(2, n + 1)); best = min(best, c)
    return best
def dp(n, card, sel):
    best = {frozenset([i]): 0.0 for i in range(n)}
    for k in range(2, n + 1):
        for S in itertools.combinations(range(n), k):
            S = frozenset(S); best[S] = min(best[S - {i}] + size(S, card, sel) for i in S)
    return best[frozenset(range(n))]
for t in range(60):
    n = random.randint(3, 6); card, sel = instance(n); assert abs(brute(n, card, sel) - dp(n, card, sel)) < 1e-6 * max(1, brute(n, card, sel))
print('Selinger DP = brute force on 60 random instances')
print('join size estimate', 10000 * 5000 / max(100, 500))
# 10. independence assumption error (correlated attributes)
c = sqlite3.connect(':memory:'); c.execute('create table T(a,b)')
c.executemany('insert into T values(?,?)', [(i % 10, i % 10) for i in range(10000)])
true = c.execute('select count(*) from T where a=3 and b=3').fetchone()[0]; est = 10000 * (1 / 10) * (1 / 10)
print('true', true, 'estimated under independence', est)
