import numpy as np, math
rng=np.random.default_rng(11)
def perc(X,y,maxit=10000):
    w=np.zeros(X.shape[1]);mist=0
    for ep in range(maxit):
        ch=False
        for xi,yi in zip(X,y):
            if yi*(w@xi)<=0: w+=yi*xi;mist+=1;ch=True
        if not ch: break
    return w,mist
X=rng.normal(size=(2000,2)); wt=np.array([1.,-1.]); sc=X@wt/np.linalg.norm(wt); keep=np.abs(sc)>0.5; X=X[keep][:300]; y=np.sign(X@wt)
Xa=np.hstack([X,np.ones((len(X),1))])
wt3=np.array([1.,-1.,0.]); gam=np.min(np.abs(Xa@wt3))/np.linalg.norm(wt3); R=np.max(np.linalg.norm(Xa,axis=1))
w,m=perc(Xa,y); print('n',len(X),'gamma',gam,'R',R,'bound',(R/gam)**2,'mistakes',m)
# inventory (s,S)=(2,5), demand 0..4 pmf
dem=np.array([.1,.2,.4,.2,.1]); S=5;s=2;n=S+1; P=np.zeros((n,n))
for st in range(n):
    start=S if st<=s else st
    for d,pd in enumerate(dem): P[st,max(start-d,0)]+=pd
w,V=np.linalg.eig(P.T); i=np.argmin(abs(w-1)); pi=np.real(V[:,i]);pi/=pi.sum()
lost=sum(pi[st]*sum(pd*max(d-(S if st<=s else st),0) for d,pd in enumerate(dem)) for st in range(n))
orders=pi[:s+1].sum(); mean_inv=sum(pi[st]*(S if st<=s else st) for st in range(n))
print('pi',np.round(pi,4),'order prob',orders,'lost',lost,'mean start inv',mean_inv)
# simulate
st=S;cnt=0;T=400000;ord_=0;lostsim=0
for t in range(T):
    start=S if st<=s else st
    if st<=s: ord_+=1
    d=rng.choice(5,p=dem); lostsim+=max(d-start,0); st=max(start-d,0)
print('sim order',ord_/T,'lost',lostsim/T)
