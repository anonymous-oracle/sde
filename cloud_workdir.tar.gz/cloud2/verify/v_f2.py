import numpy as np, math, itertools
from scipy import linalg, optimize
rng=np.random.default_rng(7)
def say(*a): print(*a)
# U18.2 vectors: Gram-Schmidt, CS, correlation=cosine
A=rng.normal(size=(8,4)); Q,R=np.linalg.qr(A)
say('QR err',np.abs(Q@R-A).max(),'orth',np.abs(Q.T@Q-np.eye(4)).max())
def mgs(A):
    Q=np.zeros_like(A);R=np.zeros((A.shape[1],)*2)
    for j in range(A.shape[1]):
        v=A[:,j].copy()
        for i in range(j):
            R[i,j]=Q[:,i]@v; v-=R[i,j]*Q[:,i]
        R[j,j]=np.linalg.norm(v); Q[:,j]=v/R[j,j]
    return Q,R
Q2,R2=mgs(A); say('MGS err',np.abs(Q2@R2-A).max())
x=rng.normal(size=50);y=0.6*x+rng.normal(size=50)
xc,yc=x-x.mean(),y-y.mean()
say('corr vs cos',np.corrcoef(x,y)[0,1],xc@yc/np.linalg.norm(xc)/np.linalg.norm(yc))
bad=0
for _ in range(10000):
    u,v=rng.normal(size=5),rng.normal(size=5)
    if abs(u@v)>np.linalg.norm(u)*np.linalg.norm(v)+1e-12: bad+=1
say('CS violations',bad)
# complex: Euler, roots of unity sum
N=8; w=np.exp(2j*np.pi/N); say('roots sum',abs(sum(w**k for k in range(N))))
say('e^{i pi}+1',abs(np.exp(1j*np.pi)+1))
# U18.3 graphs/circuits
n=6; edges=[(0,1),(1,2),(2,0),(3,4),(4,5)]  # 2 components
B=np.zeros((len(edges),n))
for k,(a,b) in enumerate(edges): B[k,a]=-1;B[k,b]=1
L=B.T@B; say('rank incidence',np.linalg.matrix_rank(B),'nullity L',n-np.linalg.matrix_rank(L))
Adj=np.zeros((n,n))
for a,b in edges: Adj[a,b]=Adj[b,a]=1
# walks count
def walks(Adj,k,i,j):
    cnt=0
    for path in itertools.product(range(len(Adj)),repeat=k-1):
        p=(i,)+path+(j,)
        if all(Adj[p[t],p[t+1]] for t in range(k)): cnt+=1
    return cnt
say('walks A^3',np.linalg.matrix_power(Adj,3)[0,1],walks(Adj,3,0,1),'tri count',np.trace(np.linalg.matrix_power(Adj,3))/6)
# circuit: 3 resistor ladder
G=np.array([[1/1+1/2,-1/2],[-1/2,1/2+1/3]]); i_=np.array([1.0,0.0]); v=np.linalg.solve(G,i_); say('node volts',v)
# matrix-tree: spanning trees of K4 = 16
K4=np.ones((4,4))-np.eye(4); L4=np.diag(K4.sum(1))-K4; say('K4 spanning trees',round(np.linalg.det(L4[1:,1:])))
# traffic flow
T=np.array([[1,1,0,0],[0,-1,1,0],[0,0,-1,1],[-1,0,0,-1]],float)  # conservation
say('traffic rank',np.linalg.matrix_rank(T),'nullity',4-np.linalg.matrix_rank(T))
# U18.4 eigen/PCA
X=rng.normal(size=(500,5))@rng.normal(size=(5,5)); Xc=X-X.mean(0); S=Xc.T@Xc/(len(X)-1)
ev,V=np.linalg.eigh(S); ev=ev[::-1];V=V[:,::-1]
say('trace',np.trace(S),ev.sum(),'det',np.linalg.det(S),np.prod(ev))
k=2;P=V[:,:k]@V[:,:k].T; err=np.sum((Xc-Xc@P)**2)/(len(X)-1); say('PCA err',err,ev[k:].sum())
w=rng.normal(size=5);w/=np.linalg.norm(w); say('Rayleigh<=top',w@S@w<=ev[0]+1e-12)
# eigenfaces synthetic: 40 images 16x16 rank-5 +noise
base=rng.normal(size=(5,256)); coef=rng.normal(size=(200,5)); F=coef@base+0.1*rng.normal(size=(200,256))
Fc=F-F.mean(0); U,s,Vt=np.linalg.svd(Fc,full_matrices=False)
ev2=s**2/(len(F)-1); say('eigenface var top5',ev2[:5].sum()/ev2.sum(), 'sixth/first',ev2[5]/ev2[0])
# U18.5 SVD
M=rng.normal(size=(6,4)); U,s,Vt=np.linalg.svd(M)
for k in range(1,4):
    Mk=(U[:,:k]*s[:k])@Vt[:k]; say('EY k',k,np.linalg.norm(M-Mk,2),s[k],np.linalg.norm(M-Mk,'fro'),math.sqrt((s[k:]**2).sum()))
say('pinv',np.abs(np.linalg.pinv(M)-(Vt.T/s)@U[:,:4].T).max())
# compression: 512x512 rank-k storage
m=n_=512; for_k=[10,50]; say('storage',[k*(m+n_+1) for k in for_k],m*n_, [k*(m+n_+1)/(m*n_) for k in for_k])
# MIMO
Nt,Nr=4,4; H=(rng.normal(size=(Nr,Nt))+1j*rng.normal(size=(Nr,Nt)))/math.sqrt(2)
U,s,Vh=np.linalg.svd(H)
x=rng.normal(size=Nt)+1j*rng.normal(size=Nt); y=H@Vh.conj().T@x
say('diag',np.abs(U.conj().T@y-s*x).max())
# water-filling
def wf(g,P):  # g=gain sigma^2/N0
    g=np.sort(g)[::-1]
    for m in range(len(g),0,-1):
        mu=(P+sum(1/g[:m]))/m
        p=mu-1/g[:m]
        if (p>=0).all(): return np.concatenate([p,np.zeros(len(g)-m)]),g
g=s**2; p,gs=wf(g,10.0); C_wf=np.sum(np.log2(1+p*gs)); C_eq=np.sum(np.log2(1+10/len(g)*gs))
res=optimize.minimize(lambda q:-np.sum(np.log2(1+np.abs(q)*gs)),np.full(4,2.5),constraints={'type':'eq','fun':lambda q:q.sum()-10},bounds=[(0,None)]*4)
say('sv^2',gs,'p',p,'C_wf',C_wf,'C_eq',C_eq,'opt',-res.fun)
say('beamform gain',s[0]**2, np.linalg.norm(H@Vh.conj().T[:,0])**2)
# MUSIC
Nant=8; thetas=[20,50]; d=0.5
def steer(t): return np.exp(1j*2*np.pi*d*np.arange(Nant)*np.sin(np.deg2rad(t)))
Ssig=rng.normal(size=(2,2000))+1j*rng.normal(size=(2,2000))
Am=np.stack([steer(t) for t in thetas],1); Y=Am@Ssig+0.1*(rng.normal(size=(Nant,2000))+1j*rng.normal(size=(Nant,2000)))
Rm=Y@Y.conj().T/2000; w_,Ev=np.linalg.eigh(Rm); En=Ev[:,:Nant-2]
grid=np.arange(-90,90.01,0.1); Pm=np.array([1/np.linalg.norm(En.conj().T@steer(t))**2 for t in grid])
pk=[i for i in range(1,len(grid)-1) if Pm[i]>Pm[i-1] and Pm[i]>Pm[i+1]]; pk=sorted(pk,key=lambda i:-Pm[i])[:2]
say('MUSIC peaks',sorted(grid[pk]))
# U18.6 least squares
A=rng.normal(size=(30,4)); b=A@np.array([1,-2,0.5,3])+0.1*rng.normal(size=30)
xl=np.linalg.lstsq(A,b,rcond=None)[0]; xn=np.linalg.solve(A.T@A,A.T@b); r=b-A@xl
say('LS normal',np.abs(xl-xn).max(),'resid orth',np.abs(A.T@r).max())
U,s,Vt=np.linalg.svd(A,full_matrices=False); lam=1.0
xr=np.linalg.solve(A.T@A+lam*np.eye(4),A.T@b); xr2=Vt.T@((s/(s**2+lam))*(U.T@b)); say('ridge',np.abs(xr-xr2).max(),'norms',np.linalg.norm(xl),np.linalg.norm(xr))
# channel estimation FIR
h=np.array([0.8,0.5,-0.3]); tr=rng.choice([-1,1],size=64); Tm=linalg.toeplitz(tr[2:],tr[2::-1][:3]) if False else np.array([[tr[i-j] for j in range(3)] for i in range(2,64)])
yv=Tm@h+0.05*rng.normal(size=62); hh=np.linalg.lstsq(Tm,yv,rcond=None)[0]; say('sysid',hh,np.linalg.norm(hh-h))
# SVM
from sklearn.svm import SVC
Xs=np.vstack([rng.normal(size=(40,2))+[2.5,2.5],rng.normal(size=(40,2))-[2.5,2.5]]); ys=np.array([1]*40+[-1]*40)
sv=SVC(kernel='linear',C=1e6).fit(Xs,ys); w=sv.coef_[0]; say('margin 2/|w|',2/np.linalg.norm(w),'svs',len(sv.support_))
f=sv.decision_function(Xs)*ys; say('min functional margin',f.min())
# XOR kernel
Xx=rng.normal(size=(200,2)); yx=np.sign(Xx[:,0]*Xx[:,1]); lin=SVC(kernel='linear').fit(Xx,yx).score(Xx,yx); rbf=SVC(kernel='rbf',gamma=1.0,C=10).fit(Xx,yx).score(Xx,yx); poly=SVC(kernel='poly',degree=2,coef0=1,C=10).fit(Xx,yx).score(Xx,yx)
say('xor lin/rbf/poly',lin,rbf,poly)
# dual: kernel poly deg 2 equals feature map inner product
a_=rng.normal(size=2);b_=rng.normal(size=2); phi=lambda v:np.array([1,math.sqrt(2)*v[0],math.sqrt(2)*v[1],v[0]**2,math.sqrt(2)*v[0]*v[1],v[1]**2])
say('poly kernel',(1+a_@b_)**2,phi(a_)@phi(b_))
# U18.7 LMMSE
n=4;Sxx=np.eye(n); Hc=rng.normal(size=(6,n)); sig2=0.5
Syy=Hc@Sxx@Hc.T+sig2*np.eye(6); Sxy=Sxx@Hc.T
Wm=Sxy@np.linalg.inv(Syy); W2=np.linalg.inv(Hc.T@Hc+sig2*np.eye(n))@Hc.T
say('LMMSE forms',np.abs(Wm-W2).max())
Ecov=Sxx-Sxy@np.linalg.inv(Syy)@Sxy.T
# empirical
Xs=rng.normal(size=(n,200000)); Ys=Hc@Xs+math.sqrt(sig2)*rng.normal(size=(6,200000)); Xh=Wm@Ys
say('mse theory',np.trace(Ecov),'emp',np.mean(np.sum((Xs-Xh)**2,0)),'orth',np.abs((Xs-Xh)@Ys.T/200000).max())
Wzf=np.linalg.pinv(Hc); say('ZF mse',np.mean(np.sum((Xs-Wzf@Ys)**2,0)),'theory',sig2*np.trace(np.linalg.inv(Hc.T@Hc)))
# AR(1) Yule-Walker, AR(2)
def sim_ar(a,n,sigma=1.0):
    x=np.zeros(n)
    for t in range(len(a),n): x[t]=sum(a[i]*x[t-1-i] for i in range(len(a)))+sigma*rng.normal()
    return x
a=[0.6,-0.3]; x=sim_ar(a,100000); 
r=np.array([np.mean(x[k:]*x[:len(x)-k]) for k in range(3)]); T_=linalg.toeplitz(r[:2]); ahat=np.linalg.solve(T_,r[1:3]); say('YW',ahat,'true',a)
# stationary roots
say('AR roots',np.abs(np.roots([1,-a[0],-a[1]])))
# MVP
Sg=np.array([[0.04,0.006,0.002],[0.006,0.09,0.01],[0.002,0.01,0.16]]); one=np.ones(3); wv=np.linalg.solve(Sg,one); wv/=wv.sum(); say('MVP',wv,'var',wv@Sg@wv,'eq var',one@Sg@one/9)
# U18.8 ALS
m,n,r=100,80,3; Mtrue=rng.normal(size=(m,r))@rng.normal(size=(r,n)); mask=rng.random((m,n))<0.3
U=rng.normal(size=(m,r));V=rng.normal(size=(n,r)); obj=[]
for it in range(60):
    for i in range(m):
        idx=mask[i]; Vi=V[idx]; U[i]=np.linalg.solve(Vi.T@Vi+1e-6*np.eye(r),Vi.T@Mtrue[i,idx])
    for j in range(n):
        idx=mask[:,j]; Uj=U[idx]; V[j]=np.linalg.solve(Uj.T@Uj+1e-6*np.eye(r),Uj.T@Mtrue[idx,j])
    obj.append(np.sum(((U@V.T-Mtrue)*mask)**2))
say('ALS monotone',all(obj[i+1]<=obj[i]+1e-9 for i in range(len(obj)-1)),'final obs rmse',math.sqrt(obj[-1]/mask.sum()),'full rmse',np.sqrt(np.mean((U@V.T-Mtrue)**2)))
# netflix size
say('sparsity',1-100480507/(480189*17770),'dense floats GB',480189*17770*4/1e9)
# U18.9 DFT
N=16; F=np.fft.fft(np.eye(N)); Fu=F/math.sqrt(N); say('unitary',np.abs(Fu.conj().T@Fu-np.eye(N)).max())
c=rng.normal(size=N); C=linalg.circulant(c); ev=np.fft.fft(c); xx=rng.normal(size=N)
say('circ diag',np.abs(C@xx-np.fft.ifft(ev*np.fft.fft(xx))).max())
say('FFT butterflies N=1024',1024//2*10,'vs N^2',1024**2, 'ratio',1024**2/(512*10))
def fftrec(x):
    n=len(x)
    if n==1: return x
    e=fftrec(x[0::2]);o=fftrec(x[1::2]); t=np.exp(-2j*np.pi*np.arange(n//2)/n)*o
    return np.concatenate([e+t,e-t])
z=rng.normal(size=64)+1j*rng.normal(size=64); say('fft rec',np.abs(fftrec(z)-np.fft.fft(z)).max())
# OFDM
Nf=64; Ncp=16; hch=np.array([1,0.5j,0.3,-0.2]); Hf=np.fft.fft(hch,Nf)
sym=(rng.choice([-1,1],Nf)+1j*rng.choice([-1,1],Nf))/math.sqrt(2)
tx=np.fft.ifft(sym)*math.sqrt(Nf); txcp=np.concatenate([tx[-Ncp:],tx]); rx=np.convolve(txcp,hch)[:Nf+Ncp]; rxn=rx[Ncp:]
Y=np.fft.fft(rxn)/math.sqrt(Nf); say('OFDM 1-tap',np.abs(Y-Hf*sym).max(),'eq err',np.abs(Y/Hf-sym).max())
rx0=np.convolve(tx,hch)[:Nf]; Y0=np.fft.fft(rx0)/math.sqrt(Nf); say('no CP err',np.abs(Y0-Hf*sym).max())
# PAPR
def papr(x): return 10*np.log10(np.max(np.abs(x)**2)/np.mean(np.abs(x)**2))
Nu=64; Nt_=256; po=[];ps=[]
for _ in range(4000):
    d=(rng.choice([-1,1],Nu)+1j*rng.choice([-1,1],Nu))/math.sqrt(2)
    Xo=np.zeros(Nt_,complex);Xo[:Nu]=d; po.append(papr(np.fft.ifft(Xo,Nt_)))
    Xs_=np.zeros(Nt_,complex);Xs_[:Nu]=np.fft.fft(d); ps.append(papr(np.fft.ifft(Xs_,Nt_)))
say('PAPR dB 99th OFDM',np.percentile(po,99),'SCFDMA',np.percentile(ps,99),'median',np.median(po),np.median(ps))
# U18.10 dynamical
Ad=np.array([[0.9,0.2],[0,0.8]]); say('rho',max(abs(np.linalg.eigvals(Ad))))
Ac=np.array([[0,1],[-2,-3]]); say('cont eig',np.linalg.eigvals(Ac))
dt=0.1; Ad2=linalg.expm(Ac*dt); ser=sum(np.linalg.matrix_power(Ac*dt,k)/math.factorial(k) for k in range(20)); say('expm vs series',np.abs(Ad2-ser).max())
x0=np.array([1,0.]); 
xs=x0.copy(); 
for _ in range(50): xs=Ad2@xs
say('x(5.0) discrete vs exact',xs,linalg.expm(Ac*5)@x0)
# double integrator controllable
Ai=np.array([[0,1],[0,0.]]);Bi=np.array([[0],[1.]]); Cm=np.hstack([Bi,Ai@Bi]); say('ctrb rank',np.linalg.matrix_rank(Cm))
# two-tank
k1,k2=0.5,0.3; At=np.array([[-k1,0],[k1,-k2]]); Bt=np.array([[1],[0.]]); say('2tank eig',np.linalg.eigvals(At),'ctrb',np.linalg.matrix_rank(np.hstack([Bt,At@Bt])),'dc gain',-np.linalg.solve(At,Bt).ravel())
Bt2=np.array([[0],[1.]]); say('2tank ctrb input to tank2',np.linalg.matrix_rank(np.hstack([Bt2,At@Bt2])))
# deadbeat: reach target in 2 steps double integrator dt=1
Ad_=np.array([[1,1],[0,1.]]);Bd_=np.array([[0.5],[1.]]); Cd=np.hstack([Ad_@Bd_,Bd_]); u=np.linalg.solve(Cd,np.array([4,0.])-Ad_@Ad_@np.array([0,0.])); x1=Bd_@u[1:2]; x2=Ad_@x1+Bd_@u[0:1]; say('deadbeat u',u,'x2',x2)
# U18.11 EM
n1=300;n2=200; Xg=np.concatenate([rng.normal(0,1,n1),rng.normal(4,1.5,n2)])
mu=np.array([-1.,1.]);sg=np.array([1.,1.]);pi=np.array([.5,.5]);ll=[]
for it in range(60):
    pdf=np.stack([pi[k]*np.exp(-(Xg-mu[k])**2/2/sg[k]**2)/(sg[k]*math.sqrt(2*math.pi)) for k in range(2)],1)
    ll.append(np.log(pdf.sum(1)).sum()); r=pdf/pdf.sum(1,keepdims=True); Nk=r.sum(0)
    mu=(r*Xg[:,None]).sum(0)/Nk; sg=np.sqrt((r*(Xg[:,None]-mu)**2).sum(0)/Nk); pi=Nk/len(Xg)
say('EM monotone',all(ll[i+1]>=ll[i]-1e-9 for i in range(len(ll)-1)),'mu',mu,'sg',sg,'pi',pi,'last gain',ll[-1]-ll[-2],'ll0',ll[0],'llend',ll[-1])
# kmeans vs EM on overlapping
# U18.12 perceptron
def perc(X,y,maxit=1000):
    w=np.zeros(X.shape[1]);mist=0
    for ep in range(maxit):
        ch=False
        for xi,yi in zip(X,y):
            if yi*(w@xi)<=0: w+=yi*xi;mist+=1;ch=True
        if not ch: break
    return w,mist
Xp=rng.normal(size=(200,3)); wt=np.array([1,-1,0.5]); Xp=np.hstack([Xp,np.ones((200,1))]); wt=np.append(wt,0.3); yp=np.sign(Xp@wt)
gam=np.min(np.abs(Xp@wt))/np.linalg.norm(wt); Rr=np.max(np.linalg.norm(Xp,axis=1))
w_,mist=perc(Xp,yp); say('perceptron mistakes',mist,'bound',(Rr/gam)**2,'sep',np.all(np.sign(Xp@w_)==yp))
# CS OMP
def omp(Phi,y,s):
    r=y.copy();S=[]
    for _ in range(s):
        j=int(np.argmax(np.abs(Phi.T@r))); S.append(j); xs=np.linalg.lstsq(Phi[:,S],y,rcond=None)[0]; r=y-Phi[:,S]@xs
    x=np.zeros(Phi.shape[1]);x[S]=xs;return x,r,S
Nn,Mm,ss=128,40,5; succ=0;trials=500
for _ in range(trials):
    Phi=rng.normal(size=(Mm,Nn))/math.sqrt(Mm); x=np.zeros(Nn); sup=rng.choice(Nn,ss,replace=False); x[sup]=rng.normal(size=ss); yv=Phi@x
    xh,_,_=omp(Phi,yv,ss); succ+= np.linalg.norm(xh-x)<1e-6
say('OMP success',succ/trials)
for Mm_ in [20,30,50,60]:
    succ=0
    for _ in range(200):
        Phi=rng.normal(size=(Mm_,Nn))/math.sqrt(Mm_); x=np.zeros(Nn); sup=rng.choice(Nn,ss,replace=False); x[sup]=rng.normal(size=ss); yv=Phi@x
        xh,_,_=omp(Phi,yv,ss); succ+= np.linalg.norm(xh-x)<1e-6
    say('M',Mm_,succ/200)
Phi=rng.normal(size=(40,128))/math.sqrt(40); x=np.zeros(128);x[rng.choice(128,5,replace=False)]=1; xmn=np.linalg.pinv(Phi)@(Phi@x); say('min-norm err',np.linalg.norm(xmn-x),'nnz',np.sum(np.abs(xmn)>1e-6))
mu_=np.max(np.abs((Phi.T@Phi)[~np.eye(128,dtype=bool)])/np.outer(np.linalg.norm(Phi,axis=0),np.linalg.norm(Phi,axis=0))[~np.eye(128,dtype=bool)]); say('coherence',mu_,'1/(2s-1)',1/9)
# U18.13 markov
P=np.array([[0.7,0.2,0.1],[0.3,0.5,0.2],[0.2,0.3,0.5]]); w,V=np.linalg.eig(P.T); i=np.argmin(abs(w-1)); pi=np.real(V[:,i]);pi/=pi.sum(); say('stationary',pi,'P^50 row',np.linalg.matrix_power(P,50)[0],'lam2',sorted(abs(w))[-2])
# inventory: capacity 3 (s=1,S=3)? demand dist 0:.3 1:.4 2:.3 ; order up to 3 when inventory<=1 ; states 0..3
dem=[.3,.4,.3]; S_=3;s_=1; n=S_+1; Pm=np.zeros((n,n))
for st in range(n):
    start=S_ if st<=s_ else st
    for d,pd in enumerate(dem):
        nxt=max(start-d,0); Pm[st,nxt]+=pd
w,V=np.linalg.eig(Pm.T); i=np.argmin(abs(w-1)); pin=np.real(V[:,i]);pin/=pin.sum(); say('inventory pi',pin)
# expected lost sales per period and orders
lost=0
for st in range(n):
    start=S_ if st<=s_ else st
    lost+=pin[st]*sum(pd*max(d-start,0) for d,pd in enumerate(dem))
orders=pin[:s_+1].sum(); say('lost per period',lost,'order prob',orders)
# absorbing: gambler
Pa=np.array([[1,0,0,0],[.5,0,.5,0],[0,.5,0,.5],[0,0,0,1.]]); Q_=Pa[1:3,1:3]; Rm=Pa[1:3,[0,3]]; Nf=np.linalg.inv(np.eye(2)-Q_); say('fundamental',Nf,'abs prob',Nf@Rm,'exp steps',Nf.sum(1))
# mixing
say('tv at 10',0.5*np.abs(np.linalg.matrix_power(P,10)[0]-pi).sum())
