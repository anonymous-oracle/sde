import sqlite3, collections, itertools, random
c = sqlite3.connect(':memory:')
c.executescript("""create table Emp(name,dept,sal);
insert into Emp values('a','d1',50),('b','d1',NULL),('c','d1',70),('d','d2',40),('e','d2',60),('f','d3',NULL);""")
print('AVG', c.execute('select avg(sal) from Emp').fetchone(), 'count*', c.execute('select count(*),count(sal) from Emp').fetchone())
print('group', c.execute('select dept,count(*),count(sal),avg(sal) from Emp group by dept having count(sal)>=1 order by dept').fetchall())
c.executescript("create table A(x); create table B(x); insert into A values(1),(2),(3),(4); insert into B values(2),(2),(3),(5);")
print('left join rows', c.execute('select count(*) from A left join B on A.x=B.x').fetchone(), 'with where B.x not null', c.execute('select count(*) from A left join B on A.x=B.x where B.x is not null').fetchone())
print('NOT IN with null:', c.execute("select count(*) from A where x not in (select x from B union select null)").fetchone(), ' NOT EXISTS:', c.execute("select count(*) from A a where not exists (select 1 from (select x from B union select null) b where b.x=a.x)").fetchone())
# bag set ops multiplicities
M=collections.Counter([1,1,1,2]); N=collections.Counter([1,1,3])
print('INTERSECT ALL', M&N, 'EXCEPT ALL', M-N, 'UNION ALL', M+N)
# incremental view maintenance identity
random.seed(3); ok=0
for _ in range(300):
    R={(random.randint(0,5),random.randint(0,4)) for _ in range(random.randint(0,10))}; S={(random.randint(0,4),random.randint(0,5)) for _ in range(random.randint(0,10))}
    dR={(random.randint(0,5),random.randint(0,4)) for _ in range(random.randint(0,4))}-R; dS={(random.randint(0,4),random.randint(0,5)) for _ in range(random.randint(0,4))}-S
    J=lambda X,Y:{(a,b,cc) for (a,b) in X for (b2,cc) in Y if b==b2}
    assert J(R|dR,S|dS)==J(R,S)|J(dR,S)|J(R,dS)|J(dR,dS); ok+=1
print('IVM identity ok', ok, ' pairs:', (100+10)*(80+5), 10*80+100*5+10*5)
# recursive CTE reachability
c.executescript("create table E(u,v); insert into E values(1,2),(2,3),(3,1),(3,4),(5,6);")
print('reach from 1:', sorted(r[0] for r in c.execute("with recursive r(x) as (select 1 union select v from E join r on E.u=r.x) select x from r")))
# injection demo (own in-memory db)
c.executescript("create table U(name,pw); insert into U values('alice','s3cret'),('bob','hunter2');")
bad="x' OR '1'='1"; q="select count(*) from U where name='%s'"%bad
print('concatenated rows:', c.execute(q).fetchone(), ' bound rows:', c.execute("select count(*) from U where name=?",(bad,)).fetchone())
print('db2 pages', 16*2**30*0.25/(8*2**10))
# division by double NOT EXISTS equals algebra division
c.executescript("create table En(sid,cid); insert into En values(1,'c1'),(1,'c2'),(1,'c3'),(2,'c1'),(2,'c2'),(3,'c1'),(4,'c2'),(4,'c3'),(4,'c1'); create table Rq(cid); insert into Rq values('c1'),('c2');")
print('div', c.execute("select count(*) from (select distinct sid from En e where not exists (select 1 from Rq r where not exists (select 1 from En e2 where e2.sid=e.sid and e2.cid=r.cid)))").fetchone())
