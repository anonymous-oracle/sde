import numpy as np, math, itertools, random, collections, sys
from scipy import stats, special
rng=np.random.default_rng(5)
def say(*a): print(*a)
# U21.1 school mathematics
say('e limit n=1e6',(1+1e-6)**1e6,math.e)
def bisect(f,a,b,n):
    for _ in range(n):
        m=(a+b)/2
        if f(a)*f(m)<=0: b=m
        else: a=m
    return (a+b)/2
f=lambda x:x**3-x-2; say('bisect 40',bisect(f,1,2,40),'err',abs(bisect(f,1,2,40)-bisect(f,1,2,80)))
x=1.0;errs=[]
for _ in range(5): x=x-(x*x-2)/(2*x); errs.append(abs(x-math.sqrt(2)))
say('newton errs',errs)
Mx=np.array([[2,1,1],[1,3,2],[1,0,0.]]); say('det',np.linalg.det(Mx))
def gj_inv(M):
    n=len(M); A=np.hstack([M.astype(float),np.eye(n)])
    for i in range(n):
        p=i+np.argmax(abs(A[i:,i])); A[[i,p]]=A[[p,i]]; A[i]/=A[i,i]
        for j in range(n):
            if j!=i: A[j]-=A[j,i]*A[i]
    return A[:,n:]
say('GJ inv err',np.abs(gj_inv(Mx)-np.linalg.inv(Mx)).max())
bb=np.array([4,5,1.]); say('cramer',[np.linalg.det(np.where(np.arange(3)[None,:]==j,bb[:,None],Mx))/np.linalg.det(Mx) for j in range(3)],np.linalg.solve(Mx,bb))
h=1e-5; say('fwd err',abs((math.sin(1+h)-math.sin(1))/h-math.cos(1)),'central err',abs((math.sin(1+h)-math.sin(1-h))/(2*h)-math.cos(1)))
for h in (1e-2,1e-5,1e-8,1e-11): say(' h',h,'central',abs((math.sin(1+h)-math.sin(1-h))/(2*h)-math.cos(1)))
def trap(f,a,b,n): xs=np.linspace(a,b,n+1); return (b-a)/n*(f(xs[0])/2+f(xs[1:-1]).sum()+f(xs[-1])/2)
def simp(f,a,b,n): xs=np.linspace(a,b,n+1); return (b-a)/(3*n)*(f(xs[0])+4*f(xs[1:-1:2]).sum()+2*f(xs[2:-1:2]).sum()+f(xs[-1]))
say('trap10',abs(trap(np.exp,0,1,10)-(math.e-1)),'simp10',abs(simp(np.exp,0,1,10)-(math.e-1)),'trap100',abs(trap(np.exp,0,1,100)-(math.e-1)))
def euler(h): y=1.0; 
def eul(h):
    y=1.0
    for _ in range(int(round(1/h))): y+=h*y
    return y
def rk4(h):
    y=1.0
    for _ in range(int(round(1/h))):
        k1=y;k2=y+h*k1/2;k3=y+h*k2/2;k4=y+h*k3; y+=h/6*(k1+2*k2+2*k3+k4)
    return y
say('euler h=.1',eul(.1),'rk4',rk4(.1),'e',math.e,'euler h=.01',eul(.01))
# LP vertices
best=None
cons=[(1,1,4),(1,3,6)]
pts=[(0,0),(4,0),(0,2)]
inter=np.linalg.solve([[1,1],[1,3]],[4,6]); pts.append(tuple(inter)); say('LP vertices',pts,[3*x+2*y for x,y in pts])
# skew lines distance: L1 p=(1,2,3)+t(2,3,4); L2 q=(2,-1,0)+s(1,2,3)
d1=np.array([2,3,4.]);d2=np.array([1,2,3.]);P0=np.array([1,2,3.]);Q0=np.array([2,-1,0.]); n=np.cross(d1,d2); say('skew dist',abs((Q0-P0)@n)/np.linalg.norm(n))
say('trig',max(abs(math.sin(a+b)-(math.sin(a)*math.cos(b)+math.cos(a)*math.sin(b))) for a,b in rng.uniform(-5,5,size=(1000,2))))
say('gp sum',sum(0.5**k for k in range(60)),'binom',sum(math.comb(10,k)*2**k for k in range(11)),3**10)
say('sin x ~ x at 0.01',math.sin(0.01)-0.01)
# U21.2 python
def fibc(n):
    c=[0]
    def f(k):
        c[0]+=1
        return k if k<2 else f(k-1)+f(k-2)
    f(n); return c[0]
say('fib calls',[fibc(n) for n in (10,20,25)],'formula 2F(n+1)-1',[2*round(((1+5**.5)/2)**(n+1)/5**.5)-1 for n in (10,20,25)])
say('0.1+0.2',0.1+0.2,0.1+0.2==0.3,'sum 0.1 x10',sum([0.1]*10),'fsum',math.fsum([0.1]*10),'eps',sys.float_info.epsilon,'2**100',2**100,'recursion limit',sys.getrecursionlimit())
import time
a=[0]*1000000; t=time.time(); s=0
for v in range(1000000): s+=v*v
t1=time.time()-t; t=time.time(); xx=np.arange(1000000,dtype=np.int64); s2=int((xx*xx).sum()); t2=time.time()-t; say('python loop s',s,s2,'speed ratio ~',t1/max(t2,1e-9))
# list append amortised
import timeit
say('append total ops ~ fine')
def mutable(x,l=[]): l.append(x); return l
say('mutable default',mutable(1),mutable(2))
# U21.3 R semantics: pnorm qnorm
def pnorm(x): return 0.5*(1+math.erf(x/math.sqrt(2)))
def qnorm(p,lo=-10,hi=10):
    for _ in range(100):
        m=(lo+hi)/2
        if pnorm(m)<p: lo=m
        else: hi=m
    return (lo+hi)/2
say('pnorm 1.96',pnorm(1.96),stats.norm.cdf(1.96),'qnorm .975',qnorm(.975),stats.norm.ppf(.975))
say('dbinom(3,10,.5)',math.comb(10,3)/2**10,'dpois(2,3)',math.exp(-3)*9/2,stats.poisson.pmf(2,3))
u1=rng.random(200000);u2=rng.random(200000); z=np.sqrt(-2*np.log(u1))*np.cos(2*math.pi*u2); say('box-muller mean var',z.mean(),z.var(),'KS',stats.kstest(z,'norm').pvalue)
# recycling
def recycle(a,b):
    n=max(len(a),len(b)); return [a[i%len(a)]+b[i%len(b)] for i in range(n)]
say('recycle',recycle([1,2,3,4,5,6],[10,20]))
# lm via formula
Xm=np.c_[np.ones(100),rng.normal(size=(100,2))]; y=Xm@[1,2,-1]+rng.normal(size=100); say('lm own vs numpy',np.abs(np.linalg.solve(Xm.T@Xm,Xm.T@y)-np.linalg.lstsq(Xm,y,rcond=None)[0]).max())
# U21.4 logic/proof
say('boolean functions n=3',2**(2**3),'demorgan rows ok',all((not (p and q))==((not p) or (not q)) for p,q in itertools.product([0,1],repeat=2)))
say('pigeonhole mod12 any 13',all(len(set(c%12 for c in rng.integers(0,10**6,size=13)))<13 for _ in range(1000)))
say('stars bars',sum(1 for t in itertools.product(range(11),repeat=4) if sum(t)==10),math.comb(13,3))
say('incl-excl <=100 div by 2,3,5',sum(1 for k in range(1,101) if k%2==0 or k%3==0 or k%5==0),100-50-33-20+16+10+6-3 if False else 50+33+20-16-10-6+3)
def derange(n): return sum(1 for p in itertools.permutations(range(n)) if all(p[i]!=i for i in range(n)))
say('derangements',[derange(n) for n in (3,4,5,6)])
say('strong induction prime factor n<=10000',all(any(n%d==0 for d in range(2,n+1) if all(d%e for e in range(2,int(d**.5)+1))) for n in range(2,2000)))
say('catalan',[math.comb(2*n,n)//(n+1) for n in range(1,8)])
say('sum odd',all(sum(2*k+1 for k in range(n))==n*n for n in range(1,500)))
say('2^n > n^2 n>=5',all(2**n>n*n for n in range(5,200)),'fails at',[n for n in range(1,5) if 2**n<=n*n])
# U21.5 graphs
def prufer_to_tree(seq,n):
    deg=[1]*n
    for v in seq: deg[v]+=1
    edges=[]; import heapq
    leaves=[v for v in range(n) if deg[v]==1]; heapq.heapify(leaves)
    for v in seq:
        l=heapq.heappop(leaves); edges.append((l,v)); deg[v]-=1
        if deg[v]==1: heapq.heappush(leaves,v)
    edges.append((heapq.heappop(leaves),heapq.heappop(leaves))); return edges
def tree_to_prufer(edges,n):
    adj=collections.defaultdict(set)
    for a,b in edges: adj[a].add(b);adj[b].add(a)
    seq=[]; import heapq
    leaves=[v for v in range(n) if len(adj[v])==1]; heapq.heapify(leaves)
    for _ in range(n-2):
        l=heapq.heappop(leaves); (p,)=adj[l]; seq.append(p); adj[p].discard(l); adj[l].clear()
        if len(adj[p])==1: heapq.heappush(leaves,p)
    return seq
n=5; allseq=list(itertools.product(range(n),repeat=n-2)); trees=set()
ok=True
for s in allseq:
    e=prufer_to_tree(s,n); ok&= tree_to_prufer(e,n)==list(s); trees.add(frozenset(frozenset(x) for x in e))
say('Cayley n=5',len(allseq),len(trees),ok,'n=6',6**4)
def Lap(edges,n):
    L=np.zeros((n,n))
    for a,b in edges: L[a,a]+=1;L[b,b]+=1;L[a,b]-=1;L[b,a]-=1
    return L
Kn=lambda n:[(i,j) for i in range(n) for j in range(i+1,n)]
say('matrix-tree K6',round(np.linalg.det(Lap(Kn(6),6)[1:,1:])),'K33',round(np.linalg.det(Lap([(i,3+j) for i in range(3) for j in range(3)],6)[1:,1:])))
say('Konigsberg degrees',[3,3,3,5],'K5 edges',10,'3V-6',9,'K33 edges',9,'2V-4',8)
# graphs on 4 vertices up to isomorphism
def canon(edges,n):
    best=None
    for p in itertools.permutations(range(n)):
        e=tuple(sorted(tuple(sorted((p[a],p[b]))) for a,b in edges))
        if best is None or e<best: best=e
    return best
allE=Kn(4); cls=set()
for m in range(64):
    ed=[allE[i] for i in range(6) if m>>i&1]; cls.add(canon(ed,4))
say('labelled graphs on 4',2**6,'unlabelled',len(cls))
# Petersen greedy
P=[(i,(i+1)%5) for i in range(5)]+[(i,i+5) for i in range(5)]+[(5+i,5+(i+2)%5) for i in range(5)]
adj=collections.defaultdict(set)
for a,b in P: adj[a].add(b);adj[b].add(a)
def greedy(order):
    c={}
    for v in order:
        used={c[u] for u in adj[v] if u in c}; k=0
        while k in used: k+=1
        c[v]=k
    return max(c.values())+1
say('Petersen greedy colours over 2000 orders',collections.Counter(greedy(random.sample(range(10),10)) for _ in range(2000)),'degree',3)
# Gray code Hamiltonian path in Q3
g=[i^(i>>1) for i in range(8)]; say('gray',g,all(bin(g[i]^g[i+1]).count('1')==1 for i in range(7)))
# U21.6 probability
lam=2.0; xs=-np.log(1-rng.random(500000))/lam; say('inv CDF exp mean var',xs.mean(),xs.var(),'theory',1/lam,1/lam**2)
s,t=0.7,1.1; say('memoryless',np.mean(xs[xs>s]>s+t),np.mean(xs>t),math.exp(-lam*t))
# rejection beta(2,5)
M=special.beta(2,5); a_=2;b_=5; mode=(a_-1)/(a_+b_-2); fmax=stats.beta.pdf(mode,a_,b_); N=400000; xs=rng.random(N); us=rng.random(N)*fmax; acc=us<stats.beta.pdf(xs,a_,b_); say('rejection acceptance',acc.mean(),'1/fmax',1/fmax,'mean',xs[acc].mean(),'theory',2/7)
nmc=10**6; p=rng.random((nmc,2)); est=4*np.mean(p[:,0]**2+p[:,1]**2<1); say('MC pi',est,abs(est-math.pi),'sd theory',4*math.sqrt(math.pi/4*(1-math.pi/4)/nmc))
say('coupon n=50',50*sum(1/k for k in range(1,51)),'sim',np.mean([ (lambda: next(i for i in itertools.count(1) if False) ) and 0 for _ in range(1)]))
def coupon(n):
    seen=set();t=0
    while len(seen)<n: seen.add(random.randrange(n));t+=1
    return t
random.seed(1); say('coupon sim',np.mean([coupon(50) for _ in range(3000)]))
say('sum of 12 uniforms var',np.var(rng.random((200000,12)).sum(1)-6),'KS',stats.kstest(rng.random((20000,12)).sum(1)-6,'norm').pvalue)
say('geometric mean',np.mean(rng.geometric(0.2,size=500000)),'1/p',5)
say('Chebyshev LLN',[ (n, 0.25/(n*0.01)) for n in (100,1000)], 'empirical',[np.mean(np.abs(rng.binomial(n,0.5,size=200000)/n-0.5)>=0.1) for n in (100,1000)])
