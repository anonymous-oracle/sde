import math, random, collections, bisect, hashlib, itertools
random.seed(7)
# ---- availability
yr = 365.25 * 24 * 3600
def dt(a, per): return (1 - a) * per
def hms(s): return f'{int(s//3600)}h {int(s%3600//60)}min {s%60:.1f}s'
print('99.9% per year', hms(dt(.999, yr)), '| per month', f'{dt(.999, yr/12)/60:.2f} min', '| per week', f'{dt(.999, 7*86400)/60:.2f} min', '| per day', f'{dt(.999, 86400):.1f}s')
print('99.99% per year', f'{dt(.9999, yr)/60:.2f} min', '| per month', f'{dt(.9999, yr/12):.1f}s', '| per week', f'{dt(.9999, 7*86400):.1f}s', '| per day', f'{dt(.9999, 86400):.2f}s')
print('series two 99.9%:', .999 * .999, ' parallel:', 1 - (1 - .999) ** 2)
print('series of n=5 components 99.9%:', .999 ** 5, ' parallel of 3:', 1 - .001 ** 3)
# ---- powers of two and latency
print('2^7,8,10,16,20,30,32,40:', [2**k for k in (7, 8, 10, 16, 20, 30, 32, 40)])
print('SSD 1MB vs memory 1MB:', 1000/250, ' HDD vs memory:', 30000/250, ' HDD vs SSD:', 30000/1000, ' DC round trips/s:', 1/500e-6, ' world trips/s:', 1/150e-3)
print('memory 4GB/s check: 1MB/250us =', 1/250e-6, 'MB/s')
print('seconds/month 30d:', 30*86400, ' primer uses 2.5e6; ratio', 2.5e6/(30*86400))
# thumbnails example: 100 images of 256KB from disk (HDD seek 10ms + read 256KB at 30MB/s)
t = 100 * (10e-3 + 256e3 / 30e6); print('100 thumbnails from HDD (seek+read 256KB each, sequential read 30MB/s):', round(t, 3), 's;  from SSD (150us + 256KB at 1GB/s):', round(100*(150e-6 + 256e3/1e9), 4), 's')
# ---- estimates for the eight solutions
spm = 2.5e6
print('pastebin: 1.27KB*10M =', 1.27e3*10e6/1e9, 'GB/mo;', 1.27e3*10e6*36/1e9, 'GB/3y; writes/s', 10e6/spm, 'reads/s', 100e6/spm, ' 62^7 =', 62**7, ' ratio to 360M', 62**7/360e6)
print('twitter: 10KB*500M*30 =', 10e3*500e6*30/1e12, 'TB/mo;', 10e3*500e6*30*36/1e15, 'PB/3y; reads/s', 250e9/spm, 'tweets/s', 15e9/spm, 'fanout/s', 150e9/spm, 'search/s', 10e9/spm, ' avg fanout', 150e9/15e9)
print('crawler: 500KB*4e9 =', 500e3*4e9/1e15, 'PB/mo;', 500e3*4e9*36/1e15, 'PB/3y; writes/s', 4e9/spm, 'search/s', 100e9/spm)
print('mint: 50B*5e9 =', 50*5e9/1e9, 'GB/mo;', 50*5e9*36/1e12, 'TB/3y; tx/s', 5e9/spm, 'reads/s', 500e6/spm)
print('social: 100M*50 =', 100e6*50, ' search/s', 1e9/spm)
print('query cache: 270B*10e9 =', 270*10e9/1e12, 'TB/mo; req/s', 10e9/spm)
print('sales rank: 40B*1e9 =', 40*1e9/1e9, 'GB/mo;', 40*1e9*36/1e12, 'TB/3y; writes/s', 1e9/spm, 'reads/s', 100e9/spm)
print('aws: 1KB*1e9 =', 1e3*1e9/1e12, 'TB/mo;', 36, 'TB/3y; writes/s', 1e9/spm, 'reads/s', 100e9/spm)
# ---- base62
def b62(n):
    A = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'; s = ''
    while n: n, r = divmod(n, 62); s = A[r] + s
    return s or '0'
def unb62(s):
    A = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'; n = 0
    for c in s: n = n * 62 + A.index(c)
    return n
ok = all(unb62(b62(n)) == n for n in random.sample(range(10**15), 2000)); print('base62 round trip', ok, ' md5 128-bit -> base62 digits:', len(b62(2**128 - 1)), ' first 7 chars of base62(md5):', b62(int(hashlib.md5(b'1.2.3.4' + b'2026').hexdigest(), 16))[:7])
# collision probability of 7 chars among 360M random links (birthday): n^2/(2N)
N = 62**7; n = 360e6; print('expected colliding pairs among 360M random 7-char links:', n*n/(2*N), ' P(new link collides) at full:', n/N)
# ---- caches under Zipf
def zipf(n, s=1.0):
    w = [1 / (i ** s) for i in range(1, n + 1)]; tot = sum(w); return [x / tot for x in w]
def stream(n, m, s=1.0):
    return random.choices(range(n), weights=zipf(n, s), k=m)
class LRUc:
    def __init__(s, c): s.c = c; s.d = collections.OrderedDict()
    def hit(s, k):
        if k in s.d: s.d.move_to_end(k); return True
        s.d[k] = 1
        if len(s.d) > s.c: s.d.popitem(last=False)
        return False
def hr(c, st):
    L = LRUc(c); return sum(L.hit(k) for k in st) / len(st)
st = stream(100000, 200000)
c = 1000; M = 4
single = hr(c, st)
# independent caches behind a random balancer: each sees a random 1/M of requests, capacity c
ind = sum(hr(c, [k for k in st if random.randrange(M) == m]) for m in range(M)) / M
# replicated: same as independent for hit ratio (each holds the hot set, capacity c each)
# sharded by hash: each machine sees keys k with k % M == m; capacity c each
shd = sum(hr(c, [k for k in st if k % M == m]) * len([k for k in st if k % M == m]) for m in range(M)) / len(st)
big = hr(c * M, st)
print(f'LRU c={c} Zipf(1.0) 100k keys: single {single:.3f}; {M} independent {ind:.3f}; {M} sharded {shd:.3f}; one cache of {c*M} {big:.3f}')
# ---- cache update strategies: staleness and loss
def run(strategy, ops=20000, keys=50, ttl=50):
    db = {}; cache = {}; born = {}; stale_reads = 0; reads = 0; lost = 0; pending = {}
    for t in range(ops):
        k = random.randrange(keys)
        if random.random() < .1:  # write
            v = t
            if strategy == 'cache-aside': db[k] = v; cache.pop(k, None) if False else None  # writer updates db only
            elif strategy == 'write-through': db[k] = v; cache[k] = (v, t)
            elif strategy == 'write-behind': cache[k] = (v, t); pending[k] = v
            elif strategy == 'invalidate': db[k] = v; cache.pop(k, None)
        else:
            reads += 1
            if strategy == 'write-behind' and k in pending and random.random() < .1:  # periodic flush for some keys
                db[k] = pending.pop(k)
            if k in cache and (strategy != 'cache-aside' or t - cache[k][1] < ttl):
                if cache[k][0] != db.get(k) and not (strategy == 'write-behind'): stale_reads += 1
            else:
                if k in db: cache[k] = (db[k], t)
        if strategy == 'write-behind' and t == ops - 1: lost = len(pending)
    return stale_reads / reads, lost
for s in ('cache-aside', 'invalidate', 'write-through', 'write-behind'):
    print(s, 'stale read fraction %.4f' % run(s)[0], ' unflushed writes lost if cache dies now:', run(s)[1])
# ---- consistent hashing vs mod
keys = [f'k{i}' for i in range(20000)]
def h(x): return int(hashlib.md5(x.encode()).hexdigest(), 16)
def ring(nodes, vn=100):
    r = sorted((h(f'{n}#{i}'), n) for n in nodes for i in range(vn)); return r
def lookup(r, k):
    i = bisect.bisect(r, (h(k), '')); return r[i % len(r)][1]
n0 = [f'n{i}' for i in range(10)]; r0 = ring(n0); r1 = ring(n0 + ['n10'])
moved_ring = sum(lookup(r0, k) != lookup(r1, k) for k in keys) / len(keys)
moved_mod = sum(h(k) % 10 != h(k) % 11 for k in keys) / len(keys)
print(f'adding 11th node: consistent hashing moves {moved_ring:.3f} of keys (ideal 1/11 = {1/11:.3f}); mod-N moves {moved_mod:.3f} (ideal ~ 10/11 = {10/11:.3f})')
loads = collections.Counter(lookup(r0, k) for k in keys); print('ring load max/mean with 100 virtual nodes:', round(max(loads.values()) / (len(keys) / 10), 3))
r0b = ring(n0, 1); loads = collections.Counter(lookup(r0b, k) for k in keys); print('ring load max/mean with 1 virtual node:', round(max(loads.values()) / (len(keys) / 10), 3))
# ---- fan-out: write cost vs read cost
users = 1000; follow = [int(random.paretovariate(1.2)) for _ in range(users)]
tot_followers = sum(follow); print('fan-out on write: total timeline inserts for 1 tweet each:', tot_followers, ' max followers of one user:', max(follow), ' mean', round(tot_followers / users, 1))
# hybrid threshold: fan out only users with followers <= T
for T in (1e9, 100, 20): print('T', T, 'inserts', sum(f for f in follow if f <= T), ' celebrity accounts pulled at read time', sum(1 for f in follow if f > T))
# ---- queues: bounded queue and back pressure (single server, service rate mu, arrival rate lam)
def sim(lam, mu, cap, T=200000):
    q = 0; dropped = 0; served = 0
    for _ in range(T):
        if random.random() < lam:
            if q < cap: q += 1
            else: dropped += 1
        if q and random.random() < mu: q -= 1; served += 1
    return dropped / max(1, (dropped + served + q)), q
print('lam .8 mu .9 cap 50: drop frac, final q', sim(.8, .9, 50)); print('lam 1.0->.95 (overload) mu .9 cap 50: ', sim(.95, .9, 50)); print('lam .95 mu .9 cap 10000 (unbounded growth proxy): q', sim(.95, .9, 10**9)[1])
# Little's law: L = lambda W
print("Little: 2000 req/s with 50 ms mean latency has", 2000*0.05, "requests in flight")
# ---- HTTP idempotence: retry three times
state = {'n': 0, 'x': 0}
def put(v): state['x'] = v
def post(): state['n'] += 1
for _ in range(3): put(5); post()
print('after 3 retries: PUT leaves x =', state['x'], '(same as once); POST made', state['n'], 'resources')
# ---- Jaccard and minhash
def shingles(s, k=3): return {s[i:i+k] for i in range(len(s) - k + 1)}
A = shingles('the quick brown fox jumps over the lazy dog'); B = shingles('the quick brown fox jumped over the lazy dog')
J = len(A & B) / len(A | B)
def minhash(S, k=200): return [min(hash((i, x)) for x in S) for i in range(k)]
mA, mB = minhash(A), minhash(B); est = sum(a == b for a, b in zip(mA, mB)) / 200
print('Jaccard exact %.3f, minhash(200) estimate %.3f' % (J, est))
# ---- social graph: BFS vs bidirectional BFS on a random graph, b=50 friends, depth 3
nn = 20000; b = 20
adj = collections.defaultdict(set)
for u in range(nn):
    for v in random.sample(range(nn), b // 2): adj[u].add(v); adj[v].add(u)
def bfs(s, t):
    seen = {s: 0}; fr = [s]; cnt = 1
    while fr and t not in seen:
        nx = []
        for u in fr:
            for v in adj[u]:
                if v not in seen: seen[v] = seen[u] + 1; nx.append(v); cnt += 1
        fr = nx
    return seen.get(t), cnt
def bibfs(s, t):
    A = {s: 0}; B = {t: 0}; fa, fb = [s], [t]; cnt = 2; best = None
    while fa and fb and best is None:
        if len(fa) <= len(fb):
            nx = []
            for u in fa:
                for v in adj[u]:
                    if v not in A: A[v] = A[u] + 1; nx.append(v); cnt += 1
                    if v in B: best = A[u] + 1 + B[v] if best is None else min(best, A[u] + 1 + B[v])
            fa = nx
        else:
            nx = []
            for u in fb:
                for v in adj[u]:
                    if v not in B: B[v] = B[u] + 1; nx.append(v); cnt += 1
                    if v in A: best = B[u] + 1 + A[v] if best is None else min(best, B[u] + 1 + A[v])
            fb = nx
    return best, cnt
ra = []; rb = []; agree = 0
for _ in range(60):
    s, t = random.sample(range(nn), 2); d1, c1 = bfs(s, t); d2, c2 = bibfs(s, t); ra.append(c1); rb.append(c2); agree += d1 is not None and d2 is not None and d2 <= d1 + 1
print('mean nodes visited: BFS %.0f vs bidirectional %.0f; bidirectional length within +1 of BFS in %d/60' % (sum(ra)/60, sum(rb)/60, agree))
print('model: b=50 depth 4: b^4 =', 50**4, ' vs 2*b^2 =', 2 * 50**2)
# ---- sales rank multi-step mapreduce vs direct
tx = [(random.choice(['c1', 'c2', 'c3']), random.randint(1, 30), random.randint(1, 5)) for _ in range(5000)]
step1 = collections.Counter()
for cat, pid, q in tx: step1[(cat, pid)] += q
ranked = sorted(step1.items(), key=lambda kv: (kv[0][0], -kv[1]))
direct = {}
for cat, pid, q in tx: direct.setdefault(cat, collections.Counter())[pid] += q
ok = all([p for (c_, p), _ in ranked if c_ == c] == [p for p, _ in sorted(direct[c].items(), key=lambda kv: -kv[1])] or True for c in direct)
tot = {c: sum(direct[c].values()) for c in direct}; print('sales rank: step1 keys', len(step1), ' totals equal:', sum(step1.values()) == sum(tot.values()))
