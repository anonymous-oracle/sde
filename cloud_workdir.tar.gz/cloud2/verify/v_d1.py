import sys, itertools, math, random
sys.path.insert(0, 'verify')
from ra import *
# Sperner: max antichain of subsets of {0..n-1}
def max_antichain(n):
    subs = list(range(1, 1 << n)); best = 0
    # exact via complement-free brute force on small n: choose by layers search with recursion
    import functools
    adj = {a: [b for b in subs if a != b and (a & b == a or a & b == b)] for a in subs}
    best = 0
    def rec(cands, size):
        nonlocal best
        if size + len(cands) <= best: return
        if not cands: best = max(best, size); return
        a = cands[0]
        rec([c for c in cands[1:] if c not in set(adj[a])], size + 1)
        rec(cands[1:], size)
    rec(subs, 0)
    return best
print('Sperner n=4,5:', max_antichain(4), math.comb(4, 2), max_antichain(5), math.comb(5, 2))
print('binary relations on 3 elements:', 2 ** 9, ' instances of degree 2 over domains of size 2:', 2 ** (2 ** 2))
# De Morgan on all structures with unary predicate P over 3 elements
ok = True
for bits in range(8):
    P = [(bits >> i) & 1 for i in range(3)]
    ok &= (not all(P)) == any(not x for x in P) and (not any(P)) == all(not x for x in P)
print('De Morgan quantifiers exhaustive (3 elems):', ok)
# Division example
Enrol = Rel(['sid', 'cid'], [(1, 'c1'), (1, 'c2'), (1, 'c3'), (2, 'c1'), (2, 'c2'), (3, 'c1'), (4, 'c2'), (4, 'c3'), (4, 'c1')])
Req = Rel(['cid'], [('c1',), ('c2',)])
print('Enrol / Req:', sorted(divide(Enrol, Req).rows), len(divide(Enrol, Req)))
# cartesian sizes and join bound
R = Rel(['a', 'b'], [(i, i % 3) for i in range(12)]); S = Rel(['b', 'c'], [(0, 'x'), (1, 'y'), (2, 'z'), (1, 'w')])
J = njoin(R, S); print('|R|,|S|,|R x S|,|R join S|:', len(R), len(S), len(prod(R, ren(S, {'b': 'b2'}))), len(J))
# ternary relationship spurious tuples: supplier-part-project
T = {('s1', 'p1', 'j2'), ('s1', 'p2', 'j1'), ('s2', 'p1', 'j1')}
SP = {(s, p) for s, p, j in T}; PJ = {(p, j) for s, p, j in T}; SJ = {(s, j) for s, p, j in T}
tri = {(s, p, j) for (s, p) in SP for (p2, j) in PJ if p == p2 and (s, j) in SJ}
print('ternary: |T|=', len(T), ' join of three pairwise projections =', len(tri), sorted(tri - T))
# P(inconsistent) with k copies
p = 0.99; k = 4; print('P(all k succeed)=', p ** k, ' P(inconsistent)=', 1 - p ** k - (1 - p) ** k)
# TRC domain dependence: {t | not R(t)} depends on domain
for dom in [range(3), range(5)]:
    Rr = {(0,), (1,)}; print('not R over domain size', len(list(dom)), ':', len([x for x in dom if (x,) not in Rr]))
