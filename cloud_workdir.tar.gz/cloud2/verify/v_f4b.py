import numpy as np, math
rng=np.random.default_rng(22)
def say(*a): print(*a)
# Bloom with universal hashing mod p=2^31-1 (items < p), ints stay below 2^62
p=2**31-1
def bloom(n,m,k,trials=200000):
    bits=np.zeros(m,bool); items=rng.integers(0,p,size=n,dtype=np.int64); q=rng.integers(0,p,size=trials,dtype=np.int64)
    a=rng.integers(1,p,size=k,dtype=np.int64); b=rng.integers(0,p,size=k,dtype=np.int64)
    for r in range(k): bits[((a[r]*items+b[r])%p)%m]=True
    hit=np.ones(trials,bool)
    for r in range(k): hit&=bits[((a[r]*q+b[r])%p)%m]
    return hit.mean(), bits.mean()
n=10000
for bpi,k in [(10,7),(10,3),(8,6),(16,11)]:
    m=bpi*n; th=(1-math.exp(-k*n/m))**k; f,fill=bloom(n,m,k); say('bloom bits/item',bpi,'k',k,'theory',round(th,5),'sim',round(f,5),'fill',round(fill,3),'1-exp',round(1-math.exp(-k*n/m),3))
# MinHash: permutations vs linear hashes on consecutive integers
A=np.arange(0,1500); B=np.arange(500,2000); U=2000; J=len(np.intersect1d(A,B))/len(np.union1d(A,B)); H=128
res=[];res_lin=[]
for _ in range(400):
    perms=np.array([rng.permutation(U) for _ in range(H)]); res.append(np.mean(perms[:,A].min(1)==perms[:,B].min(1)))
    a=rng.integers(1,p,size=H,dtype=np.int64); b=rng.integers(0,p,size=H,dtype=np.int64)
    hA=((a[:,None]*A[None,:]+b[:,None])%p).min(1); hB=((a[:,None]*B[None,:]+b[:,None])%p).min(1); res_lin.append(np.mean(hA==hB))
res=np.array(res);res_lin=np.array(res_lin)
say('J',J,'perm mean',res.mean(),'sd',res.std(),'theory sd',math.sqrt(J*(1-J)/H),'linear family mean',res_lin.mean(),'sd',res_lin.std())
# random sets (not consecutive)
A2=rng.choice(10**6,1500,replace=False); B2=np.concatenate([A2[:1000],rng.choice(np.arange(10**6,2*10**6),500,replace=False)]); J2=1000/2000; r2=[]
for _ in range(400):
    a=rng.integers(1,p,size=H,dtype=np.int64); b=rng.integers(0,p,size=H,dtype=np.int64)
    hA=((a[:,None]*A2[None,:]+b[:,None])%p).min(1); hB=((a[:,None]*B2[None,:]+b[:,None])%p).min(1); r2.append(np.mean(hA==hB))
say('J2',J2,'linear family on random sets mean',np.mean(r2),'sd',np.std(r2))
# ADMM
mW=4; nn_=400;dd=10; Ai=[rng.normal(size=(nn_,dd)) for _ in range(mW)]; wt=rng.normal(size=dd); bi=[a@wt+0.5*rng.normal(size=nn_) for a in Ai]
Aall=np.vstack(Ai); ball=np.concatenate(bi); xs=np.linalg.lstsq(Aall,ball,rcond=None)[0]
rho=1.0; x=[np.zeros(dd) for _ in range(mW)]; u=[np.zeros(dd) for _ in range(mW)]; z=np.zeros(dd); hist=[]
for it in range(300):
    x=[np.linalg.solve(a.T@a+rho*np.eye(dd),a.T@b+rho*(z-ui)) for a,b,ui in zip(Ai,bi,u)]
    z=np.mean([xi+ui for xi,ui in zip(x,u)],0); u=[ui+xi-z for xi,ui in zip(x,u)]; hist.append(np.linalg.norm(z-xs))
say('ADMM err at 5,10,20,50,100,200',[float('%.2e'%hist[i-1]) for i in (5,10,20,50,100,200)])
say('first below 1e-3',next((i+1 for i,h in enumerate(hist) if h<1e-3),None),'1e-6',next((i+1 for i,h in enumerate(hist) if h<1e-6),None))
for rho in (0.1,1.0,10.0,100.0):
    x=[np.zeros(dd) for _ in range(mW)]; u=[np.zeros(dd) for _ in range(mW)]; z=np.zeros(dd); h=[]
    for it in range(300):
        x=[np.linalg.solve(a.T@a+rho*np.eye(dd),a.T@b+rho*(z-ui)) for a,b,ui in zip(Ai,bi,u)]
        z=np.mean([xi+ui for xi,ui in zip(x,u)],0); u=[ui+xi-z for xi,ui in zip(x,u)]; h.append(np.linalg.norm(z-xs))
    say('rho',rho,'iters to 1e-6',next((i+1 for i,v in enumerate(h) if v<1e-6),None),'err@300',h[-1])
Al=rng.normal(size=(100,50)); xt=np.zeros(50); xt[:5]=[3,-2,1.5,2,-1]; bl=Al@xt+0.1*rng.normal(size=100); lam=0.1*np.max(np.abs(Al.T@bl)); z=np.zeros(50);u=np.zeros(50); rho=1.0
Mi=np.linalg.inv(Al.T@Al+rho*np.eye(50))
for it in range(300):
    x=Mi@(Al.T@bl+rho*(z-u)); z=np.sign(x+u)*np.maximum(np.abs(x+u)-lam/rho,0); u+=x-z
say('lasso nnz',int(np.sum(np.abs(z)>1e-6)),'support',np.nonzero(np.abs(z)>1e-6)[0].tolist(),'err',np.linalg.norm(z-xt),'lam',lam)
# check vs sklearn lasso
from sklearn.linear_model import Lasso
sk=Lasso(alpha=lam/100,fit_intercept=False,tol=1e-10,max_iter=100000).fit(Al,bl); say('ADMM vs sklearn lasso',np.abs(sk.coef_-z).max())
say('ship data',10**10,'per round',10*100*100)
from scipy import stats
say('Hoeffding exact',stats.binom.cdf(40,100,.5)+stats.binom.sf(59,100,.5))
# lasso ADMM with tuned rho and enough iterations
from sklearn.linear_model import Lasso
for rho in (1.0,40.0):
    z=np.zeros(50);u=np.zeros(50); Mi=np.linalg.inv(Al.T@Al+rho*np.eye(50))
    for it in range(2000):
        x=Mi@(Al.T@bl+rho*(z-u)); z=np.sign(x+u)*np.maximum(np.abs(x+u)-lam/rho,0); u+=x-z
    print('lasso rho',rho,'2000 its: diff vs sklearn',np.abs(sk.coef_-z).max(),'nnz',int(np.sum(np.abs(z)>1e-6)))
