# D22 U22.5-U22.9
import ast, itertools, random, math, sys, collections, io, re
import numpy as np, networkx as nx
random.seed(23); rng=np.random.default_rng(23)
print('=== U22.5')
for a in (0.99,0.999,0.9999,0.99999): print('availability',a,'downtime/yr min',round((1-a)*365*24*60,2),'h',round((1-a)*365*24,3))
for k,(A,B) in enumerate([(0.999,0.999),(0.9999,0.99)]): print('series availability',A,B,round(A*B,6),'parallel',round(1-(1-A)*(1-B),8))
# AHP
M=np.array([[1,3,5],[1/3,1,2],[1/5,1/2,1.]]); w,v=np.linalg.eig(M); i=np.argmax(w.real); lam=w[i].real; p=np.abs(v[:,i].real); p/=p.sum()
CI=(lam-3)/2; print('AHP priorities',p.round(4),'lambda_max',round(lam,4),'CI',round(CI,4),'CR',round(CI/0.58,4))
Mi=np.array([[1,3,5],[1/3,1,1/5],[1/5,5,1.]]); w,v=np.linalg.eig(Mi); i=np.argmax(w.real); lam=w[i].real; print('inconsistent matrix lambda',round(lam,4),'CR',round((lam-3)/2/0.58,4))
# power-iteration check
x=np.ones(3)
for _ in range(50): x=M@x; x/=x.sum()
print('power iteration priorities',x.round(4))
# linter
WEAK=['fast','user-friendly','easy','adequate','as appropriate','etc','and/or','flexible','robust','efficient','approximately','if possible','support']
def lint(s): 
    low=s.lower(); return sorted(w for w in WEAK if re.search(r'\b'+re.escape(w)+r'\b',low))
reqs=['The system shall respond to a search within 2 seconds for 95 percent of requests.','The system shall be user-friendly and fast.','The report shall support export formats as appropriate.','The system shall lock an account after 5 failed logins.']
print('lint',[lint(r) for r in reqs])
print('=== U22.6')
# weakest precondition by substitution; brute-force semantic check
def subst(expr_src,var,repl_src):
    class T(ast.NodeTransformer):
        def visit_Name(s,n): return ast.parse('('+repl_src+')',mode='eval').body if n.id==var else n
    return ast.unparse(T().visit(ast.parse(expr_src,mode='eval')))
def wp(stmt,Q):
    k=stmt[0]
    if k=='assign': return subst(Q,stmt[1],stmt[2])
    if k=='seq':
        for st in reversed(stmt[1]): Q=wp(st,Q)
        return Q
    if k=='if': return '(({c}) and ({a})) or (not ({c}) and ({b}))'.format(c=stmt[1],a=wp(stmt[2],Q),b=wp(stmt[3],Q))
def run(stmt,st):
    k=stmt[0]
    if k=='assign': st[stmt[1]]=eval(stmt[2],{},dict(st))
    elif k=='seq':
        for s_ in stmt[1]: run(s_,st)
    elif k=='if': run(stmt[2] if eval(stmt[1],{},dict(st)) else stmt[3],st)
def rexpr(d=2):
    if d==0 or random.random()<0.3: return random.choice(['x','y','1','2','3'])
    return '(%s %s %s)'%(rexpr(d-1),random.choice('+-*'),rexpr(d-1))
def rstmt(d=2):
    r=random.random()
    if d==0 or r<0.5: return ('assign',random.choice('xy'),rexpr())
    if r<0.75: return ('seq',[rstmt(d-1) for _ in range(random.randint(2,3))])
    return ('if','%s %s %s'%(rexpr(1),random.choice(['<','>','==','<=']),rexpr(1)),rstmt(d-1),rstmt(d-1))
ok=0;tot=0
for _ in range(400):
    S=rstmt(); Q='%s %s %s'%(rexpr(1),random.choice(['<','>','==','<=','>=']),rexpr(1)); W=wp(S,Q)
    for x,y in itertools.product(range(-3,4),repeat=2):
        st={'x':x,'y':y}; pre=eval(W,{},{'x':x,'y':y}); run(S,st); post=eval(Q,{},dict(st)); tot+=1; ok+= bool(pre)==bool(post)
print('wp vs execution: programs 400, states',tot,'agree',ok)
print('wp example', wp(('seq',[('assign','x','x+1'),('assign','y','2*x')]),'y > 4'))
# loop invariant
def sum_loop(n):
    i=0; s=0; checks=0
    while i<n:
        assert s==i*(i+1)//2; i+=1; s+=i; checks+=1
    assert s==n*(n+1)//2 and i==n; return s,checks
print('loop invariant checked n=200',sum_loop(200))
def bad_loop(n):
    i=0; s=0
    while i<n:
        i+=1; s+=i
        if i==150: s+=1
    return s
try:
    i=0
    # invariant violation detection
    n=200; s=0; i=0; violated=None
    while i<n:
        if s!=i*(i+1)//2: violated=i; break
        i+=1; s+=i+(1 if i==150 else 0)
    print('invariant violation first seen at i',violated)
except Exception as e: print(e)
# algebraic spec by term rewriting
CONS={'new','push'}
def norm(t):
    if isinstance(t,tuple):
        t=(t[0],)+tuple(norm(a) for a in t[1:])
        f=t[0]
        if f=='pop' and t[1][0]=='push': return t[1][1]
        if f=='top' and t[1][0]=='push': return t[1][2]
        if f=='isEmpty' and t[1][0]=='new': return 'true'
        if f=='isEmpty' and t[1][0]=='push': return 'false'
        if f=='pop' and t[1]==('new',): return ('error',)
        if f=='top' and t[1]==('new',): return ('error',)
    return t
def terms(depth,vals=(0,1)):
    if depth==0: yield ('new',); return
    for s in terms(depth-1,vals):
        yield s
        for v in vals: yield ('push',s,v)
def ground(depth):
    S=list(set(terms(depth)))
    out=list(S)
    for s in S:
        out+= [('pop',s),('top',s),('isEmpty',s)]
    return out
G=ground(3); print('ground terms depth 3',len(G))
class Impl:
    pass
def ev(t):
    f=t[0]
    if f=='new': return []
    if f=='push': return ev(t[1])+[t[2]]
    if f=='pop': s=ev(t[1]); return s[:-1] if s else 'error'
    if f=='top': s=ev(t[1]); return s[-1] if s else 'error'
    if f=='isEmpty': return 'true' if not ev(t[1]) else 'false'
def toval(n):
    if isinstance(n,tuple):
        if n[0] in ('new','push'): return ev(n)
        if n==('error',): return 'error'
    return n
bad=sum(1 for t in G if toval(norm(t))!=ev(t)); print('rewriting vs list implementation, disagreements',bad)
# incomplete spec: drop error axioms
def norm2(t):
    if isinstance(t,tuple):
        t=(t[0],)+tuple(norm2(a) for a in t[1:]); f=t[0]
        if f=='pop' and t[1][0]=='push': return t[1][1]
        if f=='top' and t[1][0]=='push': return t[1][2]
        if f=='isEmpty' and t[1][0]=='new': return 'true'
        if f=='isEmpty' and t[1][0]=='push': return 'false'
    return t
def stuck(t):
    return isinstance(t,tuple) and (t[0] in ('pop','top','isEmpty') or any(stuck(a) for a in t[1:]))
st=[t for t in G if stuck(norm2(t))]; print('without the error axioms: terms that do not reduce to a constructor or a value',len(st),'examples',st[:2])
print('top(pop(push(push(new,1),2))) ->',norm(('top',('pop',('push',('push',('new',),1),2)))))
print('=== U22.7')
src='''
class Account:
    def __init__(self): self.balance=0; self.owner=None; self.log=[]
    def deposit(self,x): self.balance+=x; self.log.append(x)
    def withdraw(self,x): self.balance-=x; self.log.append(-x)
    def rename(self,n): self.owner=n
    def history(self): return list(self.log)
class Mixed:
    def __init__(self): self.a=1; self.b=2
    def f1(self): return self.a
    def f2(self): return self.a+1
    def g1(self): return self.b
    def g2(self): return self.b*2
'''
def lcom4(cls):
    meth={m.name:{n.attr for n in ast.walk(m) if isinstance(n,ast.Attribute) and isinstance(n.value,ast.Name) and n.value.id=='self'} for m in cls.body if isinstance(m,ast.FunctionDef) and m.name!='__init__'}
    G=nx.Graph(); G.add_nodes_from(meth)
    for a,b in itertools.combinations(meth,2):
        if meth[a]&meth[b]: G.add_edge(a,b)
    return nx.number_connected_components(G)
for c in [n for n in ast.parse(src).body if isinstance(n,ast.ClassDef)]: print('LCOM4',c.name,lcom4(c))
deps={'ui':['service','util'],'service':['repo','util'],'repo':['util'],'util':[]}
for m in deps:
    ce=len(deps[m]); ca=sum(m in v for v in deps.values()); print('instability',m,'Ca',ca,'Ce',ce,round(ce/(ca+ce),3))
fan={'main':(0,3),'parse':(1,2),'eval':(2,1),'util':(3,0)}
print('Henry-Kafura',{k:(a*b)**2 for k,(a,b) in fan.items()})
deps2={'a':['b'],'b':['c'],'c':['a'],'d':['a']}; Gd=nx.DiGraph([(k,v) for k,vs in deps2.items() for v in vs]); print('cycles',[sorted(c) for c in nx.strongly_connected_components(Gd) if len(c)>1])
print('=== U22.8')
# DFD balancing
dfd0={'P':{'in':{'order','payment'},'out':{'receipt','shipment'}}}
dfd1={'P1':{'in':{'order'},'out':{'invoice'}},'P2':{'in':{'invoice','payment'},'out':{'receipt'}},'P3':{'in':{'invoice'},'out':{'shipment'}}}
def balanced(parent,children):
    ins=set().union(*[c['in'] for c in children.values()]); outs=set().union(*[c['out'] for c in children.values()])
    internal=ins&outs; return (ins-internal)==parent['in'],(outs-internal)==parent['out'],internal
print('DFD balance',balanced(dfd0['P'],dfd1))
dfd1b=dict(dfd1); dfd1b['P3']={'in':{'invoice'},'out':{'shipment','label'}}; print('unbalanced',balanced(dfd0['P'],dfd1b))
# JSP
def jsp_report(records):
    out=[]; it=iter(records); cur=next(it,None)
    while cur is not None:           # group* 
        key=cur[0]; tot=0; n=0
        while cur is not None and cur[0]==key:   # record*
            tot+=cur[1]; n+=1; cur=next(it,None)
        out.append((key,n,tot))
    return out
bad=0
for _ in range(300):
    recs=sorted([(random.randint(0,6),random.randint(1,50)) for _ in range(random.randint(0,40))],key=lambda r:r[0])
    ref=[(k,len(g:=list(gr)),sum(a for _,a in g)) for k,gr in itertools.groupby(recs,key=lambda r:r[0])]
    bad+= jsp_report(recs)!=ref
print('JSP-structured report vs itertools.groupby on 300 random files, disagreements',bad,'empty file ->',jsp_report([]))
print('=== U22.9')
DSL='''
class Shape abstract
class Circle : Shape
class Square : Shape
class Order
class Item
Order 1 -> 0..* Item composition
Customer 1 -> 0..* Order
'''
def parse_dsl(t):
    classes={};assoc=[];errs=[]
    for ln in t.strip().split('\n'):
        p=ln.split()
        if p[0]=='class': classes[p[1]]={'parent':p[3] if len(p)>3 and p[2]==':' else None,'abstract':'abstract' in p}
        else: assoc.append((p[0],p[1],p[3],p[4],p[5] if len(p)>5 else 'association'))
    for a in assoc:
        for n in (a[0],a[3]):
            if n not in classes: errs.append('unknown class '+n)
    G=nx.DiGraph([(c,v['parent']) for c,v in classes.items() if v['parent']]); 
    if not nx.is_directed_acyclic_graph(G): errs.append('inheritance cycle')
    return classes,assoc,errs
cl,asoc,errs=parse_dsl(DSL); print('classes',list(cl),'assoc',len(asoc),'errors',errs)
cl2,_,e2=parse_dsl('class A : B\nclass B : A'); print('cycle detected',e2)
trace=[]
def tracer(frame,event,arg):
    if event=='call' and frame.f_code.co_filename=='<demo>':
        caller=frame.f_back.f_code.co_name if frame.f_back and frame.f_back.f_code.co_filename=='<demo>' else 'main'
        trace.append((caller,frame.f_code.co_name))
    return tracer
demo='''
def pay(order): charge(order); notify(order)
def charge(o): validate(o)
def validate(o): return True
def notify(o): return True
def checkout(): pay(1)
'''
ns={}; exec(compile(demo,'<demo>','exec'),ns); sys.settrace(tracer); ns['checkout'](); sys.settrace(None)
print('sequence trace',trace)
