"""B6 recomputation: U14.21, U14.22 and A14.21-A14.22."""
import math, itertools, random
import numpy as np
def ok(c, m):
    print(('OK  ' if c else 'FAIL'), m)
    if not c: raise SystemExit(1)
# ---------- U14.21
# utility-based way partitioning on a 16-way cache: hits per kilo-instruction as a function of ways
hA = [0, 30, 50, 62, 70, 75, 78, 80, 81, 82, 82, 82, 82, 82, 82, 82, 82]   # cache-friendly, saturating
hB = [0, 10, 20, 30, 40, 50, 60, 70, 75, 78, 79, 81, 82, 82, 82, 82, 82]   # needs many ways
best = max(range(1, 16), key=lambda a: hA[a] + hB[16 - a])
ok(best == 7 and hA[7] + hB[9] == 158 and sorted(hA[a] + hB[16 - a] for a in range(1, 16))[-2] < 158, 'UCP optimum unique: 7 ways to A, 9 to B, 158 hits per kilo-instruction')
ok(hA[8] + hB[8] == 156, 'equal split 8/8 gives 156')
# greedy marginal-utility allocation reproduces it on these concave-ish curves
a = b = 1
while a + b < 16:
    if hA[a + 1] - hA[a] >= hB[b + 1] - hB[b]: a += 1
    else: b += 1
ok((a, b) == (7, 9), 'greedy marginal-utility allocation reaches 7/9 here')
ipc_alone = np.array([2.0, 1.0]); ipc_sh = np.array([1.5, 0.5])
ws = (ipc_sh / ipc_alone).sum(); hs = 2 / (ipc_alone / ipc_sh).sum(); sd = ipc_alone / ipc_sh
ok(abs(ws - 1.25) < 1e-12 and abs(hs - 0.6) < 1e-12 and abs(sd.max() / sd.min() - 1.5) < 1e-12, 'weighted speed-up 1.25, harmonic speed-up 0.6, unfairness 1.5')
ia = np.array([3.0, 1.5, 1.0]); isd = np.array([2.0, 1.0, 0.25])
ok(abs(3 / (ia / isd).sum() - 3 / 7) < 1e-12, 'A14.21 NAT: harmonic speed-up 3/7 = 0.4286')
# weighted round-robin arbiter simulation: weights 3:1 under saturation
w = [3, 1]; grants = [0, 0]; seq = [0] * 3 + [1]
for t in range(4000): grants[seq[t % 4]] += 1
ok(grants == [3000, 1000], 'WRR 3:1 gives 75% / 25% of grants')
pos1 = [t for t in range(400) if seq[t % 4] == 1]
ok(max(b - a - 1 for a, b in zip(pos1, pos1[1:])) == 3, 'worst-case wait for flow 1 under WRR 3:1 is the other weight sum, 3 slots')
# ---------- U14.22
P = lambda a, C, V, f: a * C * V * V * f
ok(abs(P(0.1, 50e-9, 1.0, 3e9) - 15.0) < 1e-9, 'dynamic power 0.1*50nF*1V^2*3GHz = 15 W')
ok(abs(0.8 ** 3 - 0.512) < 1e-12 and abs(0.8 ** 2 - 0.64) < 1e-12, 'scale V and f by 0.8: power x0.512, energy per task x0.64')
ok(abs(P(0.1, 50e-9, 0.9, 2.4e9) / P(0.1, 50e-9, 1.0, 3e9) - 0.648) < 1e-12, 'A14.22 MCQ: V 0.9, f 0.8 -> 0.648 of power')
# race-to-idle vs slow: task 3e9 cycles; fast 3GHz/1.0V, slow 1.5GHz/0.7V; leakage 2 W while on, idle 0.1 W over a 2 s window
fast = P(0.1, 50e-9, 1.0, 3e9) * 1 + 2 * 1 + 0.1 * 1
slow = P(0.1, 50e-9, 0.7, 1.5e9) * 2 + 2 * 0.7 * 2
ok(abs(fast - 17.1) < 1e-9 and abs(slow - (7.35 + 2.8)) < 1e-9 and slow < fast, f'DVFS example: race-to-idle {fast:.2f} J vs slow {slow:.2f} J over 2 s (leakage scaled with V)')
fit = 1000 * 64
ok(fit == 64000 and abs(1e9 / fit - 15625) < 1e-9, 'A14.22 NAT: 64 Mbit at 1000 FIT/Mbit = 64000 FIT, MTTF 15625 h')
r = lambda m: next(r for r in range(1, 20) if 2 ** r >= m + r + 1)
ok(r(64) == 7 and r(512) == 10 and r(8) == 4, 'Hamming check bits: 4 for 8, 7 for 64, 10 for 512 data bits; SECDED adds 1 -> (72,64)')
# Hamming SECDED (72,64) encoder/decoder
def enc(data):
    m = len(data); rr = r(m); n = m + rr; code = [0] * (n + 1); j = 0
    for i in range(1, n + 1):
        if i & (i - 1): code[i] = data[j]; j += 1
    for p in range(rr):
        pos = 1 << p; code[pos] = sum(code[i] for i in range(1, n + 1) if i & pos and i != pos) % 2
    overall = sum(code[1:]) % 2
    return code[1:] + [overall]
def dec(cw, m):
    rr = r(m); n = m + rr; code = [0] + cw[:n]; ov = cw[n]
    syn = sum((1 << p) for p in range(rr) if sum(code[i] for i in range(1, n + 1) if i & (1 << p)) % 2)
    par = (sum(code[1:]) + ov) % 2
    if syn == 0 and par == 0: st = 'ok'
    elif par == 1: st = 'corrected'; (code.__setitem__(syn, code[syn] ^ 1) if syn else None)
    else: st = 'double'
    data = [code[i] for i in range(1, n + 1) if i & (i - 1)]
    return st, data
random.seed(9); fine = True
for trial in range(300):
    d = [random.randint(0, 1) for _ in range(64)]; c = enc(d)
    assert len(c) == 72
    e1 = c[:]; k = random.randrange(72); e1[k] ^= 1
    st, dd = dec(e1, 64); fine &= (st == 'corrected' and dd == d)
    e2 = c[:]; k1, k2 = random.sample(range(72), 2); e2[k1] ^= 1; e2[k2] ^= 1
    fine &= dec(e2, 64)[0] == 'double'
    fine &= dec(c, 64) == ('ok', d)
ok(fine, '(72,64) SECDED: all single errors corrected, all double errors detected (300 trials each)')
ok(abs(11 / 512 - 0.0215) < 1e-4 and abs(8 / 64 - 0.125) < 1e-12, 'overhead: 11 bits per 512 (2.1%) vs 8 per 64 (12.5%)')
Rt = lambda R: 3 * R ** 2 - 2 * R ** 3
ok(abs(Rt(0.9) - 0.972) < 1e-12 and Rt(0.4) < 0.4 and abs(Rt(0.5) - 0.5) < 1e-12, 'TMR: 3R^2-2R^3 = 0.972 at R=0.9; worse than simplex below 0.5')
lam = 1 / 1e5
ok(abs(Rt(math.exp(-lam * 1e4)) - 0.9746) < 1e-4 and abs(5 / 6 / lam - 83333.33) < 0.01, 'TMR MTTF = 5/(6 lambda) < 1/lambda although R_TMR > R for short missions')
# prime+probe model in simulation: victim's secret-dependent set access
def leak(partitioned, secret, sets=16):
    probe = set(range(sets))
    if partitioned: return frozenset()            # victim uses its own ways; attacker lines never evicted
    return frozenset({secret % sets})
ok(all(leak(False, s) == {s % 16} for s in range(64)) and len({leak(True, s) for s in range(64)}) == 1, 'prime+probe model: unpartitioned leaks set index of secret; partitioned observation independent of secret')
print('B6 all checks passed')
