import math
N=62**7; n=360e6
print('62^7',N, N/n)
print('pairs',n*n/(2*N),'p_new',n/N)
print('base62 digits for 128 bit', math.ceil(128/math.log2(62)), 7/22)
print('cache', 300*17, 300*17*1e8/1e9,'GB')
print('web servers', 40000/(500*0.7))
for h in (0.9,0.99): print('hit',h,40000*(1-h))
print('slow', 1-0.99**100)
print('bucket', 10+5*4)
print('ingest MB/s',1600*0.5,'Gbps',1600*0.5*8/1000)
print('dict',50000*255/1e6)
print('bidir',2*50**2,50**4)
print('12.7GB x36',1.27e3*10e6/1e9*36)
