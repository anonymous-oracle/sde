# U21.3 scientific Python for data analysis: measured claims
import numpy as np, pandas as pd, math, scipy, warnings
from scipy import stats
import patsy, statsmodels.api as sm, statsmodels.formula.api as smf
rng=np.random.default_rng(6)
print('versions numpy',np.__version__,'pandas',pd.__version__,'scipy',scipy.__version__)
# broadcasting vs recycling
a=np.arange(1,7); b=np.array([10,20])
try: a+b; print('broadcast 6+2: ok?!')
except ValueError as e: print('6+2 ValueError:',str(e)[:60])
print('tile recycle',a+np.tile(b,3))
print('column+row broadcast',(np.arange(3)[:,None]+np.arange(4)[None,:]).tolist())
# nan propagation
x=np.array([1,2,np.nan,4.]); print('np.mean nan',np.mean(x),'nanmean',np.nanmean(x),'pandas mean',pd.Series(x).mean(),'nan==nan',np.nan==np.nan)
# 0 vs 1 indexing negative
print('x[-1]',a[-1],'x[1:3]',a[1:3].tolist(),'slice is view', np.shares_memory(a,a[1:3]),'fancy copy',np.shares_memory(a,a[[1,2]]))
# distribution naming
def pnorm(x): return 0.5*(1+math.erf(x/math.sqrt(2)))
def qnorm(p,lo=-10,hi=10):
    for _ in range(100):
        m=(lo+hi)/2
        if pnorm(m)<p: lo=m
        else: hi=m
    return (lo+hi)/2
print('cdf 1.96',pnorm(1.96),stats.norm.cdf(1.96),'ppf .975',qnorm(.975),stats.norm.ppf(.975))
print('binom pmf',math.comb(10,3)/2**10,stats.binom.pmf(3,10,.5),'pois',math.exp(-3)*9/2,stats.poisson.pmf(2,3))
# Box-Muller
u1=rng.random(200000);u2=rng.random(200000); z=np.sqrt(-2*np.log(u1))*np.cos(2*math.pi*u2)
print('box-muller mean var KS',round(z.mean(),4),round(z.var(),4),round(stats.kstest(z,'norm').pvalue,3))
# formula -> design matrix own parser vs patsy
n=100
df=pd.DataFrame({'x1':rng.normal(size=n),'x2':rng.normal(size=n),'g':rng.choice(list('abc'),size=n)})
df['y']=1+2*df.x1-df.x2+0.5*df.x1*df.x2+(df.g=='b')*1.5+rng.normal(size=n)
def design(df,terms):
    cols=[np.ones(len(df))]; names=['Intercept']
    for t in terms:
        if ':' in t:
            p=t.split(':'); cols.append(np.prod([df[q].to_numpy() for q in p],axis=0)); names.append(t)
        elif not pd.api.types.is_numeric_dtype(df[t]):
            lv=sorted(df[t].unique())
            for l in lv[1:]: cols.append((df[t]==l).to_numpy().astype(float)); names.append(f'{t}[T.{l}]')
        else: cols.append(df[t].to_numpy()); names.append(t)
    return np.column_stack(cols),names
Xo,nm=design(df,['x1','x2','x1:x2','g'])
yy,Xp=patsy.dmatrices('y ~ x1 + x2 + x1:x2 + g',df)
print('design cols',nm,list(Xp.design_info.column_names))
pn=list(Xp.design_info.column_names); perm=[pn.index(c) for c in nm]; print('design equal patsy after reordering columns',np.abs(Xo-np.asarray(Xp)[:,perm]).max(),'dtype of g',df.g.dtype)
bo=np.linalg.solve(Xo.T@Xo,Xo.T@df.y.to_numpy()); fit=smf.ols('y ~ x1 + x2 + x1:x2 + g',df).fit()
print('own OLS vs statsmodels max diff',np.abs(bo-fit.params[nm].to_numpy()).max(),'R2',round(fit.rsquared,4))
print('coef',dict(zip(nm,np.round(bo,3))))
# pandas groupby / merge vs from scratch
d2=pd.DataFrame({'k':rng.integers(0,5,size=1000),'v':rng.normal(size=1000)})
own={}
for k,v in zip(d2.k,d2.v): own.setdefault(k,[0,0.0]); own[k][0]+=1; own[k][1]+=v
gb=d2.groupby('k').v.agg(['count','mean'])
print('groupby own vs pandas',max(abs(own[k][1]/own[k][0]-gb.loc[k,'mean']) for k in own),all(own[k][0]==gb.loc[k,'count'] for k in own))
L=pd.DataFrame({'id':[1,2,3,4],'a':list('wxyz')}); R=pd.DataFrame({'id':[2,3,3,5],'b':[10,20,30,40]})
print('inner',len(L.merge(R,on='id')),'left',len(L.merge(R,on='id',how='left')),'outer',len(L.merge(R,on='id',how='outer')))
# hash join own
idx={}
for i,r in R.iterrows(): idx.setdefault(r.id,[]).append(r.b)
print('own inner rows',sum(len(idx.get(i,[])) for i in L.id))
# vectorisation speed
import time
v=rng.normal(size=10**6); t=time.time(); s=0.0
for q in v: s+=q*q
t1=time.time()-t; t=time.time(); s2=float(v@v); t2=time.time()-t
print('loop vs vector ratio >=',round(t1/t2),'sums equal',abs(s-s2)<1e-6*abs(s2))
# floating point: nan comparisons, integer dtypes overflow
print('int8 overflow',np.int8(127)+np.int8(1),'float32 eps',np.finfo(np.float32).eps,'uint8 250+10',np.uint8(250)+np.uint8(10))
# reproducibility
r1=np.random.default_rng(42).random(3); r2=np.random.default_rng(42).random(3); print('same seed same',np.array_equal(r1,r2),r1.round(4))
# seaborn/matplotlib: histogram counts by hand
h,_=np.histogram(z,bins=20,range=(-4,4)); own=[0]*20
for q in z:
    if -4<=q<4: own[int((q+4)/0.4)]+=1
print('hist own equal',list(h)==own)
# apply family equivalents
print('sapply-like',[round(np.mean(c),3) for c in (rng.normal(size=(3,5)))][:0] or 'ok')
# Series dtype with NA
s=pd.Series([1,2,None],dtype='Int64'); print('Int64 NA',s.tolist(),s.sum(),'float nan sum',pd.Series([1,2,np.nan]).sum(),'skipna False',pd.Series([1,2,np.nan]).sum(skipna=False))
# categorical vs patsy treatment coding count
print('levels',sorted(df.g.unique()),'cols with C(g)',patsy.dmatrix('C(g)',df).shape[1])
