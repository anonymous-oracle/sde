import itertools, random, math, collections
def txns(S): return sorted({t for t, o, x in S if o in 'rw'})
def conflicts(a, b): return a[2] == b[2] and a[1] in 'rw' and b[1] in 'rw' and 'w' in (a[1], b[1]) and a[0] != b[0]
def prec_edges(S):
    E = set()
    for i, a in enumerate(S):
        for b in S[i + 1:]:
            if conflicts(a, b): E.add((a[0], b[0]))
    return E
def acyclic(nodes, E):
    nodes = set(nodes); E = set(E)
    while nodes:
        free = [n for n in nodes if not any(v == n for u, v in E if u in nodes)]
        if not free: return False
        nodes -= set(free)
    return True
def csr(S): return acyclic(txns(S), prec_edges(S))
def view_sig(S):
    last = {}; rf = []; 
    for t, o, x in S:
        if o == 'r': rf.append((t, x, last.get(x, 0)))
        elif o == 'w': last[x] = t
    return frozenset(rf), frozenset(last.items())
def serial_of(S, order):
    return [s for t in order for s in S if s[0] == t and s[1] in 'rw']
def vsr(S):
    sig = view_sig([s for s in S if s[1] in 'rw'])
    return any(view_sig(serial_of(S, o)) == sig for o in itertools.permutations(txns(S)))
def commit_pos(S): return {t: i for i, (t, o, x) in enumerate(S) if o == 'c'}
def recoverable(S):
    cp = commit_pos(S); last = {}
    for i, (t, o, x) in enumerate(S):
        if o == 'w': last[x] = t
        elif o == 'r' and x in last and last[x] != t:
            w = last[x]
            if cp[t] < cp.get(w, 10 ** 9): return False
    return True
def aca(S):
    cp = commit_pos(S); last = {}
    for i, (t, o, x) in enumerate(S):
        if o == 'w': last[x] = t
        elif o == 'r' and x in last and last[x] != t and cp.get(last[x], 10 ** 9) > i: return False
    return True
def strict(S):
    cp = commit_pos(S); last = {}
    for i, (t, o, x) in enumerate(S):
        if o in 'rw' and x in last and last[x] != t and cp.get(last[x], 10 ** 9) > i: return False
        if o == 'w': last[x] = t
    return True
def rand_sched(nt, ops, items):
    seqs = {t: [(t, random.choice('rw'), random.choice(items)) for _ in range(ops)] + [(t, 'c', '')] for t in range(1, nt + 1)}
    S = []; idx = {t: 0 for t in seqs}
    while any(idx[t] < len(seqs[t]) for t in seqs):
        t = random.choice([t for t in seqs if idx[t] < len(seqs[t])]); S.append(seqs[t][idx[t]]); idx[t] += 1
    return S
random.seed(2); cnt = collections.Counter()
for _ in range(20000):
    S = rand_sched(3, 2, 'xy'); a, b = csr(S), vsr(S); r, c, s = recoverable(S), aca(S), strict(S)
    assert (not a) or b, 'CSR must imply VSR'; assert (not s) or c; assert (not c) or r
    cnt['csr'] += a; cnt['vsr'] += b; cnt['rec'] += r; cnt['aca'] += c; cnt['strict'] += s; cnt['n'] += 1
print('hierarchy holds on 20000 random schedules', dict(cnt))
S = [(1, 'r', 'x'), (2, 'w', 'x'), (1, 'w', 'x'), (3, 'w', 'x'), (1, 'c', ''), (2, 'c', ''), (3, 'c', '')]
print('blind-write example: CSR', csr(S), 'VSR', vsr(S))
# interleavings count for two transactions
def inter(a, b):
    if not a: yield list(b); return
    if not b: yield list(a); return
    for r in inter(a[1:], b): yield [a[0]] + r
    for r in inter(a, b[1:]): yield [b[0]] + r
for name, T1, T2 in [('r1x w1y / r2y w2x', [(1, 'r', 'x'), (1, 'w', 'y')], [(2, 'r', 'y'), (2, 'w', 'x')]),
                     ('r1x w1x / r2x w2x', [(1, 'r', 'x'), (1, 'w', 'x')], [(2, 'r', 'x'), (2, 'w', 'x')]),
                     ('r1x w1y / r2x w2y', [(1, 'r', 'x'), (1, 'w', 'y')], [(2, 'r', 'x'), (2, 'w', 'y')]),
                     ('r1x r1y w1x / r2x w2y', [(1, 'r', 'x'), (1, 'r', 'y'), (1, 'w', 'x')], [(2, 'r', 'x'), (2, 'w', 'y')])]:
    allS = list(inter(T1, T2)); print(name, 'interleavings', len(allS), 'CSR', sum(csr(S) for S in allS), 'VSR', sum(vsr(S) for S in allS))
# timestamp ordering
def to(S, ts, thomas):
    R = collections.defaultdict(int); W = collections.defaultdict(int); ab = set(); ign = 0
    for t, o, x in S:
        if t in ab: continue
        if o == 'r':
            if ts[t] < W[x]: ab.add(t)
            else: R[x] = max(R[x], ts[t])
        elif o == 'w':
            if ts[t] < R[x]: ab.add(t)
            elif ts[t] < W[x]:
                if thomas: ign += 1
                else: ab.add(t)
            else: W[x] = ts[t]
    return ab, ign
S = [(3, 'w', 'x'), (2, 'w', 'x'), (1, 'w', 'x')]
print('TO basic aborts', to(S, {1: 1, 2: 2, 3: 3}, False), 'Thomas', to(S, {1: 1, 2: 2, 3: 3}, True))
# TO produces schedules serializable in timestamp order (committed txns)
ok = 0
for _ in range(3000):
    S = [s for s in rand_sched(3, 3, 'xy') if s[1] != 'c']; ts = {1: 1, 2: 2, 3: 3}; ab, _ = to(S, ts, False)
    kept = [s for s in S if s[0] not in ab]
    order = sorted({t for t, o, x in kept}); ser = serial_of(kept, order)
    # conflict-equivalent to the serial order: every conflicting pair keeps timestamp order
    assert all(ts[a[0]] < ts[b[0]] for i, a in enumerate(kept) for b in kept[i + 1:] if conflicts(a, b)); ok += 1
print('TO keeps conflict order = timestamp order (3000 random)', ok)
# multigranularity matrix
M = {'IS': {'IS', 'IX', 'S', 'SIX'}, 'IX': {'IS', 'IX'}, 'S': {'IS', 'S'}, 'SIX': {'IS'}, 'X': set()}
assert all((b in M[a]) == (a in M[b]) for a in M for b in M); print('compatible ordered pairs', sum(len(v) for v in M.values()))
# wait-die / wound-wait vs plain waiting: deadlock frequency
def run(policy, seed, ntx=4, nitems=3):
    rnd = random.Random(seed); ts = {t: t for t in range(ntx)}
    plans = {t: rnd.sample(range(nitems), 2) for t in range(ntx)}
    holder = {}; waits = {}; pos = {t: 0 for t in range(ntx)}; dead = False; aborts = 0
    for step in range(200):
        runnable = [t for t in range(ntx) if pos[t] < 2 and t not in waits]
        if not runnable:
            if all(pos[t] >= 2 for t in range(ntx)): break
            wf = {(t, holder[i]) for t, i in waits.items()}; 
            if not acyclic(range(ntx), wf): return 'deadlock', aborts
            break
        t = rnd.choice(runnable); i = plans[t][pos[t]]
        if i not in holder or holder[i] == t: holder[i] = t; pos[t] += 1
        else:
            h = holder[i]
            if policy == 'wait': waits[t] = i
            elif policy == 'wait-die':
                if ts[t] < ts[h]: waits[t] = i
                else:
                    aborts += 1; pos[t] = 0
                    for k in [k for k, v in holder.items() if v == t]: del holder[k]
            else:
                if ts[t] < ts[h]:
                    aborts += 1; pos[h] = 0
                    for k in [k for k, v in holder.items() if v == h]: del holder[k]
                    waits.pop(h, None); holder[i] = t; pos[t] += 1
                else: waits[t] = i
        # release finished
        for u in range(ntx):
            if pos[u] >= 2:
                for k in [k for k, v in holder.items() if v == u]: del holder[k]
        for u in list(waits):
            if waits[u] not in holder: i2 = waits.pop(u)
    return 'ok', aborts
res = {p: collections.Counter(run(p, s)[0] for s in range(3000)) for p in ('wait', 'wait-die', 'wound-wait')}
print(res)
# min victims
def min_victims(E, nodes):
    for k in range(len(nodes) + 1):
        for V in itertools.combinations(nodes, k):
            if acyclic(set(nodes) - set(V), {(u, v) for u, v in E if u not in V and v not in V}): return k
print('min victims', min_victims({(1, 2), (2, 3), (3, 1), (2, 4), (4, 2)}, [1, 2, 3, 4]))
