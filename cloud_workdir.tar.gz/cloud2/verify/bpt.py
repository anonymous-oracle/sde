import math, random, bisect
class BPT:
    def __init__(s, m): s.m = m; s.root = {'leaf': True, 'k': [], 'c': []}; s.h = 1
    def _ins(s, node, key):
        m = s.m
        if node['leaf']:
            i = bisect.bisect_left(node['k'], key)
            if i < len(node['k']) and node['k'][i] == key: return None
            node['k'].insert(i, key)
            if len(node['k']) > m - 1:
                mid = len(node['k']) // 2; r = {'leaf': True, 'k': node['k'][mid:], 'c': []}; node['k'] = node['k'][:mid]; return r['k'][0], r
            return None
        i = bisect.bisect_right(node['k'], key); res = s._ins(node['c'][i], key)
        if res:
            k, r = res; node['k'].insert(i, k); node['c'].insert(i + 1, r)
            if len(node['c']) > m:
                mid = len(node['k']) // 2; up = node['k'][mid]
                r2 = {'leaf': False, 'k': node['k'][mid + 1:], 'c': node['c'][mid + 1:]}; node['k'] = node['k'][:mid]; node['c'] = node['c'][:mid + 1]; return up, r2
        return None
    def insert(s, key):
        res = s._ins(s.root, key)
        if res:
            k, r = res; s.root = {'leaf': False, 'k': [k], 'c': [s.root, r]}; s.h += 1
    def check(s):
        m = s.m; leaves = []
        def go(node, depth, root):
            if node['leaf']:
                assert root or len(node['k']) >= math.ceil((m - 1) / 2), 'leaf underfull'
                assert len(node['k']) <= m - 1; leaves.append(depth); return
            assert len(node['c']) == len(node['k']) + 1 and len(node['c']) <= m
            assert len(node['c']) >= (2 if root else math.ceil(m / 2)), 'internal underfull'
            for c in node['c']: go(c, depth + 1, False)
        go(s.root, 1, True); assert len(set(leaves)) == 1 and leaves[0] == s.h
def hbounds(n, m):
    hmin = 1
    while (m - 1) * m ** (hmin - 1) < n: hmin += 1
    h = 1 if n <= m - 1 else None
    hmax = 1
    if n > m - 1:
        hmax = 2
        while 2 * math.ceil(m / 2) ** (hmax - 1 - 1) * math.ceil((m - 1) / 2) <= n: hmax += 1
        hmax -= 1
    return hmin, hmax
if __name__ == '__main__':
    random.seed(5)
    for m in (4, 5, 8):
        for order in ('random', 'asc'):
            t = BPT(m); keys = random.sample(range(10 ** 6), 20000) if order == 'random' else list(range(20000))
            for k in keys: t.insert(k)
            t.check(); lo, hi = hbounds(20000, m); assert lo <= t.h <= hi, (m, order, t.h, lo, hi); print('m', m, order, 'h', t.h, 'bounds', lo, hi)
    print('n=1e6 m=200', hbounds(10 ** 6, 200), ' n=1e9 m=200', hbounds(10 ** 9, 200), ' n=1e6 m=100', hbounds(10 ** 6, 100))
