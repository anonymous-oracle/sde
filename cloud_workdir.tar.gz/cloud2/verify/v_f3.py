import numpy as np, math, itertools
from scipy import stats, special, integrate, optimize
from sklearn.metrics import roc_auc_score
rng=np.random.default_rng(3)
def say(*a): print(*a)
# U19.1
say('gauss integral',integrate.quad(lambda x:math.exp(-x*x/2),-np.inf,np.inf)[0],math.sqrt(2*math.pi),'sumC',sum(math.comb(10,k) for k in range(11)))
# U19.2
x=rng.exponential(2,10000); w_m=0;M2=0
for i,v in enumerate(x,1):
    d=v-w_m; w_m+=d/i; M2+=d*(v-w_m)
say('welford',M2/(len(x)-1),np.var(x,ddof=1))
big=1e9+rng.normal(size=1000); naive=(np.sum(big**2)-len(big)*np.mean(big)**2)/(len(big)-1); say('naive var cancellation',naive,'two-pass',np.var(big,ddof=1))
say('frac beyond 2sd exp',np.mean(np.abs(x-x.mean())>2*x.std()),'chebyshev bound 0.25')
q1,q3=np.percentile(x,[25,75]); say('IQR rule outlier frac',np.mean((x>q3+1.5*(q3-q1))|(x<q1-1.5*(q3-q1))))
ln=rng.lognormal(0,1,100000); say('lognormal mean/median',ln.mean(),np.median(ln),'theory',math.exp(.5),1)
# U19.3
pre,sens,fpr=0.01,0.90,0.05; post=pre*sens/(pre*sens+(1-pre)*fpr); say('posterior test',post)
say('birthday 23',1-math.prod((365-i)/365 for i in range(23)))
n,p=1000,0.003; say('bin vs poisson k=5',stats.binom.pmf(5,n,p),stats.poisson.pmf(5,n*p),'k=0',stats.binom.pmf(0,n,p),stats.poisson.pmf(0,n*p))
m=np.array([rng.exponential(1,30).mean() for _ in range(100000)]); z=(m-1)/(1/math.sqrt(30)); say('CLT P(z<1.96) exp n=30',np.mean(z<1.96),'normal',stats.norm.cdf(1.96),'P(z<-1.96)',np.mean(z<-1.96))
say('binom mean var',stats.binom.stats(20,0.3))
# LLN
say('LLN',[abs(rng.binomial(10**k,0.3)/10**k-0.3) for k in (2,4,6)])
say('Markov/Chebyshev',1/4)
# U19.4
cov_t=0;cov_z=0;T=100000
xs=rng.normal(5,2,size=(T,10)); mm=xs.mean(1); ss=xs.std(1,ddof=1); se=ss/math.sqrt(10)
tc=stats.t.ppf(.975,9); say('t crit',tc)
say('coverage t',np.mean(np.abs(mm-5)<=tc*se),'z with s',np.mean(np.abs(mm-5)<=1.96*se))
xe=rng.exponential(1,size=(T,10)); me=xe.mean(1); se_=xe.std(1,ddof=1)/math.sqrt(10); say('coverage t exp n=10',np.mean(np.abs(me-1)<=tc*se_))
xe=rng.exponential(1,size=(T//5,100)); me=xe.mean(1); se_=xe.std(1,ddof=1)/10; say('coverage t exp n=100',np.mean(np.abs(me-1)<=1.984*se_))
say('SE quad',2/math.sqrt(25),2/math.sqrt(100))
# bootstrap coverage for median? simply bootstrap SE of mean vs formula
d=rng.exponential(1,50); bs=np.array([rng.choice(d,50).mean() for _ in range(5000)]); say('bootstrap SE',bs.std(),'formula',d.std(ddof=1)/math.sqrt(50))
# U19.5
rej=0;T=100000
xs=rng.normal(0,1,size=(T,25)); t=xs.mean(1)/(xs.std(1,ddof=1)/5); say('type I',np.mean(np.abs(t)>stats.t.ppf(.975,24)))
say('power z n=32 d=.5',stats.norm.cdf(0.5*math.sqrt(32)-1.96)+stats.norm.cdf(-0.5*math.sqrt(32)-1.96))
xs=rng.normal(0.5,1,size=(T,32)); t=xs.mean(1)/(xs.std(1,ddof=1)/math.sqrt(32)); say('power t sim',np.mean(np.abs(t)>stats.t.ppf(.975,31)))
say('FWER 20',1-0.95**20,'bonf alpha',0.05/20,'FWER bonf',1-(1-0.0025)**20)
# BH sim: 1000 tests, 900 null 100 alt effect 3
pv=np.concatenate([rng.uniform(size=900),stats.norm.sf(rng.normal(3,1,100))]); lab=np.r_[np.zeros(900),np.ones(100)]
o=np.argsort(pv); k=np.max(np.where(pv[o]<=0.05*np.arange(1,1001)/1000)[0]); sel=o[:k+1]; say('BH rejects',len(sel),'false disc',np.mean(lab[sel]==0),'uncorrected rejects',np.sum(pv<.05),'false frac',np.mean(lab[pv<.05]==0),'bonf rejects',np.sum(pv<0.05/1000))
# U19.6
T=20000; fp_pool=0;fp_welch=0
for _ in range(T):
    a=rng.normal(0,1,10); b=rng.normal(0,4,40)
    fp_pool+= stats.ttest_ind(a,b,equal_var=True).pvalue<0.05; fp_welch+= stats.ttest_ind(a,b,equal_var=False).pvalue<0.05
say('pooled FP',fp_pool/T,'welch FP',fp_welch/T)
a=rng.normal(0,1,15);b=rng.normal(0.8,1,15); t=stats.ttest_ind(a,b); F=stats.f_oneway(a,b); say('t^2 vs F',t.statistic**2,F.statistic)
g=[rng.normal(m,1,12) for m in (0,0.5,1.0)]; allv=np.concatenate(g); gm=allv.mean(); SSB=sum(len(x)*(x.mean()-gm)**2 for x in g); SSW=sum(((x-x.mean())**2).sum() for x in g); say('SST',((allv-gm)**2).sum(),SSB+SSW,'F',(SSB/2)/(SSW/33),stats.f_oneway(*g).statistic)
# two-way balanced
a_,b_,r=3,2,6; mu=np.array([[0,1],[1,0],[2,2]]); Y=mu[:,:,None]+rng.normal(size=(a_,b_,r)); gm=Y.mean(); A=Y.mean((1,2)); B=Y.mean((0,2)); AB=Y.mean(2)
SSA=b_*r*((A-gm)**2).sum(); SSB2=a_*r*((B-gm)**2).sum(); SSAB=r*((AB-A[:,None]-B[None,:]+gm)**2).sum(); SSE=((Y-AB[:,:,None])**2).sum(); SST=((Y-gm)**2).sum(); say('twoway',SST,SSA+SSB2+SSAB+SSE,'df',a_*b_*r-1,(a_-1)+(b_-1)+(a_-1)*(b_-1)+a_*b_*(r-1))
# U19.7
x=rng.normal(size=100); y=2+1.5*x+rng.normal(size=100); b1=np.cov(x,y)[0,1]/np.var(x,ddof=1); r_=np.corrcoef(x,y)[0,1]
Xd=np.c_[np.ones(100),x]; beta=np.linalg.lstsq(Xd,y,rcond=None)[0]; res=y-Xd@beta; R2=1-res@res/np.sum((y-y.mean())**2); say('slope',b1,beta[1],'R2',R2,r_**2)
H=Xd@np.linalg.inv(Xd.T@Xd)@Xd.T; say('leverage sum',np.trace(H))
x1=rng.normal(size=200); x2=0.95*x1+math.sqrt(1-0.95**2)*rng.normal(size=200); r12=np.corrcoef(x1,x2)[0,1]; say('VIF',1/(1-r12**2),'rho',r12)
yy=1+x1+x2+rng.normal(size=200); X2=np.c_[np.ones(200),x1,x2]; cov=np.linalg.inv(X2.T@X2); b=cov@X2.T@yy; s2=((yy-X2@b)**2).sum()/197; say('coef se',np.sqrt(s2*np.diag(cov)))
X1=np.c_[np.ones(200),x1]; b1_=np.linalg.lstsq(X1,yy,rcond=None)[0]; cov1=np.linalg.inv(X1.T@X1); s21=((yy-X1@b1_)**2).sum()/198; say('simple se',np.sqrt(s21*np.diag(cov1)))
# AIC choose polynomial degree
xp=rng.uniform(-2,2,60); yp=1+xp-0.5*xp**2+rng.normal(0,.5,60)
for dgr in range(1,7):
    P=np.vander(xp,dgr+1); b=np.linalg.lstsq(P,yp,rcond=None)[0]; rss=((yp-P@b)**2).sum(); n=60; k=dgr+2
    say('deg',dgr,'RSS',round(rss,2),'AIC',round(n*math.log(rss/n)+2*k,2),'BIC',round(n*math.log(rss/n)+k*math.log(n),2))
# U19.8
k,n=7,10; say('bern mle',k/n)
xs=rng.normal(3,2,size=(100000,5)); say('MLE var bias',np.mean(xs.var(1)),'(n-1)/n *4',4*4/5)
Xl=np.c_[np.ones(500),rng.normal(size=(500,2))]; wtrue=np.array([-0.5,1.0,-2.0]); yl=(rng.random(500)<1/(1+np.exp(-Xl@wtrue))).astype(float)
w=np.zeros(3)
for it in range(10):
    p=1/(1+np.exp(-Xl@w)); W=p*(1-p); w=w+np.linalg.solve(Xl.T@(Xl*W[:,None]),Xl.T@(yl-p))
    if it in (0,1,2,3,4): print(' irls it',it,np.round(w,4))
from sklearn.linear_model import LogisticRegression
sk=LogisticRegression(penalty=None,fit_intercept=False,max_iter=1000).fit(Xl,yl); say('IRLS vs sklearn',w,sk.coef_[0])
say('odds ratio e^1',math.exp(1.0),'e^0.693',math.exp(math.log(2)))
sc=Xl@w; pairs=np.mean([(a>b)+0.5*(a==b) for a in sc[yl==1] for b in sc[yl==0]]) if False else None
pos=sc[yl==1];neg=sc[yl==0]; auc_pairs=(pos[:,None]>neg[None,:]).mean(); say('AUC pairs',auc_pairs,'sklearn',roc_auc_score(yl,sc),'U stat',stats.mannwhitneyu(pos,neg).statistic/(len(pos)*len(neg)))
say('prevalence',yl.mean())
# U19.9
tab=np.array([[30,20],[20,30]]); c=stats.chi2_contingency(tab,correction=False); say('chi2 2x2',c.statistic,c.pvalue,'z',(30/50-20/50)/math.sqrt(0.5*0.5*(1/50+1/50)),'z^2',((0.6-0.4)/math.sqrt(0.25*(2/50)))**2)
obs=np.array([8,12,9,11,14,6]); say('die gof',stats.chisquare(obs).statistic,stats.chisquare(obs).pvalue)
from sklearn.datasets import make_blobs, make_moons
from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
from sklearn.metrics import silhouette_score, adjusted_rand_score
Xb,yb=make_blobs(300,centers=3,cluster_std=0.6,random_state=1)
for kk in (2,3,4,5): say('silhouette k',kk,silhouette_score(Xb,KMeans(kk,n_init=10,random_state=0).fit_predict(Xb)))
Xm,ym=make_moons(300,noise=0.06,random_state=0)
say('moons ARI kmeans',adjusted_rand_score(ym,KMeans(2,n_init=10,random_state=0).fit_predict(Xm)),'single',adjusted_rand_score(ym,AgglomerativeClustering(2,linkage='single').fit_predict(Xm)),'complete',adjusted_rand_score(ym,AgglomerativeClustering(2,linkage='complete').fit_predict(Xm)),'dbscan',adjusted_rand_score(ym,DBSCAN(eps=0.2,min_samples=5).fit_predict(Xm)))
# outliers masking
xo=np.r_[rng.normal(0,1,50),[8,9,10]]; z=(xo-xo.mean())/xo.std(ddof=1); say('z-score flagged',np.sum(np.abs(z)>3)); med=np.median(xo);mad=np.median(np.abs(xo-med)); rz=0.6745*(xo-med)/mad; say('robust flagged',np.sum(np.abs(rz)>3.5))
# U19.10
def gini(p): return 1-sum(q*q for q in p)
def ent(p): return -sum(q*math.log2(q) for q in p if q>0)
say('gini .5',gini([.5,.5]),'ent',ent([.5,.5]),'gini perfect',gini([1,0]))
# split gain example: parent 10/10, left 8/2 right 2/8
par=gini([.5,.5]); l=gini([.8,.2]); r=gini([.2,.8]); say('gini gain',par-(0.5*l+0.5*r),'ent gain',ent([.5,.5])-(0.5*ent([.8,.2])+0.5*ent([.2,.8])))
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
Xt=rng.normal(size=(600,6)); yt=((Xt[:,0]+0.5*Xt[:,1]*Xt[:,2]+rng.normal(0,0.8,600))>0).astype(int)
Xtr,Xte,ytr,yte=train_test_split(Xt,yt,test_size=0.5,random_state=0)
full=DecisionTreeClassifier(random_state=0).fit(Xtr,ytr); say('full tree train/test',full.score(Xtr,ytr),full.score(Xte,yte),'leaves',full.get_n_leaves())
path=full.cost_complexity_pruning_path(Xtr,ytr); best=None
for a in path.ccp_alphas:
    t=DecisionTreeClassifier(random_state=0,ccp_alpha=a).fit(Xtr,ytr); s=t.score(Xte,yte)
    if best is None or s>best[0]: best=(s,a,t.get_n_leaves())
say('pruned best test acc',best)
# U19.11
d=6; say('rules d=6',3**d-2**(d+1)+1,'itemsets',2**d-1)
cnt=0
items=range(d)
for r_ in range(1,d+1):
    for S in itertools.combinations(items,r_):
        cnt+= 2**r_-2
say('rules by enumeration',cnt)
T=[{'bread','milk'},{'bread','diaper','beer','eggs'},{'milk','diaper','beer','cola'},{'bread','milk','diaper','beer'},{'bread','milk','diaper','cola'}]
def supp(S): return sum(S<=t for t in T)/len(T)
for A,B in [({'diaper'},{'beer'}),({'milk','diaper'},{'beer'}),({'bread','milk'},{'diaper'})]:
    s=supp(A|B); c=s/supp(A); say('rule',A,B,'supp',s,'conf',c,'lift',c/supp(B))
def apriori(T,minsup):
    items=sorted(set().union(*T)); L=[]; Ck=[frozenset([i]) for i in items]; ncand=len(Ck); allc=0
    freq=[]
    while Ck:
        allc+=len(Ck); Lk=[c for c in Ck if sum(c<=t for t in T)>=minsup]; freq+=Lk
        Ck=set(); 
        for a in Lk:
            for b in Lk:
                u=a|b
                if len(u)==len(a)+1 and all(frozenset(s) in set(Lk) for s in itertools.combinations(u,len(a))): Ck.add(u)
        Ck=list(Ck)
    return freq,allc
fr,allc=apriori(T,3); say('apriori frequent count',len(fr),'candidates counted',allc,'total itemsets',2**6-1,[sorted(f) for f in fr if len(f)>=2])
# U19.12
from sklearn.neighbors import KNeighborsClassifier
for dim in (2,10,100,1000):
    Xq=rng.random(size=(500,dim)); dd=np.linalg.norm(Xq[1:]-Xq[0],axis=1); say('dist ratio max/min dim',dim,dd.max()/dd.min())
Xg=np.vstack([rng.normal(0,1,size=(1000,2)),rng.normal(1.5,1,size=(1000,2))]); yg=np.r_[np.zeros(1000),np.ones(1000)]
bayes=stats.norm.cdf(-1.5*math.sqrt(2)/2); say('bayes err',bayes)
Xte2=np.vstack([rng.normal(0,1,size=(20000,2)),rng.normal(1.5,1,size=(20000,2))]); yte2=np.r_[np.zeros(20000),np.ones(20000)]
for kk in (1,5,25,101): say('knn',kk,1-KNeighborsClassifier(kk).fit(Xg,yg).score(Xte2,yte2))
# NB toy with Laplace
spam=['buy now cheap','cheap pills buy','win cash now']; ham=['meeting at noon','lunch at noon now']
V=set(' '.join(spam+ham).split()); ws=' '.join(spam).split(); wh=' '.join(ham).split()
def lp(word,words): return (words.count(word)+1)/(len(words)+len(V))
msg='cheap now'.split(); ls=math.log(len(spam)/5)+sum(math.log(lp(w,ws)) for w in msg); lh=math.log(len(ham)/5)+sum(math.log(lp(w,wh)) for w in msg); say('NB log spam,ham',ls,lh,'P(spam)',1/(1+math.exp(lh-ls)),'V',len(V))
# U19.13
say('accuracy paradox',0.99)
from sklearn.model_selection import cross_val_score, StratifiedKFold
sc_=cross_val_score(DecisionTreeClassifier(max_depth=3,random_state=0),Xt,yt,cv=StratifiedKFold(5,shuffle=True,random_state=0)); say('cv scores',sc_,sc_.mean(),sc_.std())
# imbalanced case
n=10000; yb=(rng.random(n)<0.02).astype(int); Xc=rng.normal(size=(n,3)); Xc[:,0]+=1.2*yb; Xc[:,1]+=0.6*yb
Xa,Xb_,ya,yb_=train_test_split(Xc,yb,test_size=0.5,random_state=0,stratify=yb); lr=LogisticRegression().fit(Xa,ya); pr=lr.predict_proba(Xb_)[:,1]
from sklearn.metrics import precision_score,recall_score,f1_score,average_precision_score
for th in (0.5,0.1,0.05): pred=(pr>th).astype(int); say('th',th,'acc',np.mean(pred==yb_),'prec',precision_score(yb_,pred,zero_division=0),'rec',recall_score(yb_,pred),'f1',f1_score(yb_,pred))
say('AUC',roc_auc_score(yb_,pr),'AP',average_precision_score(yb_,pr),'base rate',yb_.mean())
# sequences PrefixSpan simple (items single)
S=[list('abcb'),list('abbc'),list('acbc'),list('bcab')]
def subseq(p,s):
    i=0
    for x in s:
        if i<len(p) and x==p[i]: i+=1
    return i==len(p)
minsup=3; freq=[]
def ps(prefix,db):
    cnt={}
    for s in db:
        for x in set(s): cnt[x]=cnt.get(x,0)+1
    for x,c in sorted(cnt.items()):
        if c>=minsup:
            p=prefix+[x]; freq.append(''.join(p)); proj=[s[s.index(x)+1:] for s in db if x in s]; ps(p,proj)
ps([],S)
brute=[]
for L in range(1,5):
    for p in itertools.product('abc',repeat=L):
        if sum(subseq(list(p),s) for s in S)>=minsup: brute.append(''.join(p))
say('prefixspan',sorted(freq),'brute',sorted(brute),sorted(freq)==sorted(brute))
# U19.14
a,b=1+7,1+3; say('Beta(8,4) mean',a/(a+b),'CI',stats.beta.ppf([.025,.975],a,b),'mode',(a-1)/(a+b-2))
grid=np.linspace(0,1,1001); post=grid**7*(1-grid)**3; post/=np.trapezoid(post,grid); gm=np.trapezoid(grid*post,grid); cdf=np.cumsum(post)/np.sum(post); say('grid mean',gm,'grid 95',grid[np.searchsorted(cdf,.025)],grid[np.searchsorted(cdf,.975)])
say('prior beta(10,10) post mean',(10+7)/(20+10),'post predictive next 3 heads of 3',stats.betabinom.pmf(3,3,8,4))
y=np.array([1.2,0.8,1.9,1.4,0.7]); s=1.0; m0,t0=0,2.0; prec=1/t0**2+len(y)/s**2; pm=(m0/t0**2+y.sum()/s**2)/prec; say('normal-normal',pm,math.sqrt(1/prec),'mle',y.mean())
# gamma-poisson
say('gamma-poisson',(2+14)/(1+5),'post var',(2+14)/(1+5)**2)
# Laplace approx beta(8,4)
mode=7/10; v=1/(7/mode**2+3/(1-mode)**2); say('laplace sd',math.sqrt(v),'exact sd',stats.beta.std(8,4))
# U19.15
def rwm(logp,x0,scale,n,rng):
    x=np.array(x0,float);lp=logp(x);ch=[];acc=0
    for _ in range(n):
        y=x+scale*rng.normal(size=x.shape);lq=logp(y)
        if math.log(rng.random())<lq-lp: x,lp=y,lq;acc+=1
        ch.append(x.copy())
    return np.array(ch),acc/n
def ess(x):
    x=x-x.mean(); n=len(x); f=np.fft.rfft(x,2*n); ac=np.fft.irfft(f*np.conj(f))[:n]; ac/=ac[0]
    s=0
    for t in range(1,n-1,2):
        pr=ac[t]+ac[t+1]
        if pr<0: break
        s+=pr
    return n/(1+2*(sum([ac[1]]) if False else 0)+2*(s-0)) if False else n/(-1+2*(1+s))
d=20; logp=lambda x:-0.5*x@x
ch,acc=rwm(logp,np.zeros(d),2.38/math.sqrt(d),20000,rng); say('RWM d=20 acc',acc,'ESS coord0',ess(ch[:,0]))
ch2,acc2=rwm(logp,np.zeros(d),0.1,20000,rng); say('too small scale acc',acc2,'ESS',ess(ch2[:,0])); ch3,acc3=rwm(logp,np.zeros(d),3.0,20000,rng); say('too big',acc3,'ESS',ess(ch3[:,0]))
def hmc(grad,logp,x0,eps,L,n,rng):
    x=np.array(x0,float);ch=[];acc=0;maxdH=0
    for _ in range(n):
        p=rng.normal(size=x.shape);xn=x.copy();pn=p.copy(); H0=-logp(x)+0.5*p@p
        pn+=0.5*eps*grad(xn)
        for i in range(L):
            xn+=eps*pn
            if i<L-1: pn+=eps*grad(xn)
        pn+=0.5*eps*grad(xn); H1=-logp(xn)+0.5*pn@pn; maxdH=max(maxdH,abs(H1-H0))
        if math.log(rng.random())<H0-H1: x=xn;acc+=1
        ch.append(x.copy())
    return np.array(ch),acc/n,maxdH
chh,acch,mdh=hmc(lambda x:-x,logp,np.zeros(d),0.3,10,5000,rng); say('HMC d=20 acc',acch,'ESS',ess(chh[:,0]),'maxdH',mdh,'grads',5000*11)
# correlated gaussian rho=.95 d=2
Sg=np.array([[1,.95],[.95,1]]);Si=np.linalg.inv(Sg); lpc=lambda x:-0.5*x@Si@x
chr_,accr=rwm(lpc,np.zeros(2),0.5,20000,rng); say('RWM rho .95 acc',accr,'ESS',ess(chr_[:,0]))
chh2,acch2,_=hmc(lambda x:-Si@x,lpc,np.zeros(2),0.15,15,5000,rng); say('HMC rho .95 acc',acch2,'ESS',ess(chh2[:,0]))
# rhat
def rhat(chains):
    m,n=chains.shape; W=chains.var(1,ddof=1).mean(); B=n*chains.mean(1).var(ddof=1); return math.sqrt(((n-1)/n*W+B/n)/W)
logbeta=lambda x:(7*math.log(x[0])+3*math.log(1-x[0])) if 0<x[0]<1 else -np.inf
chs=[];
for st in (0.1,0.3,0.7,0.9):
    c,a=rwm(logbeta,[st],0.15,4000,rng); chs.append(c[1000:,0])
chs=np.array(chs); say('rhat beta chains',rhat(chs),'mean',chs.mean(),'sd',chs.std(),'exact',8/12,stats.beta.std(8,4),'rhat bad short',rhat(np.array([rwm(logbeta,[st],0.01,500,rng)[0][:,0] for st in (0.1,0.9,0.1,0.9)])))
# U19.16
Xr=np.c_[np.ones(50),rng.normal(size=(50,3))]; yr=Xr@np.array([1,2,-1,0.5])+rng.normal(0,1,50); s2=1.0;tau2=0.5; lam=s2/tau2
pm=np.linalg.solve(Xr.T@Xr+lam*np.eye(4),Xr.T@yr); rg=np.linalg.solve(Xr.T@Xr+lam*np.eye(4),Xr.T@yr); say('posterior mean = ridge',np.abs(pm-rg).max(),'lam',lam)
yj=np.array([28,8,-3,7,-1,1,18,12.]); sj=np.array([15,10,16,11,9,11,10,18.])
tau=np.linspace(1e-4,40,8000)
def margmu(t):
    w=1/(sj**2+t**2); mu=(w*yj).sum()/w.sum(); V=1/w.sum(); return mu,V,w
logpt=[]
for t in tau:
    mu,V,w=margmu(t); logpt.append(0.5*math.log(V)-0.5*np.sum(np.log(sj**2+t**2))-0.5*np.sum((yj-mu)**2*w))
logpt=np.array(logpt); pt=np.exp(logpt-logpt.max()); pt/=np.trapezoid(pt,tau)
cdf=np.cumsum(pt)*(tau[1]-tau[0]); say('tau median',tau[np.searchsorted(cdf,.5)],'95%',tau[np.searchsorted(cdf,.95)],'mean',np.trapezoid(tau*pt,tau))
th=np.zeros(8)
for t,pw in zip(tau,pt):
    mu,V,w=margmu(t); B=sj**2/(sj**2+t**2); th+=pw*(1-B)*yj*(tau[1]-tau[0])+pw*B*mu*(tau[1]-tau[0])
say('partial pooling theta mean',np.round(th,1))
w=1/sj**2; say('complete pooling',(w*yj).sum()/w.sum(),'se',1/math.sqrt(w.sum()),'no pooling',yj)
# U19.17
yv=rng.normal(1,1,30); # exact LOO for normal mean known var with prior N(0,10^2)
def logpred(yi,ytrain,s=1.0,t0=10.0):
    prec=1/t0**2+len(ytrain)/s**2; pm=(ytrain.sum()/s**2)/prec; pv=1/prec+s**2; return stats.norm.logpdf(yi,pm,math.sqrt(pv))
loo=sum(logpred(yv[i],np.delete(yv,i)) for i in range(30)); say('exact LOO elpd',loo)
# PSIS-less IS LOO using posterior draws
prec=1/100+30; pm=yv.sum()/prec; draws=rng.normal(pm,math.sqrt(1/prec),20000); ll=stats.norm.logpdf(yv[:,None],draws[None,:],1.0)
is_loo=sum(-special.logsumexp(-ll[i])+math.log(ll.shape[1]) for i in range(30)); lppd=sum(special.logsumexp(ll[i])-math.log(ll.shape[1]) for i in range(30)); pw=sum(ll[i].var() for i in range(30)); say('IS LOO',is_loo,'lppd',lppd,'p_waic',pw,'WAIC elpd',lppd-pw)
say('BF coin',(1/11)/(math.comb(10,7)/2**10),'BF01',(math.comb(10,7)/2**10)*11,'SD pdf',stats.beta.pdf(.5,8,4))
for a_,b_ in [(1,1),(10,10),(0.5,0.5),(100,100)]:
    m1=special.beta(7+a_,3+b_)/special.beta(a_,b_); m0=0.5**10; say('prior',a_,b_,'BF10',m1/m0)
# BIC approx
say('BIC BF approx',math.exp(0.5*(10*math.log(0.7**0.7*0.3**0.3*0+1)) if False else 0))
# MPT
H,F=0.8,0.3; D=H-F; g=F/(1-D); say('MPT D,g',D,g)
nh,nf=100,100; hh=rng.binomial(nh,H); ff=rng.binomial(nf,F); Dh=hh/nh-ff/nf; gh=(ff/nf)/(1-Dh); say('MPT est',hh,ff,Dh,gh)
# param count 2HT
say('2HT params 3 vs 2 free categories')
# mixture two comp mixture label switching sample
