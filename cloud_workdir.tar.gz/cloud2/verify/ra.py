"""Verification helper (mine, not graded work): a tiny relational algebra engine with set semantics."""
import itertools, random, sqlite3
class Rel:
    def __init__(s, attrs, rows): s.attrs = tuple(attrs); s.rows = frozenset(tuple(r) for r in rows)
    def __len__(s): return len(s.rows)
    def d(s): return [dict(zip(s.attrs, r)) for r in s.rows]
def sel(R, p): return Rel(R.attrs, [r for r in R.rows if p(dict(zip(R.attrs, r)))])
def proj(R, A): i = [R.attrs.index(a) for a in A]; return Rel(A, [tuple(r[j] for j in i) for r in R.rows])
def prod(R, S): return Rel(R.attrs + S.attrs, [r + t for r in R.rows for t in S.rows])
def union(R, S): return Rel(R.attrs, R.rows | S.rows)
def diff(R, S): return Rel(R.attrs, R.rows - S.rows)
def inter(R, S): return Rel(R.attrs, R.rows & S.rows)
def ren(R, m): return Rel([m.get(a, a) for a in R.attrs], R.rows)
def njoin(R, S):
    com = [a for a in R.attrs if a in S.attrs]; rest = [a for a in S.attrs if a not in com]
    out = []
    for r in R.rows:
        dr = dict(zip(R.attrs, r))
        for t in S.rows:
            dt = dict(zip(S.attrs, t))
            if all(dr[a] == dt[a] for a in com): out.append(r + tuple(dt[a] for a in rest))
    return Rel(R.attrs + tuple(rest), out)
def divide(R, S):
    X = [a for a in R.attrs if a not in S.attrs]
    return diff(proj(R, X), proj(diff(prod(proj(R, X), S), reorder(R, X + list(S.attrs))), X))
def reorder(R, A): return proj(R, A)
def divide_direct(R, S):
    X = [a for a in R.attrs if a not in S.attrs]; rx = proj(R, X); out = []
    for x in rx.rows:
        if all((x + s) in reorder(R, X + list(S.attrs)).rows for s in S.rows): out.append(x)
    return Rel(X, out)
if __name__ == '__main__':
    random.seed(1)
    ok = 0
    for _ in range(300):
        R = Rel(['a', 'b'], {(random.randint(0, 4), random.randint(0, 3)) for _ in range(random.randint(0, 14))})
        S = Rel(['b'], {(random.randint(0, 3),) for _ in range(random.randint(1, 3))})
        assert divide(R, S).rows == divide_direct(R, S).rows; ok += 1
    print('division identity ok on', ok)
