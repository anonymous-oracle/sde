"""Verification helpers (mine, not graded work): FD theory algorithms."""
import itertools, random
def S(x): return frozenset(x)
def closure(X, F):
    X = set(X); ch = True
    while ch:
        ch = False
        for l, r in F:
            if set(l) <= X and not set(r) <= X: X |= set(r); ch = True
    return X
def implies(F, l, r): return set(r) <= closure(l, F)
def candidate_keys(R, F):
    R = set(R); keys = []
    for k in range(1, len(R) + 1):
        for c in itertools.combinations(sorted(R), k):
            if closure(c, F) >= R and not any(set(kk) <= set(c) for kk in keys): keys.append(c)
    return keys
def minimal_cover(F):
    G = [(frozenset(l), frozenset([a])) for l, r in F for a in r]
    G = list(dict.fromkeys(G))
    out = []
    for l, r in G:
        l = set(l)
        for a in sorted(l):
            if len(l) > 1 and set(r) <= closure(l - {a}, G): l = l - {a}
        out.append((frozenset(l), r))
    out = list(dict.fromkeys(out)); i = 0
    while i < len(out):
        rest = out[:i] + out[i + 1:]
        if set(out[i][1]) <= closure(out[i][0], rest): out = rest
        else: i += 1
    return out
def project(F, Rs):
    Rs = set(Rs); out = []
    for k in range(1, len(Rs)):
        for c in itertools.combinations(sorted(Rs), k):
            cl = closure(c, F) & Rs
            if cl - set(c): out.append((frozenset(c), frozenset(cl - set(c))))
    return out
def is_bcnf(R, F):
    Fp = project(F, R)
    return all(closure(l, Fp) >= set(R) for l, r in Fp)
def prime_attrs(R, F): return set().union(*map(set, candidate_keys(R, F)))
def is_3nf(R, F):
    P = prime_attrs(R, F); Fp = project(F, R)
    return all(closure(l, Fp) >= set(R) or set(r) <= P for l, r in Fp)
def bcnf_decompose(R, F):
    R = frozenset(R); work = [R]; done = []
    while work:
        Ri = work.pop(); Fi = project(F, Ri); bad = None
        for l, r in Fi:
            if closure(l, Fi) < Ri: bad = (l, r); break
        if bad is None: done.append(Ri); continue
        l = bad[0]; cl = frozenset(closure(l, Fi) & Ri)
        work += [cl, frozenset(l) | (Ri - cl)]
    return done
def synth3nf(R, F):
    G = minimal_cover(F); groups = {}
    for l, r in G: groups.setdefault(l, set()).update(r)
    rels = [frozenset(l | r) for l, r in groups.items()]
    keys = candidate_keys(R, F)
    if not any(set(k) <= set(x) for k in keys for x in rels): rels.append(frozenset(keys[0]))
    rels = [x for x in rels if not any(x < y for y in rels)]
    return list(dict.fromkeys(rels))
def chase_lossless(R, F, parts):
    R = sorted(R); rows = [[('a', c) if c in p else ('b', i, c) for c in R] for i, p in enumerate(parts)]
    ch = True
    while ch:
        ch = False
        for l, r in F:
            for t1, t2 in itertools.combinations(rows, 2):
                if all(t1[R.index(c)] == t2[R.index(c)] for c in l):
                    for c in r:
                        i = R.index(c)
                        if t1[i] != t2[i]:
                            keep = t1[i] if t1[i][0] == 'a' else t2[i]; old = t2[i] if keep is t1[i] or keep == t1[i] else t1[i]
                            old = t1[i] if keep == t2[i] else t2[i]
                            for row in rows:
                                if row[i] == old: row[i] = keep
                            ch = True
    return any(all(x[0] == 'a' for x in row) for row in rows)
def preserved(F, parts):
    for l, r in F:
        Z = set(l); ch = True
        while ch:
            ch = False
            for p in parts:
                add = closure(Z & set(p), F) & set(p)
                if not add <= Z: Z |= add; ch = True
        if not set(r) <= Z: return False
    return True
def holds_mvd(rows, attrs, X, Y):
    idx = {a: i for i, a in enumerate(attrs)}; rest = [a for a in attrs if a not in X and a not in Y]
    rs = set(rows)
    for t1 in rows:
        for t2 in rows:
            if all(t1[idx[a]] == t2[idx[a]] for a in X):
                t = tuple(t1[idx[a]] if (a in X or a in Y) else t2[idx[a]] for a in attrs)
                if t not in rs: return False
    return True
def project_rows(rows, attrs, A): return {tuple(r[attrs.index(a)] for a in A) for r in rows}
def join_rows(r1, a1, r2, a2):
    com = [a for a in a1 if a in a2]; out = set(); attrs = list(a1) + [a for a in a2 if a not in a1]
    for t in r1:
        for u in r2:
            if all(t[a1.index(a)] == u[a2.index(a)] for a in com):
                out.add(tuple(dict(zip(a1, t)).get(a, dict(zip(a2, u)).get(a)) for a in attrs))
    return out, attrs
