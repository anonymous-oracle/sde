import numpy as np, math
from scipy import stats
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split, cross_val_score
rng=np.random.default_rng(5)
T=20000; fp_pool=0;fp_welch=0
for _ in range(T):
    a=rng.normal(0,4,10); b=rng.normal(0,1,40)
    fp_pool+= stats.ttest_ind(a,b,equal_var=True).pvalue<0.05; fp_welch+= stats.ttest_ind(a,b,equal_var=False).pvalue<0.05
print('small group big var: pooled FP',fp_pool/T,'welch',fp_welch/T)
Xt=rng.normal(size=(600,6)); yt=((Xt[:,0]+0.5*Xt[:,1]*Xt[:,2]+rng.normal(0,0.8,600))>0).astype(int)
Xtr,Xte,ytr,yte=train_test_split(Xt,yt,test_size=0.5,random_state=0)
full=DecisionTreeClassifier(random_state=0).fit(Xtr,ytr); print('full',full.score(Xtr,ytr),full.score(Xte,yte),full.get_n_leaves())
al=full.cost_complexity_pruning_path(Xtr,ytr).ccp_alphas; al=al[:-1]
cv=[cross_val_score(DecisionTreeClassifier(random_state=0,ccp_alpha=a),Xtr,ytr,cv=5).mean() for a in al]; a=al[int(np.argmax(cv))]
t=DecisionTreeClassifier(random_state=0,ccp_alpha=a).fit(Xtr,ytr); print('cv-chosen alpha',a,'leaves',t.get_n_leaves(),'train',t.score(Xtr,ytr),'test',t.score(Xte,yte),'cv acc',max(cv))
# masking
rng=np.random.default_rng(3)
xo=np.r_[rng.normal(0,1,50),rng.uniform(8,10,10)]
z=(xo-xo.mean())/xo.std(ddof=1); med=np.median(xo);mad=np.median(np.abs(xo-med)); rz=0.6745*(xo-med)/mad
print('masking: z flagged',np.sum(np.abs(z)>3),'robust flagged',np.sum(np.abs(rz)>3.5),'sd',xo.std(ddof=1))
