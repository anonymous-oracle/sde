"""B5 recomputation: U14.17-U14.20 and A14.17-A14.20 (pure Python / NumPy models, no GPU)."""
import math, numpy as np
def ok(c, m):
    print(('OK  ' if c else 'FAIL'), m)
    if not c: raise SystemExit(1)
# ---------- U14.17
def occupancy(tpb, regs, smem_kib, maxthr=2048, maxblk=32, regfile=65536, smem=64):
    b = min(maxthr // tpb, maxblk, regfile // (regs * tpb), int(smem // smem_kib) if smem_kib else 10 ** 9)
    return b, b * tpb / maxthr
ok(occupancy(256, 40, 12) == (5, 0.625), 'occupancy 256 thr, 40 regs, 12 KiB: 5 blocks, 62.5% (shared memory limits)')
ok(occupancy(256, 32, 0) == (8, 1.0), 'occupancy 256 thr, 32 regs, no smem: 8 blocks, 100%')
ok(occupancy(128, 64, 8) == (8, 0.5), 'A14.17 NAT: 128 thr, 64 regs, 8 KiB: 8 blocks, 50% (registers and smem both give 8)')
# SIMT reconvergence-stack simulator: a warp executes if/else
def simt(warp, cond, len_if, len_else):
    mask = np.array([cond(t) for t in warp]); cycles = 0; useful = 0
    for m, L in ((mask, len_if), (~mask, len_else)):
        if m.any(): cycles += L; useful += m.sum() * L
    return cycles, useful / (len(warp) * cycles)
w = np.arange(32)
ok(simt(w, lambda t: t % 2 == 1, 20, 10) == (30, 0.5), 'tid%2 branch, 20/10 instr: 30 cycles, SIMD efficiency 0.5')
ok(simt(w, lambda t: (t // 32) % 2 == 1, 20, 10) == (10, 1.0), 'warp-uniform branch: no divergence, efficiency 1')
# full stack-based simulator on nested branches checks against path-sum formula
def stack_sim(prog, nthreads=32):
    # prog: nested ('if', predicate, then_prog, else_prog) or ('op', n)
    stack = [(np.ones(nthreads, bool), prog)]; cyc = 0
    def run(mask, p):
        nonlocal cyc
        for ins in p:
            if ins[0] == 'op':
                if mask.any(): cyc += ins[1]
            else:
                pm = np.array([ins[1](t) for t in range(nthreads)])
                run(mask & pm, ins[2]); run(mask & ~pm, ins[3])
    run(*stack[0]); return cyc
prog = [('op', 2), ('if', lambda t: t < 16, [('op', 5), ('if', lambda t: t < 8, [('op', 3)], [('op', 1)])], [('op', 4)]), ('op', 2)]
ok(stack_sim(prog) == 2 + 5 + 3 + 1 + 4 + 2, 'nested divergence: serialised path sum 17 cycles')
ok(stack_sim([('op', 2), ('if', lambda t: True, [('op', 5)], [('op', 4)]), ('op', 2)]) == 9, 'uniform branch skips untaken path (9 cycles)')
ok(1 + 400 / 10 == 41, 'latency hiding: 1 + L/C = 41 warps per scheduler for L=400, C=10')
ok(1 + 600 / 20 == 31, 'A14.17 MCQ alt: 31 warps for L=600, C=20')
# ---------- U14.18
N, B = 1_000_000, 256
g = math.ceil(N / B)
ok(g == 3907 and g * B - N == 192, 'grid: 3907 blocks, 192 idle threads (bounds check needed)')
def sectors(stride, offset=0, n=32, size=4, sec=32):
    return len({(offset + i * stride) * size // sec for i in range(n)})
ok([sectors(s) for s in (1, 2, 4, 8, 16, 32)] == [4, 8, 16, 32, 32, 32], 'sectors per warp vs stride: 4,8,16,32,32,32')
ok(sectors(1, 1) == 5 and abs(4 / 5 - 0.8) < 1e-12, 'misaligned by one element: 5 sectors, 80% efficiency')
ok(sectors(3) == 12, 'A14.18 NAT: stride 3 -> 12 sectors')
ok(abs(128 / (sectors(3) * 32) - 1 / 3) < 1e-12, 'stride 3 efficiency 1/3')
banks = lambda s: max(np.bincount([(i * s) % 32 for i in range(32)]))
ok([banks(s) for s in (1, 2, 3, 4, 32)] == [1, 2, 1, 4, 32] and all(banks(s) == math.gcd(s, 32) for s in range(1, 65)), 'shared-memory bank conflict degree = gcd(stride, 32)')
x = np.random.default_rng(1).random(2 ** 12)
def tree_reduce(v):
    v = v.copy(); n = len(v); steps = 0
    while n > 1:
        h = n // 2; v[:h] += v[h:n]; n = h; steps += 1
    return v[0], steps
s, st = tree_reduce(x)
ok(abs(s - x.sum()) < 1e-9 and st == 12, 'sequential-addressing tree reduction of 4096: correct, 12 steps')
ok(int(math.log2(2 ** 20)) == 20 and 2 ** 20 // 256 == 4096, 'N=2^20: span 20 steps; 4096 block partial sums with 256-thread blocks')
# interleaved addressing divergence: active threads tid % (2s) == 0 -> warps active per step
def active_warps(bs, interleaved):
    out = []; s = 1
    while s < bs:
        act = [t for t in range(bs) if (t % (2 * s) == 0 if interleaved else t < bs // (2 * s))]
        out.append(len({t // 32 for t in act})); s *= 2
    return out
ok(active_warps(256, True) == [8, 8, 8, 8, 8, 4, 2, 1] and active_warps(256, False) == [4, 2, 1, 1, 1, 1, 1, 1], 'interleaved addressing keeps all 8 warps busy-but-divergent; sequential retires warps')
ok(3 * 2 * 4 == 24 and 2 * 4 == 8, 'fusion of 3 elementwise kernels: 24N vs 8N bytes, 3x less traffic')
n, T = 1024, 16
ok(2 * n ** 3 == 2147483648 and 2 * n ** 3 // T == 134217728, 'tiled matmul global loads 2N^3/T = 134217728 at N=1024, T=16')
# tiled matmul in numpy equals reference
A = np.random.default_rng(2).random((64, 64)); Bm = np.random.default_rng(3).random((64, 64)); C = np.zeros((64, 64)); t = 16
for i in range(0, 64, t):
    for j in range(0, 64, t):
        for k in range(0, 64, t): C[i:i+t, j:j+t] += A[i:i+t, k:k+t] @ Bm[k:k+t, j:j+t]
ok(np.allclose(C, A @ Bm), 'tiled matmul equals reference')
# ---------- U14.19
ok(abs((256 * 2 ** 20) / 12e9 * 1e3 + 0.01 - 22.38) < 0.01, 'copy 256 MiB at 12 GB/s + 10 us = 22.38 ms')
f = 300 / (300 + 100)
ok(f == 0.75 and abs((1 / (0.75 / 300)) / 300 - 4 / 3) < 1e-12, 'CPU+GPU split f = r_g/(r_g+r_c) = 0.75, speed-up 4/3 over GPU alone')
# offload break-even: CPU 2 s; GPU kernel 0.2 s; transfer of 2 GiB each way at 12 GB/s
tt = 2 * 2 * 2 ** 30 / 12e9
ok(abs(tt - 0.3579) < 1e-4 and 0.2 + tt < 2, f'transfer 2x2 GiB = {tt:.4f} s; offload worthwhile (0.558 s < 2 s)')
ok(abs(0.5 + 2 * 512 * 2 ** 20 / 16e9 - 0.5671) < 1e-4, 'A14.19 NAT: 0.5 s kernel + 2 x 512 MiB at 16 GB/s = 0.5671 s')
gid = lambda grp, lsz, lid: grp * lsz + lid
ok(gid(5, 64, 7) == 327, 'get_global_id = group*local_size + local_id: 327')
# ---------- U14.20
roof = lambda I, pi=10e12, beta=400e9: min(pi, I * beta)
ok(10e12 / 400e9 == 25 and abs(roof(1 / 12) - 33.33e9) < 0.01e9, 'ridge 25 FLOP/B; vector add 1/12 FLOP/B -> 33.3 GFLOP/s')
ok(abs(1024 / 6 - 170.67) < 0.01 and roof(1024 / 6) == 10e12, 'matmul ideal AI N/6 = 170.7 > ridge, compute bound')
ok(roof(8, 20e12, 1e12) == 8e12, 'A14.20 NAT: I=8, pi=20 TFLOP/s, beta=1 TB/s -> 8 TFLOP/s')
# output-stationary systolic array simulator
def systolic(Am, Bm):
    n = Am.shape[0]; K = Am.shape[1]; C = np.zeros((n, n)); last = np.zeros((n, n), int)
    a = np.zeros((n, n)); b = np.zeros((n, n)); t = 0
    while t < K + 2 * n - 2:
        a = np.roll(a, 1, axis=1); b = np.roll(b, 1, axis=0)
        for i in range(n):
            k = t - i; a[i, 0] = Am[i, k] if 0 <= k < K else 0
        for j in range(n):
            k = t - j; b[0, j] = Bm[k, j] if 0 <= k < K else 0
        C += a * b
        for i in range(n):
            for j in range(n):
                if 0 <= t - i - j < K: last[i, j] = t
        t += 1
    return C, last.max() + 1
for n, K in ((4, 4), (4, 10), (6, 3)):
    Am = np.random.default_rng(n).random((n, K)); Bm = np.random.default_rng(K).random((K, n))
    C, cyc = systolic(Am, Bm)
    ok(np.allclose(C, Am @ Bm) and cyc == K + 2 * n - 2, f'systolic {n}x{n}, K={K}: correct, {cyc} cycles = K + 2n - 2')
ok(abs(128 / 382 - 0.3351) < 1e-4 and abs(4096 / 4350 - 0.9416) < 1e-4, 'utilisation K/(K+2n-2): 0.335 at K=n=128, 0.942 at K=4096')
xq = np.random.default_rng(7).uniform(-1, 1, 200000)
for bits in (4, 8):
    d = 2 / (2 ** bits); q = (np.floor(xq / d) + 0.5) * d
    ok(abs(np.var(xq - q) / (d * d / 12) - 1) < 0.02, f'{bits}-bit uniform quantiser error variance = step^2/12')
    sqnr = 10 * math.log10(np.var(xq) / np.var(xq - q))
    ok(abs(sqnr - 6.02 * bits) < 0.1, f'{bits}-bit SQNR {sqnr:.2f} dB ~ 6.02 b for a full-range uniform signal')
ok(64 * 128 * 9 * 56 * 56 == 231211008, 'conv 64->128, 3x3, 56x56 output: 231,211,008 MACs')
s8 = 2.54 / 127
ok(abs(round(1.0 / s8) - 50) < 1 and round(1.0 / s8) == 50, 'INT8 symmetric scale max|x|/127: x=1.0 with max 2.54 -> code 50')
print('B5 all checks passed')
