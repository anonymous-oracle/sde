# U19.15-U19.17 in PyMC, Bambi and ArviZ: measured claims (seeded; values vary a little across versions)
import numpy as np, pymc as pm, arviz as az, time, math, warnings, logging, sys
warnings.filterwarnings('ignore'); logging.getLogger('pymc').setLevel(logging.ERROR)
import pymc, bambi, pytensor
print('pymc',pymc.__version__,'arviz',az.__version__,'bambi',bambi.__version__)
kw=dict(chains=4,cores=1,progressbar=False,random_seed=7)
def summ(idata,var): 
    s=az.summary(idata,var_names=[var],round_to=4); return s
sel=sys.argv[1:] or ['a','b','c','d','e']
if 'a' in sel:
    t=time.time()
    with pm.Model():
        th=pm.Beta('th',1,1); pm.Binomial('y',10,th,observed=7)
        idata=pm.sample(1000,tune=1000,**kw)
    s=az.summary(idata,round_to=4); print('A beta-binomial',s.loc['th',['mean','sd','r_hat']].to_dict(),'exact mean',8/12,'sd',math.sqrt(8*4/(144*13)),'div',int(idata.sample_stats['diverging'].sum()),round(time.time()-t,1),'s')
if 'b' in sel:
    t=time.time()
    with pm.Model():
        x=pm.Normal('x',0,1,shape=20)
        idata=pm.sample(1000,tune=1000,**kw)
    ess=az.ess(idata,var_names=['x']); r=az.rhat(idata,var_names=['x'])
    print('B 20-d normal NUTS: min ess_bulk',float(ess['x'].min()),'mean ess',float(ess['x'].mean()),'max rhat',float(r['x'].max()),'div',int(idata.sample_stats['diverging'].sum()),'total draws 4000','grad evals',int(idata.sample_stats['n_steps'].sum()),round(time.time()-t,1),'s')
if 'c' in sys.argv[1:] or not sys.argv[1:]:
    t=time.time()
    import pandas as pd, bambi as bmb
    rng=np.random.default_rng(3); n=60
    df=pd.DataFrame({'x1':rng.normal(size=n),'x2':rng.normal(size=n)}); df['y']=1+2*df.x1-df.x2+rng.normal(size=n)
    m=bmb.Model('y ~ x1 + x2',df); idata=m.fit(draws=1000,tune=1000,chains=4,cores=1,random_seed=7,progressbar=False)
    s=az.summary(idata,round_to=3); print('C bambi\n',s[['mean','sd','r_hat']])
    X=np.c_[np.ones(n),df.x1,df.x2]; b=np.linalg.lstsq(X,df.y,rcond=None)[0]; print('OLS',b.round(3),'resid sd',np.std(df.y-X@b,ddof=3).round(3),round(time.time()-t,1),'s')
    print(m.backend.model.basic_RVs if hasattr(m,'backend') else '')
if 'd' in sel:
    t=time.time()
    y=np.array([28,8,-3,7,-1,1,18,12.]); sg=np.array([15,10,16,11,9,11,10,18.])
    for name in ('centred','noncentred'):
        with pm.Model():
            mu=pm.Normal('mu',0,10); tau=pm.HalfCauchy('tau',5)
            if name=='centred':
                th=pm.Normal('theta',mu,tau,shape=8)
            else:
                z=pm.Normal('z',0,1,shape=8); th=pm.Deterministic('theta',mu+tau*z)
            pm.Normal('y',th,sg,observed=y)
            idata=pm.sample(2000,tune=1000,target_accept=0.9 if name=='noncentred' else 0.8,**kw)
        d=int(idata.sample_stats['diverging'].sum()); tau_s=idata.posterior['tau'].values.ravel(); th_m=idata.posterior['theta'].mean(('chain','draw')).values
        print('D eight schools',name,'divergences',d,'of 8000','tau median',round(float(np.median(tau_s)),2),'mean',round(float(tau_s.mean()),2),'p95',round(float(np.quantile(tau_s,.95)),2),'theta means',th_m.round(1).tolist(),'min ess tau',round(float(az.ess(idata,var_names=['tau'])['tau']),0),round(time.time()-t,1),'s')
if 'e' in sel:
    t=time.time()
    rng=np.random.default_rng(11); z=rng.random(300)<0.4; data=np.where(z,rng.normal(2,1,300),rng.normal(-1,1,300))
    with pm.Model():
        w=pm.Dirichlet('w',np.ones(2)); mu=pm.Normal('mu',0,5,shape=2,transform=pm.distributions.transforms.ordered,initval=np.array([-1.,2.]))
        pm.NormalMixture('obs',w=w,mu=mu,sigma=1.0,observed=data)
        idata=pm.sample(1000,tune=1000,**kw)
    s=az.summary(idata,var_names=['w','mu'],round_to=3); print('E mixture ordered\n',s[['mean','sd','r_hat']],'true w[1] =',z.mean().round(3),'div',int(idata.sample_stats['diverging'].sum()),round(time.time()-t,1),'s')
    with pm.Model():
        w=pm.Dirichlet('w',np.ones(2)); mu=pm.Normal('mu',0,5,shape=2)
        pm.NormalMixture('obs',w=w,mu=mu,sigma=1.0,observed=data)
        idata2=pm.sample(1000,tune=1000,chains=4,cores=1,progressbar=False,random_seed=3,initvals={'mu':np.array([-1.,2.])})
    print('E unordered r_hat mu',az.rhat(idata2,var_names=['mu'])['mu'].values.round(3),'chain means mu0',idata2.posterior['mu'].sel(mu_dim_0=0).mean('draw').values.round(2))
if 'f' in sel:
    y=np.array([28,8,-3,7,-1,1,18,12.]); sg=np.array([15,10,16,11,9,11,10,18.])
    with pm.Model():
        mu=pm.Flat('mu'); tau=pm.Uniform('tau',0,100); z=pm.Normal('z',0,1,shape=8); th=pm.Deterministic('theta',mu+tau*z)
        pm.Normal('y',th,sg,observed=y)
        idata=pm.sample(2000,tune=1500,target_accept=0.95,**kw)
    tau_s=idata.posterior['tau'].values.ravel(); th_m=idata.posterior['theta'].mean(('chain','draw')).values
    print('F eight schools uniform tau noncentred div',int(idata.sample_stats['diverging'].sum()),'tau median',round(float(np.median(tau_s)),2),'mean',round(float(tau_s.mean()),2),'p95',round(float(np.quantile(tau_s,.95)),2),'theta',th_m.round(1).tolist())
if 'g' in sel:
    # LOO/WAIC vs exact for conjugate normal, known sigma=1
    rng=np.random.default_rng(5); n=30; y=rng.normal(0.5,1,n)
    # exact LOO with prior mu~N(0,10^2), sigma=1
    def lpd_loo(y,i):
        yy=np.delete(y,i); m=len(yy); pv=1/(1/100+m); pm_=pv*yy.sum(); var=pv+1; return -0.5*math.log(2*math.pi*var)-0.5*(y[i]-pm_)**2/var
    exact=sum(lpd_loo(y,i) for i in range(n))
    with pm.Model():
        mu=pm.Normal('mu',0,10); pm.Normal('obs',mu,1,observed=y)
        idata=pm.sample(2000,tune=1000,idata_kwargs={'log_likelihood':True},**kw)
    lo=az.loo(idata); wa=None; print([a for a in dir(az) if 'waic' in a.lower() or 'loo' in a.lower() or 'compare' in a.lower()])
    print('G exact LOO',round(exact,3),'az.loo',lo,'az.waic',wa)
