"""B3 recomputation: U14.10-U14.13 and A14.10-A14.13."""
import math, random, collections
import numpy as np
def ok(c, m):
    print(('OK  ' if c else 'FAIL'), m)
    if not c: raise SystemExit(1)
# ---- U14.10
ok(2 ** (48 - 14) * 8 == 128 * 2 ** 30, 'single-level table 48-bit VA, 16 KiB pages, 8 B PTE = 128 GiB')
ok(2 ** (48 - 12) * 8 == 512 * 2 ** 30, 'single-level table with 4 KiB pages = 512 GiB')
lv = lambda va, pg, pte=8: math.ceil((va - pg) / (pg - int(math.log2(pte))))
ok(lv(48, 12) == 4 and 12 + 9 * 4 == 48, '4 KiB granule: 9 bits per level, 4 levels for 48 bits')
ok(14 + 11 * 3 == 47 and lv(47, 14) == 3 and lv(48, 14) == 4, '16 KiB granule: 11 bits per level, 3 levels cover 47 bits, 48 bits need a 4th level of 2 entries')
ok(2048 * 16 * 1024 == 32 * 2 ** 20 and 2048 * 4096 == 8 * 2 ** 20, 'TLB reach 2048 entries: 32 MiB at 16 KiB, 8 MiB at 4 KiB')
ok(128 * 1024 // 8 == 16 * 1024 and 32 * 1024 // 4096 == 8, 'VIPT: 128 KiB 8-way fits 16 KiB pages; 32 KiB with 4 KiB pages needs 8 ways')
pmax = (110 - 100) / (8e6 - 100)
ok(abs(pmax - 1.25e-6) < 1e-9, f'max fault rate for 10% slowdown = {pmax:.6e}')
def eat(h, t, k): return h * t + (1 - h) * (t + k * t)          # U4.1 formula (owned there)
# simulate an MMU+TLB to reproduce U4.1 EAT
rng = np.random.default_rng(5); t = 100; k = 4
for hit in (0.9, 0.98):
    acc = rng.random(200000) < hit
    cost = np.where(acc, t, t + k * t).mean()
    ok(abs(cost - eat(hit, t, k)) < 2, f'simulated EAT {cost:.1f} vs U4.1 formula {eat(hit,t,k):.1f} (hit {hit})')
ok((4 + 1) * (4 + 1) - 1 == 24, 'nested walk 4x4 levels = 24 references (U4.2 formula)')
leaf = (2 ** 30) // 4096 // 512
ok(leaf == 512 and (leaf + 1 + 1 + 1) * 4096 == 2109440, 'A14.10 NAT: 1 GiB aligned with 4-level 4 KiB tables = 515 tables = 2109440 bytes')
# ---- U14.11
ok(3200e6 * 8 / 1e9 == 25.6, 'DDR4-3200 x64 channel = 25.6 GB/s')
tck = 1 / 1.6e9 * 1e9
ok(abs(tck - 0.625) < 1e-12 and abs(22 * tck - 13.75) < 1e-12 and abs(3 * 22 * tck - 41.25) < 1e-12, 'DDR4-3200 CL22: 0.625 ns, 13.75 ns, conflict 41.25 ns')
ok(abs(0.6 * 13.75 + 0.4 * 41.25 - 24.75) < 1e-12, 'avg latency 60% hit 40% conflict = 24.75 ns')
ok(abs(64e-3 / 8192 * 1e6 - 7.8125) < 1e-12 and abs(350 / 7812.5 - 0.0448) < 1e-12, 'tREFI 7.8125 us; refresh overhead 350/7812.5 = 4.48%')
ok(2 ** 15 * 2 ** 13 * 16 * 2 == 2 ** 33 and 33 - 3 - 10 - 4 - 1 == 15, 'address map 8 GiB: offset 3, column 10, bank 4, rank 1, row 15')
ok(abs(32 + 13.75 - 45.75) < 1e-12, 'tRC = tRAS + tRP = 45.75 ns')
tck2 = 1 / 1.2e9 * 1e9; cl = 17 * tck2
ok(abs(0.5 * cl + 0.2 * 2 * cl + 0.3 * 3 * cl - 25.5) < 1e-9, 'A14.11 NAT DDR4-2400 CL17 mix = 25.5 ns')
# FR-FCFS vs FCFS row hits on a toy queue
def serve(reqs, policy, tcl=1, trcd=1, trp=1):
    open_row = {}; q = list(reqs); time = 0; hits = 0
    while q:
        if policy == 'frfcfs':
            idx = next((i for i, (b, r) in enumerate(q) if open_row.get(b) == r), 0)
        else: idx = 0
        b, r = q.pop(idx)
        if open_row.get(b) == r: time += tcl; hits += 1
        elif b in open_row: time += trp + trcd + tcl
        else: time += trcd + tcl
        open_row[b] = r
    return time, hits
reqs = [(0, 1), (0, 2), (0, 1), (0, 2), (0, 1), (0, 2)]
ok(serve(reqs, 'fcfs') == (17, 0) and serve(reqs, 'frfcfs') == (9, 4), 'FR-FCFS turns 0 row hits into 4 on an alternating-row queue (17 -> 9 time units)')
# ---- U14.12
ok(abs((2e6 / 4) * 400 / 1e9 - 0.2) < 1e-12, 'polling 4 B at 2 MB/s, 400 cycles/poll, 1 GHz = 20% of CPU')
ok(abs((8e6 / 16) * 400 / 2e9 - 0.1) < 1e-12, 'A14.12 NAT polling = 10%')
blocks = 2e6 / 4096
ok(abs(blocks * 1500 / 1e9 - 0.000732) < 1e-6, f'DMA 4 KiB blocks: {blocks*1500/1e9*100:.4f}% of CPU')
rot = 0.5 * 60 / 7200 * 1e3
ok(abs(rot - 4.1667) < 1e-4, '7200 rpm average rotational latency 4.167 ms')
acc = 4 + rot + 4096 / 200e6 * 1e3 + 0.1
ok(abs(acc - 8.2871) < 1e-4, f'disk access 4 ms seek + rot + 4 KiB at 200 MB/s + 0.1 ms = {acc:.4f} ms')
ok(abs(8e9 * 128 / 130 * 4 / 8 / 1e9 - 3.938) < 1e-3, 'PCIe 3.0 x4 = 3.938 GB/s per direction')
ok(abs(32 / (6 * 5e-9) / 1e9 - 1.0667) < 1e-4, 'bus 64-bit 200 MHz, 32 B in 6 cycles = 1.067 GB/s')
# ---- U14.13
kf = lambda S, p: (1 / S - 1 / p) / (1 - 1 / p)
ok(abs(kf(6, 8) - 0.047619) < 1e-6, 'Karp-Flatt S=6 p=8 = 0.0476')
ok(abs(kf(12, 16) - 0.022222) < 1e-6, 'A14.13 NAT Karp-Flatt S=12 p=16 = 0.0222')
# Karp-Flatt recovers Amdahl serial fraction exactly
s = 0.07; p = 32; S = 1 / (s + (1 - s) / p); ok(abs(kf(S, p) - s) < 1e-12, 'Karp-Flatt returns s under Amdahl')
W, D, P = 1e6, 1e3, 64
ok(W / P + D == 16625 and abs(W / (W / P + D) - 60.15) < 0.01, 'Brent bound: T_p <= W/p + D = 16625, speed-up >= 60.15')
# greedy scheduling of a random DAG obeys max(W/p, D) <= Tp <= W/p + D
random.seed(4)
for trial in range(50):
    n = 60; preds = {i: [j for j in range(i) if random.random() < 0.05] for i in range(n)}
    depth = {}; 
    for i in range(n): depth[i] = 1 + max([depth[j] for j in preds[i]] + [0])
    Dd = max(depth.values()); Ww = n
    for p in (2, 4, 8):
        done = set(); tt = 0
        while len(done) < n:
            ready = [i for i in range(n) if i not in done and all(j in done for j in preds[i])]
            done |= set(ready[:p]); tt += 1
        assert max(Ww / p, Dd) <= tt <= Ww / p + Dd
ok(True, 'greedy unit-task schedules satisfy max(W/p, D) <= T_p <= W/p + D (150 cases)')
n, p = 1024, 64
ok(abs(4 * math.sqrt(p) / n - 0.03125) < 1e-12 and abs(2 * p / n - 0.125) < 1e-12, 'comm/comp: blocks 4 sqrt(p)/n = 0.03125, strips 2p/n = 0.125')
ok(abs(64 / 45.75 - 1.399) < 1e-3 and abs(2 / 130 - 0.01538) < 1e-4, 'per-bank random bound 1.40 GB/s; 128b/130b loss 1.54%')
ok(abs(17 / 1.2 - 14.1667) < 1e-4, 'DDR4-2400 17 cycles = 14.17 ns')
print('B3 all checks passed')
