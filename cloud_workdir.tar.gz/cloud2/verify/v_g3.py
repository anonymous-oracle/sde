# D22 U22.10-U22.14
import ast, io, tokenize, itertools, random, math, collections, sys, keyword
import numpy as np, networkx as nx
from scipy import optimize, stats
random.seed(24); rng=np.random.default_rng(24)
print('=== U22.10')
sample='''def gcd(a, b):
    while b != 0:
        a, b = b, a % b
    return a
'''
ops=collections.Counter(); opd=collections.Counter()
for t in tokenize.generate_tokens(io.StringIO(sample).readline):
    if t.type==tokenize.OP: ops[t.string]+=1
    elif t.type==tokenize.NAME: (ops if keyword.iskeyword(t.string) else opd)[t.string]+=1
    elif t.type==tokenize.NUMBER: opd[t.string]+=1
n1,n2,N1,N2=len(ops),len(opd),sum(ops.values()),sum(opd.values()); n=n1+n2; N=N1+N2; V=N*math.log2(n); D=(n1/2)*(N2/n2); print('operators',dict(ops),'operands',dict(opd)); print('n1',n1,'n2',n2,'N1',N1,'N2',N2,'vocab',n,'length',N,'volume',round(V,2),'difficulty',round(D,2),'effort',round(D*V,1))
def cr(N0,p1,p2,trials=20000):
    est=[];chap=[]
    for _ in range(trials):
        a=rng.random(N0)<p1; b=rng.random(N0)<p2; m=(a&b).sum(); n1_=a.sum(); n2_=b.sum()
        if m>0: est.append(n1_*n2_/m)
        chap.append((n1_+1)*(n2_+1)/(m+1)-1)
    return np.mean(est),np.std(est),np.mean(chap),np.std(chap)
print('capture-recapture N=100 p1=.5 p2=.4 (LP mean,sd; Chapman mean,sd)',[round(x,2) for x in cr(100,.5,.4)])
print('N=100 p1=.3 p2=.3',[round(x,2) for x in cr(100,.3,.3)])
e=[0.6,0.5,0.35,0.5]; r=1
for x in e: r*=1-x
print('defect removal cascade',e,'residual fraction',round(r,4),'overall efficiency',round(1-r,4),'of 200 injected, residual',round(200*r,1))
print('=== U22.11')
for n_ in (1,2,3,5): print('BVA n',n_,'4n+1',4*n_+1,'robust 6n+1',6*n_+1,'worst-case 5^n',5**n_,'robust worst 7^n',7**n_)
def bva_points(lo,hi): return [lo,lo+1,(lo+hi)//2,hi-1,hi]
cnt=len(set(itertools.product(*[bva_points(1,100)]*3))); print('enumerated worst-case BVA n=3',cnt)
# BVA single-fault set size
nom=[50]*3; S=set()
for i in range(3):
    for v in bva_points(1,100): t=list(nom); t[i]=v; S.add(tuple(t))
print('single-fault BVA n=3 distinct',len(S))
funcs={'f1':'''def f(a,b):
    if a>0:
        if b>0:
            return 1
        return 2
    for i in range(a):
        if i%2==0:
            continue
    return 3
''','f2':'''def f(x):
    return x+1
''','f3':'''def f(xs):
    t=0
    for x in xs:
        if x<0: t-=x
        elif x==0: pass
        else: t+=x
    while t>100:
        t//=2
    return t
''','f4':'''def f(a,b):
    if a>0 and b>0:
        return 1
    return 2
'''}
from radon.complexity import cc_visit
def cfg(src):
    fn=ast.parse(src).body[0]; G=nx.DiGraph(); k=[0]
    def new():
        k[0]+=1; return k[0]
    ENTRY=new(); EXIT=new(); G.add_edge(ENTRY,ENTRY); G.remove_edge(ENTRY,ENTRY)
    def block(body,cur,loop):
        for st in body:
            if cur is None: return None
            if isinstance(st,ast.If):
                c=new(); G.add_edge(cur,c); j=new()
                te=block(st.body,c,loop)
                if te is not None: G.add_edge(te,j)
                if st.orelse:
                    ee=block(st.orelse,c,loop)
                    if ee is not None: G.add_edge(ee,j)
                else: G.add_edge(c,j)
                cur=j
            elif isinstance(st,(ast.For,ast.While)):
                h=new(); G.add_edge(cur,h); x=new(); G.add_edge(h,x)
                be=block(st.body,h,(h,x))
                if be is not None: G.add_edge(be,h)
                cur=x
            elif isinstance(st,ast.Return):
                c=new(); G.add_edge(cur,c); G.add_edge(c,EXIT); cur=None
            elif isinstance(st,ast.Continue):
                c=new(); G.add_edge(cur,c); G.add_edge(c,loop[0]); cur=None
            else:
                c=new(); G.add_edge(cur,c); cur=c
        return cur
    end=block(fn.body,ENTRY,None)
    if end is not None: G.add_edge(end,EXIT)
    pred=sum(isinstance(n,(ast.If,ast.For,ast.While)) for n in ast.walk(fn))
    return G.number_of_edges()-G.number_of_nodes()+2,pred+1
for k,src in funcs.items(): print(k,'E-N+2 and predicates+1',cfg(src),'radon (counts each and/or)',cc_visit(src)[0].complexity)
# MC/DC minimal set sizes
def mcdc_min(f,n):
    vecs=list(itertools.product([0,1],repeat=n)); best=None
    pairs={i:[(a,b) for a in vecs for b in vecs if f(*a)!=f(*b) and all((a[j]==b[j]) for j in range(n) if j!=i) and a[i]!=b[i]] for i in range(n)}
    for size in range(2,2**n+1):
        for S in itertools.combinations(vecs,size):
            Ss=set(S)
            if all(any(a in Ss and b in Ss for a,b in pairs[i]) for i in range(n)): return size
    return None
print('MC/DC minimal test set sizes: A and B',mcdc_min(lambda a,b:a and b,2),'; A or B',mcdc_min(lambda a,b:a or b,2),'; (A and B) or C',mcdc_min(lambda a,b,c:(a and b) or c,3),'; A xor B',mcdc_min(lambda a,b:a^b,2),'; (A and B) or (C and D)',mcdc_min(lambda a,b,c,d:(a and b) or (c and d),4))
# statement vs branch coverage with coverage.py
import coverage, tempfile, os, importlib.util
code='def g(x):\n    y = 0\n    if x > 0:\n        y = 1\n    return 10 // (y + x + 1) if x == -1 else y\n'
d=tempfile.mkdtemp(); fp=os.path.join(d,'gmod.py'); open(fp,'w').write(code)
def measure(inputs):
    c=coverage.Coverage(branch=True,data_file=None); c.start()
    spec=importlib.util.spec_from_file_location('gmod',fp); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    for i_ in inputs:
        try: m.g(i_)
        except ZeroDivisionError: pass
    c.stop(); a=c.analysis2(fp); data=c._analyze(fp); st=data.numbers
    return st.n_statements,st.n_missing,st.n_branches,st.n_missing_branches
for ins in ([5],[5,-3],[5,-3,-1]): print('inputs',ins,'(statements, missing, branches, missing branches)',measure(ins))
# basis paths: rank of edge-usage vectors
G=nx.DiGraph([(1,2),(2,3),(2,4),(3,5),(4,5),(5,6),(6,7),(6,2),(7,8)]); paths=[p for p in nx.all_simple_paths(G,1,8)]
E=list(G.edges()); 
vec=lambda p:[1 if (a,b) in set(zip(p,p[1:])) else 0 for a,b in E]
print('CFG E,N',len(E),G.number_of_nodes(),'V(G)',len(E)-G.number_of_nodes()+2,'simple paths',len(paths),'rank of path vectors',np.linalg.matrix_rank(np.array([vec(p) for p in paths])))
print('=== U22.12')
def is_leap(y): return (y%4==0 and y%100!=0) or y%400==0
SRC='''def is_leap(y):
    return (y%4==0 and y%100!=0) or y%400==0
'''
class Mut(ast.NodeTransformer):
    def __init__(s,k): s.k=k; s.i=0; s.done=False
    def tick(s): 
        s.i+=1; return s.i==s.k
    def visit_Compare(s,n):
        s.generic_visit(n)
        for j,op in enumerate(n.ops):
            sw={ast.Eq:ast.NotEq,ast.NotEq:ast.Eq,ast.Lt:ast.LtE,ast.LtE:ast.Lt,ast.Gt:ast.GtE,ast.GtE:ast.Gt}.get(type(op))
            if sw and s.tick(): n.ops[j]=sw()
        return n
    def visit_BinOp(s,n):
        s.generic_visit(n)
        sw={ast.Mod:ast.Mult,ast.Add:ast.Sub,ast.Sub:ast.Add,ast.Mult:ast.Add}.get(type(n.op))
        if sw and s.tick(): n.op=sw()
        return n
    def visit_BoolOp(s,n):
        s.generic_visit(n)
        if s.tick(): n.op=ast.Or() if isinstance(n.op,ast.And) else ast.And()
        return n
    def visit_Constant(s,n):
        if isinstance(n.value,int) and not isinstance(n.value,bool) and s.tick(): return ast.Constant(n.value+1)
        return n
def mutants(src):
    out=[]; k=1
    while True:
        m=Mut(k); tree=m.visit(ast.parse(src)); 
        if m.i<k: break
        out.append(ast.unparse(ast.fix_missing_locations(tree))); k+=1
    return out
ms=mutants(SRC); print('mutants generated',len(ms))
def score(tests):
    killed=0; alive=[]
    for m in ms:
        ns={}; exec(m,ns); 
        try:
            if any(ns['is_leap'](y)!=exp for y,exp in tests): killed+=1
            else: alive.append(m)
        except Exception: killed+=1
    return killed,len(ms),alive
t_weak=[(2001,False),(2004,True)]; t_mid=t_weak+[(1900,False),(2000,True)]
print('mutation score weak',score(t_weak)[:2],'with century cases',score(t_mid)[:2])
t_full=[(y,is_leap(y)) for y in range(1,2500)]; k,tot,alive=score(t_full); print('exhaustive 1..2499',k,tot,'equivalent or surviving',len(alive))
# ddmin
def ddmin(inp,test):
    n=2; calls=0
    while len(inp)>=2:
        sub=len(inp)//n; chunks=[inp[i:i+sub] for i in range(0,len(inp),sub)] if sub else [inp]
        red=False
        for i in range(len(chunks)):
            comp=sum((c for j,c in enumerate(chunks) if j!=i),[]) 
            calls+=1
            if test(comp): inp=comp; n=max(n-1,2); red=True; break
        if not red:
            if n>=len(inp): break
            n=min(len(inp),2*n)
    return inp,calls
fail=lambda xs: ('<' in xs and '>' in xs and xs.index('<')<len(xs)-1 and '>' in xs[xs.index('<'):])
inp=list('abc<def'+'x'*80+'g>hij'); inp=list(inp)
res,calls=ddmin(inp,lambda xs: fail(xs)); print('ddmin input length',len(inp),'->',''.join(res),'test calls',calls)
# one-minimal check
print('1-minimal',all(not fail(res[:i]+res[i+1:]) for i in range(len(res))))
# tarantula
prog=list(range(1,11)); fault=6
def run_test(inp):
    cov={1,2,3}
    if inp%2==0: cov|={4,5}
    else: cov|={6,7}
    if inp>5: cov|={8}
    cov|={9,10}
    fails=(6 in cov and inp%3==1) or (inp%7==0 and inp>20 and 8 in cov and False)
    return cov,fails
tests=list(range(0,40)); data=[run_test(t) for t in tests]
tf=sum(f for _,f in data); tp=len(data)-tf
def susp(s):
    pf=sum(1 for c,f in data if s in c and f)/tf; pp=sum(1 for c,f in data if s in c and not f)/tp
    return pf/(pf+pp) if pf+pp else 0
sc={s:round(susp(s),3) for s in prog}; print('tarantula',sc,'faulty stmt 6 rank',sorted(sc,key=lambda s:-sc[s]).index(6)+1,'ties at top',[s for s in sc if sc[s]==max(sc.values())])
from hypothesis import given, strategies as st, settings, Phase
def buggy_sort(xs): return sorted(set(xs))
found=[]
@settings(max_examples=300,database=None,derandomize=True)
@given(st.lists(st.integers(-5,5),max_size=10))
def prop(xs):
    found.append(xs); assert buggy_sort(xs)==sorted(xs)
try: prop()
except AssertionError: print('hypothesis shrunk counterexample',found[-1])
print('=== U22.13')
def mm1(lam,mu,T=200000,seed=1):
    r=random.Random(seed); t=0; arr=[]; 
    t_arr=0; dep_time=0; sojourn=[]; area=0; times=[]; 
    n=int(T*lam); t_arr=0; ev=[]
    for _ in range(n):
        t_arr+=r.expovariate(lam); s=r.expovariate(mu); start=max(t_arr,dep_time); dep_time=start+s; sojourn.append(dep_time-t_arr); ev.append((t_arr,dep_time))
    W=sum(sojourn)/n; horizon=ev[-1][1]; L=sum(d-a for a,d in ev)/horizon; lam_hat=n/horizon; return W,L,lam_hat
W,L,lh=mm1(0.8,1.0); print('M/M/1 rho .8: W',round(W,3),'theory 5.0','L',round(L,3),'theory 4.0','lambda_hat',round(lh,3),'L vs lam*W',round(L,3),round(lh*W,3))
W,L,lh=mm1(0.95,1.0,T=2000000); print('rho .95: W',round(W,2),'theory 20','L',round(L,2),'theory 19')
hist=[18,22,20,25,19,23]; backlog=300
def sprints(): 
    done=0;k=0
    while done<backlog: done+=random.choice(hist); k+=1
    return k
S=[sprints() for _ in range(20000)]; print('sprints to finish 300 points: mean',round(np.mean(S),2),'P50',np.percentile(S,50),'P85',np.percentile(S,85),'naive 120/mean velocity',round(backlog/np.mean(hist),2))
G=nx.DiGraph([('lint','test'),('compile','test'),('test','package'),('docs','package'),('package','deploy')])
for ch in (['docs'],['compile'],['lint','docs']):
    desc=set(ch); [desc.update(nx.descendants(G,c)) for c in ch]; print('changed',ch,'rerun',sorted(desc),'cached',sorted(set(G)-desc))
print('=== U22.14')
def jm_sim(N0,phi,seed):
    r=random.Random(seed); return [r.expovariate(phi*(N0-i)) for i in range(N0)]
def jm_mle(x):
    n=len(x)
    def g(N):
        a=n/sum((N-i)*xi for i,xi in enumerate(x)); return sum(1/(N-i) for i in range(n))-a*sum(xi for xi in x)
    N=optimize.brentq(g,n-1+1e-6,10*n); phi=n/sum((N-i)*xi for i,xi in enumerate(x)); return N,phi
est=[]
for sd in range(200):
    x=jm_sim(60,0.02,sd)[:45]
    try: est.append(jm_mle(x))
    except Exception: pass
a=np.array(est); print('JM: true N0 60 phi .02; 200 simulated projects, first 45 failures observed; fits',len(a),'median N0',round(np.median(a[:,0]),1),'IQR',np.percentile(a[:,0],[25,75]).round(1),'median phi',round(np.median(a[:,1]),4))
x=jm_sim(60,0.02,3); print('mean time to next failure at start',round(1/(0.02*60),3),'after 30 fixes',round(1/(0.02*30),3),'after 59 fixes',round(1/(0.02*1),1),'sample intervals first/last',round(x[0],2),round(x[-1],1))
def go(t,a,b): return a*(1-np.exp(-b*t))
ts=np.arange(5,101,5); true=go(ts,100,0.03); obs=rng.poisson(np.diff(np.r_[0,true])).cumsum()
p,_=optimize.curve_fit(go,ts,obs,p0=[80,0.05]); print('Goel-Okumoto fit a,b',p.round(3),'true 100,0.03; expected remaining faults',round(p[0]-obs[-1],1))
pf=lambda p:3*p**2-2*p**3
print('TMR failure prob p=.1',round(pf(.1),4),'p=.01',round(pf(.01),6),'single .1')
def tmr_mc(p,q,n=400000):
    common=rng.random(n)<q; f=(rng.random((n,3))<p)|common[:,None]; return (f.sum(1)>=2).mean()
print('TMR with common-mode q: p=.1 q=0',round(tmr_mc(.1,0),4),'q=.01',round(tmr_mc(.1,.01),4),'q=.05',round(tmr_mc(.1,.05),4),'theory q+(1-q)pf',round(0.05+(0.95)*pf(.1),4))
lam=1/500; print('R(100h) lambda 1/500',round(math.exp(-lam*100),4),'MTTF',500,'availability MTTF 500 MTTR 2',round(500/502,5))
