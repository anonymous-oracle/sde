"""B1 recomputation: every number and formula stated in U14.1-U14.5 Results and A14.1-A14.5."""
import math, itertools, struct
import numpy as np
ok = lambda c, m: print(('OK  ' if c else 'FAIL'), m) or (c or exit(1))
# ---- U14.1
def tc(x, n): return x - (1 << n) if x >> (n - 1) else x
def oc(x, n): return x - ((1 << n) - 1) if x >> (n - 1) else x
for n in (4, 8, 12):
    v = [tc(x, n) for x in range(1 << n)]; ok(min(v) == -(1 << n-1) and max(v) == (1 << n-1) - 1, f'two complement range n={n}')
    w = [oc(x, n) for x in range(1 << n)]; ok(min(w) == -((1 << n-1) - 1) and w.count(0) == 2, f'ones complement range and two zeros n={n}')
    ok(all(tc((~x + 1) & ((1 << n) - 1), n) == -tc(x, n) for x in range(1 << n) if tc(x, n) != -(1 << n-1)), f'negation ~x+1 n={n}')
ok(tc(0xF3, 8) == -13 and oc(0xF3, 8) == -12, '0xF3 = -13 (two) and -12 (ones)')
ok(tc(0xF3A, 12) == -198, '0xF3A as 12-bit two complement = -198')
# overflow iff carry into msb != carry out, iff same-sign operands give different-sign result
n = 6; M = (1 << n) - 1
for a in range(1 << n):
    for b in range(1 << n):
        s = (a + b) & M
        cout = (a + b) >> n; cin = ((a & (M >> 1)) + (b & (M >> 1))) >> (n - 1)
        ov_true = not (-(1 << n-1) <= tc(a, n) + tc(b, n) <= (1 << n-1) - 1)
        ov_sign = (a >> n-1) == (b >> n-1) and (s >> n-1) != (a >> n-1)
        assert ov_true == (cin != cout) == ov_sign
ok(True, 'overflow rule: carry-in(msb) xor carry-out == sign rule == true overflow (exhaustive, n=6)')
ok(tc((100 + 50) & 0xFF, 8) == -106, '100+50 in 8 bits wraps to -106')
# sign extension preserves value
ok(all(tc(x | (((1 << 8) - 1) << 8 if x >> 7 else 0), 16) == tc(x, 8) for x in range(256)), 'sign extension 8->16 preserves value')
ok(2 ** (2 ** 3) == 256, 'number of 3-input Boolean functions 256')
# NAND universality by construction
nand = lambda a, b: 1 - (a & b)
NOT = lambda a: nand(a, a); AND = lambda a, b: NOT(nand(a, b)); OR = lambda a, b: nand(NOT(a), NOT(b))
ok(all(NOT(a) == 1 - a and AND(a, b) == a & b and OR(a, b) == a | b for a in (0, 1) for b in (0, 1)), 'NAND builds NOT, AND, OR')
# full adder: sum = a^b^c, cout = ab + c(a^b): 2 gate levels for carry per bit -> ripple 2n
ok(all(((a ^ b ^ c) + 2 * ((a & b) | (c & (a ^ b)))) == a + b + c for a in (0, 1) for b in (0, 1) for c in (0, 1)), 'full adder equations')
ok(2 * 32 == 64, 'ripple carry worst case 2n = 64 gate delays for n=32')
# timing: T >= tcq + tcomb + tsetup (+ skew)
T = 40 + 610 + 25; ok(abs(1e3 / T - 1.4815) < 1e-4, f'fmax for 40+610+25 ps = {1e3/T:.4f} GHz')
ok(50 + 400 + 30 == 480 and abs(1e3 / 480 - 2.0833) < 1e-4, 'fmax 480 ps = 2.083 GHz')
# hold: tcq_min + tcomb_min >= thold
ok(30 + 15 >= 40, 'hold example 30+15 >= 40 ps holds')
# ---- U14.2 encodings
def mips_r(op, rs, rt, rd, sh, fn): return (op << 26) | (rs << 21) | (rt << 16) | (rd << 11) | (sh << 6) | fn
ok(mips_r(0, 17, 18, 8, 0, 0x20) == 0x02324020, 'MIPS add $t0,$s1,$s2 = 0x02324020')
def a64_add_reg(rd, rn, rm, sf=1): return (sf << 31) | (0b0001011 << 24) | (0 << 22) | (0 << 21) | (rm << 16) | (0 << 10) | (rn << 5) | rd
ok(a64_add_reg(0, 1, 2) == 0x8B020020, 'A64 ADD X0,X1,X2 = 0x8B020020 (shifted-register form, recalled layout)')
def rv_r(f7, rs2, rs1, f3, rd, op): return (f7 << 25) | (rs2 << 20) | (rs1 << 15) | (f3 << 12) | (rd << 7) | op
ok(rv_r(0, 2, 1, 0, 10, 0x33) == 0x00208533, 'RISC-V add x10,x1,x2 = 0x00208533')
ok((2 ** 25) * 4 == 128 * 2 ** 20, 'B imm26 x4 reaches +-128 MiB')
ok((2 ** 18) * 4 == 2 ** 20, 'B.cond/CBZ imm19 x4 reaches +-1 MiB')
ok((2 ** 18 - 1) * 4 == 1048572, 'largest forward CBZ offset 1048572 bytes')
ok(2 ** 15 * 4 == 131072, 'MIPS beq imm16 words reach +-128 KiB')
# expanding opcode: 4-bit opcode field, 15 three-address ops leave 1 escape x 16 = 16 two-address patterns ...
# ---- U14.3
f = [0.45, 0.25, 0.10, 0.20]; c = [1, 4, 3, 2]
cpi = sum(a * b for a, b in zip(f, c)); ok(abs(cpi - 2.15) < 1e-12, 'CPI mix = 2.15')
ok(abs(3200 / cpi - 1488.37) < 0.01, f'MIPS at 3.2 GHz = {3200/cpi:.2f}')
ok(abs(1 / (0.6 + 0.4 / 10) - 1.5625) < 1e-12, 'Amdahl F=0.4,S=10 -> 1.5625')
# geometric mean reference independence
rng = np.random.default_rng(0)
a, b, r1, r2 = rng.uniform(1, 10, (4, 6))
gm = lambda x: float(np.exp(np.mean(np.log(x))))
ok(abs(gm(a / r1) / gm(b / r1) - gm(a / r2) / gm(b / r2)) < 1e-12, 'GM ratio independent of reference machine')
ok(abs(gm(a / r1) / gm(b / r1) - gm(a / b)) < 1e-12, 'GM(a/r)/GM(b/r) = GM(a/b)')
am = np.mean(a); hm = len(a) / np.sum(1 / a); ok(am >= gm(a) >= hm, 'AM >= GM >= HM')
# AM of times consistent with total time; arithmetic mean of rates misleads: two programs 1e9 instr, 1s and 4s
ok(abs(2 / (1 / 1000 + 1 / 250) - 400) < 1e-9, 'harmonic mean of 1000 and 250 MIPS for equal work = 400 = 2e9/5s')
# iron law example: 2e9 instr, CPI 1.5, 2 GHz -> 1.5 s
ok(abs(2e9 * 1.5 / 2e9 - 1.5) < 1e-12, 'iron law 2e9*1.5/2e9 = 1.5 s')
# availability
ok(abs(1000 / (1000 + 2) - 0.998004) < 1e-6, 'availability MTTF 1000 h MTTR 2 h')
# dies per wafer (recalled formula) example 300 mm, 1.5 cm^2
d = 30; A = 1.5
dpw = math.pi * (d / 2) ** 2 / A - math.pi * d / math.sqrt(2 * A); ok(abs(dpw - 416.8) < 0.05, f'dies per wafer = {dpw:.1f}')
# ---- U14.4
def ks_cells(n): L = int(math.log2(n)); return sum(n - 2 ** k for k in range(L))
ok(all(ks_cells(n) == n * int(math.log2(n)) - n + 1 for n in (4, 8, 16, 32, 64)), 'Kogge-Stone cells n log n - n + 1')
def bk(n):  # Brent-Kung: up-sweep + down-sweep, count cells and depth
    L = int(math.log2(n)); up = sum(n // 2 ** (k + 1) for k in range(L)); down = sum(2 ** k - 1 for k in range(1, L))
    return up + down, 2 * L - 1
ok(all(bk(n) == (2 * n - 2 - int(math.log2(n)), 2 * int(math.log2(n)) - 1) for n in (4, 8, 16, 32, 64)), 'Brent-Kung cells 2n-2-log n, depth 2 log n - 1')
# verify prefix carries equal ripple carries for random inputs, n=16, Kogge-Stone
def ks_add(a, b, n):
    g = [(a >> i & 1) & (b >> i & 1) for i in range(n)]; p = [(a >> i & 1) ^ (b >> i & 1) for i in range(n)]
    G, P = g[:], p[:]; d = 1
    while d < n:
        G2, P2 = G[:], P[:]
        for i in range(d, n):
            G2[i] = G[i] | (P[i] & G[i - d]); P2[i] = P[i] & P[i - d]
        G, P, d = G2, P2, d * 2
    c = [0] + G[:-1]
    return sum(((p[i] ^ c[i]) << i) for i in range(n)) | (G[n - 1] << n)
ok(all(ks_add(x, y, 16) == x + y for x, y in rng.integers(0, 2 ** 16, (2000, 2)).tolist()), 'Kogge-Stone adder = integer add (2000 random 16-bit)')
def wallace_levels(k):
    m, d = 2, 0
    while m < k: m = (3 * m) // 2; d += 1
    return d
ok([wallace_levels(k) for k in (3, 4, 6, 9, 13, 19, 28, 42, 63)] == list(range(1, 10)), 'Wallace 3:2 capacities 3,4,6,9,13,19,28,42,63')
ok(wallace_levels(32) == 8 and wallace_levels(24) == 7 and wallace_levels(16) == 6, 'Wallace levels 16->6, 24->7, 32->8')
# simulate 3:2 reduction directly
def reduce_levels(k):
    d = 0
    while k > 2: k = 2 * (k // 3) + k % 3; d += 1
    return d
ok(all(reduce_levels(k) == wallace_levels(k) for k in range(3, 200)), 'greedy 3:2 reduction matches capacity sequence')
# Booth radix-2 recoding value preserved
def booth2(x, n):
    bits = [(x >> i) & 1 for i in range(n)]; prev = 0; ds = []
    for i in range(n): ds.append(prev - bits[i]); prev = bits[i]
    return ds
ok(all(sum(d * 2 ** i for i, d in enumerate(booth2(x & 0xFF, 8))) == tc(x & 0xFF, 8) for x in range(-128, 128)), 'Booth radix-2 digits a(i-1)-a(i) reproduce the two complement value')
def booth4(x, n):
    xs = [(x >> i) & 1 for i in range(n)]; out = []
    for j in range(0, n, 2):
        bm1 = xs[j - 1] if j else 0; out.append(-2 * xs[j + 1] + xs[j] + bm1)
    return out
ok(all(sum(d * 4 ** i for i, d in enumerate(booth4(x & 0xFF, 8))) == tc(x & 0xFF, 8) and all(-2 <= d <= 2 for d in booth4(x & 0xFF, 8)) for x in range(-128, 128)), 'radix-4 Booth digits in {-2..2}, n/2 partial products')
# restoring / non-restoring division
def nonrestoring(N, D, n):
    R, Q = 0, 0
    for i in range(n - 1, -1, -1):
        if R >= 0: R = 2 * R + ((N >> i) & 1) - D
        else: R = 2 * R + ((N >> i) & 1) + D
        Q = (Q << 1) | (1 if R >= 0 else 0)
    if R < 0: R += D
    return Q, R
ok(all(nonrestoring(N, D, 8) == divmod(N, D) for N in range(256) for D in range(1, 256)), 'non-restoring division = divmod (all 8-bit)')
# IEEE 754
f32 = lambda u: float(np.array([u], dtype=np.uint32).view(np.float32)[0])
ok(f32(0xC0B00000) == -5.5 and f32(0xC1240000) == -10.25 and f32(0x3F400000) == 0.75, 'binary32 decodes -5.5, -10.25, 0.75')
fi = np.finfo(np.float32)
ok(float(fi.max) == (2 - 2 ** -23) * 2 ** 127 and float(fi.tiny) == 2 ** -126 and float(fi.eps) == 2 ** -23, 'binary32 max, min normal, eps')
ok(f32(1) == 2 ** -149, 'min binary32 subnormal 2^-149')
ok(np.finfo(np.float64).eps == 2 ** -52, 'binary64 eps 2^-52')
ok((1e16 + 1.0) - 1e16 == 0.0 and (1e16 - 1e16) + 1.0 == 1.0, '(1e16+1)-1e16 = 0 but (1e16-1e16)+1 = 1 in binary64')
# Sterbenz: y/2<=x<=2y => x-y exact
xs = rng.uniform(1, 2, 20000); ys = xs * rng.uniform(0.5, 2, 20000)
from fractions import Fraction
ok(all(Fraction(float(x)) - Fraction(float(y)) == Fraction(float(x) - float(y)) for x, y in zip(xs, ys) if y / 2 <= x <= 2 * y), 'Sterbenz lemma exact subtraction (20000 samples)')
# round-to-nearest-even example: 1 + 2^-24 in binary32 rounds to 1 (tie to even), 1+3*2^-24 rounds up
ok(np.float32(1 + 2 ** -24) == 1 and np.float32(1 + 3 * 2 ** -24) == 1 + 2 ** -22, 'RNE ties-to-even cases in binary32')
# ---- U14.5
fr = {'load': .25, 'store': .10, 'R': .45, 'branch': .15, 'jump': .05}; st = {'load': 5, 'store': 4, 'R': 4, 'branch': 3, 'jump': 3}
cpi = sum(fr[k] * st[k] for k in fr); ok(abs(cpi - 4.05) < 1e-12, 'multi-cycle CPI 4.05')
ok(200 + 100 + 200 + 200 + 100 == 800 and abs(cpi * 200 - 810) < 1e-9, 'single-cycle 800 ps vs multi-cycle 4.05*200 = 810 ps')
fr2 = {'load': .20, 'store': .10, 'R': .50, 'branch': .15, 'jump': .05}
cpi2 = sum(fr2[k] * st[k] for k in fr2); ok(abs(cpi2 - 4.0) < 1e-12, "A14.5 NAT multi-cycle CPI 4.00")
ok(256 * 48 == 12288, 'control store 256 x 48 = 12288 bits')
ok(math.ceil(math.log2(9)) == 4 and 9 + 5 + 3 == 17 and 4 + 3 + 2 == 9, 'vertical encoding 17 one-hot bits -> 9 encoded bits (groups of 9,5,3 incl. none)')
print('B1 all checks passed')
