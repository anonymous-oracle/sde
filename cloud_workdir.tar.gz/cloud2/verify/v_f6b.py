# from-scratch builds promised in U21.3: strided arrays with broadcasting, mini data frame, formula parser
import numpy as np, itertools, random, pandas as pd, re
rng=np.random.default_rng(8); random.seed(8)
class Arr:
    """flat buffer + shape + strides (in elements) + offset: views share the buffer"""
    def __init__(s,buf,shape,strides=None,offset=0):
        s.buf=buf; s.shape=tuple(shape); s.offset=offset
        if strides is None:
            st=[];acc=1
            for n in reversed(s.shape): st.append(acc); acc*=n
            strides=tuple(reversed(st))
        s.strides=tuple(strides)
    def tolist_flat(s):
        out=[]
        for idx in itertools.product(*[range(n) for n in s.shape]):
            out.append(s.buf[s.offset+sum(i*t for i,t in zip(idx,s.strides))])
        return out
    def T(s): return Arr(s.buf,s.shape[::-1],s.strides[::-1],s.offset)
    def reshape(s,shape):
        # only for contiguous C-order arrays
        return Arr(s.buf,shape,None,s.offset)
    def slice(s,axis,start,stop,step=1):
        n=len(range(start,stop,step)); sh=list(s.shape); st=list(s.strides); sh[axis]=n; off=s.offset+start*st[axis]; st[axis]*=step
        return Arr(s.buf,sh,st,off)
    def broadcast_to(s,shape):
        if len(shape)<len(s.shape): raise ValueError('rank')
        pad=len(shape)-len(s.shape); sh=(1,)*pad+s.shape; st=(0,)*pad+s.strides; ns=[]
        for a,b,t in zip(sh,shape,st):
            if a==b: ns.append(t)
            elif a==1: ns.append(0)
            else: raise ValueError('cannot broadcast')
        return Arr(s.buf,shape,ns,s.offset)
def bshape(a,b):
    out=[]
    for x,y in itertools.zip_longest(reversed(a),reversed(b),fillvalue=1):
        if x==y or y==1: out.append(x)
        elif x==1: out.append(y)
        else: raise ValueError('shapes %s %s'%(a,b))
    return tuple(reversed(out))
def add(a,b):
    sh=bshape(a.shape,b.shape); A=a.broadcast_to(sh).tolist_flat(); B=b.broadcast_to(sh).tolist_flat()
    return Arr([x+y for x,y in zip(A,B)],sh)
ok=0;err=0;mism=0
for _ in range(400):
    ra=random.randint(1,3); rb=random.randint(1,3)
    sa=tuple(random.choice([1,2,3,4]) for _ in range(ra)); sb=tuple(random.choice([1,2,3,4]) for _ in range(rb))
    xa=rng.integers(0,100,size=sa); xb=rng.integers(0,100,size=sb)
    A=Arr(xa.ravel().tolist(),sa); B=Arr(xb.ravel().tolist(),sb)
    try: ref=xa+xb
    except ValueError: ref=None
    try: mine=add(A,B)
    except ValueError: mine=None
    if ref is None and mine is None: err+=1
    elif ref is None or mine is None: mism+=1
    else:
        if mine.shape==ref.shape and mine.tolist_flat()==ref.ravel().tolist(): ok+=1
        else: mism+=1
print('broadcast: agree on result',ok,'agree on error',err,'mismatch',mism)
# views: transpose, slice, reshape share the buffer, no copy
x=np.arange(24); A=Arr(x.tolist(),(2,3,4)); xr=x.reshape(2,3,4)
t=A.T(); print('transpose equal',t.tolist_flat()==xr.T.ravel().tolist(),'shape',t.shape,'strides',t.strides,'numpy strides(elements)',tuple(s//8 for s in xr.T.strides))
sl=A.slice(2,1,4,2); print('slice equal',sl.tolist_flat()==xr[:,:,1:4:2].ravel().tolist(),sl.shape,sl.strides,'buffer is same object',sl.buf is A.buf)
A.buf[5]=999; print('write through view seen',999 in sl.tolist_flat() or 999 in t.tolist_flat())
# stride-0 broadcast column+row
col=Arr([0,1,2],(3,1)); row=Arr([10,20,30,40],(1,4)); r=add(col,row); print('col+row',r.shape,r.tolist_flat()[:8],'stride0 strides',col.broadcast_to((3,4)).strides)
# mini frame: groupby and hash-join merge
def groupby_mean(keys,vals):
    d={}
    for k,v in zip(keys,vals):
        c=d.setdefault(k,[0,0.0]); c[0]+=1; c[1]+=v
    return {k:(c[0],c[1]/c[0]) for k,c in d.items()}
def merge(L,R,on,how):
    idx={}
    for j,k in enumerate(R[on]): idx.setdefault(k,[]).append(j)
    rows=[]; used=set()
    for i,k in enumerate(L[on]):
        if k in idx:
            for j in idx[k]: rows.append((k,i,j)); used.add(j)
        elif how in('left','outer'): rows.append((k,i,None))
    if how=='outer':
        for j,k in enumerate(R[on]):
            if j not in used: rows.append((k,None,j))
    return rows
bad=0
for trial in range(200):
    n=random.randint(0,30); m=random.randint(0,30)
    L=pd.DataFrame({'k':rng.integers(0,8,size=n),'a':rng.normal(size=n)}); R=pd.DataFrame({'k':rng.integers(0,8,size=m),'b':rng.normal(size=m)})
    for how in ('inner','left','outer'):
        mine=len(merge({'k':L.k.tolist()},{'k':R.k.tolist()},'k',how)); ref=len(L.merge(R,on='k',how=how))
        bad+= mine!=ref
    if n:
        g=groupby_mean(L.k.tolist(),L.a.tolist()); gp=L.groupby('k').a.agg(['count','mean'])
        for k in g: bad+= not(g[k][0]==gp.loc[k,'count'] and abs(g[k][1]-gp.loc[k,'mean'])<1e-12)
print('merge row counts and groupby: 200 random tables, disagreements',bad)
# formula parser
def parse_formula(f):
    lhs,rhs=[t.strip() for t in f.split('~')]; terms=[t.strip() for t in rhs.split('+')]
    intercept=True; out=[]
    for t in terms:
        if t=='1': continue
        if t in('0','-1'): intercept=False; continue
        out.append(t)
    return lhs,intercept,out
print(parse_formula('y ~ x1 + x2 + x1:x2 + C(g)'))
import patsy
df=pd.DataFrame({'x1':rng.normal(size=5),'x2':rng.normal(size=5),'g':list('abcab')})
print('patsy columns for C(g) + x1:x2',patsy.dmatrix('C(g) + x1:x2',df).design_info.column_names,'no intercept',patsy.dmatrix('0 + x1',df).shape)
