import numpy as np, math, itertools, collections
from scipy import stats, special
rng=np.random.default_rng(21)
def say(*a): print(*a)
# U20.1
n,t=100,0.1; X=rng.binomial(n,0.5,size=400000)/n; say('Hoeffding bound',2*math.exp(-2*n*t*t),'emp',np.mean(np.abs(X-0.5)>=t),'exact',stats.binom.cdf(40,n,.5)+stats.binom.sf(59,n,.5))
mu=0.01;n=2000; say('Chernoff mult upper delta=1',math.exp(-n*mu*1/3), 'emp P(X>=2mu n)',stats.binom.sf(2*n*mu-1,n,mu), 'exp(-mu n/3)')
# GD kappa
for kap in (10,100):
    A=np.diag(np.linspace(1,kap,50)); x=np.ones(50); L=kap; mu_=1; eta=2/(L+mu_); it=0
    while np.linalg.norm(x)>1e-6: x=x-eta*(A@x); it+=1
    say('GD kappa',kap,'iters to 1e-6',it,'pred',math.log(1e6*math.sqrt(50))/-math.log((kap-1)/(kap+1)))
say('memory svm GB',300*10**7*4/1e9,'wiki')
# SVD low rank via randomised
A=rng.normal(size=(2000,50))@rng.normal(size=(50,1000))+0.01*rng.normal(size=(2000,1000)); U,s,Vt=np.linalg.svd(A,full_matrices=False)
Om=rng.normal(size=(1000,60)); Y=A@Om; Q,_=np.linalg.qr(Y); B=Q.T@A; Ub,sb,Vtb=np.linalg.svd(B,full_matrices=False)
say('randomised SVD top5 rel err',np.max(np.abs(sb[:5]-s[:5])/s[:5]),'low-rank err',np.linalg.norm(A-Q@B)/np.linalg.norm(A-(U[:,:60]*s[:60])@Vt[:60]))
# U20.2 universal hash collision
p=2**31-1; m=1024; x,y=12345,987654321 % p; cnt=0; T=400000
a=rng.integers(1,p,size=T); b=rng.integers(0,p,size=T); cnt=np.mean(((a*x+b)%p)%m==((a*y+b)%p)%m); say('collision prob',cnt,'1/m',1/m)
# Bloom
def bloom_fpr(n,m,k,trials=200000):
    bits=np.zeros(m,bool); 
    items=rng.integers(0,2**62,size=n)
    salts=rng.integers(1,2**61,size=k)
    for it in items:
        for s_ in salts: bits[(it*s_+s_)%(2**61-1)%m]=True
    q=rng.integers(0,2**62,size=trials)
    hit=np.ones(trials,bool)
    for s_ in salts: hit&=bits[(q*s_+s_)%(2**61-1)%m]
    return hit.mean()
n=10000; 
for bpi,k in [(10,7),(10,3),(8,6),(16,11)]:
    m=bpi*n; th=(1-math.exp(-k*n/m))**k; say('bloom bits/item',bpi,'k',k,'theory',th,'sim',bloom_fpr(n,m,k,100000))
say('optimal k for 10 bits',10*math.log(2),'min fpr',0.6185**10)
# KMV
def kmv(stream_n,k):
    h=rng.random(stream_n); return (k-1)/np.partition(h,k-1)[k-1]
for k in (64,256,1024):
    est=np.array([kmv(100000,k) for _ in range(300)]); say('KMV k',k,'rel rmse',np.sqrt(np.mean((est/100000-1)**2)),'theory 1/sqrt(k-2)',1/math.sqrt(k-2))
# Misra-Gries
def mg(stream,k):
    c={}
    for x in stream:
        if x in c: c[x]+=1
        elif len(c)<k: c[x]=1
        else:
            for key in list(c): 
                c[key]-=1
                if c[key]==0: del c[key]
    return c
z=rng.zipf(1.3,size=200000); z=z[z<10**6]; N=len(z); true=collections.Counter(z); k=99
c=mg(z,k); err=max(true[x]-c.get(x,0) for x in true); say('MG N',N,'k',k,'max undercount',err,'bound N/(k+1)',N/(k+1),'items f>N/(k+1)',[x for x in true if true[x]>N/(k+1)] , 'all present', all(x in c for x in true if true[x]>N/(k+1)))
# U20.3 count-min
eps,delta=0.001,0.01; w=math.ceil(math.e/eps); d=math.ceil(math.log(1/delta)); say('CM w,d',w,d,'cells',w*d)
P=2**61-1; ha=rng.integers(1,P,size=d); hb=rng.integers(0,P,size=d)
tab=np.zeros((d,w),int)
keys=np.array(list(true.keys()),dtype=np.int64)
cnts=np.array([true[x] for x in keys])
for r in range(d):
    idx=((ha[r]*keys.astype(object)+hb[r])%P%w).astype(np.int64)
    np.add.at(tab[r],idx,cnts)
est=np.min([tab[r][((ha[r]*keys.astype(object)+hb[r])%P%w).astype(np.int64)] for r in range(d)],axis=0)
over=est-cnts; say('CM overcount max',over.max(),'eps*N',eps*N,'frac > epsN',np.mean(over>eps*N),'never under',np.all(over>=0),'distinct',len(keys),'exact table size',len(keys))
# Count sketch
d=5;w=2000; ct=np.zeros((d,w)); sg=[rng.choice([-1,1],size=10**6+1) for _ in range(d)]; hs=[rng.integers(0,w,size=10**6+1) for _ in range(d)]
for r in range(d): np.add.at(ct[r],hs[r][keys],sg[r][keys]*cnts)
ests=np.median([sg[r][keys]*ct[r][hs[r][keys]] for r in range(d)],axis=0); f2=math.sqrt((cnts**2).sum()); say('CS max err',np.abs(ests-cnts).max(),'F2',f2,'F2/sqrt(w)',f2/math.sqrt(w))
# MinHash
A=set(range(0,1500)); B=set(range(500,2000)); J=len(A&B)/len(A|B); say('J',J)
H=128; est=[]
for _ in range(2000):
    salts=rng.integers(1,2**61,size=(H,2)); 
    ha_=np.array([min(((s[0]*x+s[1])%(2**61-1)) for x in list(A)[:0] or A) for s in salts[:1]])
est=None
def mh(S,salts): 
    arr=np.fromiter(S,dtype=object); return np.array([min((int(s[0])*int(x)+int(s[1]))%(2**61-1) for x in arr) for s in salts])
# faster using ints in numpy with modulus 2^31-1
def mh2(S,a,b): 
    x=np.fromiter(S,dtype=np.int64); return ((a[:,None]*x[None,:]+b[:,None])%2147483647).min(1)
res=[]
for _ in range(300):
    a_=rng.integers(1,2147483647,size=H,dtype=np.int64); b_=rng.integers(0,2147483647,size=H,dtype=np.int64)
    res.append(np.mean(mh2(A,a_,b_)==mh2(B,a_,b_)))
res=np.array(res); say('minhash mean',res.mean(),'sd',res.std(),'theory sd',math.sqrt(J*(1-J)/H))
r,bb=5,20
for s in (0.3,0.5,0.55,0.8): say('S-curve s',s,1-(1-s**r)**bb)
say('threshold',(1/bb)**(1/r))
# SimHash
u=rng.normal(size=100); v=u*0.8+rng.normal(size=100)*0.6; th=math.acos(u@v/np.linalg.norm(u)/np.linalg.norm(v)); Rn=rng.normal(size=(200000,100)); agree=np.mean(np.sign(Rn@u)==np.sign(Rn@v)); say('simhash agree',agree,'1-theta/pi',1-th/math.pi)
# kd-tree distance computations
class KD:
    def __init__(s,pts,idx=None,depth=0):
        s.d=0
        s.root=s.build(pts,np.arange(len(pts)),0)
    def build(s,pts,idx,depth):
        if len(idx)==1: return ('leaf',idx[0])
        ax=depth%pts.shape[1]; o=idx[np.argsort(pts[idx,ax])]; mid=len(o)//2
        return ('node',ax,pts[o[mid],ax],s.build(pts,o[:mid],depth+1) if mid>0 else None,s.build(pts,o[mid:],depth+1))
def nn(pts,node,q,best,cnt):
    if node is None: return
    if node[0]=='leaf':
        cnt[0]+=1; d=np.linalg.norm(pts[node[1]]-q)
        if d<best[0]: best[0]=d
        return
    _,ax,val,l,r=node; near,far=(l,r) if q[ax]<val else (r,l)
    nn(pts,near,q,best,cnt)
    if abs(q[ax]-val)<best[0]: nn(pts,far,q,best,cnt)
for dim in (2,8,16,32):
    pts=rng.random(size=(5000,dim)); kd=KD(pts); tot=0
    for _ in range(100):
        q=rng.random(dim); cnt=[0]; best=[1e9]; nn(pts,kd.root,q,best,cnt); tot+=cnt[0]
    say('kd dim',dim,'avg distance computations',tot/100,'of 5000')
# U20.4 b-bit
J=0.5; Hbits=1024
for b_ in (1,2,8,64):
    C=2.0**-b_
    est=[]
    for _ in range(500):
        match=rng.random(Hbits//b_ if b_<=64 else Hbits)<(C+(1-C)*J)
        est.append((match.mean()-C)/(1-C))
    say('b',b_,'hashes',Hbits//b_,'rmse',np.sqrt(np.mean((np.array(est)-J)**2)))
# JL
nn_=10**4;eps=0.1; say('JL k',math.ceil(4*math.log(nn_)/(eps**2/2-eps**3/3)))
Xp=rng.normal(size=(200,5000)); 
for k in (100,400,1600):
    R=rng.normal(size=(5000,k))/math.sqrt(k); Y=Xp@R
    from scipy.spatial.distance import pdist
    ratio=pdist(Y)/pdist(Xp); say('JL k',k,'ratio min max',ratio.min(),ratio.max(),'frac within 10%',np.mean(np.abs(ratio-1)<=0.1),'theory sd',1/math.sqrt(2*k))
# U20.5 CUR
Am=rng.normal(size=(400,20))@rng.normal(size=(20,300))+0.05*rng.normal(size=(400,300)); U_,s_,Vt_=np.linalg.svd(Am,full_matrices=False)
kk=20; opt=np.linalg.norm(Am-(U_[:,:kk]*s_[:kk])@Vt_[:kk]); lev_c=(Vt_[:kk]**2).sum(0)/kk; lev_r=(U_[:,:kk]**2).sum(1)/kk
for c in (40,80,160):
    cs=rng.choice(300,c,replace=False,p=lev_c); rs=rng.choice(400,c,replace=False,p=lev_r); C=Am[:,cs];R=Am[rs];Um=np.linalg.pinv(C)@Am@np.linalg.pinv(R); say('CUR c',c,'err/opt',np.linalg.norm(Am-C@Um@R)/opt)
# sparse RP (Achlioptas)
k=200; Rsp=rng.choice([-1,0,1],size=(5000,k),p=[1/6,2/3,1/6])*math.sqrt(3/k); Y=Xp@Rsp; ratio=pdist(Y)/pdist(Xp); say('sparse RP ratio sd',ratio.std(),'dense',(pdist(Xp@(rng.normal(size=(5000,k))/math.sqrt(k)))/pdist(Xp)).std(),'nonzero frac',np.mean(Rsp!=0))
# subspace embedding least squares
n_,d_=20000,20; Ax=rng.normal(size=(n_,d_)); bx=Ax@rng.normal(size=d_)+rng.normal(size=n_); x_opt=np.linalg.lstsq(Ax,bx,rcond=None)[0]; r_opt=np.linalg.norm(Ax@x_opt-bx)
for kk in (100,400,1600):
    S=rng.normal(size=(kk,n_))/math.sqrt(kk); xs=np.linalg.lstsq(S@Ax,S@bx,rcond=None)[0]; say('sketch LS k',kk,'resid ratio',np.linalg.norm(Ax@xs-bx)/r_opt)
# kitchen sink RFF
Xk=rng.normal(size=(300,5)); g=0.5; from scipy.spatial.distance import cdist
K=np.exp(-g*cdist(Xk,Xk,'sqeuclidean'))
for D in (50,500,5000):
    W=rng.normal(size=(5,D))*math.sqrt(2*g); bb_=rng.uniform(0,2*math.pi,D); Z=math.sqrt(2/D)*np.cos(Xk@W+bb_); say('RFF D',D,'max err',np.abs(Z@Z.T-K).max(),'mean err',np.abs(Z@Z.T-K).mean(),'1/sqrt D',1/math.sqrt(D))
# U20.6 mini mapreduce
def mapreduce(data,mapper,reducer):
    inter=collections.defaultdict(list); emitted=0
    for rec in data:
        for k_,v in mapper(rec): inter[k_].append(v); emitted+=1
    return {k_:reducer(k_,vs) for k_,vs in inter.items()},emitted
n=20; A=rng.normal(size=(n,n)); B=rng.normal(size=(n,n))
recs=[('A',i,k_,A[i,k_]) for i in range(n) for k_ in range(n)]+[('B',k_,j,B[k_,j]) for k_ in range(n) for j in range(n)]
def m1(r):
    if r[0]=='A': return [((r[1],j),('A',r[2],r[3])) for j in range(n)]
    return [((i,r[2]),('B',r[1],r[3])) for i in range(n)]
def r1(key,vs):
    a={k_:v for t,k_,v in vs if t=='A'}; b={k_:v for t,k_,v in vs if t=='B'}; return sum(a[k_]*b[k_] for k_ in a)
C1,em1=mapreduce(recs,m1,r1); C1m=np.array([[C1[(i,j)] for j in range(n)] for i in range(n)])
def m2a(r): return [(r[2] if r[0]=='A' else r[1],r)]
def r2a(k_,vs): As=[v for v in vs if v[0]=='A']; Bs=[v for v in vs if v[0]=='B']; return [((a[1],b[2]),a[3]*b[3]) for a in As for b in Bs]
P1,em2a=mapreduce(recs,m2a,r2a); prods=[x for v in P1.values() for x in v]
C2,em2b=mapreduce(prods,lambda kv:[kv],lambda k_,vs:sum(vs)); C2m=np.array([[C2[(i,j)] for j in range(n)] for i in range(n)])
say('MM one-phase pairs',em1,'= 2n^3',2*n**3,'two-phase pairs',em2a+em2b,'= 2n^2+n^3',2*n*n+n**3,'err',np.abs(C1m-A@B).max(),np.abs(C2m-A@B).max())
# pagerank in MR
Nn=50; Adj=(rng.random((Nn,Nn))<0.08).astype(float); np.fill_diagonal(Adj,0)
for j in range(Nn):
    if Adj[:,j].sum()==0: Adj[(j+1)%Nn,j]=1
Mm=Adj/Adj.sum(0); alpha=0.85; v=np.ones(Nn)/Nn
for _ in range(100): v=alpha*Mm@v+(1-alpha)/Nn
vv=np.ones(Nn)/Nn
for it in range(100):
    recs=[(j,vv[j],list(np.nonzero(Adj[:,j])[0])) for j in range(Nn)]
    def mp(r):
        j,pr,outs=r; return [(i,pr/len(outs)) for i in outs]+[(j,0.0)]
    res,_=mapreduce(recs,mp,lambda k_,vs:alpha*sum(vs)+(1-alpha)/Nn); vv=np.array([res[i] for i in range(Nn)])
say('PR MR vs power',np.abs(vv-v).max(),'sum',vv.sum())
# k-means MR 
Xc=np.vstack([rng.normal(c,0.5,size=(200,2)) for c in ([0,0],[4,0],[0,4])]); cen=Xc[rng.choice(600,3,replace=False)]
for it in range(10):
    res,em=mapreduce(list(Xc),lambda x:[(int(np.argmin(((cen-x)**2).sum(1))),(x,1))],lambda k_,vs:(sum(v[0] for v in vs)/len(vs)))
    cen=np.array([res[k_] for k_ in sorted(res)])
say('kmeans MR centres',np.round(cen[np.lexsort(cen.T)],2).tolist())
# U20.7 SGD
nS,dS=5000,10; Xs=rng.normal(size=(nS,dS)); wt=rng.normal(size=dS); ys=np.sign(Xs@wt+0.5*rng.normal(size=nS)); 
def loss(w): return np.mean(np.log1p(np.exp(-ys*(Xs@w))))
# optimum by GD
w=np.zeros(dS)
for _ in range(3000):
    g=-(Xs.T@(ys/(1+np.exp(ys*(Xs@w)))))/nS; w-=0.5*g
fstar=loss(w); R=np.linalg.norm(w); G=np.max(np.linalg.norm(Xs,axis=1))
for T in (1000,10000,100000):
    eta=R/(G*math.sqrt(T)); wc=np.zeros(dS); avg=np.zeros(dS)
    for t in range(T):
        i=rng.integers(nS); gi=-ys[i]*Xs[i]/(1+math.exp(ys[i]*(Xs[i]@wc))); wc=wc-eta*gi; avg+=wc
    avg/=T; say('SGD T',T,'subopt',loss(avg)-fstar,'bound RG/sqrtT',R*G/math.sqrt(T))
# GD cost
say('per-step cost ratio',nS)
# U20.8 ADMM consensus LS
mW=4; nn_=400;dd=10; Ai=[rng.normal(size=(nn_,dd)) for _ in range(mW)]; wt=rng.normal(size=dd); bi=[a@wt+0.5*rng.normal(size=nn_) for a in Ai]
Aall=np.vstack(Ai); ball=np.concatenate(bi); xs=np.linalg.lstsq(Aall,ball,rcond=None)[0]
rho=1.0; x=[np.zeros(dd) for _ in range(mW)]; u=[np.zeros(dd) for _ in range(mW)]; z=np.zeros(dd); hist=[]
for it in range(100):
    x=[np.linalg.solve(a.T@a+rho*np.eye(dd),a.T@b+rho*(z-ui)) for a,b,ui in zip(Ai,bi,u)]
    z=np.mean([xi+ui for xi,ui in zip(x,u)],0); u=[ui+xi-z for xi,ui in zip(x,u)]; hist.append(np.linalg.norm(z-xs))
say('ADMM err at 5,10,20,50',[hist[i] for i in (4,9,19,49)],'first below 1e-6',next((i+1 for i,h in enumerate(hist) if h<1e-6),'not within 100 iterations at rho=1; see v_f4b for the rho sweep'))
# lasso ADMM
Al=rng.normal(size=(100,50)); xt=np.zeros(50); xt[:5]=[3,-2,1.5,2,-1]; bl=Al@xt+0.1*rng.normal(size=100); lam=0.1*np.max(np.abs(Al.T@bl)); z=np.zeros(50);u=np.zeros(50); rho=1.0
Mi=np.linalg.inv(Al.T@Al+rho*np.eye(50))
for it in range(300):
    x=Mi@(Al.T@bl+rho*(z-u)); z=np.sign(x+u)*np.maximum(np.abs(x+u)-lam/rho,0); u+=x-z
say('lasso nnz',np.sum(np.abs(z)>1e-6),'support',np.nonzero(np.abs(z)>1e-6)[0][:10],'err',np.linalg.norm(z-xt))
n_,d_,k_,w_=10**8,100,10,100; say('ship data',n_*d_,'per round',k_*d_*w_, 'ratio',n_*d_/(k_*d_*w_))
