# mini ARIES: analysis, redo, undo on a fixed log
log = {1: ('upd', 'T1', 'P1', 0), 2: ('upd', 'T2', 'P2', 0), 3: ('upd', 'T1', 'P2', 1), 4: ('bcp',), 5: ('ecp', {'P1': 1, 'P2': 2}, {'T1': 3, 'T2': 2}),
       6: ('upd', 'T2', 'P3', 2), 7: ('commit', 'T2', 6), 8: ('upd', 'T3', 'P1', 0)}
disk = {'P1': 1, 'P2': 0, 'P3': 0}   # pageLSN on disk at crash
dpt = dict(log[5][1]); att = dict(log[5][2])
for l in range(6, 9):
    r = log[l]
    if r[0] == 'upd':
        dpt.setdefault(r[2], l); att[r[1]] = l
    elif r[0] == 'commit': att.pop(r[1], None)
print('DPT', dpt, 'losers', att, 'redo start', min(dpt.values()))
redo = [l for l in sorted(log) if log[l][0] == 'upd' and log[l][2] in dpt and l >= dpt[log[l][2]] and disk[log[l][2]] < l]
print('redone updates', redo, len(redo))
# undo: losers' updates in reverse LSN order
undo = sorted([l for l in log if log[l][0] == 'upd' and log[l][1] in att], reverse=True); print('undone', undo, 'CLRs', len(undo))
# deferred vs immediate: T1 writes a,b ; T2 writes c; crash after T2 commit, before T1 commit
print('deferred: redo T2 only; immediate: redo T2 + undo T1 (flushes may have happened)')
