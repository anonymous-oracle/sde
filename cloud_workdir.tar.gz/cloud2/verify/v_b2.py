"""B2 recomputation: U14.6-U14.9 and A14.6-A14.9."""
import math, random, collections
import numpy as np
def ok(c, m):
    print(('OK  ' if c else 'FAIL'), m)
    if not c: raise SystemExit(1)
# ---- U14.6
ok(abs(5 * 1000 / (5 + 999) - 4.980) < 1e-3, 'pipeline speed-up nk/(k+n-1) k=5 n=1000 = 4.980')
ok(abs(1 + 0.3 * 0.4 * 1 + 0.15 * 0.6 * 1 - 1.21) < 1e-12, 'CPI 1 + load-use + taken-branch = 1.21')
ok(abs(1 + 0.25 * 0.5 * 1 + 0.20 * 0.65 * 2 - 1.385) < 1e-12, 'A14.6 NAT CPI = 1.385')
# simulate in-order 5-stage hazards for a toy program: load-use with forwarding = 1 stall, without forwarding = 2 stalls (write in first half, read in second)
def stalls(prog, fwd):
    # prog: list of (dest, srcs, is_load); returns total stall cycles in classic 5-stage (IF ID EX MEM WB)
    ready = {}; t_id = 0; total = 0
    for i, (d, srcs, ld) in enumerate(prog):
        t_id = t_id + 1 if i else 1  # earliest ID cycle
        need = max([ready.get(s, 0) for s in srcs] + [0])
        if need > t_id: total += need - t_id; t_id = need
        ex = t_id + 1
        if fwd: ready[d] = ex + (1 if ld else 0)       # consumer ID cycle so its EX >= producer's EX+1 (ALU) or MEM+1 (load)
        else: ready[d] = ex + 2
    return total
prog_lu = [('r1', ['r2'], True), ('r3', ['r1'], False)]
prog_alu = [('r1', ['r2'], False), ('r3', ['r1'], False)]
ok(stalls(prog_lu, True) == 1 and stalls(prog_alu, True) == 0, 'forwarding: load-use 1 stall, ALU-ALU 0 stalls')
ok(stalls(prog_alu, False) == 2 and stalls(prog_lu, False) == 2, 'no forwarding (split-cycle register file): 2 stalls for a dependent next instruction')
# predictors on loops
def run_pred(outcomes, bits):
    mx = (1 << bits) - 1; c = mx; miss = 0     # start strongly taken
    for o in outcomes:
        pred = c > mx // 2
        miss += pred != o
        c = min(mx, c + 1) if o else max(0, c - 1)
    return miss
n = 10; trace = ([True] * (n - 1) + [False]) * 1000
m1, m2 = run_pred(trace, 1), run_pred(trace, 2)
ok(abs(1 - m1 / len(trace) - 0.8) < 2e-3 and abs(1 - m2 / len(trace) - 0.9) < 1e-9, f'loop trip 10: 1-bit accuracy {1-m1/len(trace):.4f} (~0.8), 2-bit 0.9')
# two-bit counter on iid outcomes: stationary pi_i prop (p/q)^i
def two_bit_acc(p):
    q = 1 - p; r = p / q; w = np.array([r ** i for i in range(4)]); pi = w / w.sum()
    return p * (pi[2] + pi[3]) + q * (pi[0] + pi[1])
random.seed(1); p = 0.9
tr = [random.random() < p for _ in range(400000)]
sim = 1 - run_pred(tr, 2) / len(tr)
ok(abs(sim - two_bit_acc(p)) < 3e-3, f'2-bit Markov accuracy p=0.9: formula {two_bit_acc(p):.4f} sim {sim:.4f}')
ok(abs(two_bit_acc(0.9) - 0.8902) < 1e-4 and abs(0.9 ** 2 + 0.1 ** 2 - 0.82) < 1e-12, '2-bit 0.8902 vs 1-bit p^2+q^2 = 0.82 at p=0.9')
ok(abs(two_bit_acc(0.7) - 0.6379) < 1e-4, f'2-bit accuracy at p=0.7 = {two_bit_acc(0.7):.4f}')
# optimal depth: time per instr (T/k + o)(1 + g k) minimised at sqrt(T/(o g))
T, o, g = 2000.0, 40.0, 0.15
ks = np.linspace(1, 60, 600000); f = (T / ks + o) * (1 + g * ks)
ok(abs(ks[np.argmin(f)] - math.sqrt(T / (o * g))) < 1e-3 and abs(math.sqrt(T / (o * g)) - 18.26) < 0.01, 'optimal depth sqrt(T/(o g)) = 18.26')
# gshare index
ok((0b1011001110 ^ 0b0110100101) & 0x3FF == 0b1101101011, 'gshare index = PC bits xor history')
# ---- U14.7
ok(max(math.ceil(9 / 2), math.ceil(7 / 2)) == 5, 'MII = max(ResMII 5, RecMII 4) = 5')
ok(math.ceil((4 + 2) / 1) == 6, 'recurrence a[i]=a[i-1]*b+c with mul 4 add 2, distance 1: RecMII 6')
ok(max(math.ceil(12 / 3), math.ceil(10 / 2), math.ceil(8 / 1)) == 8, 'A14.7 NAT MII = 8')
ok(4 * 100 == 400, 'Little: IPC 4 across a 100-cycle miss needs ~400 window entries')
ok(all(abs((3 * u + 2) / u - (3 + 2 / u)) < 1e-12 for u in (1, 2, 4, 8)) and 3 + 2 / 4 == 3.5, 'unroll by u: 3 + 2/u instructions per element (3.5 at u=4 vs 5)')
# software pipelining: total cycles for N iterations with II and stage count S: (N + S - 1) * II
ok((100 + 3 - 1) * 2 == 204, 'software-pipelined loop 100 iters, II 2, 3 stages = 204 cycles')
# Tomasulo: simulate a tiny example to check WAR/WAW elimination by renaming: count distinct physical tags
def rename(prog, arch=8):
    rat = {f'r{i}': f'p{i}' for i in range(arch)}; nxt = arch; out = []
    for d, s1, s2 in prog:
        a, b = rat[s1], rat[s2]; rat[d] = f'p{nxt}'; out.append((rat[d], a, b)); nxt += 1
    return out
prog = [('r1', 'r2', 'r3'), ('r2', 'r1', 'r4'), ('r1', 'r5', 'r6'), ('r7', 'r1', 'r2')]
rn = rename(prog)
ok(rn == [('p8', 'p2', 'p3'), ('p9', 'p8', 'p4'), ('p10', 'p5', 'p6'), ('p11', 'p10', 'p9')], 'register renaming removes WAR (r2) and WAW (r1), keeps RAW')
# ---- U14.8
ok([w * (w - 1) for w in (2, 4, 6, 8)] == [2, 12, 30, 56], 'intra-group rename comparators w(w-1)')
def mt_sim(N, R, L, C, cycles=200000):
    # coarse-grained switch-on-miss: each thread runs R cycles then waits L; switching costs C busy cycles
    ready_at = [0] * N; t = 0; busy = 0; cur = None
    while t < cycles:
        cand = [i for i in range(N) if ready_at[i] <= t]
        if not cand:
            t = min(ready_at); continue
        i = min(cand, key=lambda j: ready_at[j])
        if cur is not None and i != cur: t += C
        busy += R; t += R; ready_at[i] = t + L; cur = i
    return busy / t
R, L, C = 20, 200, 4
for N in (2, 4, 6):
    ok(abs(mt_sim(N, R, L, C) - N * R / (R + L + C)) < 0.01, f'MT utilisation linear region N={N}: {mt_sim(N,R,L,C):.4f} vs NR/(R+L+C) {N*R/(R+L+C):.4f}')
ok(abs(mt_sim(14, R, L, C) - R / (R + C)) < 0.01, f'MT utilisation saturates at R/(R+C) = {R/(R+C):.4f}')
ok(abs((R + L + C) / (R + C) - 9.333) < 1e-3, 'N_sat = (R+L+C)/(R+C) = 9.33')
ok(abs(6 * 25 / (25 + 300 + 5) - 0.4545) < 1e-4, 'A14.8 NAT utilisation 6*25/330 = 0.4545')
ok(math.ceil(1003 / 4) == 251 and 1003 % 4 == 3, 'strip mining 1003 elements VL 4: 251 strips, remainder 3')
ok(128 // 32 == 4 and 128 // 64 == 2 and 128 // 8 == 16 and 128 // 16 == 8, 'NEON 128-bit lanes: 4 fp32, 2 fp64, 8 fp16, 16 int8')
ok(abs(4 * 4 * 2 * 3.2 - 102.4) < 1e-9, 'hypothetical 4 FMA pipes x 4 lanes x 2 flops x 3.2 GHz = 102.4 GFLOP/s')
# ---- U14.9
def split(size, assoc, line, abits):
    sets = size // (line * assoc); off = int(math.log2(line)); idx = int(math.log2(sets)); return abits - idx - off, idx, off
ok(split(32 * 1024, 8, 64, 48) == (36, 6, 6), '32 KiB 8-way 64 B, 48-bit: tag 36 index 6 offset 6')
ok(split(128 * 1024, 8, 128, 48) == (34, 7, 7), '128 KiB 8-way 128 B lines: tag 34 index 7 offset 7')
ok(split(64 * 1024, 4, 64, 32) == (18, 8, 6), "A14.9 MCQ: 64 KiB 4-way 64 B 32-bit: tag 18 index 8 offset 6")
ok(abs(1 + 0.05 * (10 + 0.2 * 100) - 2.5) < 1e-12, 'AMAT two-level = 2.5')
ok(abs(1 + 0.04 * (12 + 0.25 * 150) - 2.98) < 1e-12, 'A14.9 NAT AMAT = 2.98')
ok(abs((36 + 2) / 512 - 0.0742) < 1e-4, 'tag+valid+dirty overhead 38/512 = 7.4%')
ok((64 // 16) * (8 // 4) == 8, '64Kx8 from 16Kx4 chips: 8 chips, 2-to-4 decoder on 2 high address bits')
def faults_fifo(seq, k):
    q = collections.deque(); s = set(); f = 0
    for x in seq:
        if x not in s:
            f += 1
            if len(q) == k: s.discard(q.popleft())
            q.append(x); s.add(x)
    return f
def faults_lru(seq, k):
    od = collections.OrderedDict(); f = 0
    for x in seq:
        if x in od: od.move_to_end(x)
        else:
            f += 1
            if len(od) == k: od.popitem(last=False)
            od[x] = 1
    return f
def faults_opt(seq, k):
    s = set(); f = 0
    for i, x in enumerate(seq):
        if x in s: continue
        f += 1
        if len(s) == k:
            nxt = {y: (seq.index(y, i + 1) if y in seq[i + 1:] else 10 ** 9) for y in s}
            s.discard(max(nxt, key=nxt.get))
        s.add(x)
    return f
bel = [1, 2, 3, 4, 1, 2, 5, 1, 2, 3, 4, 5]
ok(faults_fifo(bel, 3) == 9 and faults_fifo(bel, 4) == 10, 'Belady anomaly FIFO: 9 faults with 3 frames, 10 with 4')
random.seed(2)
for _ in range(300):
    seq = [random.randint(1, 8) for _ in range(40)]
    for k in range(1, 8):
        assert faults_lru(seq, k + 1) <= faults_lru(seq, k)
        assert faults_opt(seq, k) <= faults_lru(seq, k) and faults_opt(seq, k) <= faults_fifo(seq, k)
ok(True, 'LRU stack property (never more misses with more capacity) and OPT <= LRU, FIFO on 300 random traces')
# 3C on a direct-mapped toy
def dm_misses(blocks, nsets):
    tags = {}; m = 0
    for b in blocks:
        s = b % nsets
        if tags.get(s) != b: m += 1; tags[s] = b
    return m
seq = [0, 8, 0, 8, 1, 2, 3, 0]
comp = len(set(seq)); fa = faults_lru(seq, 8); dm = dm_misses(seq, 8)
ok((comp, fa - comp, dm - fa) == (5, 0, 3), '3C example: 5 compulsory, 0 capacity, 3 conflict')
# Che approximation as oracle (owned by U10.6): LRU hit ratio under Zipf
Nn, Cc, s_ = 1000, 100, 0.8
pz = np.arange(1, Nn + 1) ** -s_; pz /= pz.sum()
from math import exp
def che(tc): return sum(1 - math.exp(-q * tc) for q in pz) - Cc
lo, hi = 1.0, 1e7
for _ in range(100):
    mid = (lo + hi) / 2
    if che(mid) > 0: hi = mid
    else: lo = mid
tc = (lo + hi) / 2; h_che = float(sum(q * (1 - math.exp(-q * tc)) for q in pz))
rng = np.random.default_rng(3); req = rng.choice(Nn, 300000, p=pz)
od = collections.OrderedDict(); hits = 0
for x in req.tolist():
    if x in od: od.move_to_end(x); hits += 1
    else:
        if len(od) == Cc: od.popitem(last=False)
        od[x] = 1
h_sim = hits / len(req)
ok(abs(h_sim - h_che) < 0.01, f'Che approximation {h_che:.4f} vs LRU simulation {h_sim:.4f} (Zipf 0.8, N=1000, C=100)')
print('B2 all checks passed')
