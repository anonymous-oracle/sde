# U17.15 elementary structures and recursion; U17.16 tries, B-trees, skip lists, string matching; U17.17 hard problems
import random, math, itertools, time, sys, collections, heapq
random.seed(15)
print('=== U17.15')
class DynArray:
    def __init__(s,grow): s.cap=1; s.n=0; s.copies=0; s.grow=grow
    def append(s):
        if s.n==s.cap:
            s.copies+=s.n; s.cap=s.grow(s.cap)
        s.n+=1
for name,g in (('double',lambda c:2*c),('+1000',lambda c:c+1000),('x1.5',lambda c:int(c*1.5)+1)):
    for n in (10**5,10**6):
        if name=='+1000' and n==10**6: continue
        a=DynArray(g)
        for _ in range(n): a.append()
        print('dynarray',name,'n',n,'copies',a.copies,'copies/n',round(a.copies/n,3))
def hanoi(n,a='A',b='B',c='C',cnt=[0]):
    if n==0: return
    hanoi(n-1,a,c,b,cnt); cnt[0]+=1; hanoi(n-1,c,b,a,cnt)
for n in (10,20):
    c=[0]; hanoi(n,cnt=c); print('hanoi',n,c[0],2**n-1)
def bsearch(a,x):
    lo,hi=0,len(a)-1; steps=0
    while lo<=hi:
        steps+=1; m=(lo+hi)//2
        if a[m]==x: return m,steps
        if a[m]<x: lo=m+1
        else: hi=m-1
    return -1,steps
n=10**6; a=list(range(n)); mx=max(bsearch(a,x)[1] for x in random.sample(range(n),20000)+[0,n-1]); miss=bsearch(a,n+5)[1]
print('bsearch n=1e6 max steps over 20000 keys',mx,'floor(lg n)+1',int(math.log2(n))+1,'miss steps',miss)
def inv(p): return sum(1 for i in range(len(p)) for j in range(i+1,len(p)) if p[i]>p[j])
def ins_sort(p):
    p=p[:]; comps=0; moves=0
    for i in range(1,len(p)):
        k=p[i]; j=i-1
        while j>=0:
            comps+=1
            if p[j]>k: p[j+1]=p[j]; moves+=1; j-=1
            else: break
        p[j+1]=k
    return comps,moves
def bubble(p):
    p=p[:]; sw=0
    for i in range(len(p)):
        for j in range(len(p)-1-i):
            if p[j]>p[j+1]: p[j],p[j+1]=p[j+1],p[j]; sw+=1
    return sw
def sel(p):
    p=p[:]; comps=0; sw=0
    for i in range(len(p)-1):
        m=i
        for j in range(i+1,len(p)):
            comps+=1
            if p[j]<p[m]: m=j
        if m!=i: p[i],p[m]=p[m],p[i]; sw+=1
    return comps,sw
n=500; tot=[0,0,0]; ok=True; ms=[]; ss=[]
for _ in range(50):
    p=random.sample(range(n),n); I=inv(p); c,m=ins_sort(p); b=bubble(p); sc,sw=sel(p)
    ok&=(m==I and b==I); tot[0]+=I; tot[1]+=c; ms.append(sw); ss.append(sc)
print('n=500 mean inversions',tot[0]/50,'theory n(n-1)/4',n*(n-1)/4,'insertion moves==inversions & bubble swaps==inversions',ok,'insertion comps mean',tot[1]/50,'selection comps',set(ss),'n(n-1)/2',n*(n-1)//2,'selection swaps max',max(ms),'n-1',n-1)
p=list(range(n)); print('sorted input insertion comps',ins_sort(p)[0],'reverse',ins_sort(p[::-1])[0],'n-1',n-1,'n(n-1)/2',n*(n-1)//2)
def deep(n): return 0 if n==0 else 1+deep(n-1)
try: deep(5000); print('deep 5000 ok')
except RecursionError: print('deep(5000) RecursionError, limit',sys.getrecursionlimit())
print('deep(900)',deep(900))
cnt=0
bad=0
for _ in range(100000):
    x=random.getrandbits(32); y=x; k=0
    while y: y&=y-1; k+=1
    bad+= k!=bin(x).count('1')
print('x&(x-1) loop count equals popcount, disagreements',bad,'power of two test',[x for x in range(1,40) if x&(x-1)==0])
n=10**5
t=time.time(); L=[]
for i in range(n): L.insert(0,i)
t1=time.time()-t; t=time.time(); D=collections.deque()
for i in range(n): D.appendleft(i)
t2=time.time()-t; print('front insert list vs deque 1e5 ratio >=',int(t1/t2),'shifted elements',n*(n-1)//2)
# linked list reverse + cycle detection (Floyd)
class N: 
    def __init__(s,v,nx=None): s.v=v; s.nx=nx
def mk(vs):
    h=None
    for v in reversed(vs): h=N(v,h)
    return h
def rev(h):
    p=None
    while h: h.nx,p,h=p,h,h.nx
    return p
def tolist(h):
    o=[]
    while h: o.append(h.v); h=h.nx
    return o
print('reverse',tolist(rev(mk(list(range(6))))))
def has_cycle(h):
    s=f=h
    while f and f.nx:
        s=s.nx; f=f.nx.nx
        if s is f: return True
    return False
h=mk(list(range(10))); t=h
while t.nx: t=t.nx
print('floyd no cycle',has_cycle(h)); t.nx=h.nx.nx; print('floyd cycle',has_cycle(h))
print('=== U17.16')
class Trie:
    def __init__(s): s.ch={}; s.end=False
def tins(t,w):
    for c in w: t=t.ch.setdefault(c,Trie())
    t.end=True
def tnodes(t): return 1+sum(tnodes(c) for c in t.ch.values())
words=[''.join(random.choice('abcd') for _ in range(random.randint(3,10))) for _ in range(5000)]
T=Trie()
for w in set(words): tins(T,w)
print('trie nodes',tnodes(T),'total chars',sum(map(len,set(words))),'distinct',len(set(words)))
# longest prefix match on bit strings
def lpm(trie,addr):
    best=None; t=trie; d=0
    for c in addr:
        if c not in t.ch: break
        t=t.ch[c]; d+=1
        if t.end: best=d
    return best
pref=['0','01','011','1','110']; R=Trie()
for p in pref: tins(R,p)
print('lpm 0110 ->',lpm(R,'0110'),'lpm 1101 ->',lpm(R,'1101'),'lpm 1000 ->',lpm(R,'1000'))
# B-tree with min degree t
class BNode:
    def __init__(s,leaf): s.keys=[]; s.kids=[]; s.leaf=leaf
class BTree:
    def __init__(s,t): s.t=t; s.root=BNode(True)
    def search(s,k,x=None):
        x=x or s.root; i=0
        while i<len(x.keys) and k>x.keys[i]: i+=1
        if i<len(x.keys) and k==x.keys[i]: return True
        return False if x.leaf else s.search(k,x.kids[i])
    def split(s,x,i):
        t=s.t; y=x.kids[i]; z=BNode(y.leaf); x.keys.insert(i,y.keys[t-1]); x.kids.insert(i+1,z)
        z.keys=y.keys[t:]; y.keys=y.keys[:t-1]
        if not y.leaf: z.kids=y.kids[t:]; y.kids=y.kids[:t]
    def insert(s,k):
        r=s.root
        if len(r.keys)==2*s.t-1:
            n=BNode(False); n.kids=[r]; s.root=n; s.split(n,0); r=n
        s.ins(r,k)
    def ins(s,x,k):
        i=len(x.keys)-1
        if x.leaf:
            x.keys.append(k); x.keys.sort()
        else:
            while i>=0 and k<x.keys[i]: i-=1
            i+=1
            if len(x.kids[i].keys)==2*s.t-1:
                s.split(x,i)
                if k>x.keys[i]: i+=1
            s.ins(x.kids[i],k)
    def height(s):
        h=0; x=s.root
        while not x.leaf: x=x.kids[0]; h+=1
        return h
    def check(s,x=None,lo=-1,hi=10**18,root=True,depth=0,leaves=None):
        x=x or s.root; leaves=leaves if leaves is not None else set()
        assert x.keys==sorted(x.keys) and all(lo<k<hi for k in x.keys)
        if not root: assert s.t-1<=len(x.keys)<=2*s.t-1
        if x.leaf: leaves.add(depth)
        else:
            assert len(x.kids)==len(x.keys)+1
            b=[lo]+x.keys+[hi]
            for i,c in enumerate(x.kids): s.check(c,b[i],b[i+1],False,depth+1,leaves)
        return leaves
for t in (2,5,50):
    for n in (10**5,):
        B=BTree(t); keys=random.sample(range(10**7),n)
        for k in keys: B.insert(k)
        lv=B.check(); h=B.height(); bound=math.floor(math.log((n+1)/2,t))
        print('btree t',t,'n',n,'height',h,'bound floor(log_t((n+1)/2))',bound,'all leaves same depth',len(lv)==1,'search ok',all(B.search(k) for k in keys[:2000]),'miss',B.search(-5))
print('t=100, n=1e9 bound',math.floor(math.log((10**9+1)/2,100)),'t=1000 n=1e9',math.floor(math.log((10**9+1)/2,1000)))
class SNode:
    def __init__(s,k,h): s.k=k; s.nx=[None]*h
class SL:
    def __init__(s,p=0.5,maxh=32): s.p=p; s.maxh=maxh; s.head=SNode(-1,maxh); s.h=1; s.n=0
    def rh(s):
        h=1
        while random.random()<s.p and h<s.maxh: h+=1
        return h
    def ins(s,k):
        upd=[s.head]*s.maxh; cur=s.head
        for l in range(s.h-1,-1,-1):
            while cur.nx[l] is not None and cur.nx[l].k<k: cur=cur.nx[l]
            upd[l]=cur
        h=s.rh(); s.h=max(s.h,h); node=SNode(k,h)
        for l in range(h): node.nx[l]=upd[l].nx[l]; upd[l].nx[l]=node
        s.n+=1
    def find(s,k):
        cur=s.head; steps=0
        for l in range(s.h-1,-1,-1):
            while cur.nx[l] is not None and cur.nx[l].k<k: cur=cur.nx[l]; steps+=1
            steps+=1
        nxt=cur.nx[0]; return (nxt is not None and nxt.k==k),steps
for p in (0.5,0.25):
    S=SL(p); keys=random.sample(range(10**7),10**5)
    for k in keys: S.ins(k)
    st=[S.find(k) for k in random.sample(keys,5000)]
    # sorted order check
    lst=[]; c=S.head.nx[0]
    while c: lst.append(c.k); c=c.nx[0]
    print('skiplist p',p,'n 1e5 found all',all(f for f,_ in st),'sorted',lst==sorted(keys),'mean steps',round(sum(x for _,x in st)/len(st),2),'log2 n',round(math.log2(10**5),2),'height',S.h)
print('=== string matching')
def naive(text,pat):
    comps=0;res=[]
    for i in range(len(text)-len(pat)+1):
        j=0
        while j<len(pat):
            comps+=1
            if text[i+j]!=pat[j]: break
            j+=1
        if j==len(pat): res.append(i)
    return res,comps
def kmp_fail(p):
    f=[0]*len(p); k=0
    for i in range(1,len(p)):
        while k and p[i]!=p[k]: k=f[k-1]
        if p[i]==p[k]: k+=1
        f[i]=k
    return f
def kmp(text,pat):
    f=kmp_fail(pat); k=0; res=[]; comps=0
    for i,c in enumerate(text):
        while k:
            comps+=1
            if c!=pat[k]: k=f[k-1]
            else: break
        comps+=1 if k==0 else 0
        if c==pat[k]: k+=1
        if k==len(pat): res.append(i-k+1); k=f[k-1]
    return res,comps
print('fail abab',kmp_fail('ababaca'),'aabaaab',kmp_fail('aabaaab'))
text='a'*20000+'b'; pat='a'*100+'b'
r1,c1=naive(text,pat); r2,c2=kmp(text,pat); print('worst case naive comps',c1,'kmp comps',c2,'2n',2*len(text),'same matches',r1==r2,len(r1))
bad=0
for _ in range(2000):
    t=''.join(random.choice('ab') for _ in range(random.randint(0,40))); q=''.join(random.choice('ab') for _ in range(random.randint(1,5)))
    ref=[i for i in range(len(t)-len(q)+1) if t.startswith(q,i)]
    bad+= kmp(t,q)[0]!=ref or naive(t,q)[0]!=ref
print('kmp and naive vs str.startswith on 2000 random cases, disagreements',bad)
def rk(text,pat,B=256,M=1000003):
    n,m=len(text),len(pat); 
    if m>n: return [],0
    hp=0;ht=0;pw=pow(B,m-1,M)
    for i in range(m): hp=(hp*B+ord(pat[i]))%M; ht=(ht*B+ord(text[i]))%M
    res=[];fp=0
    for i in range(n-m+1):
        if hp==ht:
            if text[i:i+m]==pat: res.append(i)
            else: fp+=1
        if i<n-m: ht=((ht-ord(text[i])*pw)*B+ord(text[i+m]))%M
    return res,fp
tt=''.join(random.choice('abcdefgh') for _ in range(200000)); qq='abcdefgh'[:6]
r,fp=rk(tt,qq); print('rabin-karp matches',len(r),'ref',sum(1 for i in range(len(tt)-5) if tt.startswith(qq,i)),'false positives M=1000003 n=2e5',fp,'expected ~ n/M',round(200000/1000003,2))
r,fp=rk(tt,qq,M=101); print('M=101 false positives',fp,'expected ~ n/M',round(200000/101))
print('=== U17.17')
def queens(n):
    cnt=0; nodes=0
    cols=set(); d1=set(); d2=set()
    def go(r):
        nonlocal cnt,nodes
        nodes+=1
        if r==n: cnt+=1; return
        for c in range(n):
            if c in cols or r-c in d1 or r+c in d2: continue
            cols.add(c); d1.add(r-c); d2.add(r+c); go(r+1); cols.discard(c); d1.discard(r-c); d2.discard(r+c)
    go(0); return cnt,nodes
for n in (6,8,10): print('queens',n,queens(n),'n^n',n**n)
def tsp_bf(D):
    n=len(D); best=1e18
    for p in itertools.permutations(range(1,n)):
        c=D[0][p[0]]+sum(D[p[i]][p[i+1]] for i in range(n-2))+D[p[-1]][0]; best=min(best,c)
    return best
def held_karp(D):
    n=len(D); INF=1e18; dp={}
    for j in range(1,n): dp[(1<<j,j)]=D[0][j]
    ops=0
    for sz in range(2,n):
        for sub in itertools.combinations(range(1,n),sz):
            m=sum(1<<j for j in sub)
            for j in sub:
                pm_=m^(1<<j); best=INF
                for k in sub:
                    if k==j: continue
                    ops+=1; best=min(best,dp[(pm_,k)]+D[k][j])
                dp[(m,j)]=best
    full=sum(1<<j for j in range(1,n)); return min(dp[(full,j)]+D[j][0] for j in range(1,n)),ops
pts=[(random.random(),random.random()) for _ in range(10)]
D=[[math.dist(a,b) for b in pts] for a in pts]
bf=tsp_bf(D); hk,ops=held_karp(D); print('tsp n=10 bf',round(bf,6),'held-karp',round(hk,6),'tours',math.factorial(9)//2,'HK inner steps',ops,'n^2 2^n',100*2**10)
# metric tsp mst doubling 2-approx
def mst_tour(D):
    n=len(D); inT=[False]*n; key=[1e18]*n; par=[-1]*n; key[0]=0; adj=collections.defaultdict(list)
    for _ in range(n):
        u=min((v for v in range(n) if not inT[v]),key=lambda v:key[v]); inT[u]=True
        if par[u]>=0: adj[par[u]].append(u); adj[u].append(par[u])
        for v in range(n):
            if not inT[v] and D[u][v]<key[v]: key[v]=D[u][v]; par[v]=u
    seen=[];st=[0];vis=set()
    while st:
        u=st.pop()
        if u in vis: continue
        vis.add(u); seen.append(u); st.extend(adj[u])
    return sum(D[seen[i]][seen[(i+1)%n]] for i in range(n))
ratios=[]
for _ in range(60):
    pts=[(random.random(),random.random()) for _ in range(9)]; D=[[math.dist(a,b) for b in pts] for a in pts]
    ratios.append(mst_tour(D)/held_karp(D)[0])
print('mst-preorder tour / optimum over 60 random metric instances n=9: max',round(max(ratios),3),'mean',round(sum(ratios)/60,3),'bound 2')
# vertex cover maximal matching 2-approx vs optimum
def vc_opt(n,E):
    for k in range(n+1):
        for S in itertools.combinations(range(n),k):
            s=set(S)
            if all(a in s or b in s for a,b in E): return k
def vc_approx(n,E):
    cov=set()
    for a,b in E:
        if a not in cov and b not in cov: cov.add(a); cov.add(b)
    return len(cov)
mr=0; eq=0
for _ in range(100):
    n=9; E=[(i,j) for i in range(n) for j in range(i+1,n) if random.random()<0.3]
    if not E: continue
    o=vc_opt(n,E); a=vc_approx(n,E); mr=max(mr,a/o); eq+= a==o
print('vertex cover matching approx max ratio over 100 graphs n=9',round(mr,3),'bound 2','cases equal to optimum',eq)
# set cover greedy ratio vs H_n on classic bad instance
def greedy_sc(U,sets):
    U=set(U); ch=0
    while U:
        s=max(sets,key=lambda s:len(U&s)); U-=s; ch+=1
    return ch
k=5; U=list(range(2**(k+1)-2)); 
sets=[]; start=0; blocks=[]
for i in range(1,k+1):
    blocks.append(set(range(start,start+2**i))); start+=2**i
A=set(x for b in blocks for x in list(b)[:len(b)//2]); B=set(U)-A
sets=[A,B]+blocks
print('greedy set cover on layered instance: universe',len(U),'greedy',greedy_sc(U,sets),'optimum 2','H_n',round(sum(1/i for i in range(1,len(U)+1)),2))
# knapsack branch and bound vs DP
def knap_dp(w,v,W):
    dp=[0]*(W+1)
    for wi,vi in zip(w,v):
        for c in range(W,wi-1,-1): dp[c]=max(dp[c],dp[c-wi]+vi)
    return dp[W]
def knap_bb(w,v,W):
    order=sorted(range(len(w)),key=lambda i:-v[i]/w[i]); w=[w[i] for i in order]; v=[v[i] for i in order]; n=len(w); best=0; nodes=0
    def bound(i,cw,cv):
        b=cv
        while i<n and cw+w[i]<=W: cw+=w[i]; b+=v[i]; i+=1
        if i<n: b+=v[i]*(W-cw)/w[i]
        return b
    def go(i,cw,cv):
        nonlocal best,nodes
        nodes+=1
        if cw>W: return
        best=max(best,cv)
        if i==n or bound(i,cw,cv)<=best: return
        go(i+1,cw+w[i],cv+v[i]); go(i+1,cw,cv)
    go(0,0,0); return best,nodes
agree=0; tn=[]
for _ in range(50):
    n=22; w=[random.randint(5,40) for _ in range(n)]; v=[random.randint(5,60) for _ in range(n)]; W=sum(w)//3
    b,nodes=knap_bb(w,v,W); agree+= b==knap_dp(w,v,W); tn.append(nodes)
print('knapsack B&B == DP on',agree,'of 50, n=22, mean nodes',sum(tn)/50,'2^23',2**23)
# meet in the middle subset sum
def subset_sum_mitm(a,target):
    h=len(a)//2
    def sums(x):
        o=[0]
        for v in x: o+= [s+v for s in o]
        return o
    L=sums(a[:h]); R=sorted(sums(a[h:])); import bisect
    for s in L:
        i=bisect.bisect_left(R,target-s)
        if i<len(R) and R[i]==target-s: return True
    return False
a=[random.randint(10**6,10**7) for _ in range(40)]; print('mitm subset sum n=40 (2^20 per half) target = sum of 7 chosen items',subset_sum_mitm(a,sum(a[3:10])),'impossible target',subset_sum_mitm(a,1))
# local search 2-opt improvement
def tour_len(D,t): return sum(D[t[i]][t[(i+1)%len(t)]] for i in range(len(t)))
def two_opt(D,t):
    imp=True
    while imp:
        imp=False
        for i in range(1,len(t)-1):
            for j in range(i+1,len(t)):
                a,b,c,d=t[i-1],t[i],t[j],t[(j+1)%len(t)]
                if D[a][c]+D[b][d]<D[a][b]+D[c][d]-1e-12: t[i:j+1]=reversed(t[i:j+1]); imp=True
    return t
rs=[]
for _ in range(30):
    n=9; pts=[(random.random(),random.random()) for _ in range(n)]; D=[[math.dist(a,b) for b in pts] for a in pts]
    t=list(range(n)); random.shuffle(t); r0=tour_len(D,t)/held_karp(D)[0]; t=two_opt(D,t); rs.append((r0,tour_len(D,t)/held_karp(D)[0]))
print('2-opt n=9 30 instances: mean ratio random start',round(sum(a for a,_ in rs)/30,3),'after 2-opt mean',round(sum(b for _,b in rs)/30,3),'worst',round(max(b for _,b in rs),3))
