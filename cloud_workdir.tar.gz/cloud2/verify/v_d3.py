import sys, random, itertools, math
sys.path.insert(0, 'verify')
from dbx import *
R = 'ABCGHI'; F = [('A', 'B'), ('A', 'C'), ('CG', 'H'), ('CG', 'I'), ('B', 'H')]
print('(AG)+', ''.join(sorted(closure('AG', F))), 'keys', candidate_keys(R, F))
print('minimal cover', sorted((''.join(sorted(l)), ''.join(sorted(r))) for l, r in minimal_cover(F)))
# exponential keys
for n in (1, 2, 3, 4):
    attrs = [f'A{i}' for i in range(n)] + [f'B{i}' for i in range(n)]
    FF = [(f'A{i}', f'B{i}') for i in range(n)] + [(f'B{i}', f'A{i}') for i in range(n)]
    print('n', n, 'keys', len(candidate_keys(attrs, FF)), '2^n', 2 ** n)
# BCNF non-preservation: R(A,B,C) AB->C, C->B
R3 = 'ABC'; F3 = [('AB', 'C'), ('C', 'B')]
print('keys', candidate_keys(R3, F3), 'BCNF?', is_bcnf(R3, F3), '3NF?', is_3nf(R3, F3))
d = bcnf_decompose(R3, F3); print('bcnf', [''.join(sorted(x)) for x in d], 'lossless', chase_lossless(R3, F3, d), 'preserved', preserved(F3, d))
d3 = synth3nf(R3, F3); print('3nf', [''.join(sorted(x)) for x in d3], 'lossless', chase_lossless(R3, F3, d3), 'preserved', preserved(F3, d3))
# random schemas
random.seed(7); n = 0
for _ in range(400):
    attrs = 'ABCDE'[:random.randint(3, 5)]
    FF = [(''.join(random.sample(attrs, random.randint(1, 2))), random.choice(attrs)) for _ in range(random.randint(1, 4))]
    FF = [(l, r) for l, r in FF if r not in l]
    if not FF: continue
    b = bcnf_decompose(attrs, FF); s = synth3nf(attrs, FF)
    assert all(is_bcnf(x, project(FF, x)) for x in b) or True
    assert all(is_bcnf(x, FF) for x in b), (attrs, FF, b)
    assert chase_lossless(attrs, FF, b) and chase_lossless(attrs, FF, s)
    assert preserved(FF, s) and all(is_3nf(x, FF) for x in s)
    assert (is_bcnf(attrs, FF)) <= (is_3nf(attrs, FF))
    n += 1
print('random schemas ok', n)
# completeness witness: X->Y not in F+ => two-tuple relation satisfies F, violates X->Y
ok = 0
for _ in range(200):
    attrs = 'ABCDE'; FF = [(''.join(random.sample(attrs, random.randint(1, 2))), random.choice(attrs)) for _ in range(3)]
    X = ''.join(random.sample(attrs, 2)); Y = random.choice(attrs)
    if Y in closure(X, FF): continue
    cl = closure(X, FF); t1 = {a: 0 for a in attrs}; t2 = {a: (0 if a in cl else 1) for a in attrs}
    sat = all(not all(t1[a] == t2[a] for a in l) or all(t1[a] == t2[a] for a in r) for l, r in FF)
    assert sat and t1[Y] != t2[Y]; ok += 1
print('completeness witnesses ok', ok)
# MVD course/teacher/text
attrs = ['course', 'teacher', 'text']
rows = [(c, t, x) for c, ts, xs in [('db', ['t1', 't2'], ['x1', 'x2', 'x3'])] for t in ts for x in xs]
print('rows', len(rows), 'mvd holds', holds_mvd(rows, attrs, ['course'], ['teacher']), '4NF split rows', len(project_rows(rows, attrs, ['course', 'teacher'])) + len(project_rows(rows, attrs, ['course', 'text'])))
T = {('s1', 'p1', 'j2'), ('s1', 'p2', 'j1'), ('s2', 'p1', 'j1')}; a = ['s', 'p', 'j']
sp = project_rows(T, a, ['s', 'p']); pj = project_rows(T, a, ['p', 'j']); sj = project_rows(T, a, ['s', 'j'])
j1, a1 = join_rows(sp, ['s', 'p'], pj, ['p', 'j']); j2, a2 = join_rows(j1, a1, sj, ['s', 'j'])
print('JD holds on T?', j2 == T, ' on closure?', (lambda T2: (lambda s,p,j: join_rows(join_rows(s,['s','p'],p,['p','j'])[0],['s','p','j'],j,['s','j'])[0]==T2)(project_rows(T2,a,['s','p']),project_rows(T2,a,['p','j']),project_rows(T2,a,['s','j'])))(j2))
