# D22 U22.1-U22.4: team arithmetic, life-cycle toy models, function points, COCOMO, Putnam/Rayleigh, CPM/PERT, content-addressed store
import math, random, itertools, subprocess, hashlib, os, tempfile, collections
import numpy as np
from scipy import stats, integrate
random.seed(22); rng=np.random.default_rng(22)
print('=== U22.1')
print('channels',{n:n*(n-1)//2 for n in (3,5,10,50)})
W=100; s=0.10; c=0.05
def T(n): return W*(1-s)/n+W*s+c*n*(n-1)/2
best=min(range(1,60),key=T); print('T(1)',T(1),'T(10)',round(T(10),2),'argmin n',best,'T(best)',round(T(best),2),'T(40)',round(T(40),2))
# continuous optimum d/dn: -W(1-s)/n^2 + c(2n-1)/2 =0
from scipy.optimize import brentq
print('continuous optimum',round(brentq(lambda n:-W*(1-s)/n**2+c*(2*n-1)/2,1,50),3))
# adding people late: project 50% done at month 6 of 10 with team 5; add k people with onboarding cost 1 month of one existing person each
print('=== U22.2')
g=2.0
def detect_delay_waterfall(): return 3  # defect injected in requirements, found in system test (phase 4 vs phase 1)
print('waterfall relative rework (g=2, delay 3 phases)',g**3)
# incremental with m equal increments: defect in increment j found when increment j is tested -> delay is phases within the increment, 3 phases of a 4-phase mini cycle but cost scale relative to the increment
# simpler: model cost of a defect = g^(phases between injection and detection); incremental: detection delay 3 but defects only live in a 1/m slice of work -> rework scope shrinks by m
for m in (1,2,4,8): print('incremental m',m,'expected rework scope fraction',1/m,'relative expected rework',g**3/m)
# Monte Carlo: n requirements, each wrong with p; wrong found at the end of the increment containing it; cost = size of work built on it (after it) within the same increment (waterfall: everything built after)
def sim(m,p=0.1,n=100,trials=4000):
    tot=0
    for _ in range(trials):
        wrong=[random.random()<p for _ in range(n)]
        # rework = for every wrong requirement, count of requirements designed/coded after it in the same increment (they inherit its error) + 1
        size=n//m; cost=0
        for inc in range(m):
            seg=wrong[inc*size:(inc+1)*size]
            for i,w in enumerate(seg):
                if w: cost+=1+(len(seg)-1-i)*0.2
        tot+=cost
    return tot/trials
print('MC rework units',{m:round(sim(m),1) for m in (1,2,4,10)})
print('spiral risk: RE before',0.3*100,'after prototype',0.1*100,'prototype cost 10, net',(0.3*100)-(0.1*100)-10)
print('=== U22.3')
EI,EO,EQ,ILF,EIF=20,12,8,6,3
ufp=EI*4+EO*5+EQ*4+ILF*10+EIF*7; gsc=[3,2,4,3,3,1,4,3,2,3,2,3,3,2]; vaf=0.65+0.01*sum(gsc); print('UFP',ufp,'sumGSC',sum(gsc),'VAF',round(vaf,2),'FP',round(ufp*vaf,2))
def cocomo(k,mode):
    a,b,c,d={'organic':(2.4,1.05,2.5,0.38),'semi':(3.0,1.12,2.5,0.35),'embedded':(3.6,1.20,2.5,0.32)}[mode]
    E=a*k**b; D=c*E**d; return E,D,E/D
for md in ('organic','semi','embedded'):
    E,D,N=cocomo(32,md); print('cocomo',md,'E',round(E,1),'D',round(D,2),'staff',round(N,2),'productivity KLOC/PM',round(32/E,3))
print('cocomo organic 10,50,100,400 KLOC E',[round(cocomo(k,'organic')[0],1) for k in (10,50,100,400)])
print('diseconomy: 100 KLOC vs 10 KLOC effort ratio',round(cocomo(100,'organic')[0]/cocomo(10,'organic')[0],2),'organic b=1.05 gives 10^1.05 =',round(10**1.05,2))
eaf=1.15*1.08*0.91*1.10; print('intermediate EAF example',round(eaf,3),'E nominal organic 3.2*k^1.05 for 32',round(3.2*32**1.05,1),'adjusted',round(3.2*32**1.05*eaf,1))
# Putnam
print('Putnam: effort ratio when schedule cut 20%',round(1/0.8**4,3),'25%',round(1/0.75**4,3))
K=100; td=12
m=lambda t:K/td**2*t*math.exp(-t*t/(2*td*td))
val,err=integrate.quad(m,0,td); print('rayleigh cum at td',round(val,3),'formula',round(K*(1-math.exp(-0.5)),3),'peak staff',round(m(td),3),'K/(td sqrt e)',round(K/(td*math.sqrt(math.e)),3))
val,_=integrate.quad(m,0,3*td); print('cum at 3td',round(val,2),'K(1-e^-4.5)',round(K*(1-math.exp(-4.5)),2))
print('=== U22.4')
tasks={'A':(3,[]),'B':(4,['A']),'C':(2,['A']),'D':(5,['B']),'E':(3,['B','C']),'F':(4,['C']),'G':(2,['D','E']),'H':(3,['E','F']),'I':(2,['G','H'])}
order=list(tasks); ES={};EF={}
for t in order:
    d,pr=tasks[t]; ES[t]=max([EF[p] for p in pr],default=0); EF[t]=ES[t]+d
end=max(EF.values()); LF={};LS={}
for t in reversed(order):
    succ=[u for u in order if t in tasks[u][1]]; LF[t]=min([LS[u] for u in succ],default=end); LS[t]=LF[t]-tasks[t][0]
slack={t:LS[t]-ES[t] for t in order}; crit=[t for t in order if slack[t]==0]
print('project duration',end,'critical',crit,'slack',slack)
paths=[]
def dfs(t,p):
    succ=[u for u in order if t in tasks[u][1]]
    if not succ: paths.append((sum(tasks[x][0] for x in p+[t]),p+[t])); return
    for u in succ: dfs(u,p+[t])
for t in order:
    if not tasks[t][1]: dfs(t,[])
print('all paths',sorted(paths,reverse=True)[:4],'count',len(paths))
# PERT three-point
est={'A':(2,3,6),'B':(3,4,8),'C':(1,2,3),'D':(4,5,9),'E':(2,3,5),'F':(3,4,7),'G':(1,2,4),'H':(2,3,6),'I':(1,2,3)}
mean={t:(a+4*m_+b)/6 for t,(a,m_,b) in est.items()}; var={t:((b-a)/6)**2 for t,(a,m_,b) in est.items()}
ES2={};EF2={}
for t in order:
    pr=tasks[t][1]; ES2[t]=max([EF2[p] for p in pr],default=0); EF2[t]=ES2[t]+mean[t]
cm=max(EF2.values()); crit2=[t for t in order if abs((EF2[t])-cm)<1e-9 or True]
# critical path by expected durations
LF2={};LS2={}
for t in reversed(order):
    succ=[u for u in order if t in tasks[u][1]]; LF2[t]=min([LS2[u] for u in succ],default=cm); LS2[t]=LF2[t]-mean[t]
cp=[t for t in order if abs(LS2[t]-ES2[t])<1e-9]; print('PERT expected duration',round(cm,3),'critical path by means',cp,'sum var on it',round(sum(var[t] for t in cp),4),'sd',round(math.sqrt(sum(var[t] for t in cp)),3))
def beta_sample(a,m_,b,n):
    al=1+4*(m_-a)/(b-a); be=1+4*(b-m_)/(b-a); return a+(b-a)*rng.beta(al,be,size=n)
N=200000; dur={t:beta_sample(*est[t],N) for t in order}; EFs={}
for t in order:
    pr=tasks[t][1]; st=np.max([EFs[p] for p in pr],axis=0) if pr else np.zeros(N); EFs[t]=st+dur[t]
mk=EFs['I']; print('MC mean makespan',round(mk.mean(),3),'sd',round(mk.std(),3),'critical-path mean',round(cm,3),'bias',round(mk.mean()-cm,3))
Tdl=cm+1; zz=(Tdl-cm)/math.sqrt(sum(var[t] for t in cp)); print('P(finish<=cm+1) normal approx',round(stats.norm.cdf(zz),3),'MC',round((mk<=Tdl).mean(),3))
print('P(finish<=cm) MC',round((mk<=cm).mean(),3),'normal approx 0.5')
# criticality index
crit_idx={t:float(np.mean([0]) ) for t in order}
# risk exposure
print('RE',0.2*50, 'two risks',[0.2*50,0.05*400,0.5*10])
# content-addressed store vs git
def blob_hash(b): return hashlib.sha1(b'blob %d\0'%len(b)+b).hexdigest()
d=tempfile.mkdtemp(); subprocess.run(['git','init','-q',d]); f=os.path.join(d,'a.txt'); open(f,'w').write('hello\n')
g=subprocess.run(['git','-C',d,'hash-object','a.txt'],capture_output=True,text=True).stdout.strip(); print('blob hash own',blob_hash(b'hello\n'),'git',g,blob_hash(b'hello\n')==g)
def tree_hash(entries):  # entries: (mode, name, sha hex)
    body=b''.join(b'%s %s\0'%(m.encode(),n.encode())+bytes.fromhex(h) for m,n,h in sorted(entries,key=lambda e:e[1]))
    return hashlib.sha1(b'tree %d\0'%len(body)+body).hexdigest()
bl=blob_hash(b'hello\n'); th=tree_hash([('100644','a.txt',bl)])
env=dict(os.environ,GIT_AUTHOR_NAME='a',GIT_AUTHOR_EMAIL='a@x',GIT_COMMITTER_NAME='a',GIT_COMMITTER_EMAIL='a@x',GIT_AUTHOR_DATE='1700000000 +0000',GIT_COMMITTER_DATE='1700000000 +0000')
subprocess.run(['git','-C',d,'add','a.txt'],env=env); subprocess.run(['git','-C',d,'-c','commit.gpgsign=false','commit','-q','-m','first'],env=env)
gt=subprocess.run(['git','-C',d,'rev-parse','HEAD^{tree}'],capture_output=True,text=True).stdout.strip(); print('tree own',th,'git',gt,th==gt)
body=('tree %s\nauthor a <a@x> 1700000000 +0000\ncommitter a <a@x> 1700000000 +0000\n\nfirst\n'%th).encode(); ch=hashlib.sha1(b'commit %d\0'%len(body)+body).hexdigest()
gc=subprocess.run(['git','-C',d,'rev-parse','HEAD'],capture_output=True,text=True).stdout.strip(); print('commit own',ch,'git',gc,ch==gc)
# three-way merge
def lcs_diff(a,b):
    n,m=len(a),len(b); L=[[0]*(m+1) for _ in range(n+1)]
    for i in range(n-1,-1,-1):
        for j in range(m-1,-1,-1): L[i][j]=L[i+1][j+1]+1 if a[i]==b[j] else max(L[i+1][j],L[i][j+1])
    i=j=0; ops=[]
    while i<n and j<m:
        if a[i]==b[j]: ops.append(('=',i,j)); i+=1; j+=1
        elif L[i+1][j]>=L[i][j+1]: ops.append(('-',i,None)); i+=1
        else: ops.append(('+',None,j)); j+=1
    while i<n: ops.append(('-',i,None)); i+=1
    while j<m: ops.append(('+',None,j)); j+=1
    return ops
def merge3(base,a,b):
    # map base line index -> (changed text list) for each side, using hunk alignment on base lines
    def edits(side):
        ops=lcs_diff(base,side); ed={}  # base index -> replacement lines (or None if kept), plus insertions before index
        ins=collections.defaultdict(list); dele=set(); 
        pos=0
        for op,i,j in ops:
            if op=='=': pos=i+1
            elif op=='-': dele.add(i); pos=i+1
            else: ins[pos].append(side[j])
        return ins,dele
    ia,da=edits(a); ib,db=edits(b); out=[]; conflict=False
    for i in range(len(base)+1):
        xa,xb=ia.get(i,[]),ib.get(i,[])
        if xa and xb and xa!=xb: conflict=True; out+=['<<<<<<<']+xa+['=======']+xb+['>>>>>>>']
        else: out+=xa or xb
        if i<len(base):
            if i in da and i in db: pass
            elif i in da or i in db:
                pass
            else: out.append(base[i])
    return out,conflict
base=['a','b','c','d','e']; A=['a','B','c','d','e']; B=['a','b','c','D','e']
res,conf=merge3(base,A,B); print('own 3-way clean merge',res,conf)
for name,(x,y,z) in {'clean':(base,A,B)}.items():
    paths=[]
    for lab,L in (('base',x),('a',y),('b',z)):
        p=os.path.join(d,lab+'.txt'); open(p,'w').write('\n'.join(L)+'\n'); paths.append(p)
    r=subprocess.run(['git','merge-file','-p']+[paths[1],paths[0],paths[2]],capture_output=True,text=True); print('git merge-file',r.stdout.split(),'exit',r.returncode)

# conflict case and random clean cases against git merge-file
def run_git(base,a,b):
    ps=[]
    for lab,L in (('b',base),('a',a),('c',b)):
        p=os.path.join(d,lab+'.txt'); open(p,'w').write('\n'.join(L)+'\n'); ps.append(p)
    r=subprocess.run(['git','merge-file','-p',ps[1],ps[0],ps[2]],capture_output=True,text=True); return r.stdout.split('\n')[:-1],r.returncode
res,conf=merge3(['a','b','c'],['a','X','c'],['a','Y','c']); gout,gr=run_git(['a','b','c'],['a','X','c'],['a','Y','c'])
print('conflict case own',conf,'git exit',gr,'git has markers',any(l.startswith('<<<<<<<') for l in gout))
agree=0; tot=0; cc=0
for _ in range(300):
    n=8; base=[chr(97+i) for i in range(n)]
    # edit disjoint line sets: A edits some lines, B edits others (replace), keeping 2-line gaps
    idx=list(range(n)); random.shuffle(idx)
    ia=[i for i in idx[:2]]; ib=[i for i in idx[2:4] if all(abs(i-j)>1 for j in ia)]
    A=[x.upper() if i in ia else x for i,x in enumerate(base)]; B=[x.upper()+'2' if i in ib else x for i,x in enumerate(base)]
    mine,cf=merge3(base,A,B); go,gr=run_git(base,A,B)
    tot+=1; cc+=cf
    agree+= (not cf and gr==0 and mine==go) or (cf and gr!=0)
print('random disjoint-edit merges: agree with git',agree,'of',tot,'own conflicts reported',cc)
