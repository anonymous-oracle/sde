import glob, math, sys, numpy as np
cur = None
pat = sys.argv[1] if len(sys.argv) > 1 else ''
for f in sorted(glob.glob('assign/*.txt')):
    for ln in open(f):
        ln = ln.rstrip('\n')
        if ln.startswith('## '): cur = ln[3:]; continue
        if ln.startswith('NAT|') and cur.startswith(pat):
            _, t, expr, tol, unit, why = ln.split('|')
            print(cur, float(eval(expr, {'np': np, 'math': math})), tol, why[:90])
