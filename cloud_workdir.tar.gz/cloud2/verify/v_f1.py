import math, random, heapq, itertools, numpy as np
random.seed(7)
# U17.1
print('H_n', sum(1/k for k in range(1,10**6+1)), math.log(10**6)+0.5772156649)
fp=sum(sum(1 for i,x in enumerate(random.sample(range(50),50)) if i==x) for _ in range(20000))/20000; print('fixed pts',fp)
# U17.2 merge sort comparisons (worst-case bound), insertion sort worst
def msort(a):
    c=0
    def rec(a):
        nonlocal c
        if len(a)<=1: return a
        m=len(a)//2; l=rec(a[:m]); r=rec(a[m:]); out=[]; i=j=0
        while i<len(l) and j<len(r):
            c+=1
            if l[i]<=r[j]: out.append(l[i]); i+=1
            else: out.append(r[j]); j+=1
        return out+l[i:]+r[j:]
    rec(a); return c
for n in (8,100,1000):
    worst=max(msort(random.sample(range(n),n)) for _ in range(20)); bound=n*math.ceil(math.log2(n))-2**math.ceil(math.log2(n))+1
    print('msort',n,worst,bound,worst<=bound)
n=1000; print('insertion worst',n*(n-1)//2)
def kad(a):
    best=cur=a[0]
    for x in a[1:]: cur=max(x,cur+x); best=max(best,cur)
    return best
ok=all(kad(a)==max(sum(a[i:j]) for i in range(len(a)) for j in range(i+1,len(a)+1)) for a in ([random.randint(-9,9) for _ in range(random.randint(1,25))] for _ in range(2000)))
print('kadane',ok)
# local min 2D: simple halving check existence
# U17.3 quicksort expected comparisons
def qs(a):
    c=0
    def rec(a):
        nonlocal c
        if len(a)<=1: return
        p=random.choice(a); c+=len(a)-1
        rec([x for x in a if x<p]); rec([x for x in a if x>p])
    rec(a); return c
n=2000; avg=sum(qs(random.sample(range(n),n)) for _ in range(200))/200
H=sum(1/k for k in range(1,n+1)); print('qs',avg,2*(n+1)*H-4*n, 1.386*n*math.log2(n))
print('karatsuba exp',math.log2(3))
def inv(a):
    c=0
    def rec(a):
        nonlocal c
        if len(a)<=1: return a
        m=len(a)//2; l=rec(a[:m]); r=rec(a[m:]); o=[];i=j=0
        while i<len(l) and j<len(r):
            if l[i]<=r[j]: o.append(l[i]); i+=1
            else: o.append(r[j]); j+=1; c+=len(l)-i
        return o+l[i:]+r[j:]
    rec(a); return c
a=random.sample(range(500),500); print('inversions',inv(a)==sum(1 for i in range(500) for j in range(i+1,500) if a[i]>a[j]))
def halfmaj(a):
    cand=None;cnt=0
    for x in a:
        if cnt==0: cand=x;cnt=1
        elif x==cand: cnt+=1
        else: cnt-=1
    return cand
ok=True
for _ in range(2000):
    a=[random.randint(0,3) for _ in range(random.randint(1,21))]
    m=max(set(a),key=a.count)
    if a.count(m)>len(a)/2: ok&= halfmaj(a)==m
print('half-majority',ok)
# U17.4 build-heap sift count, lg n!
def buildheap(a):
    n=len(a);sw=0
    for i in range(n//2-1,-1,-1):
        while True:
            l,r,m=2*i+1,2*i+2,i
            if l<n and a[l]<a[m]: m=l
            if r<n and a[r]<a[m]: m=r
            if m==i: break
            a[i],a[m]=a[m],a[i]; sw+=1; i=m
    return sw
for n in (1000,100000): print('buildheap swaps/n',buildheap(random.sample(range(n),n))/n)
n=1000; print('lg n!',math.lgamma(n+1)/math.log(2),n*math.log2(n)-1.443*n)
# U17.5
for al in (.5,.8,.9):
    m=10007; n=int(al*m); tab=[None]*m; keys=random.sample(range(10**9),n)
    h=lambda k,i:(k%m+i*(1+k%(m-1)))%m
    for k in keys:
        i=0
        while tab[h(k,i)] is not None: i+=1
        tab[h(k,i)]=k
    pr=[];
    for _ in range(3000):
        k=random.randrange(10**9,2*10**9);i=0
        while tab[h(k,i)] is not None: i+=1
        pr.append(i+1)
    print('open addr',al,sum(pr)/len(pr),1/(1-al))
p=2**31-1
def univ(m): a=random.randrange(1,p); b=random.randrange(p); return lambda k:((a*k+b)%p)%m
n=40; trials=2000; good=0
for _ in range(trials):
    keys=random.sample(range(10**6),n); h=univ(n*n); good+= len({h(k) for k in keys})==n
print('n^2 table collision-free prob',good/trials)
sq=[];
for _ in range(500):
    keys=random.sample(range(10**6),200); h=univ(200); cnt=[0]*200
    for k in keys: cnt[h(k)]+=1
    sq.append(sum(c*c for c in cnt))
print('E sum n_i^2 / n',sum(sq)/len(sq)/200)
# U17.6
a=[random.randint(0,99) for _ in range(300)]; import math
K=int(math.log2(len(a)))+1; sp=[a[:]]
for k in range(1,K): sp.append([min(sp[-1][i],sp[-1][i+2**(k-1)]) for i in range(len(a)-2**k+1)])
ok=True
for _ in range(5000):
    l=random.randrange(len(a)); r=random.randrange(l,len(a)); k=int(math.log2(r-l+1)); ok&= min(sp[k][l],sp[k][r-2**k+1])==min(a[l:r+1])
print('sparse table',ok)
# U17.7 RB height / random BST depth
class N: 
    def __init__(s,k): s.k=k;s.l=s.r=None
def bst_depth(keys):
    root=N(keys[0]); tot=0
    for k in keys[1:]:
        x=root;d=0
        while True:
            d+=1
            if k<x.k:
                if x.l is None: x.l=N(k);break
                x=x.l
            else:
                if x.r is None: x.r=N(k);break
                x=x.r
        tot+=d
    return tot/len(keys)
n=20000; print('random BST avg depth',bst_depth(random.sample(range(n),n)),2*math.log(n))
print('RB bound 2lg(n+1) n=10^6',2*math.log2(10**6+1))
# U17.8 vEB recurrence: T(u)=T(sqrt u)+1 -> lg lg u
for w in (16,32,64): print('vEB depth lg lg u',w, math.log2(w))
# cross product
a1=(0,0);b1=(4,0);ok=True
for _ in range(2000):
    c=(random.uniform(-5,5),random.uniform(-5,5)); cr=(b1[0]-a1[0])*(c[1]-a1[1])-(b1[1]-a1[1])*(c[0]-a1[0]); ok&= (cr>0)==(c[1]>0)
print('orientation',ok)
# U17.9 amortized counter, doubling array
tot=0; c=[0]*20
for _ in range(2**15):
    i=0
    while i<20 and c[i]==1: c[i]=0;tot+=1;i+=1
    c[i]=1; tot+=1
print('counter flips per increment',tot/2**15)
cap=1;sz=0;cost=0
for _ in range(100000):
    if sz==cap: cost+=sz; cap*=2
    cost+=1; sz+=1
print('doubling amortized',cost/100000)
def hull(pts):
    pts=sorted(set(pts))
    def cr(o,a,b): return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
    lo=[]
    for p_ in pts:
        while len(lo)>=2 and cr(lo[-2],lo[-1],p_)<=0: lo.pop()
        lo.append(p_)
    up=[]
    for p_ in reversed(pts):
        while len(up)>=2 and cr(up[-2],up[-1],p_)<=0: up.pop()
        up.append(p_)
    return lo[:-1]+up[:-1]
pts=[(random.randint(0,50),random.randint(0,50)) for _ in range(300)]; H=hull(pts)
def inside(p_,H):
    n=len(H)
    return all((H[(i+1)%n][0]-H[i][0])*(p_[1]-H[i][1])-(H[(i+1)%n][1]-H[i][1])*(p_[0]-H[i][0])>=0 for i in range(n))
print('hull contains all',all(inside(q,H) for q in pts),len(H))
# U17.10 knapsack vs brute, Prim vs Kruskal
def knap(w,v,W):
    d=[0]*(W+1)
    for wi,vi in zip(w,v):
        for c in range(W,wi-1,-1): d[c]=max(d[c],d[c-wi]+vi)
    return d[W]
ok=True
for _ in range(300):
    n=random.randint(1,10); w=[random.randint(1,9) for _ in range(n)]; v=[random.randint(1,20) for _ in range(n)]; W=random.randint(1,30)
    best=max(sum(v[i] for i in range(n) if m>>i&1) for m in range(1<<n) if sum(w[i] for i in range(n) if m>>i&1)<=W)
    ok&= knap(w,v,W)==best
print('knapsack',ok)
def rg(n,e):
    E=set()
    while len(E)<e: a,b=random.sample(range(n),2); E.add((min(a,b),max(a,b)))
    return [(a,b,random.random()) for a,b in E]
def kruskal(n,E):
    par=list(range(n))
    def f(x):
        while par[x]!=x: par[x]=par[par[x]]; x=par[x]
        return x
    t=0
    for a,b,w in sorted(E,key=lambda e:e[2]):
        ra,rb=f(a),f(b)
        if ra!=rb: par[ra]=rb; t+=w
    return t
def prim(n,E):
    adj=[[] for _ in range(n)]
    for a,b,w in E: adj[a].append((w,b)); adj[b].append((w,a))
    seen={0}; h=list(adj[0]); heapq.heapify(h); t=0
    while h:
        w,b=heapq.heappop(h)
        if b in seen: continue
        seen.add(b); t+=w
        for x in adj[b]:
            if x[1] not in seen: heapq.heappush(h,x)
    return t,len(seen)
ok=True
for _ in range(200):
    n=30;E=rg(n,120);t,s=prim(n,E)
    if s==n: ok&= abs(t-kruskal(n,E))<1e-9
print('prim=kruskal',ok)
# U17.11 articulation points vs removal
import sys; sys.setrecursionlimit(10000)
def art(n,adj):
    disc=[-1]*n;low=[0]*n;ap=set();t=[0]
    def dfs(u,p):
        disc[u]=low[u]=t[0];t[0]+=1;ch=0
        for v in adj[u]:
            if v==p: continue
            if disc[v]==-1:
                ch+=1; dfs(v,u); low[u]=min(low[u],low[v])
                if p!=-1 and low[v]>=disc[u]: ap.add(u)
            else: low[u]=min(low[u],disc[v])
        if p==-1 and ch>1: ap.add(u)
    for s in range(n):
        if disc[s]==-1: dfs(s,-1)
    return ap
def ncomp(n,adj,skip=None):
    seen=set();c=0
    for s in range(n):
        if s==skip or s in seen: continue
        c+=1;st=[s];seen.add(s)
        while st:
            u=st.pop()
            for v in adj[u]:
                if v!=skip and v not in seen: seen.add(v);st.append(v)
    return c
ok=True
for _ in range(1000):
    n=12;E=rg(n,random.randint(8,20));adj=[[] for _ in range(n)]
    for a,b,_w in E: adj[a].append(b);adj[b].append(a)
    A=art(n,adj);base=ncomp(n,adj)
    true={v for v in range(n) if ncomp(n,adj,skip=v)>base - (1 if not adj[v] else 0) and adj[v]}
    ok&= A==true
print('articulation',ok)
# bipartite iff no odd cycle (BFS colouring vs brute)
# U17.12 Dijkstra wrong with negative edge
G={0:[(1,2),(2,3)],1:[(3,-5)],2:[(1,-2)],3:[]}
def dij(G,s):
    d={s:0};h=[(0,s)];done=set()
    while h:
        du,u=heapq.heappop(h)
        if u in done: continue
        done.add(u)
        for v,w in G[u]:
            if v not in done and du+w<d.get(v,1e9): d[v]=du+w;heapq.heappush(h,(d[v],v))
    return d
def bf(G,s):
    d={u:1e9 for u in G};d[s]=0
    for _ in range(len(G)-1):
        for u in G:
            for v,w in G[u]:
                if d[u]+w<d[v]: d[v]=d[u]+w
    return d
print('dijkstra',dij(G,0),'bellman-ford',bf(G,0))
# arbitrage via -log
rates={('A','B'):2.0,('B','C'):0.8,('C','A'):0.7}
print('cycle product',2.0*0.8*0.7)
# U17.13 Johnson reweighting nonneg
from scipy.sparse.csgraph import floyd_warshall
n=15;ok=True
for _ in range(200):
    E=[(a,b,random.randint(-3,10)) for a,b,_w in rg(n,40)]
    # make acyclic-ish negative: orient low->high so no cycles with directed negative cycles
    E=[(min(a,b),max(a,b),w) for a,b,w in E]
    h=[0]*n
    for _ in range(n):
        for a,b,w in E: h[b]=min(h[b],h[a]+w)
    ok&= all(w+h[a]-h[b]>=0 for a,b,w in E)
print('johnson reweight',ok)
# U17.14 max-flow = min-cut (small), bipartite matching
from scipy.sparse.csgraph import maximum_flow
from scipy.sparse import csr_matrix
ok=True
for _ in range(100):
    n=6;M=np.zeros((n,n),dtype=np.int32)
    for _e in range(10):
        a,b=random.sample(range(n),2); M[a,b]+=random.randint(1,9)
    f=maximum_flow(csr_matrix(M),0,n-1).flow_value
    best=min(sum(M[i,j] for i in S for j in range(n) if j not in S) for r in range(0,n-1) for T in itertools.combinations(range(1,n-1),r) for S in [set((0,)+T)])
    ok&= f==best
print('maxflow=mincut',ok)
