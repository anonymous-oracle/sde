import random, math, itertools, collections, statistics
random.seed(4)
# 1 authorization graph (Griffiths-Wade): privilege holds if a path of grants with non-decreasing timestamps from owner exists and each granter held grant option
grants = [('DBA', 'U1', 1), ('U1', 'U2', 2), ('DBA', 'U2', 3), ('U2', 'U3', 4)]
def valid(grants, owner='DBA'):
    # earliest time each user obtained the privilege through valid chain
    have = {owner: 0}; ch = True; ok = set()
    while ch:
        ch = False
        for g in sorted(grants, key=lambda x: x[2]):
            f, t, ts = g
            if f in have and have[f] <= ts and g not in ok:
                ok.add(g); ch = True
                if t not in have or ts < have[t]: have[t] = ts
    return have
print('before', sorted(valid(grants)), 'after revoking DBA->U1:', sorted(valid([g for g in grants if g != ('DBA', 'U1', 1)])))
# 2 statistical DB tracker
emp = [('e1', 'D1', 'M', 50), ('e2', 'D1', 'F', 60), ('e3', 'D1', 'M', 55), ('e4', 'D2', 'F', 70), ('e5', 'D2', 'M', 65), ('e6', 'D2', 'F', 80), ('e7', 'D3', 'M', 45), ('e8', 'D3', 'F', 90)]
def q_sum(pred, k=2):
    rows = [r for r in emp if pred(r)]
    if len(rows) < k or len(rows) > len(emp) - k: return None
    return sum(r[3] for r in rows)
# target e2 (D1, F): D1 has 3 employees; tracker T = gender M ; q(D1 and F) alone has size 1 -> refused
print('direct refused:', q_sum(lambda r: r[1] == 'D1' and r[2] == 'F'))
a = q_sum(lambda r: r[1] == 'D1'); b = q_sum(lambda r: r[1] == 'D1' and r[2] == 'M'); print('tracker: SUM(D1) - SUM(D1 and M) =', a - b, ' true salary of e2 =', 60)
print('Laplace sd for count with eps=0.5:', round(math.sqrt(2) * 1 / 0.5, 4))
# 3 R-tree
class RT:
    def __init__(s, M=8): s.M = M; s.m = M // 2; s.root = {'leaf': True, 'e': []}; s.h = 1
    @staticmethod
    def area(r): return (r[2] - r[0]) * (r[3] - r[1])
    @staticmethod
    def union(a, b): return (min(a[0], b[0]), min(a[1], b[1]), max(a[2], b[2]), max(a[3], b[3]))
    def mbr(s, node):
        r = node['e'][0][0]
        for e in node['e'][1:]: r = s.union(r, e[0])
        return r
    def insert(s, rect, oid):
        path = []; node = s.root
        while not node['leaf']:
            best = min(node['e'], key=lambda e: (s.area(s.union(e[0], rect)) - s.area(e[0]), s.area(e[0])))
            path.append((node, best)); node = best[1]
        node['e'].append((rect, oid)); split = None
        if len(node['e']) > s.M: split = s.split(node)
        for parent, entry in reversed(path):
            i = parent['e'].index(entry); parent['e'][i] = (s.mbr(entry[1]), entry[1])
            if split:
                parent['e'].append((s.mbr(split), split)); split = None
                if len(parent['e']) > s.M: split = s.split(parent)
        if split:
            old = s.root; s.root = {'leaf': False, 'e': [(s.mbr(old), old), (s.mbr(split), split)]}; s.h += 1
    def split(s, node):
        E = node['e']; best = None
        for i, j in itertools.combinations(range(len(E)), 2):
            d = s.area(s.union(E[i][0], E[j][0])) - s.area(E[i][0]) - s.area(E[j][0])
            if best is None or d > best[0]: best = (d, i, j)
        _, i, j = best; A = [E[i]]; B = [E[j]]; rest = [e for k, e in enumerate(E) if k not in (i, j)]
        while rest:
            if len(A) + len(rest) == s.m: A += rest; break
            if len(B) + len(rest) == s.m: B += rest; break
            e = rest.pop(); ma, mb = A[0][0], B[0][0]
            for x in A[1:]: ma = s.union(ma, x[0])
            for x in B[1:]: mb = s.union(mb, x[0])
            (A if s.area(s.union(ma, e[0])) - s.area(ma) <= s.area(s.union(mb, e[0])) - s.area(mb) else B).append(e)
        node['e'] = A; return {'leaf': node['leaf'], 'e': B}
    def search(s, q, node=None, out=None):
        node = node or s.root; out = [] if out is None else out
        for r, c in node['e']:
            if r[0] <= q[2] and q[0] <= r[2] and r[1] <= q[3] and q[1] <= r[3]:
                if node['leaf']: out.append(c)
                else: s.search(q, c, out)
        return out
t = RT(8); rects = []
for i in range(3000):
    x, y = random.random(), random.random(); r = (x, y, x + random.random() * 0.02, y + random.random() * 0.02); rects.append(r); t.insert(r, i)
bad = 0
for _ in range(200):
    x, y = random.random(), random.random(); q = (x, y, x + 0.1, y + 0.1)
    brute = {i for i, r in enumerate(rects) if r[0] <= q[2] and q[0] <= r[2] and r[1] <= q[3] and q[1] <= r[3]}
    bad += set(t.search(q)) != brute
print('R-tree mismatches vs brute force:', bad, 'height', t.h)
def morton(x, y, bits):
    z = 0
    for i in reversed(range(bits)): z = (z << 2) | (((x >> i) & 1) << 1) | ((y >> i) & 1)
    return z
print('Morton(5,3), 3 bits:', morton(5, 3, 3))
# 4 Allen's relations
def allen(a, b):
    (s1, e1), (s2, e2) = a, b
    if e1 < s2: return 'before'
    if e1 == s2: return 'meets'
    if s1 < s2 < e1 < e2: return 'overlaps'
    if s1 == s2 and e1 < e2: return 'starts'
    if s2 < s1 and e1 < e2: return 'during'
    if s2 < s1 and e1 == e2: return 'finishes'
    if s1 == s2 and e1 == e2: return 'equals'
    r = allen(b, a); return r + '-inv'
rel = {allen((a, b), (c, d)) for a in range(6) for b in range(a + 1, 7) for c in range(6) for d in range(c + 1, 7)}
print('Allen relations found', len(rel))
# 5 curse of dimensionality
print('volume within 0.05 of surface, d=20:', round(1 - 0.9 ** 20, 4), 'd=2:', round(1 - 0.9 ** 2, 4))
for d in (2, 100, 1000):
    pts = [[random.random() for _ in range(d)] for _ in range(200)]; q = [random.random() for _ in range(d)]
    ds = [math.dist(q, p) for p in pts]; print('d', d, 'max/min distance ratio', round(max(ds) / min(ds), 3))
# 6 distributed: ROWA availability, semijoin
p = 0.9; print('ROWA N=3 write avail', round(p ** 3, 4), 'read avail', round(1 - (1 - p) ** 3, 4))
R = [(random.randint(0, 999), i) for i in range(10000)]; S = [(random.randint(0, 999) if random.random() < 0.5 else 5000 + i, i) for i in range(1000)]
sb = {b for b, _ in S}; Rr = [r for r in R if r[0] in sb]
J1 = {(r, s) for r in R for s in S if r[0] == s[0]}; J2 = {(r, s) for r in Rr for s in S if r[0] == s[0]}
print('semijoin keeps join:', J1 == J2, 'reduced R', len(Rr), 'of', len(R))
# fragmentation correctness
rows = [(i, random.choice('NSEW'), random.random()) for i in range(100)]
frags = {c: [r for r in rows if r[1] == c] for c in 'NSEW'}
assert sum(len(f) for f in frags.values()) == len(rows) and sorted(sum(frags.values(), [])) == sorted(rows); print('horizontal fragmentation complete, disjoint, reconstructable')
# 7 graph 2-hop
E = [(1, 2), (1, 3), (2, 4), (3, 4), (4, 5), (5, 6), (2, 7), (7, 8), (3, 9)]
adj = collections.defaultdict(set)
for u, v in E: adj[u].add(v); adj[v].add(u)
d = {1: 0}; fr = [1]
while fr:
    nx = []
    for u in fr:
        for v in adj[u]:
            if v not in d: d[v] = d[u] + 1; nx.append(v)
    fr = nx
print('exactly 2 hops from 1:', sorted(k for k, v in d.items() if v == 2), 'within 2:', sorted(k for k, v in d.items() if 0 < v <= 2))
