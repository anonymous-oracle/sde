import random
random.seed(11)
# Dynamo-style quorum: N replicas, write to W, read from R; count stale reads over random replica subsets
def stale(N, R, W, trials=20000):
    bad = 0
    for _ in range(trials):
        rep = [0] * N
        for i in random.sample(range(N), W): rep[i] = 1       # latest version 1 written to W replicas
        got = max(rep[i] for i in random.sample(range(N), R))  # read takes the newest version among R replies
        bad += got != 1
    return bad / trials
for N, R, W in ((3, 2, 2), (3, 1, 1), (3, 1, 3), (5, 3, 3), (5, 2, 3)):
    print(N, R, W, 'R+W>N' if R + W > N else 'R+W<=N', 'stale fraction', stale(N, R, W))
# exact stale probability for R+W<=N: C(N-W,R)/C(N,R)
from math import comb
print('exact N=3 R=1 W=1:', comb(2, 1) / comb(3, 1), ' N=5 R=2 W=3:', comb(2, 2) / comb(5, 2))
# availability
p = .9
print('majority write avail N=3', 3 * p**2 * (1 - p) + p**3, 'rowa', p**3)
