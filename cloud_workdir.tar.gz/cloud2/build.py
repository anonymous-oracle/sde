#!/usr/bin/env python3
"""Build unified_curriculum.md from authored unit files and check source coverage.

usage: build.py check            -> coverage + atom-level check only
       build.py build OUT.md     -> write the document
"""
import re, sys, glob, collections
import srclib as S

STOP = set('the and for with from into week lecture topics topic over using use used their its are this that these those '
           'also such via per etc one two three out can will have has been being may more most some any each other than then '
           'how what why which who whom where when while about above after before between both during under very part parts '
           'based methods method basic basics introduction introductions'.split())


ALIAS = {'centre': 'center', 'colour': 'color', 'behaviour': 'behavior', 'generalised': 'generalized',
         'optimisation': 'optimization', 'regularisation': 'regularization', 'neighbour': 'neighbor',
         'neighbourhood': 'neighborhood', 'grammer': 'grammar', 'normalised': 'normalized', 'visualisation': 'visualization'}


def stem(w):
    w = ALIAS.get(w, w)
    if w.endswith('ies') and len(w) > 4:
        w = w[:-3] + 'y'
    elif w.endswith('es') and len(w) > 4:
        w = w[:-2]
    elif w.endswith('s') and not w.endswith('ss') and len(w) > 3:
        w = w[:-1]
    return w[:5]


def toks(s):
    s = s.lower()
    s = re.sub(r"[’']s\b", '', s)
    ws = re.findall(r'[a-z0-9]+', s)
    return [stem(w) for w in ws if (len(w) >= 3 and w not in STOP) or (w.isdigit())]


def atoms(text):
    t = re.sub(r'(?im)^\s*week\s*\d+\s*[:\-]?\s*', '', text)
    t = re.sub(r'(?i)\bweek\s*\d+\s*[:\-]?', ' ', t)
    t = re.sub(r'(?i)lecture\s*\d+\s*[:\-]?', ' ; ', t)
    t = re.sub(r'(?m)^\s*\d+(\.\d+)*\.?\s+', '', t)
    t = re.sub(r'\b\d+\.\s+(?=[A-Z])', ' ; ', t)
    parts = re.split(r'[,;:•\n|\t]|\s[-–]\s|\.\s|\.$|\(|\)|\s\d+\.\s', t)
    out = []
    for p in parts:
        tk = toks(p)
        if tk:
            out.append((p.strip(), tk))
    return out


# ---------------- unit parsing ----------------
class Unit:
    def __init__(self, uid, title):
        self.uid, self.title = uid, title
        self.src = []      # list of (course, cell)
        self.lines = []
        self.domain = None

    @property
    def text(self):
        return '\n'.join(self.lines)


def parse_src(spec):
    cells = []
    for part in re.split(r';', spec):
        part = part.strip()
        if not part:
            continue
        k, _, rest = part.partition(':')
        k = k.strip()
        for c in rest.split(','):
            c = c.strip()
            if not c:
                continue
            if k == 'GEN':
                if c.endswith('*'):
                    pre = c[:-1]
                    cells += [(k, s) for s in S.GEN if s.startswith(pre)]
                else:
                    cells.append((k, c))
            elif c == '*':
                cells += [(k, x) for x in S.cell_ids(k)]
            elif re.fullmatch(r'\d+', c):
                cells.append((k, 'W' + c))
            elif re.fullmatch(r'\d+-\d+', c):
                a, b = map(int, c.split('-'))
                cells += [(k, f'W{i}') for i in range(a, b + 1)]
            else:
                cells.append((k, c))
    return cells


def load_units(files):
    units, domains, front = [], [], []
    cur = None
    dom = None
    for f in files:
        for ln in open(f).read().split('\n'):
            m = re.match(r'^## (D\d+)\. (.*)', ln)
            if m:
                dom = dict(id=m.group(1), title=m.group(2), intro=[], units=[])
                domains.append(dom)
                cur = None
                continue
            m = re.match(r'^### (U[\d.]+[a-z]?) (.*)', ln)
            if m:
                cur = Unit(m.group(1), m.group(2))
                cur.domain = dom['id']
                dom['units'].append(cur)
                units.append(cur)
                continue
            if cur is None:
                if dom is not None:
                    dom['intro'].append(ln)
                else:
                    front.append(ln)
                continue
            m = re.match(r'^src:\s*(.*)', ln)
            if m:
                cur.src += parse_src(m.group(1))
                continue
            cur.lines.append(ln)
    return units, domains, front


def check(units, verbose=True):
    cited = collections.defaultdict(list)
    for u in units:
        for c in u.src:
            cited[c].append(u)
    bad_cells = [c for c in cited if c[0] != 'GEN' and c[1] not in S.cell_ids(c[0])]
    bad_cells += [c for c in cited if c[0] == 'GEN' and c[1] not in S.GEN]
    required = [c for c in S.all_cells() if not re.match(r'^(P\d*)$', c[1]) or c[0] in ('ALAB',)]
    required = [c for c in required if not (c[0] == 'IPS' and c[1] == 'dup')]
    missing = [c for c in required if c not in cited]
    miss_atoms = []
    prose_atoms = []
    scattered = 0
    total_atoms = 0
    for c, us in cited.items():
        if c in bad_cells:
            continue
        txt = S.text_of(*c)
        union = ' '.join(u.text + ' ' + u.title for u in us)
        ut = toks(union)
        uset = set(ut)
        ubig = {tuple(ut[i:i + 3]) for i in range(len(ut))}
        for a, tk in atoms(txt):
            total_atoms += 1
            if len(tk) == 1:
                ok = tk[0] in uset
                strict = ok
            else:
                allin = sum(1 for t in tk if t in uset)
                ok = allin >= max(1, int(len(tk) * 0.75 + 0.999))
                # strict: contiguous stems present
                seq = tuple(tk[:3])
                strict = seq in ubig or len(tk) == 1
                if not strict and len(tk) == 2:
                    strict = any(ut[i:i + 2] == tk for i in range(len(ut) - 1))
            if not ok:
                (miss_atoms if len(tk) <= 7 else prose_atoms).append((c, a, [u.uid for u in us]))
            elif not strict:
                scattered += 1
    if verbose:
        print(f'cells total {len(S.all_cells())}; required {len(required)}; cited {len(cited)}; uncited {len(missing)}')
        if bad_cells:
            print('BAD CELL REFS:', bad_cells)
        print(f'atoms checked {total_atoms}; missing {len(miss_atoms)}; long-prose-missing {len(prose_atoms)}; loose-only {scattered}')
    check.prose = prose_atoms
    return missing, miss_atoms, bad_cells, cited


def fmt_cells(cells):
    by = collections.OrderedDict()
    for k, c in cells:
        by.setdefault(k, [])
        if c not in by[k]:
            by[k].append(c)
    out = []
    for k, cs in by.items():
        ws = [c for c in cs if re.fullmatch(r'W\d+', c)]
        oth = [c for c in cs if c not in ws]
        nums = sorted(int(c[1:]) for c in ws)
        runs, i = [], 0
        while i < len(nums):
            j = i
            while j + 1 < len(nums) and nums[j + 1] == nums[j] + 1:
                j += 1
            runs.append(f'{nums[i]}' if i == j else f'{nums[i]}–{nums[j]}')
            i = j + 1
        parts = (['W' + ','.join(runs)] if runs else []) + oth
        out.append(f'{k} ' + ', '.join(parts))
    return '; '.join(out)


if __name__ == '__main__':
    files = sorted(glob.glob('/home/claude/work/cloud2/units/*.md'))
    units, domains, front = load_units(files)
    mode = sys.argv[1] if len(sys.argv) > 1 else 'check'
    missing, miss_atoms, bad, cited = check(units)
    if mode == 'check':
        if '-v' in sys.argv:
            print('UNCITED:', ' '.join(f'{k}:{c}' for k, c in missing))
        lim = 400
        NOISE = re.compile(r'^(continued?|examples?|cont…|cont|iii?|\d+|and|etc|contd|namely|however|therefore|finally|initially|specifically|key takeaways?.*|hands.on.*)$', re.I)
        show = miss_atoms if '-o' in sys.argv else [m for m in miss_atoms if m[0][1] != 'o']
        show = [m for m in show if not NOISE.match(m[1].strip())]
        seen_ = set(); show2 = []
        for m in show:
            k_ = (m[0], m[1])
            if k_ in seen_: continue
            seen_.add(k_); show2.append(m)
        show = show2
        print('shown', len(show), 'of', len(miss_atoms), '(o-cells hidden unless -o)')
        for c, a, us in show[:lim]:
            print(f'MISS {c[0]}:{c[1]} [{",".join(us)}] :: {a[:90]}')
