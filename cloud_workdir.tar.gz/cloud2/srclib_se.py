"""Cell table for software-engineering.txt (two outlines): ISE = Introduction to Software Engineering (Chatterjee, IIT (ISM) Dhanbad),
SEM = Software Engineering (Mall, IIT Kharagpur). Cell Wn is the course-plan line for week n; 'o' the description, audience and industry lines."""
SRC = open('/home/claude/work/cloud2/src6.txt').read().split('\n')
def R(a, b=None): return list(range(a, (b or a) + 1))
COURSES = {}
def course(key, title, who, cells, pre=None, books=None, note=''):
    COURSES[key] = dict(title=title, who=who, cells=cells, pre=pre or [], books=books or [], note=note)
course('ISE', 'Introduction to Software Engineering: A Road Map to Reliable Software Development and Maintenance',
       'Subhashis Chatterjee, IIT (ISM) Dhanbad (NPTEL 111105002)',
       {'o': [19, 22, 26], **{f'W{i}': [30 + i] for i in range(1, 13)}}, pre=[24], books=[44, 45])
course('SEM', 'Software Engineering', 'Rajib Mall, IIT Kharagpur (NPTEL 106105182)',
       {'o': [64, 67], **{f'W{i}': [73 + i] for i in range(1, 13)}}, pre=[69], books=[87])
