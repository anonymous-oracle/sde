#!/usr/bin/env python3
"""Build src4.txt (outline-style source for the design domain) from the cloned READMEs and print the cell table."""
import re, json, glob, os, sys
P = '/home/claude/work/src_new/primer/repo/'
Y = '/home/claude/work/src_new/pypat/repo/README.md'
lines = open(P + 'README.md').read().split('\n')
# heading tree
heads = []  # (idx, level, title)
infence = False
for i, ln in enumerate(lines):
    if ln.startswith('```'): infence = not infence
    if infence: continue
    m = re.match(r'(#{1,6}) (.*)', ln)
    if m: heads.append((i, len(m.group(1)), m.group(2).strip()))
def section(title, level=2):
    for k, (i, l, t) in enumerate(heads):
        if t == title and l == level:
            j = len(lines)
            for (i2, l2, t2) in heads[k + 1:]:
                if l2 <= level: j = i2; break
            return i, j, [h for h in heads[k + 1:] if i < h[0] < j]
    raise KeyError(title)
def clean(t):
    t = re.sub(r'\[([^\]]*)\]\([^)]*\)', r'\1', t)
    t = re.sub(r'[`*]', '', t).strip()
    return t
SKIP = re.compile(r'^(Source\(s\) and further reading|Source\(s\))', re.I)
def flat(title, level=2):
    i, j, hs = section(title, level)
    out = []
    for (_, l, t) in hs:
        if SKIP.match(t): continue
        out.append(clean(t))
    return out
def bold(title, level=2, maxn=40):
    i, j, hs = section(title, level)
    seen = []
    for ln in lines[i:j]:
        for b in re.findall(r'\*\*([^*]{3,60})\*\*', ln):
            b = clean(b).rstrip('-: ').strip()
            if b and b.lower() not in [s.lower() for s in seen] and not b.startswith('Source') and 'Note' not in b: seen.append(b)
    return seen[:maxn]
cells = []   # (key, cid, [lines])
def add(key, cid, text):
    cells.append((key, cid, [text]))
# ---- primer topic cells
add('SDP', 'o', 'The System Design Primer (Donne Martin): Motivation; Learn how to design large-scale systems; Learn from the open source community; Prep for the system design interview; Index of system design topics: everything is a trade-off; Anki flashcards; Coding resource: interactive coding challenges')
add('SDP', 'STUDY', 'Study guide: suggested topics to review based on your interview timeline (short, medium, long); do you need to know everything: no; start broad and go deeper in a few areas')
add('SDP', 'HOW', 'How to approach a system design interview question: ' + '; '.join(flat('How to approach a system design interview question')) + '; the interview is an open-ended conversation you lead; use cases, constraints, assumptions; who, how, how many users, inputs and outputs, data, requests per second, read to write ratio; sketch main components and justify; hash of the full url (MD5 and Base62, hash collisions, SQL or NoSQL, database schema), API and object-oriented design; load balancer, horizontal scaling, caching, database sharding; everything is a trade-off')
add('SDP', 'START', 'System design topics: start here: ' + '; '.join(flat('System design topics: start here')))
add('SDP', 'PERF', 'Performance vs scalability: a service is scalable if added resources increase performance proportionally; performance problem: slow for a single user; scalability problem: fast for a single user but slow under heavy load')
add('SDP', 'LAT', 'Latency vs throughput: latency is the time to perform an action; throughput is the number of actions per unit of time; maximal throughput with acceptable latency')
add('SDP', 'CAP', 'Availability vs consistency: CAP theorem (consistency, availability, partition tolerance); ' + '; '.join(flat('Availability vs consistency')) + '; networks are not reliable, so support partition tolerance; CP is a good choice for atomic reads and writes; AP is a good choice for eventual consistency')
add('SDP', 'CONS', 'Consistency patterns: weak consistency, eventual consistency, strong consistency; memcached; DNS and email; file systems and RDBMSes; real time use cases such as VoIP, video chat, multiplayer games; data replicated asynchronously or synchronously')
add('SDP', 'AVL', 'Availability patterns: fail-over (active-passive, active-active, disadvantages of failover); replication (master-slave and master-master); availability in numbers (99.9% three 9s, 99.99% four 9s, downtime per year, month, week, day); availability in parallel vs in sequence; heartbeats; hot standby and cold standby')
add('SDP', 'DNS', 'Domain name system: hierarchical lookup with caching and propagation delays; NS record (name server), MX record (mail exchange), A record (address), CNAME (canonical); managed DNS services (CloudFlare, Route 53) that route traffic to avoid servers under maintenance, to balance between varying cluster sizes and for A/B testing; disadvantages of DNS')
add('SDP', 'CDN', 'Content delivery network: ' + '; '.join(flat('Content delivery network')) + '; globally distributed proxy servers; push CDNs for small amounts of traffic or rarely updated content; pull CDNs for heavy traffic; time-to-live (TTL); CloudFront')
add('SDP', 'LB', 'Load balancer: ' + '; '.join(flat('Load balancer')) + '; SSL termination; session persistence; routing metrics (random, least loaded, session/cookies, layer 4, layer 7); hardware or software (HAProxy); vertical scaling vs horizontal scaling; servers should be stateless; sessions in a centralized data store')
add('SDP', 'RP', 'Reverse proxy (web server): ' + '; '.join(flat('Reverse proxy (web server)')) + '; increased security; increased scalability and flexibility; SSL termination; compression; caching; static content; NGINX and HAProxy')
add('SDP', 'APP', 'Application layer: separating the web layer from the application layer (platform layer); single responsibility principle; workers enable asynchronism; microservices (independently deployable, small, modular services); service discovery (Consul, Etcd, Zookeeper, health checks done using an HTTP endpoint, built-in key-value store); disadvantages of the application layer')
add('SDP', 'RDB', 'Database: relational database management system (RDBMS); ACID (atomicity, consistency, isolation, durability); master-slave replication; master-master replication; disadvantages of replication; federation (functional partitioning); sharding (consistent hashing, lopsided data); denormalization (materialized views, reads outnumber writes 100:1 or 1000:1); SQL tuning (benchmark, profile, tighten up the schema, use good indices, avoid expensive joins, partition tables, tune the query cache)')
add('SDP', 'NOSQL', 'NoSQL: key-value store (abstraction: hash table), document store (abstraction: key-value store with documents stored as values), wide column store (abstraction: nested map ColumnFamily, Bigtable, HBase, Cassandra), graph database (abstraction: graph); BASE (basically available, soft state, eventual consistency); MongoDB, CouchDB, DynamoDB')
add('SDP', 'SQLNO', 'SQL or NoSQL: reasons for SQL (structured data, strict schema, relational data, need for complex joins, transactions, clear patterns for scaling, more established, lookups by index are very fast); reasons for NoSQL (semi-structured data, dynamic or flexible schema, non-relational data, no need for complex joins, store many TB (or PB) of data, very data intensive workload, very high throughput for IOPS); sample data well-suited for NoSQL (clickstream and log data, leaderboard or scoring data, temporary data such as a shopping cart, frequently accessed hot tables, metadata and lookup tables)')
add('SDP', 'CACHE', 'Cache: client caching, CDN caching, web server caching, database caching, application caching (Memcached, Redis), caching at the database query level, caching at the object level, when to update the cache (cache-aside, write-through, write-behind (write-back), refresh-ahead), disadvantages of cache, cache invalidation; lazy loading; read-through; Varnish')
add('SDP', 'ASYNC', 'Asynchronism: message queues (Redis, RabbitMQ, Amazon SQS), task queues (Celery), back pressure, disadvantages of asynchronism; workers; job status; AMQP')
add('SDP', 'COMM', 'Communication: hypertext transfer protocol (HTTP) with verbs GET, POST, PUT, PATCH, DELETE (idempotent, safe, cacheable); transmission control protocol (TCP) with sequence numbers, checksum, flow control, congestion control, connection pooling; user datagram protocol (UDP) with datagrams, broadcast, DHCP; remote procedure call (RPC) with client stub, server stub, marshalling; representational state transfer (REST) with four qualities (identify resources, change with representations, self-descriptive error message, HATEOAS); RPC and REST calls comparison; disadvantages of RPC and REST')
add('SDP', 'SEC', 'Security: encrypt in transit and at rest; sanitize all user inputs to prevent XSS and SQL injection; use parameterized queries; use the principle of least privilege')
add('SDP', 'APPX', 'Appendix: back-of-the-envelope estimates; powers of two table (power, exact value, approx value, bytes); latency numbers every programmer should know (L1 cache reference, branch mispredict, L2 cache reference, mutex lock/unlock, main memory reference, compress 1K bytes, send 1 KB over 1 Gbps network, read 4 KB randomly from SSD, read 1 MB sequentially from memory, round trip within same datacenter, read 1 MB sequentially from SSD, HDD seek, read 1 MB sequentially from HDD, send packet CA->Netherlands->CA); handy metrics; latency numbers visualized')
add('SDP', 'MORE', 'Additional system design interview questions (Dropbox file sync, search engine, scalable web crawler, Google docs, key-value store like Redis, cache system like Memcached, recommendation system, tinyurl, WhatsApp chat, Instagram picture sharing, Facebook news feed, timeline, chat, graph search, CDN like CloudFlare, trending topics, random ID generation, top k requests, multiple data centers, online multiplayer card game, garbage collection, API rate limiter, stock exchange); real world architectures (data processing: MapReduce, Spark, Storm; data store: Bigtable, HBase, Cassandra, DynamoDB, MongoDB, Spanner, Memcached, Redis; file system: GFS, HDFS; misc: Chubby, Dapper, Kafka, Zookeeper); company architectures (Amazon, Cinchcast, DataSift, Dropbox, ESPN, Google, Instagram, Justin.tv, Facebook, Flickr, Mailbox, Netflix, Pinterest, Playfish, PlentyOfFish, Salesforce, Stack Overflow, TripAdvisor, Tumblr, Twitter, Uber, WhatsApp, YouTube); company engineering blogs')
add('SDP', 'DEV', 'Under development: distributed computing with MapReduce; consistent hashing; scatter gather')
# ---- the eight system design solutions + question list
SOL = {'SOL1': ('pastebin', 'Design Pastebin.com (or Bit.ly)'), 'SOL2': ('twitter', 'Design the Twitter timeline and search (or Facebook feed and search)'),
       'SOL3': ('web_crawler', 'Design a web crawler'), 'SOL4': ('mint', 'Design Mint.com'), 'SOL5': ('social_graph', 'Design the data structures for a social network'),
       'SOL6': ('query_cache', 'Design a key-value store for a search engine'), 'SOL7': ('sales_rank', "Design Amazon's sales ranking by category feature"),
       'SOL8': ('scaling_aws', 'Design a system that scales to millions of users on AWS')}
for cid, (d, title) in SOL.items():
    t = open(P + f'solutions/system_design/{d}/README.md').read().split('\n')
    hs = []; inf = False
    for ln in t:
        if ln.startswith('```'): inf = not inf
        if inf: continue
        m = re.match(r'#{2,4} (.*)', ln)
        if m: hs.append(clean(m.group(1)))
    keep = [h for h in hs if not h.startswith("We'll scope the problem") and h not in ('Caching', 'Asynchronism and microservices', 'Communications', 'Security', 'Latency numbers', 'Ongoing')]
    seen = []
    for h in keep:
        if h not in seen: seen.append(h)
    add('SDP', cid, title + ': ' + '; '.join(seen))
OOD = {'OOD1': ('hash_table/hash_map', 'Design a hash map'), 'OOD2': ('lru_cache/lru_cache', 'Design a least recently used cache'),
       'OOD3': ('call_center/call_center', 'Design a call center'), 'OOD4': ('deck_of_cards/deck_of_cards', 'Design a deck of cards'),
       'OOD5': ('parking_lot/parking_lot', 'Design a parking lot'), 'OOD6': ('online_chat/online_chat', 'Design a chat server')}
for cid, (d, title) in OOD.items():
    nb = json.load(open(P + f'solutions/object_oriented_design/{d}.ipynb'))
    cls = []
    for c in nb['cells']:
        if c['cell_type'] == 'code':
            for nm, base in re.findall(r'^class (\w+)(?:\(([\w, .]*)\))?', ''.join(c['source']), re.M):
                cls.append(nm + (f' ({base})' if base and base != 'object' else ''))
    add('SDP', cid, title + ': classes ' + ', '.join(cls))
add('SDP', 'OODQ', 'Object-oriented design interview questions with solutions: hash map, least recently used cache, call center, deck of cards, parking lot, chat server, circular array (to contribute)')
add('SDP', 'SDQ', 'System design interview questions with solutions: Pastebin.com (or Bit.ly), Twitter timeline and search (or Facebook feed and search), web crawler, Mint.com, data structures for a social network, key-value store for a search engine, Amazon sales ranking by category, scaling to millions of users on AWS')
# ---- python-patterns README
y = open(Y).read().split('\n')
def rows(start, end):
    out = []
    for ln in y[start:end]:
        m = re.match(r'\|\s*\[([^\]]+)\]\([^)]*\)\s*(\([^)]*\))?\s*\|\s*(.*?)\s*\|\s*$', ln)
        if m: out.append(m.group(1).replace('_', ' ') + (' ' + m.group(2) if m.group(2) else '') + ' (' + re.sub(r'\s+', ' ', m.group(3)) + ')')
    return out
hidx = {ln: i for i, ln in enumerate(y)}
def at(h): return next(i for i, ln in enumerate(y) if ln.startswith(h))
add('PYP', 'o', 'python-patterns: a collection of design patterns and idioms in Python; each pattern has its own trade-offs; pay more attention to why you are choosing a certain pattern than to how to implement it')
add('PYP', 'CRE', 'Creational patterns (object creation): ' + '; '.join(rows(at('## Creational'), at('## Structural'))))
add('PYP', 'STR', 'Structural patterns (how classes and objects are composed): ' + '; '.join(rows(at('## Structural'), at('## Behavioral'))))
add('PYP', 'BEH', 'Behavioral patterns (communication and responsibility between objects): ' + '; '.join(rows(at('## Behavioral'), at('## Design for Testability'))))
add('PYP', 'TST', 'Design for testability patterns: ' + '; '.join(rows(at('## Design for Testability'), at('## Fundamental'))))
add('PYP', 'FUN', 'Fundamental patterns: ' + '; '.join(rows(at('## Fundamental'), at('## Others'))))
add('PYP', 'OTH', 'Others: ' + '; '.join(rows(at('## Others'), at('## 🚫'))))
add('PYP', 'ANTI', 'Anti-patterns (common design patterns not recommended in Python): singleton (Python modules are already singletons; use module-level variables or dependency injection); god object (centralizes too much logic; split into smaller cohesive classes); inheritance overuse (deep inheritance trees are brittle; prefer composition and delegation; favor composition over inheritance)')
add('PYP', 'VID', 'Videos: Design Patterns in Python (Peter Ullrich); Why you do not need design patterns in Python (Sebastian Buczynski); You do not need that; Pluggable libs through design patterns')
# ---- Gang of Four catalogue (checked on Wikipedia, 2026-11-06)
add('GOF', 'o', 'Design Patterns: Elements of Reusable Object-Oriented Software (1994) by Erich Gamma, Richard Helm, Ralph Johnson and John Vlissides, the Gang of Four: 23 patterns in three groups')
add('GOF', 'CRE', 'Creational patterns (5): abstract factory; builder; factory method; prototype; singleton')
add('GOF', 'STR', 'Structural patterns (7): adapter; bridge; composite; decorator; facade; flyweight; proxy')
add('GOF', 'BEH', 'Behavioral patterns (11): chain of responsibility; command; interpreter; iterator; mediator; memento; observer; state; strategy; template method; visitor')
add('GOF', 'PRI', 'Design principles stated in the book: program to an interface, not an implementation; favor object composition over class inheritance; inheritance mainly when adding to existing components; inherit only from abstract classes; delegation is an extreme form of object composition; acquaintance is preferable to aggregation for looser coupling')
# write src4.txt and table
out = []; table = []
for key, cid, ls in cells:
    start = len(out) + 1
    out.extend(ls)
    table.append((key, cid, start, len(out)))
open('/home/claude/work/cloud2/src4.txt', 'w').write('\n'.join(out) + '\n')
json.dump(table, open('/home/claude/work/cloud2/design_src/table.json', 'w'))
print(len(out), 'lines;', len(table), 'cells;', sum(len(l) for l in out), 'chars')
