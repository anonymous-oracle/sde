module cloudcurr

go 1.24
