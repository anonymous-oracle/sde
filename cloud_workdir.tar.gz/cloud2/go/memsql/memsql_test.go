package memsql

import (
	"database/sql"
	"sync"
	"testing"
)

func open(t *testing.T, name string) *sql.DB {
	db, err := sql.Open("memsql", name)
	if err != nil {
		t.Fatal(err)
	}
	return db
}

func TestBasicSQL(t *testing.T) {
	db := open(t, "basic")
	if _, err := db.Exec("CREATE TABLE acct (id, bal)"); err != nil {
		t.Fatal(err)
	}
	for i := 0; i < 5; i++ {
		db.Exec("INSERT INTO acct VALUES (?, ?)", i, 100)
	}
	var bal int64
	if err := db.QueryRow("SELECT bal FROM acct WHERE id = ?", 3).Scan(&bal); err != nil || bal != 100 {
		t.Fatal(err, bal)
	}
	res, _ := db.Exec("DELETE FROM acct WHERE id = ?", 2)
	n, _ := res.RowsAffected()
	if n != 1 {
		t.Fatal(n)
	}
	rows, _ := db.Query("SELECT * FROM acct")
	cnt := 0
	for rows.Next() {
		cnt++
	}
	if cnt != 4 {
		t.Fatal(cnt)
	}
	if err := db.QueryRow("SELECT nope FROM acct").Scan(&bal); err == nil {
		t.Fatal("expected error for unknown column")
	}
}

func TestRollbackIsAllOrNothing(t *testing.T) {
	db := open(t, "tx")
	db.Exec("CREATE TABLE a (id, bal)")
	db.Exec("INSERT INTO a VALUES (?, ?)", 1, 100)
	tx, _ := db.Begin()
	tx.Exec("INSERT INTO a VALUES (?, ?)", 2, 50)
	tx.Exec("DELETE FROM a WHERE id = ?", 1)
	tx.Rollback()
	var n int
	rows, _ := db.Query("SELECT id FROM a")
	for rows.Next() {
		n++
	}
	if n != 1 {
		t.Fatalf("after rollback want 1 row, got %d", n)
	}
	tx, _ = db.Begin()
	tx.Exec("INSERT INTO a VALUES (?, ?)", 3, 5)
	tx.Commit()
	rows, _ = db.Query("SELECT id FROM a")
	n = 0
	for rows.Next() {
		n++
	}
	if n != 2 {
		t.Fatal(n)
	}
}

// Many goroutines insert through the pool; the row count must match exactly.
func TestPoolConcurrency(t *testing.T) {
	db := open(t, "pool")
	db.SetMaxOpenConns(10)
	db.Exec("CREATE TABLE c (g, i)")
	var wg sync.WaitGroup
	for g := 0; g < 16; g++ {
		wg.Add(1)
		go func(g int) {
			defer wg.Done()
			for i := 0; i < 100; i++ {
				if _, err := db.Exec("INSERT INTO c VALUES (?, ?)", g, i); err != nil {
					t.Error(err)
				}
			}
		}(g)
	}
	wg.Wait()
	rows, _ := db.Query("SELECT g FROM c")
	n := 0
	for rows.Next() {
		n++
	}
	t.Logf("16 goroutines x 100 inserts through a pool of 10 -> %d rows, open conns %d", n, db.Stats().OpenConnections)
	if n != 1600 {
		t.Fatal(n)
	}
}

// Transfers inside transactions conserve the total.
func TestTransfersConserveTotal(t *testing.T) {
	db := open(t, "bank")
	db.SetMaxOpenConns(8)
	db.Exec("CREATE TABLE b (id, bal)")
	for i := 0; i < 4; i++ {
		db.Exec("INSERT INTO b VALUES (?, ?)", i, 1000)
	}
	var wg sync.WaitGroup
	for g := 0; g < 8; g++ {
		wg.Add(1)
		go func(g int) {
			defer wg.Done()
			for i := 0; i < 50; i++ {
				from, to := (g+i)%4, (g+i+1)%4
				tx, err := db.Begin()
				if err != nil {
					t.Error(err)
					return
				}
				var fb, tb int64
				tx.QueryRow("SELECT bal FROM b WHERE id = ?", from).Scan(&fb)
				tx.QueryRow("SELECT bal FROM b WHERE id = ?", to).Scan(&tb)
				tx.Exec("DELETE FROM b WHERE id = ?", from)
				tx.Exec("DELETE FROM b WHERE id = ?", to)
				tx.Exec("INSERT INTO b VALUES (?, ?)", from, fb-10)
				tx.Exec("INSERT INTO b VALUES (?, ?)", to, tb+10)
				tx.Commit()
			}
		}(g)
	}
	wg.Wait()
	rows, _ := db.Query("SELECT bal FROM b")
	var total int64
	cnt := 0
	for rows.Next() {
		var b int64
		rows.Scan(&b)
		total += b
		cnt++
	}
	t.Logf("accounts %d, total %d after 400 concurrent transfers", cnt, total)
	if total != 4000 || cnt != 4 {
		t.Fatal(total, cnt)
	}
}
