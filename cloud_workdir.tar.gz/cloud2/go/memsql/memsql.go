// Package memsql is a tiny in-memory database/sql driver. It understands
//
//	CREATE TABLE t (a, b)
//	INSERT INTO t VALUES (?, ?)
//	SELECT a, b FROM t [WHERE c = ?]
//	DELETE FROM t [WHERE c = ?]
//
// and gives all-or-nothing transactions by copying the database on Begin.
// It exists to show how database/sql talks to a driver, not to be a database.
package memsql

import (
	"database/sql"
	"database/sql/driver"
	"errors"
	"fmt"
	"io"
	"strings"
	"sync"
)

func init() { sql.Register("memsql", &drv{dbs: map[string]*db{}}) }

type table struct {
	cols []string
	rows [][]driver.Value
}

type db struct {
	mu     sync.Mutex
	tables map[string]*table
}

func (d *db) clone() map[string]*table {
	c := map[string]*table{}
	for n, t := range d.tables {
		nt := &table{cols: append([]string{}, t.cols...)}
		for _, r := range t.rows {
			nt.rows = append(nt.rows, append([]driver.Value{}, r...))
		}
		c[n] = nt
	}
	return c
}

type drv struct {
	mu  sync.Mutex
	dbs map[string]*db
}

func (d *drv) Open(name string) (driver.Conn, error) {
	d.mu.Lock()
	defer d.mu.Unlock()
	x, ok := d.dbs[name]
	if !ok {
		x = &db{tables: map[string]*table{}}
		d.dbs[name] = x
	}
	return &conn{db: x}, nil
}

type conn struct {
	db      *db
	inTx    bool
	backup  map[string]*table
	holding bool
}

func (c *conn) Prepare(q string) (driver.Stmt, error) {
	return &stmt{c: c, q: strings.TrimSpace(q)}, nil
}
func (c *conn) Close() error { return nil }
func (c *conn) Begin() (driver.Tx, error) {
	c.db.mu.Lock() // one writer at a time: serialisable by construction
	c.holding = true
	c.inTx = true
	c.backup = c.db.clone()
	return c, nil
}
func (c *conn) Commit() error   { c.end(); return nil }
func (c *conn) Rollback() error { c.db.tables = c.backup; c.end(); return nil }
func (c *conn) end() {
	c.inTx = false
	c.backup = nil
	if c.holding {
		c.holding = false
		c.db.mu.Unlock()
	}
}

type stmt struct {
	c *conn
	q string
}

func (s *stmt) Close() error  { return nil }
func (s *stmt) NumInput() int { return strings.Count(s.q, "?") }

func (s *stmt) lock() func() {
	if s.c.holding {
		return func() {}
	}
	s.c.db.mu.Lock()
	return s.c.db.mu.Unlock
}

func (s *stmt) Exec(args []driver.Value) (driver.Result, error) {
	defer s.lock()()
	f := strings.Fields(s.q)
	up := strings.ToUpper(s.q)
	switch {
	case strings.HasPrefix(up, "CREATE TABLE"):
		name := f[2]
		open := strings.Index(s.q, "(")
		cols := strings.Split(strings.Trim(s.q[open:], "() "), ",")
		for i := range cols {
			cols[i] = strings.TrimSpace(cols[i])
		}
		if _, ok := s.c.db.tables[name]; ok {
			return nil, fmt.Errorf("table %s exists", name)
		}
		s.c.db.tables[name] = &table{cols: cols}
		return driver.RowsAffected(0), nil
	case strings.HasPrefix(up, "INSERT INTO"):
		t, ok := s.c.db.tables[f[2]]
		if !ok {
			return nil, errors.New("no such table")
		}
		if len(args) != len(t.cols) {
			return nil, fmt.Errorf("want %d values, got %d", len(t.cols), len(args))
		}
		t.rows = append(t.rows, append([]driver.Value{}, args...))
		return driver.RowsAffected(1), nil
	case strings.HasPrefix(up, "DELETE FROM"):
		t, ok := s.c.db.tables[f[2]]
		if !ok {
			return nil, errors.New("no such table")
		}
		keep := t.rows[:0]
		var n int64
		for _, r := range t.rows {
			if s.match(t, r, args) {
				n++
			} else {
				keep = append(keep, r)
			}
		}
		t.rows = keep
		return driver.RowsAffected(n), nil
	}
	return nil, errors.New("unsupported statement")
}

func (s *stmt) match(t *table, r []driver.Value, args []driver.Value) bool {
	i := strings.Index(strings.ToUpper(s.q), " WHERE ")
	if i < 0 {
		return true
	}
	cond := strings.Fields(s.q[i+7:]) // col = ?
	for ci, c := range t.cols {
		if c == cond[0] {
			return r[ci] == args[0]
		}
	}
	return false
}

func (s *stmt) Query(args []driver.Value) (driver.Rows, error) {
	defer s.lock()()
	up := strings.ToUpper(s.q)
	fi := strings.Index(up, " FROM ")
	if !strings.HasPrefix(up, "SELECT") || fi < 0 {
		return nil, errors.New("unsupported query")
	}
	sel := strings.Split(strings.TrimSpace(s.q[6:fi]), ",")
	rest := strings.Fields(s.q[fi+6:])
	t, ok := s.c.db.tables[rest[0]]
	if !ok {
		return nil, errors.New("no such table")
	}
	var idx []int
	var names []string
	for _, c := range sel {
		c = strings.TrimSpace(c)
		if c == "*" {
			for i, n := range t.cols {
				idx = append(idx, i)
				names = append(names, n)
			}
			continue
		}
		found := false
		for i, n := range t.cols {
			if n == c {
				idx = append(idx, i)
				names = append(names, n)
				found = true
			}
		}
		if !found {
			return nil, fmt.Errorf("no such column %s", c)
		}
	}
	var out [][]driver.Value
	for _, r := range t.rows {
		if !s.match(t, r, args) {
			continue
		}
		row := make([]driver.Value, len(idx))
		for j, i := range idx {
			row[j] = r[i]
		}
		out = append(out, row)
	}
	return &rows{names: names, data: out}, nil
}

type rows struct {
	names []string
	data  [][]driver.Value
	i     int
}

func (r *rows) Columns() []string { return r.names }
func (r *rows) Close() error      { return nil }
func (r *rows) Next(dest []driver.Value) error {
	if r.i >= len(r.data) {
		return io.EOF
	}
	copy(dest, r.data[r.i])
	r.i++
	return nil
}
