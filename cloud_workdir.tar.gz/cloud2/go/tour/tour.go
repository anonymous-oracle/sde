// Package tour holds the small programs of U23.1: values, slices, maps, errors.
package tour

import (
	"errors"
	"fmt"
	"sort"
	"strings"
)

// WordCount counts words, the Go counterpart of collections.Counter.
func WordCount(text string) map[string]int {
	m := make(map[string]int)
	for _, w := range strings.Fields(strings.ToLower(text)) {
		m[w]++
	}
	return m
}

// TopN returns the n most frequent words, ties broken alphabetically.
func TopN(m map[string]int, n int) []string {
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	sort.Slice(keys, func(i, j int) bool {
		if m[keys[i]] != m[keys[j]] {
			return m[keys[i]] > m[keys[j]]
		}
		return keys[i] < keys[j]
	})
	if n > len(keys) {
		n = len(keys)
	}
	return keys[:n]
}

// ErrNegative is a sentinel error.
var ErrNegative = errors.New("negative input")

// ParseError carries context and wraps a cause.
type ParseError struct {
	Input string
	Err   error
}

func (e *ParseError) Error() string { return fmt.Sprintf("parse %q: %v", e.Input, e.Err) }
func (e *ParseError) Unwrap() error { return e.Err }

// Sqrt returns an integer square root or a wrapped error.
func Sqrt(x int) (int, error) {
	if x < 0 {
		return 0, &ParseError{Input: fmt.Sprint(x), Err: ErrNegative}
	}
	r := 0
	for (r+1)*(r+1) <= x {
		r++
	}
	return r, nil
}

// Append shows slice aliasing: it returns the new slice and whether the
// backing array changed.
func Append(s []int, v int) ([]int, bool) {
	before := cap(s)
	t := append(s, v)
	return t, cap(t) != before
}
