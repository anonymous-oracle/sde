package tour

import (
	"errors"
	"reflect"
	"testing"
)

func TestWordCount(t *testing.T) {
	m := WordCount("the cat The dog the end")
	if m["the"] != 3 {
		t.Fatalf("got %d", m["the"])
	}
	got := TopN(m, 2)
	if !reflect.DeepEqual(got, []string{"the", "cat"}) {
		t.Fatalf("got %v", got)
	}
}

func TestSqrtErrors(t *testing.T) {
	tests := []struct {
		in   int
		want int
		err  error
	}{{0, 0, nil}, {15, 3, nil}, {16, 4, nil}, {-1, 0, ErrNegative}}
	for _, tc := range tests {
		got, err := Sqrt(tc.in)
		if !errors.Is(err, tc.err) || got != tc.want {
			t.Errorf("Sqrt(%d)=%d,%v", tc.in, got, err)
		}
	}
	var pe *ParseError
	_, err := Sqrt(-5)
	if !errors.As(err, &pe) || pe.Input != "-5" {
		t.Fatal("As failed")
	}
}

func TestSliceAliasing(t *testing.T) {
	a := make([]int, 3, 4)
	b, grew := Append(a, 1) // fits: shares the array
	if grew {
		t.Fatal("should not grow")
	}
	c, grew := Append(a, 2) // overwrites b[3]
	if grew || b[3] != 2 || c[3] != 2 {
		t.Fatalf("aliasing expected, b=%v c=%v", b, c)
	}
	d, grew := Append(b, 9) // full: reallocates
	if !grew {
		t.Fatal("should grow")
	}
	d[0] = 77
	if b[0] == 77 {
		t.Fatal("must not alias after growth")
	}
}

func FuzzSqrt(f *testing.F) {
	for _, s := range []int{0, 1, 15, 16, 1 << 20} {
		f.Add(s)
	}
	f.Fuzz(func(t *testing.T, x int) {
		if x > 1<<30 || x < -(1<<30) { // keep the linear search short
			t.Skip()
		}
		r, err := Sqrt(x)
		if x < 0 {
			if err == nil {
				t.Fatal("expected error")
			}
			return
		}
		if err != nil || r*r > x || (r+1)*(r+1) <= x {
			t.Fatalf("Sqrt(%d)=%d,%v", x, r, err)
		}
	})
}
