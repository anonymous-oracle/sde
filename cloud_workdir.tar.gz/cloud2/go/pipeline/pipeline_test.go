package pipeline

import (
	"context"
	"errors"
	"runtime"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

func TestMapOrderAndConcurrencyBound(t *testing.T) {
	in := make([]int, 200)
	for i := range in {
		in[i] = i
	}
	var cur, peak int32
	out, err := Map(context.Background(), in, 8, func(_ context.Context, x int) (int, error) {
		c := atomic.AddInt32(&cur, 1)
		for {
			p := atomic.LoadInt32(&peak)
			if c <= p || atomic.CompareAndSwapInt32(&peak, p, c) {
				break
			}
		}
		time.Sleep(time.Millisecond)
		atomic.AddInt32(&cur, -1)
		return x * x, nil
	})
	if err != nil {
		t.Fatal(err)
	}
	for i, v := range out {
		if v != i*i {
			t.Fatalf("out[%d]=%d", i, v)
		}
	}
	t.Logf("peak concurrency %d (limit 8)", peak)
	if peak > 8 {
		t.Fatal(peak)
	}
}

func TestMapCancelsOnError(t *testing.T) {
	in := make([]int, 1000)
	var started int32
	_, err := Map(context.Background(), in, 4, func(ctx context.Context, x int) (int, error) {
		n := atomic.AddInt32(&started, 1)
		if n == 10 {
			return 0, errors.New("boom")
		}
		select {
		case <-ctx.Done():
		case <-time.After(time.Millisecond):
		}
		return 0, nil
	})
	if err == nil || err.Error() != "boom" {
		t.Fatal(err)
	}
	t.Logf("jobs started before cancellation took effect: %d of 1000", started)
	if started >= 1000 {
		t.Fatal("not cancelled")
	}
}

func TestNoGoroutineLeak(t *testing.T) {
	before := runtime.NumGoroutine()
	Map(context.Background(), make([]int, 50), 5, func(context.Context, int) (int, error) { return 0, nil })
	time.Sleep(20 * time.Millisecond)
	if after := runtime.NumGoroutine(); after > before {
		t.Fatalf("leak: %d -> %d", before, after)
	}
}

func TestSingleflight(t *testing.T) {
	var g Group[int]
	var calls int32
	var wg sync.WaitGroup
	shared := int32(0)
	for i := 0; i < 50; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			_, _, s := g.Do("k", func() (int, error) {
				atomic.AddInt32(&calls, 1)
				time.Sleep(20 * time.Millisecond)
				return 42, nil
			})
			if s {
				atomic.AddInt32(&shared, 1)
			}
		}()
	}
	wg.Wait()
	t.Logf("50 concurrent callers -> %d backend call(s), %d shared", calls, shared)
	if calls != 1 {
		t.Fatal(calls)
	}
}

// A data race the detector must catch is kept out of the build; see the exercise.
