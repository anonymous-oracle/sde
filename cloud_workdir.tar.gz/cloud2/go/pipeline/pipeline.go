// Package pipeline: worker pool, fan-in/fan-out with context cancellation, and a singleflight-style dedupe.
package pipeline

import (
	"context"
	"sync"
)

// Map applies f to every input with at most workers goroutines; results keep input order.
func Map[T, R any](ctx context.Context, in []T, workers int, f func(context.Context, T) (R, error)) ([]R, error) {
	out := make([]R, len(in))
	type job struct{ i int }
	jobs := make(chan job)
	ctx, cancel := context.WithCancel(ctx)
	defer cancel()
	var wg sync.WaitGroup
	var once sync.Once
	var firstErr error
	for w := 0; w < workers; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := range jobs {
				r, err := f(ctx, in[j.i])
				if err != nil {
					once.Do(func() { firstErr = err; cancel() })
					continue
				}
				out[j.i] = r
			}
		}()
	}
loop:
	for i := range in {
		select {
		case jobs <- job{i}:
		case <-ctx.Done():
			break loop
		}
	}
	close(jobs)
	wg.Wait()
	return out, firstErr
}

// Group deduplicates concurrent calls for the same key (the idea of singleflight).
type Group[V any] struct {
	mu    sync.Mutex
	calls map[string]*call[V]
}

type call[V any] struct {
	wg  sync.WaitGroup
	val V
	err error
}

func (g *Group[V]) Do(key string, fn func() (V, error)) (V, error, bool) {
	g.mu.Lock()
	if g.calls == nil {
		g.calls = map[string]*call[V]{}
	}
	if c, ok := g.calls[key]; ok {
		g.mu.Unlock()
		c.wg.Wait()
		return c.val, c.err, true
	}
	c := &call[V]{}
	c.wg.Add(1)
	g.calls[key] = c
	g.mu.Unlock()
	c.val, c.err = fn()
	c.wg.Done()
	g.mu.Lock()
	delete(g.calls, key)
	g.mu.Unlock()
	return c.val, c.err, false
}
