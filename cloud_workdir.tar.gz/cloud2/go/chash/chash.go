// Package chash is a consistent-hash ring with virtual nodes.
package chash

import (
	"hash/fnv"
	"sort"
	"strconv"
)

type Ring struct {
	vnodes int
	hashes []uint32
	owner  map[uint32]string
}

func New(vnodes int) *Ring { return &Ring{vnodes: vnodes, owner: map[uint32]string{}} }

func h(s string) uint32 {
	f := fnv.New32a()
	f.Write([]byte(s))
	// finalise to spread FNV's weak low bits
	x := f.Sum32()
	x ^= x >> 16
	x *= 0x85ebca6b
	x ^= x >> 13
	x *= 0xc2b2ae35
	x ^= x >> 16
	return x
}

func (r *Ring) Add(node string) {
	for i := 0; i < r.vnodes; i++ {
		x := h(node + "#" + strconv.Itoa(i))
		r.owner[x] = node
		r.hashes = append(r.hashes, x)
	}
	sort.Slice(r.hashes, func(i, j int) bool { return r.hashes[i] < r.hashes[j] })
}

func (r *Ring) Remove(node string) {
	keep := r.hashes[:0]
	for _, x := range r.hashes {
		if r.owner[x] == node {
			delete(r.owner, x)
		} else {
			keep = append(keep, x)
		}
	}
	r.hashes = keep
}

func (r *Ring) Get(key string) string {
	x := h(key)
	i := sort.Search(len(r.hashes), func(i int) bool { return r.hashes[i] >= x })
	if i == len(r.hashes) {
		i = 0
	}
	return r.owner[r.hashes[i]]
}
