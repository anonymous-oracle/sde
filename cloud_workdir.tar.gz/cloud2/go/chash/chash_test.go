package chash

import (
	"fmt"
	"math"
	"testing"
)

func assign(r *Ring, n int) map[string]string {
	m := make(map[string]string, n)
	for i := 0; i < n; i++ {
		k := fmt.Sprintf("key-%d", i)
		m[k] = r.Get(k)
	}
	return m
}

// Adding a 11th node moves about 1/11 of the keys; mod-N hashing moves about 10/11.
func TestMovementOnAdd(t *testing.T) {
	r := New(200)
	for i := 0; i < 10; i++ {
		r.Add(fmt.Sprintf("n%d", i))
	}
	const N = 100000
	before := assign(r, N)
	r.Add("n10")
	after := assign(r, N)
	moved := 0
	for k, v := range before {
		if after[k] != v {
			moved++
		}
	}
	frac := float64(moved) / N
	modMoved := 0
	for i := 0; i < N; i++ {
		if int(h(fmt.Sprintf("key-%d", i)))%10 != int(h(fmt.Sprintf("key-%d", i)))%11 {
			modMoved++
		}
	}
	t.Logf("ring moved %.4f (ideal %.4f); mod-N moved %.4f (ideal %.4f)", frac, 1.0/11, float64(modMoved)/N, 10.0/11)
	if math.Abs(frac-1.0/11) > 0.02 {
		t.Fatal(frac)
	}
}

func TestBalanceVsVnodes(t *testing.T) {
	for _, v := range []int{1, 10, 100, 1000} {
		r := New(v)
		for i := 0; i < 10; i++ {
			r.Add(fmt.Sprintf("n%d", i))
		}
		cnt := map[string]int{}
		const N = 100000
		for i := 0; i < N; i++ {
			cnt[r.Get(fmt.Sprintf("k%d", i))]++
		}
		max := 0
		for _, c := range cnt {
			if c > max {
				max = c
			}
		}
		t.Logf("vnodes %4d: max/mean load %.3f", v, float64(max)/(N/10.0))
	}
}
