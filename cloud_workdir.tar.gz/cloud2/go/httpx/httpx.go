// Package httpx: an HTTP service built from the standard library: middleware, a circuit breaker
// for calls to a dependency, and a server with graceful shutdown.
package httpx

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"sync"
	"time"
)

// Chain wraps h with middleware, first listed outermost.
func Chain(h http.Handler, mw ...func(http.Handler) http.Handler) http.Handler {
	for i := len(mw) - 1; i >= 0; i-- {
		h = mw[i](h)
	}
	return h
}

// Timeout cancels the request context after d.
func Timeout(d time.Duration) func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			ctx, cancel := context.WithTimeout(r.Context(), d)
			defer cancel()
			next.ServeHTTP(w, r.WithContext(ctx))
		})
	}
}

// Counter counts requests by status code.
type Counter struct {
	mu sync.Mutex
	By map[int]int
}

type rec struct {
	http.ResponseWriter
	code int
}

func (r *rec) WriteHeader(c int) { r.code = c; r.ResponseWriter.WriteHeader(c) }

func (c *Counter) Middleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		rw := &rec{ResponseWriter: w, code: 200}
		next.ServeHTTP(rw, r)
		c.mu.Lock()
		if c.By == nil {
			c.By = map[int]int{}
		}
		c.By[rw.code]++
		c.mu.Unlock()
	})
}

// Breaker is a closed/open/half-open circuit breaker with an injectable clock.
type Breaker struct {
	mu        sync.Mutex
	maxFails  int
	cooldown  float64
	fails     int
	openUntil float64
	now       func() float64
	Rejected  int
}

var ErrOpen = errors.New("circuit open")

func NewBreaker(maxFails int, cooldown float64, now func() float64) *Breaker {
	return &Breaker{maxFails: maxFails, cooldown: cooldown, now: now}
}

func (b *Breaker) Do(f func() error) error {
	b.mu.Lock()
	t := b.now()
	if b.fails >= b.maxFails && t < b.openUntil {
		b.Rejected++
		b.mu.Unlock()
		return ErrOpen
	}
	b.mu.Unlock() // closed, or half-open: let one probe through
	err := f()
	b.mu.Lock()
	defer b.mu.Unlock()
	if err != nil {
		b.fails++
		if b.fails >= b.maxFails {
			b.openUntil = b.now() + b.cooldown
		}
		return err
	}
	b.fails = 0
	return nil
}

// Serve runs srv until ctx is cancelled, then drains in-flight requests for up to grace.
func Serve(ctx context.Context, srv *http.Server, grace time.Duration, listenErr chan<- error) error {
	errc := make(chan error, 1)
	go func() { errc <- srv.ListenAndServe() }()
	select {
	case err := <-errc:
		return err
	case <-ctx.Done():
	}
	sctx, cancel := context.WithTimeout(context.Background(), grace)
	defer cancel()
	return srv.Shutdown(sctx)
}

type Health struct {
	Status string `json:"status"`
	Uptime int    `json:"uptime_s"`
}

func HealthHandler(start func() int) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(Health{"ok", start()})
	}
}
