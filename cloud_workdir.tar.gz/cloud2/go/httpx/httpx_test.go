package httpx

import (
	"context"
	"encoding/json"
	"errors"
	"net"
	"net/http"
	"net/http/httptest"
	"sync"
	"testing"
	"time"
)

func TestMiddlewareAndHealth(t *testing.T) {
	var c Counter
	mux := http.NewServeMux()
	mux.Handle("/healthz", HealthHandler(func() int { return 42 }))
	mux.HandleFunc("/boom", func(w http.ResponseWriter, r *http.Request) { http.Error(w, "x", 500) })
	ts := httptest.NewServer(Chain(mux, c.Middleware, Timeout(time.Second)))
	defer ts.Close()
	resp, err := http.Get(ts.URL + "/healthz")
	if err != nil {
		t.Fatal(err)
	}
	var h Health
	json.NewDecoder(resp.Body).Decode(&h)
	resp.Body.Close()
	if h.Status != "ok" || h.Uptime != 42 {
		t.Fatal(h)
	}
	http.Get(ts.URL + "/boom")
	http.Get(ts.URL + "/nope")
	c.mu.Lock()
	t.Logf("status counts: %v", c.By)
	if c.By[200] != 1 || c.By[500] != 1 || c.By[404] != 1 {
		t.Fatal(c.By)
	}
	c.mu.Unlock()
}

func TestTimeoutPropagates(t *testing.T) {
	slow := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		select {
		case <-r.Context().Done():
			http.Error(w, "deadline", http.StatusGatewayTimeout)
		case <-time.After(2 * time.Second):
		}
	})
	ts := httptest.NewServer(Timeout(50 * time.Millisecond)(slow))
	defer ts.Close()
	start := time.Now()
	resp, _ := http.Get(ts.URL)
	el := time.Since(start)
	t.Logf("handler cut off after %v with status %d", el.Round(10*time.Millisecond), resp.StatusCode)
	if resp.StatusCode != 504 || el > time.Second {
		t.Fatal(resp.StatusCode, el)
	}
}

func TestBreakerStateMachine(t *testing.T) {
	now := 0.0
	b := NewBreaker(3, 10, func() float64 { return now })
	bad := errors.New("down")
	calls := 0
	dep := func() error { calls++; return bad }
	for i := 0; i < 3; i++ {
		b.Do(dep)
	}
	if err := b.Do(dep); err != ErrOpen {
		t.Fatal("should be open")
	}
	if calls != 3 {
		t.Fatal("dependency must not be called while open", calls)
	}
	now = 11 // cooldown over: half-open, one probe
	if err := b.Do(func() error { calls++; return nil }); err != nil {
		t.Fatal(err)
	}
	if err := b.Do(dep); err != bad { // closed again, failure is passed through
		t.Fatal(err)
	}
	t.Logf("dependency calls %d, rejected while open %d", calls, b.Rejected)
}

// A breaker turns a dead dependency from N slow failures into N-3 instant rejections.
func TestBreakerSavesLatency(t *testing.T) {
	now := 0.0
	b := NewBreaker(3, 1000, func() float64 { return now })
	cost := 0.0 // simulated seconds waiting on the dependency
	for i := 0; i < 100; i++ {
		err := b.Do(func() error { cost += 2.0; return errors.New("timeout") })
		_ = err
	}
	t.Logf("100 requests to a dead dependency: %.0f s waited with breaker (%.0f s without), %d rejected", cost, 200.0, b.Rejected)
	if cost != 6 || b.Rejected != 97 {
		t.Fatal(cost, b.Rejected)
	}
}

func TestGracefulShutdownDrains(t *testing.T) {
	ln, _ := net.Listen("tcp", "127.0.0.1:0")
	started := make(chan struct{})
	var once sync.Once
	srv := &http.Server{Handler: http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		once.Do(func() { close(started) })
		time.Sleep(200 * time.Millisecond)
		w.Write([]byte("done"))
	})}
	go srv.Serve(ln)
	ctx, cancel := context.WithCancel(context.Background())
	result := make(chan string, 1)
	go func() {
		resp, err := http.Get("http://" + ln.Addr().String())
		if err != nil {
			result <- "error: " + err.Error()
			return
		}
		buf := make([]byte, 4)
		resp.Body.Read(buf)
		result <- string(buf)
	}()
	<-started
	cancel()
	_ = ctx
	sctx, c2 := context.WithTimeout(context.Background(), 2*time.Second)
	defer c2()
	if err := srv.Shutdown(sctx); err != nil {
		t.Fatal(err)
	}
	got := <-result
	t.Logf("in-flight request finished during shutdown: %q", got)
	if got != "done" {
		t.Fatal(got)
	}
	if _, err := http.Get("http://" + ln.Addr().String()); err == nil {
		t.Fatal("new connections must be refused after shutdown")
	}
}
