// Command svc is a twelve-factor service: configuration from the environment, structured logs,
// a health endpoint, and graceful shutdown on SIGTERM (what an orchestrator sends before SIGKILL).
package main

import (
	"context"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"cloudcurr/httpx"
)

func main() {
	addr := os.Getenv("ADDR")
	if addr == "" {
		addr = ":8080"
	}
	log := slog.New(slog.NewJSONHandler(os.Stdout, nil))
	start := time.Now()
	mux := http.NewServeMux()
	mux.Handle("/healthz", httpx.HealthHandler(func() int { return int(time.Since(start).Seconds()) }))
	srv := &http.Server{Addr: addr, Handler: httpx.Chain(mux, httpx.Timeout(5*time.Second))}
	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGTERM, syscall.SIGINT)
	defer stop()
	log.Info("listening", "addr", addr)
	if err := httpx.Serve(ctx, srv, 10*time.Second, nil); err != nil && err != http.ErrServerClosed {
		log.Error("server", "err", err)
		os.Exit(1)
	}
	log.Info("shutdown complete")
}
