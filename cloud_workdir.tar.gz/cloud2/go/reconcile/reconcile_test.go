package reconcile

import (
	"context"
	"math/rand"
	"testing"
	"time"
)

func TestConvergesAndIsIdempotent(t *testing.T) {
	c := NewCluster()
	a, err := Reconcile(c, 5)
	if err != nil || a != 5 {
		t.Fatal(a, err)
	}
	a, _ = Reconcile(c, 5)
	if a != 0 {
		t.Fatal("second run must do nothing, did", a)
	}
	ids, _ := c.List()
	c.Crash(ids[1])
	c.Crash(ids[3])
	a, _ = Reconcile(c, 5)
	if a != 2 {
		t.Fatal(a)
	}
	a, _ = Reconcile(c, 3)
	if a != 2 {
		t.Fatal("scale down", a)
	}
	ids, _ = c.List()
	if len(ids) != 3 {
		t.Fatal(ids)
	}
}

// With 30% of API calls failing, repeated reconciliation still converges.
func TestConvergesUnderFaults(t *testing.T) {
	r := rand.New(rand.NewSource(7))
	c := NewCluster()
	c.Fail = func() bool { return r.Float64() < 0.3 }
	rounds := 0
	for {
		rounds++
		Reconcile(c, 20)
		fail := c.Fail
		c.Fail = nil // look without injecting faults
		ids, _ := c.List()
		c.Fail = fail
		if len(ids) == 20 {
			break
		}
		if rounds > 200 {
			t.Fatal("did not converge")
		}
	}
	t.Logf("20 instances reached in %d reconcile rounds with 30%% API failure, %d API calls", rounds, c.Calls)
}

func TestBackoffBounds(t *testing.T) {
	r := rand.New(rand.NewSource(1))
	base, cap := 100*time.Millisecond, 5*time.Second
	for n := 0; n < 12; n++ {
		max := base << uint(n)
		if max > cap {
			max = cap
		}
		var sum time.Duration
		const T = 5000
		for i := 0; i < T; i++ {
			d := Backoff(n, base, cap, r)
			if d < 0 || d > max {
				t.Fatalf("n=%d d=%v max=%v", n, d, max)
			}
			sum += d
		}
		mean := sum / T
		if n == 0 || n == 3 || n == 11 {
			t.Logf("attempt %2d: window %v, mean delay %v (expected %v)", n, max, mean.Round(time.Millisecond), max/2)
		}
	}
}

func TestRetry(t *testing.T) {
	r := rand.New(rand.NewSource(2))
	fails := 3
	var slept time.Duration
	tries, err := Retry(context.Background(), 6, 10*time.Millisecond, time.Second, r,
		func(d time.Duration) { slept += d },
		func() error {
			if fails > 0 {
				fails--
				return ErrTransient
			}
			return nil
		})
	if err != nil || tries != 4 {
		t.Fatal(tries, err)
	}
	tries, err = Retry(context.Background(), 3, time.Millisecond, time.Second, r, func(time.Duration) {},
		func() error { return ErrTransient })
	if err != ErrTransient || tries != 3 {
		t.Fatal(tries, err)
	}
}

func TestLeaseFencing(t *testing.T) {
	var l Lease
	e1, ok := l.Acquire("A", 0, 10)
	if !ok || e1 != 1 {
		t.Fatal()
	}
	if _, ok := l.Acquire("B", 5, 10); ok {
		t.Fatal("B must not steal a live lease")
	}
	if e, ok := l.Acquire("A", 8, 10); !ok || e != 1 {
		t.Fatal("renew keeps epoch")
	}
	e2, ok := l.Acquire("B", 20, 10) // A stalled past its expiry
	if !ok || e2 != 2 {
		t.Fatal(e2, ok)
	}
	// A wakes up and tries to renew with its old epoch: the store sees epoch 2 and must refuse A.
	if _, ok := l.Acquire("A", 21, 10); ok {
		t.Fatal("old leader must lose")
	}
	t.Logf("old leader epoch %d is fenced by new epoch %d", e1, e2)
}
