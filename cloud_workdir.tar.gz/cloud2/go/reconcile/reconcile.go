// Package reconcile is the control loop at the heart of Kubernetes-style systems: compare desired
// state with observed state and issue the smallest actions that close the gap, repeatedly.
// It also holds retry with exponential backoff and jitter and a lease-based leader election.
package reconcile

import (
	"context"
	"errors"
	"math/rand"
	"sort"
	"sync"
	"time"
)

// Cluster is a fake infrastructure API: instances can be created, deleted, and can crash.
type Cluster struct {
	mu        sync.Mutex
	instances map[string]bool
	next      int
	Fail      func() bool // optional fault injector for API calls
	Calls     int
}

func NewCluster() *Cluster { return &Cluster{instances: map[string]bool{}} }

var ErrTransient = errors.New("transient API failure")

func (c *Cluster) call() error {
	c.Calls++
	if c.Fail != nil && c.Fail() {
		return ErrTransient
	}
	return nil
}

func (c *Cluster) List() ([]string, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if err := c.call(); err != nil {
		return nil, err
	}
	var out []string
	for k := range c.instances {
		out = append(out, k)
	}
	sort.Strings(out)
	return out, nil
}

func (c *Cluster) Create() (string, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if err := c.call(); err != nil {
		return "", err
	}
	c.next++
	id := "i-" + itoa(c.next)
	c.instances[id] = true
	return id, nil
}

func (c *Cluster) Delete(id string) error {
	c.mu.Lock()
	defer c.mu.Unlock()
	if err := c.call(); err != nil {
		return err
	}
	delete(c.instances, id)
	return nil
}

// Crash removes an instance behind the controller's back.
func (c *Cluster) Crash(id string) { c.mu.Lock(); delete(c.instances, id); c.mu.Unlock() }

func itoa(n int) string {
	if n == 0 {
		return "0"
	}
	s := ""
	for n > 0 {
		s = string(rune('0'+n%10)) + s
		n /= 10
	}
	return s
}

// Reconcile makes observed match desired; it is level-triggered and idempotent: running it twice
// in a row does nothing the second time. It returns the number of actions taken.
func Reconcile(c *Cluster, desired int) (int, error) {
	have, err := c.List()
	if err != nil {
		return 0, err
	}
	actions := 0
	for len(have)+actions < desired {
		if _, err := c.Create(); err != nil {
			return actions, err
		}
		actions++
	}
	for i := len(have) - 1; i >= desired; i-- {
		if err := c.Delete(have[i]); err != nil {
			return actions, err
		}
		actions++
	}
	return actions, nil
}

// Backoff returns the full-jitter delay for attempt n: uniform in [0, min(cap, base*2^n)].
func Backoff(n int, base, cap time.Duration, r *rand.Rand) time.Duration {
	d := base << uint(n)
	if d > cap || d <= 0 {
		d = cap
	}
	return time.Duration(r.Int63n(int64(d) + 1))
}

// Retry calls f until it succeeds, a non-transient error occurs, or attempts run out.
// sleep is injected so tests do not wait.
func Retry(ctx context.Context, attempts int, base, cap time.Duration, r *rand.Rand, sleep func(time.Duration), f func() error) (tries int, err error) {
	for n := 0; n < attempts; n++ {
		tries++
		err = f()
		if err == nil || !errors.Is(err, ErrTransient) {
			return
		}
		if ctx.Err() != nil {
			return tries, ctx.Err()
		}
		sleep(Backoff(n, base, cap, r))
	}
	return
}

// Lease is a time-limited lock held in a shared store; a leader must renew before it expires.
type Lease struct {
	mu      sync.Mutex
	holder  string
	expires float64
	Epoch   int // fencing token, increases on every new holder
}

// Acquire grants the lease to who if it is free, expired, or already held by who.
func (l *Lease) Acquire(who string, now, ttl float64) (epoch int, ok bool) {
	l.mu.Lock()
	defer l.mu.Unlock()
	if l.holder == who && now < l.expires {
		l.expires = now + ttl
		return l.Epoch, true
	}
	if l.holder == "" || now >= l.expires {
		l.holder = who
		l.expires = now + ttl
		l.Epoch++
		return l.Epoch, true
	}
	return 0, false
}
