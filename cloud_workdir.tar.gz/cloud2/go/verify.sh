#!/bin/sh
# Runs every Go reference program: format, vet, race-enabled tests with the measured numbers, benchmarks.
cd "$(dirname "$0")" || exit 1
test -z "$(gofmt -l .)" || { echo "gofmt differences"; exit 1; }
go vet ./... && go vet -tags racedemo ./racedemo || exit 1
go test -race -count=1 -v ./... 2>&1 | grep -E "^(--- |ok|FAIL|\s+\S+_test.go)"
echo "--- race demo (must report a data race)"
go test -race -count=1 -tags racedemo ./racedemo 2>&1 | grep -c "WARNING: DATA RACE"
echo "--- benchmarks"
go test -run XXX -bench . -benchmem ./lru ./kv | grep Benchmark
CGO_ENABLED=0 go build -trimpath -ldflags="-s -w" -o /tmp/svc ./cmd/svc && echo "svc binary bytes: $(wc -c < /tmp/svc)"
