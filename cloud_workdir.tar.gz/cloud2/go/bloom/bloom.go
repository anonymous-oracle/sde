// Package bloom is a Bloom filter using double hashing.
package bloom

import (
	"hash/fnv"
	"math"
)

type Filter struct {
	bits []uint64
	m    uint
	k    uint
}

// New sizes a filter for n items at target false-positive rate p.
func New(n int, p float64) *Filter {
	m := uint(math.Ceil(-float64(n) * math.Log(p) / (math.Ln2 * math.Ln2)))
	k := uint(math.Round(float64(m) / float64(n) * math.Ln2))
	return &Filter{bits: make([]uint64, (m+63)/64), m: m, k: k}
}

func (f *Filter) M() uint { return f.m }
func (f *Filter) K() uint { return f.k }

func hashes(s string) (uint64, uint64) {
	a := fnv.New64a()
	a.Write([]byte(s))
	h1 := a.Sum64()
	b := fnv.New64()
	b.Write([]byte(s))
	h2 := b.Sum64() | 1
	return h1, h2
}

func (f *Filter) Add(s string) {
	h1, h2 := hashes(s)
	for i := uint(0); i < f.k; i++ {
		x := uint((h1 + uint64(i)*h2) % uint64(f.m))
		f.bits[x/64] |= 1 << (x % 64)
	}
}

func (f *Filter) Has(s string) bool {
	h1, h2 := hashes(s)
	for i := uint(0); i < f.k; i++ {
		x := uint((h1 + uint64(i)*h2) % uint64(f.m))
		if f.bits[x/64]&(1<<(x%64)) == 0 {
			return false
		}
	}
	return true
}
