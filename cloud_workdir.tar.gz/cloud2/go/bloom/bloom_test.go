package bloom

import (
	"fmt"
	"testing"
)

func TestNoFalseNegativesAndFPR(t *testing.T) {
	const n = 100000
	f := New(n, 0.01)
	for i := 0; i < n; i++ {
		f.Add(fmt.Sprintf("in-%d", i))
	}
	for i := 0; i < n; i++ {
		if !f.Has(fmt.Sprintf("in-%d", i)) {
			t.Fatal("false negative")
		}
	}
	fp := 0
	const q = 200000
	for i := 0; i < q; i++ {
		if f.Has(fmt.Sprintf("out-%d", i)) {
			fp++
		}
	}
	rate := float64(fp) / q
	t.Logf("m=%d bits (%.2f bits/item) k=%d, false-positive rate %.4f (target 0.01)", f.M(), float64(f.M())/n, f.K(), rate)
	if rate > 0.014 || rate < 0.006 {
		t.Fatal(rate)
	}
}
