// Package lru is a generic LRU cache built on container/list.
package lru

import "container/list"

type entry[K comparable, V any] struct {
	key K
	val V
}

// Cache is not safe for concurrent use; wrap it with a mutex (see SafeCache).
type Cache[K comparable, V any] struct {
	cap          int
	ll           *list.List
	items        map[K]*list.Element
	Hits, Misses int
}

func New[K comparable, V any](capacity int) *Cache[K, V] {
	return &Cache[K, V]{cap: capacity, ll: list.New(), items: make(map[K]*list.Element)}
}

func (c *Cache[K, V]) Get(k K) (V, bool) {
	if e, ok := c.items[k]; ok {
		c.ll.MoveToFront(e)
		c.Hits++
		return e.Value.(*entry[K, V]).val, true
	}
	c.Misses++
	var zero V
	return zero, false
}

func (c *Cache[K, V]) Put(k K, v V) {
	if e, ok := c.items[k]; ok {
		e.Value.(*entry[K, V]).val = v
		c.ll.MoveToFront(e)
		return
	}
	c.items[k] = c.ll.PushFront(&entry[K, V]{k, v})
	if c.ll.Len() > c.cap {
		last := c.ll.Back()
		c.ll.Remove(last)
		delete(c.items, last.Value.(*entry[K, V]).key)
	}
}

func (c *Cache[K, V]) Len() int { return c.ll.Len() }
