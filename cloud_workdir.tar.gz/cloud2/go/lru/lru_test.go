package lru

import (
	"math"
	"math/rand"
	"testing"
)

func TestEviction(t *testing.T) {
	c := New[string, int](2)
	c.Put("a", 1)
	c.Put("b", 2)
	c.Get("a")
	c.Put("c", 3) // evicts b
	if _, ok := c.Get("b"); ok {
		t.Fatal("b should be evicted")
	}
	if v, ok := c.Get("a"); !ok || v != 1 {
		t.Fatal("a should remain")
	}
	if c.Len() != 2 {
		t.Fatal("len")
	}
}

// Under independent uniform requests over N keys a cache of size C hits with probability C/N.
func TestHitRatioUniform(t *testing.T) {
	const N, C, R = 1000, 100, 400000
	r := rand.New(rand.NewSource(1))
	c := New[int, int](C)
	for i := 0; i < R; i++ {
		k := r.Intn(N)
		if _, ok := c.Get(k); !ok {
			c.Put(k, k)
		}
	}
	h := float64(c.Hits) / float64(R)
	t.Logf("uniform hit ratio %.4f (theory %.4f)", h, float64(C)/N)
	if math.Abs(h-0.1) > 0.01 {
		t.Fatal(h)
	}
}

// Zipf-skewed requests give a much higher hit ratio for the same cache.
func TestHitRatioZipf(t *testing.T) {
	const N, C, R = 1000, 100, 400000
	r := rand.New(rand.NewSource(1))
	z := rand.NewZipf(r, 1.2, 1, N-1)
	c := New[uint64, int](C)
	for i := 0; i < R; i++ {
		k := z.Uint64()
		if _, ok := c.Get(k); !ok {
			c.Put(k, 0)
		}
	}
	h := float64(c.Hits) / float64(R)
	t.Logf("zipf hit ratio %.4f", h)
	if h < 0.6 {
		t.Fatal(h)
	}
}

func BenchmarkGetHit(b *testing.B) {
	c := New[int, int](1000)
	for i := 0; i < 1000; i++ {
		c.Put(i, i)
	}
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		c.Get(i % 1000)
	}
}

func BenchmarkPutEvict(b *testing.B) {
	c := New[int, int](1000)
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		c.Put(i, i)
	}
}
