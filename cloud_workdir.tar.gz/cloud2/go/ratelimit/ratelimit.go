// Package ratelimit: token bucket and sliding-window-log limiters with an injectable clock.
package ratelimit

import "sync"

// Clock returns seconds as a float so tests control time.
type Clock func() float64

type TokenBucket struct {
	mu       sync.Mutex
	rate     float64 // tokens per second
	capacity float64
	tokens   float64
	last     float64
	now      Clock
}

func NewTokenBucket(rate, capacity float64, now Clock) *TokenBucket {
	return &TokenBucket{rate: rate, capacity: capacity, tokens: capacity, last: now(), now: now}
}

func (b *TokenBucket) Allow() bool {
	b.mu.Lock()
	defer b.mu.Unlock()
	t := b.now()
	b.tokens += (t - b.last) * b.rate
	if b.tokens > b.capacity {
		b.tokens = b.capacity
	}
	b.last = t
	if b.tokens >= 1 {
		b.tokens--
		return true
	}
	return false
}

type SlidingLog struct {
	mu     sync.Mutex
	limit  int
	window float64
	log    []float64
	now    Clock
}

func NewSlidingLog(limit int, window float64, now Clock) *SlidingLog {
	return &SlidingLog{limit: limit, window: window, now: now}
}

func (s *SlidingLog) Allow() bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	t := s.now()
	i := 0
	for i < len(s.log) && s.log[i] <= t-s.window {
		i++
	}
	s.log = s.log[i:]
	if len(s.log) < s.limit {
		s.log = append(s.log, t)
		return true
	}
	return false
}
