package ratelimit

import "testing"

func TestTokenBucketBurstAndRate(t *testing.T) {
	now := 0.0
	b := NewTokenBucket(10, 5, func() float64 { return now })
	ok := 0
	for i := 0; i < 20; i++ { // instantaneous burst
		if b.Allow() {
			ok++
		}
	}
	if ok != 5 {
		t.Fatalf("burst allowed %d, want capacity 5", ok)
	}
	// Offer 100 requests/s for 10 s: admitted ≈ rate*time + burst.
	ok = 0
	for i := 0; i < 1000; i++ {
		now += 0.01
		if b.Allow() {
			ok++
		}
	}
	t.Logf("admitted over 10 s at 100 rps offered: %d", ok)
	if ok < 99 || ok > 105 {
		t.Fatal(ok)
	}
}

func TestSlidingLogBoundary(t *testing.T) {
	now := 0.0
	s := NewSlidingLog(3, 1, func() float64 { return now })
	got := []bool{}
	for _, at := range []float64{0, 0.125, 0.25, 0.375, 1.0, 1.125, 1.25, 1.375} {
		now = at
		got = append(got, s.Allow())
	}
	want := []bool{true, true, true, false, true, true, true, false}
	for i := range want {
		if got[i] != want[i] {
			t.Fatalf("got %v want %v", got, want)
		}
	}
}

// A fixed window lets 2x the limit through across a boundary; the log does not.
func TestFixedWindowBoundaryBurst(t *testing.T) {
	limit, window := 5, 1.0
	count := map[int]int{}
	adm := 0
	times := []float64{}
	for i := 0; i < 5; i++ {
		times = append(times, 0.9+0.001*float64(i))
	}
	for i := 0; i < 5; i++ {
		times = append(times, 1.0+0.001*float64(i))
	}
	for _, t := range times {
		w := int(t / window)
		if count[w] < limit {
			count[w]++
			adm++
		}
	}
	if adm != 10 {
		t.Fatal(adm)
	}
	now := 0.0
	s := NewSlidingLog(limit, window, func() float64 { return now })
	adm = 0
	for _, tt := range times {
		now = tt
		if s.Allow() {
			adm++
		}
	}
	if adm != 5 {
		t.Fatal(adm)
	}
}
