package kv

import (
	"fmt"
	"math/rand"
	"os"
	"path/filepath"
	"sync"
	"testing"
)

func TestRecoveryAfterReopen(t *testing.T) {
	p := filepath.Join(t.TempDir(), "wal")
	s, _ := Open(p)
	for i := 0; i < 1000; i++ {
		s.Put(fmt.Sprint("k", i), []byte(fmt.Sprint("v", i)))
	}
	s.Delete("k5")
	s.Close()
	s, err := Open(p)
	if err != nil {
		t.Fatal(err)
	}
	if s.Len() != 999 {
		t.Fatal(s.Len())
	}
	if _, err := s.Get("k5"); err != ErrNotFound {
		t.Fatal("deleted key present")
	}
	if v, _ := s.Get("k999"); string(v) != "v999" {
		t.Fatal(string(v))
	}
}

// Truncate the log at every byte offset: recovery must always yield a prefix of the operations.
func TestTornWriteEveryOffset(t *testing.T) {
	dir := t.TempDir()
	p := filepath.Join(dir, "wal")
	s, _ := Open(p)
	const n = 30
	for i := 0; i < n; i++ {
		s.Put(fmt.Sprint("k", i), []byte(fmt.Sprint("value-", i)))
	}
	s.Close()
	full, _ := os.ReadFile(p)
	checked, bad := 0, 0
	for cut := 0; cut <= len(full); cut++ {
		q := filepath.Join(dir, "cut")
		os.WriteFile(q, full[:cut], 0o644)
		r, err := Open(q)
		if err != nil {
			t.Fatal(err)
		}
		m := r.Len()
		for i := 0; i < m; i++ { // must be exactly the first m keys
			if v, err := r.Get(fmt.Sprint("k", i)); err != nil || string(v) != fmt.Sprint("value-", i) {
				bad++
			}
		}
		if m > n {
			bad++
		}
		r.Close()
		checked++
	}
	t.Logf("truncation offsets tested: %d, recoveries that were not a prefix: %d", checked, bad)
	if bad != 0 {
		t.Fatal(bad)
	}
}

func TestBitFlipDetected(t *testing.T) {
	dir := t.TempDir()
	p := filepath.Join(dir, "wal")
	s, _ := Open(p)
	for i := 0; i < 20; i++ {
		s.Put(fmt.Sprint("k", i), []byte("x"))
	}
	s.Close()
	full, _ := os.ReadFile(p)
	rng := rand.New(rand.NewSource(3))
	undetected := 0
	for trial := 0; trial < 500; trial++ {
		b := append([]byte{}, full...)
		pos := rng.Intn(len(b))
		b[pos] ^= 1 << uint(rng.Intn(8))
		q := filepath.Join(dir, "flip")
		os.WriteFile(q, b, 0o644)
		r, _ := Open(q)
		// a flipped bit must never produce a different value for a surviving key
		for i := 0; i < r.Len(); i++ {
			if v, err := r.Get(fmt.Sprint("k", i)); err == nil && string(v) != "x" {
				undetected++
			}
		}
		r.Close()
	}
	t.Logf("500 single-bit flips, undetected corruptions: %d", undetected)
	if undetected != 0 {
		t.Fatal(undetected)
	}
}

func TestConcurrentWriters(t *testing.T) {
	p := filepath.Join(t.TempDir(), "wal")
	s, _ := Open(p)
	var wg sync.WaitGroup
	for g := 0; g < 8; g++ {
		wg.Add(1)
		go func(g int) {
			defer wg.Done()
			for i := 0; i < 200; i++ {
				s.Put(fmt.Sprint("g", g, "-", i), []byte("v"))
				s.Get(fmt.Sprint("g", g, "-", i))
			}
		}(g)
	}
	wg.Wait()
	s.Close()
	s, _ = Open(p)
	if s.Len() != 1600 {
		t.Fatal(s.Len())
	}
}

func BenchmarkPutNoSync(b *testing.B) {
	s, _ := Open(filepath.Join(b.TempDir(), "wal"))
	v := make([]byte, 100)
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		s.Put(fmt.Sprint("k", i%1000), v)
	}
}

func BenchmarkPutFsync(b *testing.B) {
	s, _ := Open(filepath.Join(b.TempDir(), "wal"))
	s.Sync = true
	v := make([]byte, 100)
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		s.Put(fmt.Sprint("k", i%1000), v)
	}
}
