// Package kv is a small durable key-value store: a write-ahead log, an in-memory table and
// crash recovery by replay, with checksummed records.
package kv

import (
	"bufio"
	"encoding/binary"
	"errors"
	"hash/crc32"
	"io"
	"os"
	"sync"
)

const (
	opPut byte = 1
	opDel byte = 2
)

type Store struct {
	mu   sync.RWMutex
	f    *os.File
	data map[string][]byte
	Sync bool // fsync every write if true
}

// Open replays the log, stopping at the first torn or corrupt record and truncating there.
func Open(path string) (*Store, error) {
	f, err := os.OpenFile(path, os.O_RDWR|os.O_CREATE, 0o644)
	if err != nil {
		return nil, err
	}
	s := &Store{f: f, data: map[string][]byte{}}
	good, err := s.replay()
	if err != nil {
		f.Close()
		return nil, err
	}
	if err := f.Truncate(good); err != nil {
		f.Close()
		return nil, err
	}
	if _, err := f.Seek(good, io.SeekStart); err != nil {
		f.Close()
		return nil, err
	}
	return s, nil
}

// record = crc32 (4) | op (1) | klen (4) | vlen (4) | key | value
func encode(op byte, k string, v []byte) []byte {
	b := make([]byte, 13+len(k)+len(v))
	b[4] = op
	binary.LittleEndian.PutUint32(b[5:], uint32(len(k)))
	binary.LittleEndian.PutUint32(b[9:], uint32(len(v)))
	copy(b[13:], k)
	copy(b[13+len(k):], v)
	binary.LittleEndian.PutUint32(b[0:], crc32.ChecksumIEEE(b[4:]))
	return b
}

func (s *Store) replay() (int64, error) {
	r := bufio.NewReader(s.f)
	var off int64
	for {
		hdr := make([]byte, 13)
		if _, err := io.ReadFull(r, hdr); err != nil {
			return off, nil // clean end or torn header
		}
		kl := binary.LittleEndian.Uint32(hdr[5:])
		vl := binary.LittleEndian.Uint32(hdr[9:])
		if kl > 1<<20 || vl > 1<<26 {
			return off, nil
		}
		body := make([]byte, kl+vl)
		if _, err := io.ReadFull(r, body); err != nil {
			return off, nil // torn body
		}
		rec := append(append([]byte{}, hdr...), body...)
		if crc32.ChecksumIEEE(rec[4:]) != binary.LittleEndian.Uint32(hdr[0:]) {
			return off, nil // corrupt
		}
		k := string(body[:kl])
		switch hdr[4] {
		case opPut:
			s.data[k] = append([]byte{}, body[kl:]...)
		case opDel:
			delete(s.data, k)
		default:
			return off, nil
		}
		off += int64(len(rec))
	}
}

func (s *Store) write(b []byte) error {
	if _, err := s.f.Write(b); err != nil {
		return err
	}
	if s.Sync {
		return s.f.Sync()
	}
	return nil
}

func (s *Store) Put(k string, v []byte) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if err := s.write(encode(opPut, k, v)); err != nil {
		return err
	}
	s.data[k] = append([]byte{}, v...)
	return nil
}

func (s *Store) Delete(k string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if err := s.write(encode(opDel, k, nil)); err != nil {
		return err
	}
	delete(s.data, k)
	return nil
}

var ErrNotFound = errors.New("not found")

func (s *Store) Get(k string) ([]byte, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	v, ok := s.data[k]
	if !ok {
		return nil, ErrNotFound
	}
	return append([]byte{}, v...), nil
}

func (s *Store) Len() int { s.mu.RLock(); defer s.mu.RUnlock(); return len(s.data) }

func (s *Store) Close() error { return s.f.Close() }
