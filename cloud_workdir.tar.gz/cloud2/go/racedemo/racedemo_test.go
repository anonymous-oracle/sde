//go:build racedemo

package racedemo

import (
	"sync"
	"testing"
)

// Run with: go test -race -tags racedemo ./racedemo   (it must FAIL with "DATA RACE")
func TestUnsafeCounter(t *testing.T) {
	n := 0
	var wg sync.WaitGroup
	for i := 0; i < 8; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := 0; j < 1000; j++ {
				n++ // unsynchronised read-modify-write
			}
		}()
	}
	wg.Wait()
	t.Log("n =", n)
}
