// Package racedemo keeps a deliberate data race behind a build tag for the race-detector exercise.
package racedemo
