"""Cell table for dbms.txt (3 database-systems course outlines), read from the cleaned copy src3.txt.
src3.txt differs from dbms.txt only where the PDF text layer of the 'Database Design' outline was letter-spaced
(raw lines 188-768): that stretch was re-joined by hand into words (see mk_src3 in PROGRESS.md and Appendix E)."""
SRC = open('/home/claude/work/cloud2/src3.txt').read().split('\n')
def R(a, b=None): return list(range(a, (b or a) + 1))
COURSES = {}
def course(key, title, who, cells, pre=None, books=None, note=''):
    COURSES[key] = dict(title=title, who=who, cells=cells, pre=pre or [], books=books or [], note=note)
# Fundamentals of Database Systems: the outline is a list of 48 numbered lectures; the cell W<n> is lecture n.
_L = {1: R(15, 16), 2: R(17), 3: R(18, 19), 4: R(20, 21), 5: R(22, 23), 6: R(24), 7: R(25), 8: R(26), 9: R(40), 10: R(41),
      11: R(42), 12: R(43), 13: R(44, 45), 14: R(46, 48), 15: R(49, 50), 16: R(51, 52), 17: R(53, 54), 18: R(55, 57),
      19: R(58, 59), 20: R(60, 61), 21: R(62, 63), 22: R(64, 65), 23: R(66, 67), 24: R(68, 69), 25: R(70, 71),
      26: R(72, 74), 27: R(75, 76), 28: R(77, 78), 29: R(79, 80), 30: R(81, 82), 31: R(83, 84), 32: R(85, 86),
      33: R(87, 88), 34: R(89, 90), 35: R(91, 92), 36: R(93, 94), 37: R(95, 96), 38: R(97, 98), 39: R(99, 100),
      40: R(101, 103), 41: R(104, 106), 42: R(107, 109), 43: R(110, 112), 44: R(113, 114), 45: R(115, 116),
      46: R(117, 118), 47: R(119, 120), 48: R(121, 122)}
course('FDB', 'Fundamentals of Database Systems (NOC)', 'Arnab Bhattacharya, IIT Kanpur (sponsored by Aricent); lecture n is cell Wn',
       {'o': R(1, 12), **{f'W{i}': v for i, v in _L.items()}}, pre=R(32, 34),
       note='48 numbered lectures, 4 of them recaps (13, 22, 32, 48); lectures 29 and 30 share a title; lecture 41 is split over two lines and its second line repeats the number')
course('DBD', 'Database Design', 'S. Srinath, IIIT Bangalore and D. Janaki Ram, IIT Madras; module n is cell Wn',
       {'o': R(125, 127), 'W1': R(128, 130), 'W2': R(131, 135), 'W3': R(136, 145), 'W4': R(146, 152), 'W5': R(153, 161),
        'W6': R(162, 176) + [188], 'W7': R(189, 190), 'W8': R(191, 192), 'W9': R(193, 194), 'W10': R(195, 196),
        'W11': R(197, 199)}, books=R(200),
       note='11 modules by sessions; the PDF text layer of modules 7-11 was letter-spaced and has been re-joined')
course('IDB', 'Introduction to Database Systems', 'Sreenivasa Kumar, IIT Madras',
       {'o': R(202, 205) + R(209, 215), **{f'W{i}': R(215 + i) for i in range(1, 13)}}, pre=R(206, 208))
def cell_text(k, c): return ' '.join(SRC[i - 1].strip() for i in COURSES[k]['cells'][c])
if __name__ == '__main__':
    n = 0
    for k, c in COURSES.items():
        for cid in c['cells']:
            n += 1; print(f"{k}:{cid:4s} {cell_text(k, cid)[:100]}")
    print('cells', n)
