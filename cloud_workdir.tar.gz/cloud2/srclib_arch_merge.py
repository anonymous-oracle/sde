# Append this block to the end of srclib.py to join the architecture source (tested).
import srclib_arch as _A
_OFF = len(SRC)                       # 630 (629 lines plus the empty string after the final newline; the shift is consistent)
SRC.extend(_A.SRC)
for _k, _c in _A.COURSES.items():
    _cells = {cid: [i + _OFF for i in ls] for cid, ls in _c['cells'].items()}
    COURSES[_k] = dict(_c, cells=_cells, pre=[i + _OFF for i in _c['pre']],
                       books=[i + _OFF for i in _c['books']], inline=None,
                       file='cloud-computing2.txt', off=_OFF)
