#!/usr/bin/env python3
import sys, glob
sys.path.insert(0, '/home/claude/work/cloud2')
import srclib as S, build as B, asg_lib
units, domains, _ = B.load_units(sorted(glob.glob('/home/claude/work/cloud2/units/*.md')))
ORDER = ['D%d' % i for i in range(1, 10)] + ['D15', 'D10', 'D21', 'D17', 'D18', 'D19', 'D11', 'D20', 'D12', 'D16', 'D14', 'D13']
domains.sort(key=lambda d: ORDER.index(d['id']))
nb = sum(1 for u in units if u.lines and u.lines[0].startswith('Bridge for'))
ncap = sum(1 for u in units if u.uid.startswith('U13.'))
nasg = len(asg_lib.load())
ncell = sum(len(S.cell_ids(k)) for k in S.COURSES)
out = ["# Unified Cloud Curriculum: index", "",
 f"Index of `unified_cloud_curriculum.md` (built 2026-11-05 UTC from `cloud-computing.txt`, 13 NPTEL outlines: GCF, CN, ACN, PCS, CSP, EH, CNS, TPMC, FOC, ADS, CCDS, DS, BDC; `cloud-computing2.txt`, 6 computer-architecture outlines: MCA, CAO, CA, ACA, PCA, GPU; `dbms.txt`, 3 database courses: FDB, DBD, IDB; the System Design Primer, the python-patterns collection and the Gang of Four catalogue: SDP, PYP, GOF; and `data-analytics.txt`, 8 new outlines: DAP, AGDS, SDS, DBMS, BDA, ALA, DM, DSAD, the ninth, BDC, being a duplicate), all added 2026-11-06. {len(domains)} domains, {len(units)} units, {nasg} assignments (A<d>.<n>, five questions, key collapsed), {nb} prerequisite bridges, {ncap} capstones. All {ncell} source cells from {len(S.COURSES)} courses are cited. D15 (database systems) is printed between D9 and D10; D21, D17, D18 and D19 (data science foundations) between D10 and D11; D20 after D11; D16 (software and system design) after D12; D14 is printed before the capstones (D13), which stay together at the end. Separate from `unified_curriculum.md`; a merge is an open decision (Appendix D of the file).",
 "", "Bridge units are marked (bridge). Capstones carry no assignment.", ""]
for d in domains:
    out.append(f"## {d['id']}. {d['title']}"); out.append("")
    for u in d['units']:
        tag = ' (bridge)' if u.lines and u.lines[0].startswith('Bridge for') else (' (capstone)' if u.uid.startswith('U13.') else '')
        out.append(f"- {u.uid} {u.title}{tag}")
    out.append("")
open(sys.argv[1], 'w').write('\n'.join(out))
print(len(domains), len(units), nasg, nb, ncap, ncell, len(S.COURSES))
