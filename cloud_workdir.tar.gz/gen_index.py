#!/usr/bin/env python3
"""usage: gen_index.py INDEX_CLOUD.md INDEX_ML.md"""
import sys, glob, json, os, re
sys.path.insert(0, '/home/claude/work/cloud2'); sys.path.insert(0, '/home/claude/work/ml')
import srclib as S, build as B, asg_lib, mlload, assemble_ml as AM
from idmap import remap, dnew
units, domains, _ = B.load_units(sorted(glob.glob('/home/claude/work/cloud2/units/*.md')))
mu, mdoms = mlload.load_ml()
led = json.load(open('/home/claude/work/cloud2/merge_ledger.json'))
OLD = {new: info['old'] for new, info in led['units'].items()}
ALL = units + mu
for d in mdoms:
    if d['id'] == 'D13+':
        d13 = next(x for x in domains if x['id'] == 'D13'); d13['units'] = d13['units'] + d['units']
    else:
        domains.append(d)
ORDER = ['D%d' % i for i in range(1, 10)] + ['D15', 'D10', 'D21', 'D17', 'D23', 'D18', 'D19', 'D11', 'D20', 'D12', 'D22', 'D16', 'D14'] + ['D%d' % i for i in range(24, 42)] + ['D13']
domains.sort(key=lambda d: ORDER.index(d['id']))
nb = sum(1 for u in ALL if u.lines and u.lines[0].startswith('Bridge for'))
ncap = sum(1 for u in ALL if u.uid.startswith('U13.'))
nasg = len(asg_lib.load()) + len(glob.glob('/home/claude/work/cloud2/assign_ml/*.md'))
ncell = sum(len(S.cell_ids(k)) for k in S.COURSES) + sum(len(set(u.ml_src)) for u in [])  # cloud cells; Part G cells below
mcells = len({c for u in mu for c in u.ml_src})
ncourse = len(S.COURSES) + len(AM.mlsrc.COURSES)
PART = {'D1': 'Part A. Foundations: the cloud, networks and cloud compute', 'D5': 'Part B. Cryptography, security, risk and privacy', 'D9': 'Part C. Distributed systems, storage and databases',
        'D21': 'Part D. Data science foundations', 'D11': 'Part E. Big data, cloud operations, machine learning and system design', 'D14': 'Part F. Computer architecture and parallel hardware',
        'D24': 'Part G. Mathematics and machine learning, entered on demand (merged from the earlier machine-learning curriculum)', 'D13': 'Part H. Capstones'}
out = ["# Unified Cloud Curriculum: index (merged with the machine-learning curriculum)", "",
 f"Index of `unified_cloud_curriculum.md`, the primary curriculum. Built from the cloud sources (`cloud-computing.txt`, `cloud-computing2.txt`, `dbms.txt`, the System Design Primer, python-patterns and the Gang of Four catalogue, `data-analytics.txt`, `software-engineering.txt`) on 2026-11-05 and 2026-11-06, and, on 2026-11-06, merged completely with the earlier machine-learning curriculum (`unified_curriculum.md`, from `nptel.txt` and `iit-genai.md`), which became Part G (D24 to D41, entered on demand) and the capstones U13.11 to U13.17. {len(domains)} domains, {len(ALL)} units, {nasg} assignments (A<d>.<n>, five questions, key collapsed), {nb} prerequisite bridges and on-demand units that other units call on, {ncap} capstones. All {ncell + mcells:,} source cells from {ncourse} courses are cited ({ncell} cloud, {mcells} Part G). Part G is never read as a block: each cloud unit that needs it carries an *On demand (Part G)* line, and each Part G unit that is called on starts with a *Bridge for:* line (map in Appendix H.3 of the file). D15 (database systems) is printed between D9 and D10; D21, D17, D18 and D19 between D10 and D11; D23 (Go, taught on demand) right after D17; D20 after D11; D22 and D16 after D12; D14 and then Part G before the capstones (D13), which stay together at the end. The old identifiers of Part G are shown as (old …); the full map is Appendix H.2.",
 "", "Bridge units are marked (bridge). Capstones carry no assignment. Part G units show their old identifier.", ""]
for d in domains:
    if d['id'] in PART:
        out.append(f"# {PART[d['id']]}"); out.append("")
    out.append(f"## {d['id']}. {d['title']}"); out.append("")
    for u in d['units']:
        tag = ' (bridge)' if u.lines and u.lines[0].startswith('Bridge for') else (' (capstone)' if u.uid.startswith('U13.') else '')
        old = f" (old {OLD[u.uid]})" if u.uid in OLD else ''
        out.append(f"- {u.uid} {u.title}{tag}{old}")
    out.append("")
open(sys.argv[1], 'w').write('\n'.join(out))

# ---- the ML index, updated: a map from the old structure to the merged document
T = open('/home/claude/work/ml/ml_orig.md').read()
import mlparse
ml = ["# Unified Curriculum: index and resume point (updated 2026-11-06: merged into `unified_cloud_curriculum.md`)", "",
 "**Status: superseded.** `unified_curriculum.md` (the machine-learning curriculum) has been merged completely into `unified_cloud_curriculum.md`, which is now the primary curriculum; its index is `index_cloud.md`. Nothing was dropped: all 160 units, 153 assignments and 564 source cells are in the merged file, as Part G (domains D24 to D41, entered on demand from the cloud units that need them) and the capstones U13.11 to U13.17. The identifiers changed; this file maps the old ones to the new. The old document, `unified_curriculum.md`, is kept for reference, unchanged apart from a banner at its top.", "",
 f"**New identifiers:** domains D0 to D17 become D24 to D41 (D0→D24, D1→D25, D2→D26, D3→D27, D4→D28, D5→D29, D6→D30, D7→D31, D8→D32, D9→D33, D10→D34, D11→D35, D12→D36, D13→D37, D14→D38, D15→D39, D16→D40, D17→D41); units keep their number inside the domain (U5.1 is U29.1); assignments follow (A5.1 is A29.1); the capstones U18.1 to U18.7 are U13.11 to U13.17 in the cloud capstone domain D13. Where two units taught the same ground, the cloud unit owns it and the Part G unit says so (Appendix H.4 lists the {len(led['drops'])} atoms removed, G.2 the pairs kept on purpose).", "",
 "**Resume point:** U1.1 of the merged curriculum (the cloud curriculum's first unit); nothing has been taught yet. Part G units are opened only when a cloud unit's *On demand (Part G)* line sends you there (for example U18.4 → U28.6 to U28.8 and U33.8), or when you choose to study Part G for its own sake in the order given in the default-order section of the merged file. **Open decisions:** Appendix D.3 of the merged file (items 17 to 21 carry the open decisions of this curriculum: official-assignment downloads, gap candidates, truncated sources, inferred titles).", "",
 "**Standing instructions recorded (nptel.txt and chat, 2026-11-03 and 2026-11-06):** (1) learn every technique from scratch in Python, with NumPy as the default toolbox; a guideline, not a prohibition. (2) NPTEL-style assignments for every unit; create them where NPTEL provides none. (3) \"add a pre calculus bridge to be taught on demand. I am a trigonometry and complex numbers noob\" (now D24). (4) 2026-11-06: \"The cloud curriculum is the primary curriculum. To it, merge the other ml curriculum completely ... whenever some concept is required from the other ml curriculum, it should be taught on demand. But ensure that topics are deduped and unified.\" All four are recorded in the course profile of the merged file.", ""]
PARTSML = {}
for d in mlparse.domains:
    PARTSML.setdefault(d['part'], []).append(d)
for part, ds in PARTSML.items():
    ml.append(f"## {part.title() if part.isupper() else part}"); ml.append("")
    for d in ds:
        k = int(d['id'][1:]); nd = dnew(k)
        ml.append(f"**{d['id']} → {nd}. {d['title']}**")
        items = []
        for u in d['units']:
            a, b = u['id'][1:].split('.')
            nid = next(n for n, o in OLD.items() if o == u['id'])
            call = led['units'][nid]['callers']
            items.append(f"{u['id']} → {nid} {u['title']}" + (f" [called by {', '.join(call)}]" if call else ''))
        ml.append('; '.join(items)); ml.append("")
open(sys.argv[2], 'w').write('\n'.join(ml))
print(len(domains), len(ALL), nasg, nb, ncap, ncell, mcells, ncourse)
