import numpy as np, math, itertools
np.set_printoptions(precision=4, linewidth=150)
rng=np.random.default_rng(0)
print("== U25.2 coins")
p=np.zeros(51);p[0]=1
for c in (1,5,10,25):
    q=np.zeros(51);q[::c]=1
    p=np.convolve(p,q)[:51]
print(p[50])
print("== U25.7 Runge")
for n in (5,10,15,20):
    x=np.linspace(-1,1,n); V=np.vander(x,increasing=True)
    y=1/(1+25*x**2); c=np.linalg.solve(V,y)
    g=np.linspace(-1,1,2001); e=np.max(np.abs(np.polynomial.polynomial.polyval(g,c)-1/(1+25*g**2)))
    print(n,e,np.linalg.cond(V))
print("== U26.2")
f=lambda x:math.cos(x)-x
def newton(x):
    for k in range(1,50):
        xn=x-(math.cos(x)-x)/(-math.sin(x)-1)
        if abs(xn-x)<1e-12: return xn,k
        x=xn
def secant(a,b):
    for k in range(1,50):
        c=b-f(b)*(b-a)/(f(b)-f(a))
        if abs(c-b)<1e-12:return c,k
        a,b=b,c
def bis(a,b,tol=1e-10):
    k=0
    while b-a>tol:
        m=(a+b)/2;k+=1
        if f(a)*f(m)<=0:b=m
        else:a=m
    return (a+b)/2,k
print(newton(1.0),secant(0.0,1.0),secant(1.0,0.5),bis(0,1))
# newton counting to |f|<1e-10
x=1.0;k=0
while abs(f(x))>1e-10:
    x=x-f(x)/(-math.sin(x)-1);k+=1
print("newton iters to |f|<1e-10",k)
print("== U26.3")
def trap(n):
    h=math.pi/n;x=np.linspace(0,math.pi,n+1);return h*(np.sin(x).sum()-0.5*(np.sin(x[0])+np.sin(x[-1])))
def simp(n):
    x=np.linspace(0,math.pi,n+1);h=math.pi/n;y=np.sin(x);return h/3*(y[0]+y[-1]+4*y[1:-1:2].sum()+2*y[2:-1:2].sum())
for n in (8,16,32):
    print(n,(2-trap(n))/(2-trap(2*n)),(2-simp(n))/(2-simp(2*n)))
print("== U27.3")
for N in (10**2,10**4,10**6):
    ers=[]
    for s in range(20):
        r=np.random.default_rng(s);pts=r.uniform(-1,1,(N,2))
        est=4*np.mean(np.where((pts**2).sum(1)<=1,pts[:,0]**2,0)); ers.append(abs(est-math.pi/4))
    print(N,np.mean(ers))
print("== U28.1 Hilbert5")
H=np.array([[1/(i+j+1) for j in range(5)] for i in range(5)]);print(np.linalg.cond(H))
errs=[]
for _ in range(1):
    x=np.linalg.solve(H,H@np.ones(5));print(np.max(abs(x-1)),np.max(abs(H@x-H@np.ones(5))))
print("== U28.4 GS")
n=10;H=np.array([[1/(i+j+1) for j in range(n)] for i in range(n)])
def cgs(A):
    m=A.shape[1];Q=np.zeros_like(A)
    for j in range(m):
        v=A[:,j].copy()
        v-=Q[:,:j]@(Q[:,:j].T@A[:,j])
        Q[:,j]=v/np.linalg.norm(v)
    return Q
def mgs(A):
    m=A.shape[1];Q=A.copy()
    for j in range(m):
        Q[:,j]/=np.linalg.norm(Q[:,j])
        for k in range(j+1,m):
            Q[:,k]-=Q[:,j]@Q[:,k]*Q[:,j]
    return Q
for nm,Q in (("cgs",cgs(H)),("mgs",mgs(H)),("hh",np.linalg.qr(H)[0])):
    print(nm,np.linalg.norm(Q.T@Q-np.eye(n)))
print("== U28.2 rank")
r=np.random.default_rng(1);B=r.standard_normal((5,3));C=r.standard_normal((3,5));A=B@C
for nz in (0,1e-12,1e-6):
    M=A+nz*r.standard_normal((5,5));s=np.linalg.svd(M,compute_uv=False)
    print(nz,s)
print("== U28.8 RBF")
for ell in (0.3,1.0):
    X=r.uniform(0,1,(20,1));K=np.exp(-(X-X.T)**2/(2*ell**2));w=np.linalg.eigvalsh(K);print(ell,w.min())
    try: np.linalg.cholesky(K);print("chol ok")
    except Exception as e:print("chol fails")
print("== U28.10")
x=np.linspace(-1,1,30);X=np.vander(x,13,increasing=True);print(np.linalg.cond(X),np.linalg.cond(X.T@X),np.linalg.cond(X)**2)
print("== U28.11 OMP")
def omp(A,y,k):
    res=y.copy();S=[]
    for _ in range(k):
        S.append(int(np.argmax(abs(A.T@res))));c=np.linalg.lstsq(A[:,S],y,rcond=None)[0];res=y-A[:,S]@c
    z=np.zeros(A.shape[1]);z[S]=c;return z
for seed in range(3):
    r=np.random.default_rng(seed);ok=0
    for t in range(200):
        A=r.standard_normal((20,50))/np.sqrt(20);xs=np.zeros(50);idx=r.choice(50,3,replace=False);xs[idx]=r.standard_normal(3)
        ok+=np.linalg.norm(omp(A,A@xs,3)-xs)<1e-6
    print("OMP success",ok/200)
print("== U29.1")
r=np.random.default_rng(0);N=10**5
print(np.mean(r.integers(0,365,(N,23)).__array__()[:,:,None].shape and [len(set(row))<23 for row in r.integers(0,365,(N//10,23))]))
print("== U29.4 KS")
from math import sqrt
N=10**5;u=np.sort(r.exponential(1,N));F=1-np.exp(-u);d=max(np.max(np.arange(1,N+1)/N-F),np.max(F-np.arange(0,N)/N));print(d,1/sqrt(N))
print("== U31.2 GS vs Jacobi")
for s in range(5):
    r=np.random.default_rng(s);A=r.uniform(-1,1,(5,5));A+=np.diag(np.abs(A).sum(1)+0.5);b=r.standard_normal(5)
    def it(gs):
        x=np.zeros(5);xs=np.linalg.solve(A,b)
        for k in range(1,500):
            xo=x.copy()
            for i in range(5):
                src=x if gs else xo
                x[i]=(b[i]-A[i]@src+A[i,i]*src[i])/A[i,i]
            if np.max(abs(x-xs))<1e-8:return k
    print(it(False),it(True))
print("== U32.4 Himmelblau")
f=lambda x,y:(x*x+y-11)**2+(x+y*y-7)**2
def grad(p):
    x,y=p;return np.array([4*x*(x*x+y-11)+2*(x+y*y-7),2*(x*x+y-11)+4*y*(x+y*y-7)])
def hess(p):
    x,y=p;return np.array([[12*x*x+4*y-42,4*x+4*y],[4*x+4*y,12*y*y+4*x-26]])
roots=[]
r=np.random.default_rng(0)
for _ in range(2000):
    p=r.uniform(-6,6,2)
    for _ in range(100):
        try:p=p-np.linalg.solve(hess(p),grad(p))
        except: break
    if np.linalg.norm(grad(p))<1e-9:
        if not any(np.linalg.norm(p-q)<1e-5 for q in roots):roots.append(p)
from collections import Counter
cnt=Counter()
for p in roots:
    w=np.linalg.eigvalsh(hess(p));cnt["min" if w.min()>0 else "max" if w.max()<0 else "saddle"]+=1
print(len(roots),cnt)
print("== U32.12 waterfill")
n=np.array([1,.5,.25,.125]);mu=(4+n.sum())/4;print(mu,mu-n)
print("== U31.7 VdP amp")
def vdp(mu,x,v,h=1e-3,T=100):
    F=lambda s:np.array([s[1],mu*(1-s[0]**2)*s[1]-s[0]]);s=np.array([x,v]);mx=0
    for k in range(int(T/h)):
        k1=F(s);k2=F(s+h/2*k1);k3=F(s+h/2*k2);k4=F(s+h*k3);s=s+h/6*(k1+2*k2+2*k3+k4)
        if k*h>60:mx=max(mx,abs(s[0]))
    return mx
print(vdp(0.5,0.1,0),vdp(0.5,4,0))
print("== U31.1 orders")
fy=lambda t:math.exp(-2*t)
def rk(m,h):
    y=1;t=0
    for _ in range(int(round(1/h))):
        if m=='e':y=y+h*(-2*y)
        elif m=='h':k1=-2*y;k2=-2*(y+h*k1);y=y+h/2*(k1+k2)
        else:
            k1=-2*y;k2=-2*(y+h/2*k1);k3=-2*(y+h/2*k2);k4=-2*(y+h*k3);y=y+h/6*(k1+2*k2+2*k3+k4)
    return abs(y-fy(1))
for m in 'ehr':
    e=[rk(m,h) for h in (0.1,0.05,0.025)];print(m,math.log2(e[0]/e[1]),math.log2(e[1]/e[2]))
print("== U32.17")
for c in (0.4,1,2):
    r=np.random.default_rng(0);M=4000;nN=20000;x=np.zeros(M)
    for n_ in range(1,nN+1):
        x=x+(c/n_)*(-(x-0)+r.standard_normal(M))
    print(c,nN*np.mean(x**2))
print("== U26.4")
for d in range(1,10):
    s=sum((-1)**((k-1)//2)/math.factorial(k) for k in range(1,d+1,2));print(d,abs(math.sin(1)-s),1/math.factorial(d+1))
