#!/usr/bin/env python3
"""Cloud-side wiring for the ML merge: pointer bullets (from demand.py) and replacement of stale 'earlier curriculum' wording. Idempotent."""
import re, glob, sys
sys.path.insert(0, '/home/claude/work/cloud2')
from demand import DEMAND
import mlload
mu, _ = mlload.load_ml()
MT = {u.uid: u.title for u in mu}
def short(t, n=70):
    t = re.split(r':| — ', t)[0]
    if len(t) > n:
        t = t[:n].rsplit(',', 1)[0] if ',' in t[:n] else t[:n].rsplit(' ', 1)[0]
    return t.strip()
def key(u):
    a, b = u[1:].split('.'); return (int(a), int(b))
def bullet(uid):
    ms = sorted(DEMAND[uid], key=key)
    return '- **On demand (Part G):** the deeper treatment of this unit\'s ground is entered only when it is needed, never up front: ' + '; '.join('%s %s' % (m, short(MT[m])) for m in ms) + '.'
REPL = [
 ('units/13_D11.md', "The depth of machine learning itself is in the earlier unified curriculum; this domain takes only what the engines need.", "The depth of machine learning itself is in Part G (D33 to D36 and the optimisation of D32), entered on demand from U11.8, U11.9 and U12.3; this domain takes only what the engines need."),
 ('units/13_D11.md', "A compact version of the foundations; the full treatment is in the earlier unified machine-learning curriculum.", "A compact version of the foundations; the full treatment is the machine-learning foundations of Part G (U33.0 to U33.14), taught on demand and listed in the On demand line below."),
 ('units/13_D11.md', "stochastic gradient descent theory is in the earlier curriculum.", "stochastic gradient descent theory is in U32.10 and U32.16 (Part G)."),
 ('units/14_D12_D13.md', "(the earlier unified curriculum treats the models; this unit names only the service layer)", "(Part G treats the models, in D36 and D37; this unit names only the service layer)"),
 ('units/26_D18.md', "the ML curriculum's bridge D0 teaches the same material in a different order", "the pre-calculus bridge D24 of Part G teaches the same material in a different order and at greater depth"),
 ('units/26_D18.md', "the multi-layer perceptron and back-propagation are in the machine-learning curriculum, not here", "the multi-layer perceptron and back-propagation are in U35.1 and U35.2 (Part G), not here"),
 ('units/29_D21.md', "with the full machine-learning curriculum as the long form", "with Part G (D33 to D36) as the long form"),
]
n_ptr = 0
for f, old, new in REPL:
    t = open(f).read()
    if new in t: continue
    assert t.count(old) == 1, (f, old)
    open(f, 'w').write(t.replace(old, new))
for f in sorted(glob.glob('units/*.md')):
    L = open(f).read().split('\n')
    out = []; i = 0; changed = False
    # locate unit ranges
    starts = [k for k, l in enumerate(L) if re.match(r'^### U', l)]
    ends = {s: (starts[j + 1] if j + 1 < len(starts) else len(L)) for j, s in enumerate(starts)}
    # also stop at '## ' domain header
    ins = {}
    for s in starts:
        uid = re.match(r'^### (U[\d.]+)', L[s]).group(1)
        if uid not in DEMAND: continue
        e = ends[s]
        for k in range(s + 1, e):
            if L[k].startswith('## '): e = k; break
        rng = L[s:e]
        if any(l.startswith('- **On demand (Part G):**') for l in rng): continue
        last = max(k for k in range(s + 1, e) if L[k].startswith('- **'))
        ins[last] = bullet(uid); n_ptr += 1
    if not ins: continue
    for k, l in enumerate(L):
        out.append(l)
        if k in ins: out.append(ins[k])
    open(f, 'w').write('\n'.join(out))
print('pointers inserted', n_ptr)
