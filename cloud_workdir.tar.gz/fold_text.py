"""Generic wording rules (applied to the F-space text before the ID remap)."""
import re
GENERIC = [
    (r'On demand \(Part G\)', 'On demand'),
    (r'Integration unit \(Part H\)', 'Integration unit (Part G)'),
    (r'\bPart G units\b', 'merged units'),
    (r'\bPart G unit\b', 'merged unit'),
    (r'\bPart G sources\b', 'machine-learning sources'),
    (r'\bPart G courses\b', 'machine-learning courses'),
    (r'\bPart G cells\b', 'machine-learning cells'),
    (r'\bPart G assignments\b', 'merged assignments'),
    (r'\bPart G content unit\b', 'merged content unit'),
    (r'\bPart G gap candidates\b', 'Gap candidates of the merged units'),
    (r'\bPart G rows\b', 'machine-learning rows'),
    (r' \(Part G\) \|', ' (ML curriculum) |'),
]
def generic(t):
    for a, b in GENERIC:
        t = re.sub(a, b, t)
    return t
