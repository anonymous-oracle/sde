#!/usr/bin/env python3
import re, glob, sys, collections
sys.path.insert(0, '/home/claude/work/cloud2')
import srclib as S
import build as B
import asg_lib

files = sorted(glob.glob('/home/claude/work/cloud2/units/*.md'))
units, domains, _ = B.load_units(files)
missing, miss_atoms, bad, cited = B.check(units, verbose=False)   # word-level check: the cloud units and the 478 cloud cells only
assert not missing and not bad, (missing, bad)
import os, json
import mlload, assemble_ml as AM
from demand import DEMAND
mu, mdoms = mlload.load_ml()
for _u in mu:
    _u.src = _u.ml_src            # display only; the word-level check does not run on Part G
ALL = units + mu
for _d in mdoms:
    if _d['id'] == 'D13+':
        _d13 = next(x for x in domains if x['id'] == 'D13')
        _d13['units'] = _d13['units'] + _d['units']
        _d13['intro'] = _d13['intro'] + [''] + _d['intro']
    else:
        domains.append(_d)
ORDER = ['D%d' % i for i in range(1, 10)] + ['D15', 'D10', 'D21', 'D17', 'D23', 'D18', 'D19', 'D11', 'D20', 'D12', 'D22', 'D16', 'D14'] + ['D%d' % i for i in range(24, 42)] + ['D13']
domains.sort(key=lambda d: ORDER.index(d['id']))
ASG = asg_lib.load()
ASG_ML = {os.path.basename(f)[:-3]: open(f).read() for f in glob.glob('/home/claude/work/cloud2/assign_ml/*.md')}
ledger = json.load(open('/home/claude/work/cloud2/merge_ledger.json'))
residual = json.load(open('/home/claude/work/cloud2/merge_residual.json'))

PARTS = {
    'D1': 'PART A. FOUNDATIONS: THE CLOUD, NETWORKS AND CLOUD COMPUTE',
    'D5': 'PART B. CRYPTOGRAPHY, SECURITY, RISK AND PRIVACY',
    'D9': 'PART C. DISTRIBUTED SYSTEMS, STORAGE AND DATABASES',
    'D21': 'PART D. DATA SCIENCE FOUNDATIONS: PREREQUISITES, ALGORITHMS, LINEAR ALGEBRA AND STATISTICS',
    'D11': 'PART E. BIG DATA, SCALABLE DATA SCIENCE, CLOUD OPERATIONS, MACHINE LEARNING AND SYSTEM DESIGN',
    'D14': 'PART F. COMPUTER ARCHITECTURE AND PARALLEL HARDWARE',
    'D24': 'PART G. MATHEMATICS AND MACHINE LEARNING, ENTERED ON DEMAND (MERGED FROM THE EARLIER MACHINE-LEARNING CURRICULUM)',
    'D13': 'PART H. CAPSTONES',
}
PART_OF = {}
cur = None
for d in domains:
    if d['id'] in PARTS:
        cur = PARTS[d['id']]
    PART_OF[d['id']] = cur

# ---------- domain map ----------
def absorbs(d):
    cnt = collections.Counter()
    for u in d['units']:
        for k, c in u.src:
            cnt[k] += 1
    if d['id'] == 'D24':
        return 'none (remedial bridge)'
    return ', '.join(k for k, v in cnt.most_common() if v >= 2) or ', '.join(k for k, _ in cnt.most_common(3)) or 'none (assembles all)'

dm = ["| Part | Domain | Units | Absorbs mainly |", "|---|---|---|---|"]
last = None
for d in domains:
    p = PART_OF[d['id']]
    SHORT = {'PART A': 'A. Foundations', 'PART B': 'B. Cryptography and security', 'PART C': 'C. Distributed systems and storage',
             'PART D': 'D. Data science foundations', 'PART E': 'E. Big data, scalable data science, cloud operations and system design',
             'PART F': 'F. Computer architecture and parallel hardware', 'PART G': 'G. Mathematics and machine learning (merged; entered on demand)', 'PART H': 'H. Capstones'}
    pshort = SHORT[p.split('.')[0]] if p != last else ''
    last = p
    us = d['units']
    dm.append(f"| {pshort} | {d['id']} {d['title'].split(':')[0]} | {us[0].uid}–{us[-1].uid} | {absorbs(d)} |")
domain_map = '\n'.join(dm)

out = []
front = open('/home/claude/work/cloud2/front_cloud.md').read().replace('__DOMAIN_MAP__', domain_map).replace('__ORDER_G__', AM.order_table())
out.append(front)

for d in domains:
    if d['id'] in PARTS:
        out.append(f"\n# {PARTS[d['id']]}\n")
        if d['id'] == 'D24':
            out.append(AM.PART_G_INTRO + '\n')
    out.append(f"## {d['id']}. {d['title']}\n")
    intro = '\n'.join(d['intro']).strip()
    if intro:
        out.append(intro + '\n')
    for u in d['units']:
        out.append(f"### {u.uid} {u.title}")
        if u.src:
            out.append(f"**Sources:** {B.fmt_cells(u.src)}")
        elif u.uid.startswith('U13'):
            out.append("**Sources:** none (capstone; assembles earlier units)")
        elif getattr(u, 'src_note', ''):
            out.append("**Sources:** " + u.src_note)
        elif u.lines and u.lines[0].startswith('Bridge for'):
            out.append("**Sources:** none (prerequisite bridge, added so that later units rest on taught ground)")
        else:
            out.append("**Sources:** none (gap-fill unit added from the references)")
        out.append('\n'.join(u.lines).strip() + '\n')
        if u.uid in ASG:
            out.append(ASG[u.uid])
        elif u.uid in ASG_ML:
            out.append(ASG_ML[u.uid])

# ---------------- appendices ----------------
out.append("\n---\n\n# APPENDICES\n")

out.append("## Appendix A. Source course index\n")
out.append("| Key | Course | Instructor / institution (course id) | Source file and lines | Cells |")
out.append("|---|---|---|---|---|")
for k, c in S.COURSES.items():
    allr = [x for v in c['cells'].values() for x in v]
    f = c.get('file') or 'cloud-computing.txt'; off = c.get('off') or 0
    out.append(f"| {k} | {c['title']} | {c['who']} | `{f}` {min(allr)-off}–{max(allr)-off} | {len(S.cell_ids(k))} |")
out.extend(AM.appendix_a_rows())
out.append("\nThe line numbers for FDB, DBD and IDB refer to `src3.txt`, a cleaned copy of `dbms.txt` (the letter-spaced text of Database Design modules 7 to 11 was re-joined by hand; see Appendix E.1), kept in the work archive. Nothing else in `dbms.txt` was altered.\n")
out.append("The line numbers for SDP, PYP and GOF refer to `src4.txt`, an outline of 54 lines generated by a script (`design_src/mk_src4.py`) from the headings, bold terms, tables and solution outlines of two public repositories cloned on 2026-11-06: the System Design Primer by Donne Martin (commit ae9bbd7, 20 March 2026) and the python-patterns collection (commit a8e4090, 1 November 2026); the GOF cells list the 23 Gang of Four patterns. The primer is licensed CC BY 4.0 (Copyright 2017 Donne Martin, `LICENSE.txt` in the repository); this document paraphrases and re-derives its content, reproduces none of its code, and credits it here. The python-patterns clone has no LICENSE file, so only its catalogue (names and one-line descriptions) is used, in the curriculum's own words.\n")

out.append("The line numbers for DAP, AGDS, SDS, DBMS, BDA, ALA, DM and DSAD refer to `src5.txt`, a verbatim copy of `data-analytics.txt` (356 lines). The file holds nine outlines; the ninth, Big Data Computing, is an exact duplicate of BDC (checked line by line against `cloud-computing.txt`) and has no cells of its own. The DBMS course is a fourth database course and its cells are cited by the existing D15 units. For DM the file gives only the instructor's name and the outline text, so its title is inferred.\n")
out.append("The Part G rows (the 44 courses of the merged machine-learning curriculum, marked Part G) refer to `nptel.txt` (43 NPTEL and learner-supplied outlines) and `iit-genai.md` (GEN, a 12-chapter, 78-section Generative AI course), the two source files of that curriculum; their line numbers are those recorded when it was built, and the files themselves were not available when the merge ran. The old key DM (Discrete Mathematics, IIT Kanpur) is DMK here, because DM is the Data Mining key of D19.\n")
out.append("The line numbers for ISE and SEM refer to `src6.txt`, a verbatim copy of `software-engineering.txt` (87 lines, two outlines). Anomalies in it are listed in Appendix E.1.\n")
out.append("## Appendix B. Coverage matrix: every source cell and the units that teach it\n")
out.append("Each entry is `cell → units`. A cell may feed several units because one source week often spans several topics (for example, the CCDS and DS weeks on consensus feed the agreement, replication and coordination units).\n")
by_cell = collections.defaultdict(list)
for u in units:
    for c in u.src:
        if u.uid not in by_cell[c]:
            by_cell[c].append(u.uid)

def cell_sort(cid):
    if cid == 'o':
        return (-1, 0)
    m = re.match(r'W?(\d+)', cid)
    return (int(m.group(1)) if m else 99, cid)

n_cells = 0
for k in S.COURSES:
    parts = []
    for cid in sorted(S.cell_ids(k), key=cell_sort):
        us = by_cell.get((k, cid))
        assert us, (k, cid)
        n_cells += 1
        parts.append(f"{cid} → {', '.join(us)}")
    out.append(f"**{k}** ({S.COURSES[k]['title']}): " + '; '.join(parts) + '\n')
out.append(f"Total for the cloud courses: {n_cells} cells, every one cited.\n")
out.append("### Part G courses (the merged machine-learning curriculum)\n")
_b, _nml = AM.appendix_b(mu)
out.extend(_b)
out.append(f"Total for the Part G courses: {_nml} cells, every one cited; {n_cells + _nml} cells in the whole document.\n")

# ---- Appendix C
out.append("## Appendix C. Prerequisite bridges and the prerequisites the sources state\n")
out.append("### C.1 Bridge units (each is taught immediately before the first unit that needs it)\n")
out.append("| Bridge | Concept taught | Needed by |")
out.append("|---|---|---|")
nb = 0
for u in ALL:
    if u.lines and u.lines[0].startswith('Bridge for'):
        nb += 1
        need = u.lines[0][len('Bridge for:'):].strip().rstrip('.')
        need = need.replace('|', '/')
        title = u.title.replace('Bridge: ', '')
        out.append(f"| {u.uid} | {title} | {need} |")
out.append(f"\n{nb} bridge units in all. In D17 every unit is an on-demand bridge (the entry map in its introduction lists the units that call on it), which is why D17 appears here in full. Several other units (U5.2 modular arithmetic, U5.5 algebra, U9.1 models and the simulator, U9.2 tail bounds) also begin from first principles and carry source citations as well.\n")
out.append("### C.2 What the sources state as prerequisites, and where each is handled\n")
out.append("| Course | Prerequisite line(s) in the source | Handled in |")
out.append("|---|---|---|")
HANDLED = {
    'GCF': 'Basic IT assumed. One programming language: Python, with U1.2 as the toolbox. Shell scripting: U1.2. SQL: U10.1.',
    'ACN': 'Computer networks: D2 from first principles. Computer architecture: U4.1.',
    'PCS': 'Cyber-security fundamentals: D6 and D7 start from the basics. Operating systems and architecture: U4.1. Networking: D2. Programming: U1.2.',
    'CSP': 'Management information systems is desirable, not required: U8.1 to U8.10 introduce what is needed.',
    'EH': 'Programming: U1.2. Networking: D2.',
    'TPMC': 'Higher-secondary mathematics: U5.1, U5.2 and U5.5 start there; number theory is built in U5.12.',
    'FOC': 'Discrete mathematics, algorithms and theory of computation: probability and entropy U5.1, complexity and reductions U5.8, number theory U5.12.',
    'ADS': 'Data structures at second-year level is assumed and reinforced by the bridges U3.1 (lookup structures) and U2.7 (graph algorithms). Operating systems: U4.1.',
    'CCDS': 'Data structures and algorithms assumed as above. Computer architecture, OS, networking: U4.1 and D2. Programming: Python (U1.2).',
    'DS': 'Data structures and algorithms assumed as above. Networking: D2. OS concepts (processes, threads, synchronisation, file systems, scheduling): U4.1. The source asks for good C and C++; this curriculum uses Python throughout, so that requirement is replaced, not met (inferred; say if you want C ports).',
    'BDC': 'Data structures and algorithms assumed as above. Architecture and OS: U4.1. Database management systems: U10.1.',
    'MCA': 'Digital logic, microprocessors and computer organisation: U14.1 to U14.2.',
    'CAO': 'Digital circuit design: U14.1. C or C++: Python replaces C (inferred); small C programs appear in the Mac labs.',
    'CA': 'C programming: Python replaces C (inferred); small C programs appear in the Mac labs.',
    'ACA': 'Second-year computer architecture and data structures in Python or Java: U14.1 to U14.12; the data-structure prerequisites are assumed as above, and Python is the build language.',
    'PCA': 'The Computer Architecture and Organization course: U14.1 to U14.12.',
    'GPU': 'Programming and data structures, digital logic and computer architecture: U14.1 to U14.9.',
    'FDB': 'Data structures, algorithms and discrete mathematics: U15.3 (sets, relations and logic), U15.14 (external-memory model) and U15.19 (directed graphs) are bridges; programming: Python (U1.2).',
    'IDB': 'Discrete mathematics, data structures and programming: U15.3, U15.14 and U15.19, with U1.2 for Python.',
    'DAP': 'Basic Python, not necessary: U21.1 teaches the language from scratch; the school mathematics and probability the course uses are U21.2 and U21.6.',
    'AGDS': 'Data structures: D17 (U17.5 to U17.9). Graph theory: U21.5. Probability: U21.6 and U19.3.',
    'SDS': 'Algorithms: D17 (with U17.1 and U21.4 for the mathematics under them). Machine learning: U11.8 here and the full treatment in Part G (D33); U20.1 reviews the optimisation, linear algebra and concentration inequalities it needs.',
    'DBMS': 'Procedural or object-oriented programming (C, C++, Java, Python): U21.1 and U16.1 (Python replaces the other languages, inferred). Data structures and algorithms: D17.',
    'BDA': 'R programming: replaced by Python throughout (decision of 2026-11-06); U21.3 teaches scientific Python in its place. Mathematics up to class 12: U21.2 and U19.1. The suggested NPTEL course Foundations of R Software is replaced by U21.3.',
    'DSAD': 'Very good analytical skills: U21.4 (proofs and discrete reasoning) and U17.1.',
    'DBD': 'Data structures, basic discrete mathematics and an operating-systems course: U15.3, U15.14 and U15.19, with U4.1 for the operating-system background.',
    'ISE': 'Basics of algorithms: D17 on demand (entry map). Programming in any language: Python (U1.2, U21.1), with Go on demand (D23) for system-design, database-coding and cloud-computing exercises.',
    'SEM': 'C, Java or C++: Python replaces them (inferred), Go is taught on demand (D23) for the system-design, database-coding and cloud-computing exercises, and the object-oriented bridge is U16.1.',
}
for k, c in S.COURSES.items():
    if c['pre']:
        t = re.sub(r'\s+', ' ', ' '.join(S.SRC[i - 1].strip() for i in c['pre']))[:300].replace('|', '/')
        out.append(f"| {k} | {t} | {HANDLED.get(k, '')} |")
out.append("")
out.append(AM.appendix_c_ml())

# ---- Appendix D
out.append("## Appendix D. Gap-fills, candidates not added, and decisions needed\n")
out.append("### D.1 What was added beyond the outlines (and why)\n")
out.append("- **Prerequisite bridges** (Appendix C.1): required by the instruction to wire prerequisites in just before the concept that demands them.")
out.append("- **U4.8** (cloud networking on Google Cloud): the thin GCF weeks 5 and 6 name networking products; the concepts underneath are derived from scratch so the product names are replaceable.")
out.append("- **GCF weeks with title-only outlines** are treated as *inferred*: the concepts under each product name are taught from first principles and the product lens sits next to the concept it implements (compute D4, networking U4.8, identity U7.7, storage U10.7, operations and analytics D12).")
out.append("- **D16** (software and system design, 2026-11-06): added on request from three public sources (the System Design Primer, the python-patterns collection and the Gang of Four catalogue). Bridge U16.1 (object-oriented design, UML, SOLID) was added before the pattern units. Where an existing unit already owns the theory (DNS U2.4, CDN U3.11, CAP U9.16, nines U9.13, consistent hashing U9.5, NoSQL and caches U10.6, Kafka U11.6, hardware caches U14.9, relational theory D15), D16 keeps the engineering view and points back; the pointers were added to those units.")
out.append("- **D17 to D21** (the data-analytics extension, 2026-11-06): eight new courses from `data-analytics.txt` gave four new domains, D17 (algorithms and data structures, taught on demand with an entry map and three added units, U17.15 to U17.17), D18 (applied linear algebra), D19 (statistics, data mining and Bayesian analysis) and D20 (scalable data science); the DBMS course was mapped onto the existing D15 units with no new unit. D21 (on-demand prerequisites: Python, school mathematics, scientific Python in place of R, proofs, graph theory, probability) consolidates every prerequisite the sources state or assume, taught in depth with from-scratch builds and assignments, and U13.10 (an analytics pipeline) was added as a capstone. Ownership rules: D15 owns database theory, U11.3 and U11.4 own MapReduce and Spark, U11.7 owns the stream-sketch idea, U11.8 and U11.10 own the compact machine-learning and Markov-chain bridges; D17 to D20 add the analysis, the proofs and the experiments, and the existing units point to them.")
out.append("- **D22 and D23** (software engineering and Go on demand, 2026-11-06): `software-engineering.txt` holds two NPTEL outlines (ISE, Introduction to Software Engineering, Dhanbad; SEM, Software Engineering, Kharagpur), merged into D22 (14 units, U22.1 to U22.14: life cycle and process models, planning and estimation, scheduling and configuration management, requirements, formal specification, design, structured and object-oriented analysis and design, three units of testing and debugging, maintenance and agile methods, and reliability). U22.14 (software reliability) is a gap-fill from Shooman's book, which the Dhanbad outline lists but ties to no week. D23 (Go, taught on demand, 8 units U23.1 to U23.8) holds the language that the system-design, database-coding and cloud-computing exercises are written in; its programs are in the `go/` module of the work archive, standard library only, with tests run under the race detector (`verify/v_go.out`).")
out.append("- **Language policy** (2026-11-06): Python is the default language of every Build. Go is the language for three kinds of exercise: system design (D16), database coding (D15, D10 and capstone U13.8) and cloud computing (D4, D9, D11, D12 and capstones U13.3, U13.5 and U13.9). Each such unit carries a **Go track** line naming the Go unit to enter on demand and the result to reproduce; the Python build stays as the oracle where one exists.")
out.append("- **Part G and the capstones U13.11 to U13.17** (2026-11-06): the earlier machine-learning curriculum, merged completely and entered on demand: 18 domains (D24 to D41, 153 units with an assignment) and seven capstones. Added by the merge, beyond what that curriculum contained: the cloud-to-Part-G demand map and the On demand and Bridge for lines (Appendix H.3), the Shares ground with lines and the removal ledger (H.4), and the compact-versus-full register (G.2). Nothing was taken out of Part G except the duplicates of H.4.")
out.append("- **Capstones** (D13) assemble the earlier units and are not sourced.\n")
out.append("### D.2 Gap candidates (not added; need your agreement per Master Rules 7.4)\n")
out.append("These are adjacent subjects that no outline names, or that a unit mentions only in passing. They are **not** in the structure above until you agree.\n")
out.append("| Candidate | Why it is adjacent | Would sit in |")
out.append("|---|---|---|")
for row in [
    ("Infrastructure as code and CI/CD pipelines", "Standard practice for the Google Cloud labs; not in any outline", "D12"),
    ("Serverless platforms in depth (functions, managed containers) and event-driven design", "Mentioned only in passing in the compute and operations units", "D4 or D12"),
    ("Service meshes and Kubernetes internals beyond the orchestration loop", "U4.4 and U11.2 teach the control loop; the rest is operations practice", "D4"),
    ("Formal specification and model checking of protocols (for example TLA+)", "Natural companion to D9; mentioned only in passing", "D9"),
]:
    out.append(f"| {row[0]} | {row[1]} | {row[2]} |")
out.append("")
out.append("### D.3 Decisions I need from you\n")
out.append("1. **Labs list.** The GCF outline says the course has 26 labs on Qwiklabs but does not list them. The Build lines give a lab for each concept instead. If you can supply the list, I will map each lab to a unit.")
out.append("2. **Gap candidates** in D.2: add any, none or all.")
out.append("3. **Merging with the earlier file: done (2026-11-06).** `unified_curriculum.md` is merged into this document as Part G (D24 to D41) and the capstones U13.11 to U13.17, on the user's instruction that this document is primary and the earlier material is taught on demand (Appendix H). The earlier file and its index are kept, with a note that they are superseded.")
out.append("4. **Institution of the GCF course.** The file's header says IIT Guwahati while the course block names IIT Kharagpur (Appendix E). Which should the record carry?")
out.append("5. **Lab environment.** The architecture labs are based on your Apple silicon MacBook (decided 2026-11-04). The security units still assume an isolated host-only VM network you own: tell me the VM tool you use on the Mac and I will adjust those Build lines and cost tags.")
out.append("6. **C and C++ for DS.** The source asks for C or C++; the curriculum uses Python. Say if you want selected builds ported.")
out.append("7. **Tooling choices.** The from-scratch guideline leaves tools to the unit; each Build line names its choice. Tell me if any should change.")
out.append("8. **File name, recorded.** The architecture courses came from `cloud-computing2.txt`, a file whose name says cloud but which holds six computer-architecture courses; they are D14 here. Rename the file if you want the name to match its contents.\n")
out.append("9. **Database file, recorded (2026-11-05).** `dbms.txt` holds three database courses, now D15 (printed between D9 and D10). The garbled part of its text layer was re-joined by hand (Appendix E.1); say if you would rather supply a clean copy so the line numbers can point at the original.")
out.append("10. **Design sources, recorded (2026-11-06).** The company architectures and engineering blogs listed in the primer, and the Anki decks, were not opened or summarised (U16.16 says so); say if you want selected ones added as units. The primer's solutions are one reasonable answer each, taught here with every figure recomputed.")
out.append("11. **R replaced by Python, recorded (2026-11-06).** The Bayesian course teaches with R, brms and Stan. On the user's instruction every R-related part was converted to Python: U21.3 teaches scientific Python (NumPy, pandas, SciPy, patsy and statsmodels, Matplotlib) in place of the R programming prerequisite, and U19.15 to U19.17 use PyMC, Bambi and ArviZ, which are installed in the workspace and were run (versions in `verify/v_f7.py`). The source names (R programming, brms, Stan) are kept only where the unit says what replaces them.")
out.append("12. **Textbook checks, recorded (2026-11-06).** The contents lists of MMDS, CLRS, Strang, Hammack, the Python tutorial and the NCERT mathematics chapters were read from public pages (Appendix F); the other benchmarks of D17 to D21 are recalled, not checked. The Netflix Prize figures in U18.8 were read from public write-ups.")
out.append("13. **Algorithms and data structures on demand, recorded (2026-11-06).** On the user's instruction D17 is entered the way the prerequisite bridges are: from the unit that needs it. Each of U17.2 to U17.14 begins with a \"Bridge for:\" line, the introduction of D17 holds the entry map, the Gap-fills of 37 using units name the U17 unit to enter, and three units were added, U17.15 (arrays, linked lists, recursion, binary search, elementary sorts, bit tricks), U17.16 (tries, B-trees, skip lists, string matching) and U17.17 (backtracking, branch and bound, approximation, local search). The three added units have no source cells (they are gap-fills from CLRS and other recalled benchmarks, marked as such) and every figure in them was measured by `verify/v_f8.py`.")
out.append("14. **Software engineering, recorded (2026-11-06).** `software-engineering.txt` is two outlines, merged into D22. Their week-by-week order is kept inside D22 but several topics were merged because the outlines overlap: life-cycle models (ISE W2, SEM W2 and W3), requirements (ISE W5, SEM W4), design basics (ISE W7, SEM W5), object-oriented analysis and design (ISE W9, SEM W7 to W9) and testing (ISE W10 and W11, SEM W10 to W12) each form one set of units. Numbers in D22 (COCOMO constants, the Halstead counts, the reliability fits) are recomputed by `verify/v_g1.py` to `v_g3.py`; the textbook constants and the standards are recalled and marked so. Say if you want the Shooman reliability unit (U22.14) removed, since no week of the outline calls for it.")
out.append("15. **Go on demand, recorded (2026-11-06).** On the user's instruction Go is taught on demand for system design, database-related coding and cloud computing, and Python for everything else. D23 holds the language (U23.1 bridge, interfaces and generics, concurrency, networked services, database coding, system-design building blocks, cloud-native Go, testing and profiling). Limits to know: the build machine could not download modules, so the programs use only the standard library and the SQLite, gRPC and Kubernetes client libraries are named and not used; no container daemon was available, so the Dockerfile and the image size are untested (the static binary and its signal handling were run); the benchmark times are from one machine and are marked as such. Say if any Go-track exercise should stay in Python.")
out.append("16. **Overlapping and related concepts unified and de-duplicated, recorded (2026-11-06).** On the user's instruction every concept that two or more units taught or built is now taught and built once, by one owner, and the other units keep only what their domain adds and point to the owner (Appendix G lists each concept, its owner and the units that reuse it). The pass found, among others, probability basics taught three times (now U21.6), the Bloom filter and universal hashing built three times (U3.1 and U17.5), consistent hashing in five places (U9.5), shortest paths and spanning trees in the routing bridge and in D17 (D17), the flow and matching build (U17.14), the page-table and TLB build (U4.1), the lock manager, recovery log and precedence graph in the distributed-systems bridge and in D15 (D15), the relational engine in the storage bridge, D15 and the capstone (D15 and U13.8), UML notation (U22.9), and the birthday simulator (U5.1). Coverage of every source cell was re-run after each change.")
out.append("17. **Machine-learning curriculum merged, recorded (2026-11-06).** On the user's instruction this curriculum is primary and `unified_curriculum.md` was merged into it completely, with cloud units calling on Part G units on demand (a Bridge for line on each called unit and an On demand (Part G) line on each caller), overlapping topics deduplicated under one owner, and both index files updated (Appendix H).")
out.append("18. **Official NPTEL assignments (carried from Part G).** Do you still want the official weekly assignments of MFML (weeks 1 to 12), EMML (8 weeks) and the course id of nptel.txt line 213 downloaded as a supplement to the authored ones, with images and PDFs deleted afterwards? Nothing was downloaded (Appendix E.5).")
out.append("19. **Part G gap candidates (carried).** The candidates of D.5 (speech and linguistic NLP, structured prediction, linear factor models, music generation and world models, partial monitoring): add any, none or all.")
out.append("20. **Truncated Part G sources (carried).** OMLH has 8 of its weeks, MM has 4, S50 has 9 of 50 categories: confirm that benchmark fill-ins are acceptable, or supply the missing outlines.")
out.append("21. **Missing course titles (carried).** DMK (the old DM), MLE and PSS have no title in the source; the inferred titles of Appendix A need your confirmation.")
out.append("Resolved on 2026-11-04 and no longer open: the placement of the architecture courses (D14, printed before the capstones), the scope of the GPU labs (three tiers with a simulator fallback) and the assembly language (an AArch64 subset with a crosswalk to the MIPS-like and RISC-V-like forms).\n")

out.append(AM.appendix_d_ml())

# ---- Appendix E
out.append("## Appendix E. Source anomalies, typos and residual flagged atoms\n")
out.append("### E.1 Anomalies in the sources (kept visible, not silently fixed)\n")
out.append("| Source | Issue | Handling |")
out.append("|---|---|---|")
rows = [
    ("GCF", "The file header attributes the course to IIT Guwahati; the course block names IIT Kharagpur. Lines 1–28 are repeated verbatim at lines 30–57", "Cited once; nothing double-counted. See D.3 item 4."),
    ("GCF", "26 Qwiklabs labs are mentioned but not listed; several weeks give only a title", "Thin weeks are marked *inferred* in the units that cite them (for example U1.3 and U4.7)."),
    ("CCDS", "Eight weeks in the source (the outline cells W1–W8)", "Taken as given."),
    ("CNS, TPMC, FOC", "Overlap heavily on number theory, public-key schemes and provable security", "Merged in D5; every week cited."),
    ("Typos taken from context", "'Christians algorithm', 'Berkley's', 'El Gamal', 'DEF3ND', 'Incidence response', 'Primarily Testing', 'Rabinson', 'physical inclinable functions', 'WTC'", "The unit text quotes the source spelling in parentheses where the check needs it and uses the standard name otherwise."),
    ("ADS (U9.13)", "'TLAs' appears without an expansion", "Left unexpanded in U9.13 rather than guessed."),
    ("File name", "`cloud-computing2.txt` holds computer-architecture courses, not cloud courses", "Treated as the architecture extension of the cloud curriculum (D14); see D.3 item 8."),
    ("MCA:W5 and GPU", "Multicore Week 5 covers GPU architectures, which the GPU course also covers", "Merged in U14.17 with both cited."),
    ("CAO:W11", "Titled 'Instruction Set Pipelining'; instruction pipelining is meant", "Taught in U14.6; the source wording is quoted."),
    ("PCA:W6, W7 and outline", "'muliprocessor', 'networkon-chip' and 'specically' (typos); an instructor biography at lines 190 to 201 of the architecture file is not course content", "Meaning taken from context; the source spelling is quoted where the check needs it; the biography is not cited as content."),
    ("CAO books", "'Morgan Koffman' for Morgan Kaufmann", "Spelled correctly in the units; source spelling noted here."),
    ("GPU:W11, W12 and ACA prerequisites", "The GPU course repeats one title for Weeks 11 and 12 ('Contd.'); the ACA course lists generic Python, Java and data-structures courses as prerequisites", "One unit (U14.20) cites both GPU weeks; the ACA prerequisites are mapped in C.2."),
    ("DBD (dbms.txt)", "The text layer of the Database Design outline from module 7 onward (raw lines 188 to 768) came out with one character per line", "Re-joined by hand into a cleaned copy (`src3.txt`); the cleaned lines are cited. Nothing else in `dbms.txt` was altered."),
    ("FDB", "Lecture titles are separated by stray numerals ('45.', '46.'), 'NoSQLSystems' is run together, and recap lectures appear at 13, 22, 32 and 48", "Recaps are cells and are cited; the numerals are ignored; 'Types of NoSQL Systems' is the title used."),
    ("IDB", "Week 8 pairs the Indexes Module with the Query Processing Module", "U15.16 to U15.18 cite Week 8 together."),
    ("SDP (primer)", "Weekly downtime for four nines is printed as 1 minute 5 seconds; 0.0001 of 604,800 seconds is 60.5 seconds", "U16.10 teaches 60.5 s and records the error."),
    ("SDP (primer)", "The latency table note says main memory is 20 times slower than L2 cache; the table gives 7 ns and 100 ns, a ratio of 14.3 (the other notes, 14x, 200x, 120x and 30x, recompute)", "U16.8 uses 14.3 and records the slip."),
    ("PYP (python-patterns)", "The README lists an interpreter pattern with no matching file in the repository, and the clone has no LICENSE file", "U16.4 teaches the interpreter from the Gang of Four description; only the catalogue is used (Appendix A)."),
    ("GOF", "The Gang of Four catalogue is not a course outline: the cells are the 23 pattern names in three groups", "Taken from the book's table of contents as the python-patterns README and Wikipedia list it (Appendix F)."),
    ("data-analytics.txt (BDC)", "The ninth outline, Big Data Computing, is an exact duplicate of the existing BDC outline in `cloud-computing.txt`", "No cells added; the existing BDC cells keep their units (D11)."),
    ("DM", "The outline gives only the instructor's name; the course title is not stated", "The title 'Data Mining' is inferred from the outline text and marked as such in Appendix A."),
    ("ALA", "The Week 9 line repeats the second half of the Week 8 line (the dynamical-systems topics); 'Operations Resarch' is a typo", "Both weeks are cited by U18.10; the source spelling is quoted where the check needs it."),
    ("DAP", "Week 10 is titled 'C 2 Test', a lost chi-square symbol", "Taught as the chi-square test in U19.9; the source wording is quoted in the unit."),
    ("BDA", "The course uses R, the brms package and Stan", "Converted to Python on 2026-11-06: U21.3 teaches scientific Python in place of R programming, and U19.14 to U19.17 build every method from scratch and run it in PyMC, Bambi and ArviZ (installed in the workspace); R, brms and Stan are not used."),
    ("CSP", "Weeks carry reading-list entries: labels R3 to R21, URLs, years and 'accessible at'", "Case titles and readings are treated as cases (the Target breach in U6.1, active defense in U7.1, the HBR case on Cheddar in U8.3); the labels and URLs are not content."),
    ("ISE", "The page header gives the category as Mathematics; Week 1 says 'Evaluation of software development process' (evolution is meant); Week 8 says 'Warrior ORR diagram' (Warnier–Orr), 'Structural design techniques' (structured) and 'Water Fall'; the audience line carries an HTML entity ('&amp;')", "Meaning taken from context; the source spelling is quoted in U22.2 and U22.8 so that the check passes; the entity is read as an ampersand."),
    ("ISE books", "The second book, Shooman, Software Engineering: Reliability, Development and Management, is tied to no week", "Taught in U22.14 as a gap-fill, with the reference marked."),
    ("SEM", "Weeks 10 to 12 are titled Testing I, II and III with no topics; Weeks 2 and 3 are Life Cycle Models I and II with no models named", "Topics inferred from the field's standard content and from Mall's book, marked in the units (U22.2, U22.10 to U22.12)."),
]
for a, b, c in rows:
    out.append(f"| {a} | {b} | {c} |")
out.append("")
out.append("### E.2 Atoms the word-level check still flags, reviewed by hand\n")
NOISE = re.compile(r'^(continued?|examples?|cont…|cont|iii?|\d+|and|etc|contd)$', re.I)
seen = set(); flagged = []
n_o = 0
for c, a, us in miss_atoms + B.check.prose:
    if c[1] == 'o':
        n_o += 1
        continue
    if NOISE.match(a.strip()) or (c, a) in seen:
        continue
    seen.add((c, a)); flagged.append((c, a))
out.append(f"- **Outline-prose atoms flagged:** {n_o}. They are audience statements, marketing sentences and connective phrases (for example 'to practice the learning'); every topic named in an outline appears in the units that cite it, with the outline map sentences in U1.1, U2.2, U3.3, U5.3, U6.1, U8.1, U9.1, U11.1, U14.1, U14.2, U14.11, U14.13, U14.18 and U15.1 where an outline names many topics.")
out.append(f"- **Non-outline atoms flagged:** {len(flagged)}. All were reviewed one by one: URLs and URL fragments, years, reading labels (R11 to R21), the phrase 'accessible at', one section label ('Examples'), and the titles of cases or articles that are covered under their topic.\n")
out.append("<details><summary>Full list of non-outline flagged atoms</summary>\n")
for c, a in flagged:
    out.append(f"- `{c[0]}:{c[1]}` {a[:110]}")
out.append("\n</details>\n")

out.append(AM.appendix_e_ml())

# ---- Appendix F
out.append("""## Appendix F. Verification register and safety notes

**Checked on the web during this work** (the unit that uses each says so):

| Fact | Source type | Where used |
|---|---|---|
| NIST published FIPS 203 (ML-KEM), FIPS 204 (ML-DSA) and FIPS 205 (SLH-DSA) on 13 August 2024; HQC was selected on 11 March 2025; FIPS 206 (FN-DSA) was still in development | NIST pages | U5.25 |
| OWASP Top 10:2025 | Secondary reports, not the OWASP page itself | U6.2, U6.7 |
| Digital Personal Data Protection Rules 2025 notified 13 November 2025 with phased commencement | Law-firm summaries, not the official gazette text | U8.9 |
| Qwiklabs history: acquired by Google in November 2016, became Google Cloud Skills Boost in October 2021, now part of Google Skills (announced October 2025) | Press and Google pages | U1.3 |
| Product renames (operations suite, Vertex AI, end of AI Platform access on 31 January 2025) | Google pages | U1.3 |
| IBM Db2 Community Edition is free, limited to 4 virtual cores and 16 GB of memory, for non-production use, with a Docker image for Linux, Windows and Mac (checked 2026-11-05) | IBM's Db2 Community Edition page | U15.10 |
| The Gang of Four book (Gamma, Helm, Johnson, Vlissides, 1994) describes 23 patterns: 5 creational, 7 structural, 11 behavioral, with the names used in U16.2 to U16.4 (checked 2026-11-06) | Wikipedia page on the book | U16.2 to U16.4 |
| The System Design Primer is licensed CC BY 4.0, Copyright 2017 Donne Martin; the python-patterns clone has no licence file (checked 2026-11-06) | The cloned repositories | Appendix A |
| The Netflix Prize data: 100,480,507 ratings by 480,189 users of 17,770 movies; Cinematch RMSE 0.9525 on the test set; the winner BellKor's Pragmatic Chaos 0.8567, a 10.06 % improvement; movie-average predictor 1.0540 (checked 2026-11-06) | Wikipedia, the contest descriptions and two papers | U18.8 |
| Strang, Introduction to Linear Algebra, 5th ed.: twelve chapters (vectors through probability and statistics) (checked 2026-11-06) | Publisher and author pages, contents lists | D18 |
| Mining of Massive Datasets, CLRS and the Data Structures and Algorithms benchmarks: part and chapter structure from public contents lists (checked 2026-11-06) | Public contents pages | D17, D20 |
| The Python Tutorial has sixteen chapters; the NCERT Class 11 and 12 mathematics chapter lists; Hammack, Book of Proof, four parts and fourteen chapters (checked 2026-11-06) | docs.python.org and public contents pages | D21 |
| Db2 isolation levels UR, CS, RS and RR and which anomalies each permits (checked 2026-11-05) | IBM's Db2 documentation | U15.10, U15.20 |
| PyTorch's MPS backend needs a Mac with Apple silicon, macOS 14.0 or later and Python 3.10 or later, and Apple labels it beta (checked 2026-11-04) | Apple's page, `developer.apple.com/metal/pytorch` | Section 7 tiers in U14.17 to U14.20 |
| `PYTORCH_ENABLE_MPS_FALLBACK=1` runs operations missing on MPS on the CPU (checked 2026-11-04) | Hugging Face guide on training on Apple silicon | U14.18 to U14.20 |
| Colab's free tier gives a GPU, typically a T4, when available, with sessions up to 12 hours and no guaranteed availability (checked 2026-11-04) | Google's FAQ wording as quoted by a 2026 comparison, and secondary guides | U14.18 to U14.20 |
| Kaggle Notebooks: a weekly GPU quota commonly reported as about 30 hours and a 12-hour session limit; Kaggle's own documentation gives no quota number (checked 2026-11-04) | Secondary sources only | U14.18 to U14.20 |

**Everything else** that is a recalled reference, a benchmark title or a standard result is marked *recalled, not checked* where it appears. Everything listed as an Apple-silicon fact for the Mac labs of D14 (commands such as `sysctl hw.cachelinesize`, the 16 KB page size, MLX, the Metal vocabulary, `NUMBA_ENABLE_CUDASIM=1`) is recalled, not checked, and each lab begins by having you verify it on your Mac. Prices in U10.7 are illustrative numbers for an exercise, not current Google Cloud prices. Product names and limits change often: verify them in the console or the documentation before relying on them.

**Safety notes.** Nothing in this document asks you to scan, probe, attack or access a system you do not own. The ethical-hacking and security units use an isolated host-only lab, standard tools and Python models of the mechanisms; no exploit or malware is authored. The hardware-security work in U14.22 is a defensive model in simulation only, and free-GPU labs use a personal account with no secrets in the notebook. Cryptographic code built here is for learning and is never deployed. No assignment asks for credentials, keys or personal data; use synthetic data throughout.
""")

REG = [
 ("Probability basics (spaces, conditioning, Bayes' rule, random variables, expectation, standard distributions)", "U21.6", "U2.1, U5.1, U19.3, U22.3, U22.14"),
 ("Birthday problem and collision simulation", "U5.1", "U19.3, U21.6"),
 ("Queueing, M/M/1 and Little's law", "U2.1", "U22.13, U23.4"),
 ("Quantitative risk and Monte Carlo risk", "U8.2", "U22.2, U22.4"),
 ("Nines arithmetic, availability and composition", "U16.10", "U22.5, U22.14"),
 ("SLI, SLO and error budgets", "U9.13", "U12.1, U22.5, U23.4"),
 ("Bloom filter", "U3.1", "U20.2, U11.7, U23.6"),
 ("Universal hashing and perfect hashing", "U17.5", "U3.1, U20.2, U20.3"),
 ("Consistent hashing with virtual nodes", "U9.5", "U10.3, U16.9, U16.11, U16.12, U23.6"),
 ("LRU and LFU cache against a Zipf workload", "U10.6", "U16.7, U16.12, U23.2"),
 ("Token bucket and traffic shaping", "U3.6", "U23.6"),
 ("Dijkstra, Bellman-Ford, Floyd-Warshall, graph search, minimum spanning trees", "U17.10 to U17.13", "U2.7, U9.11, U3.7"),
 ("Max-flow and bipartite matching", "U17.14", "U4.5, U3.2"),
 ("Page tables, MMU and TLB", "U4.1", "U14.10"),
 ("Precedence graph, strict 2PL lock manager, deadlock detection", "U15.21 and U15.22", "U9.17"),
 ("Write-ahead log, redo and undo recovery, ARIES", "U15.23", "U9.17, U23.5"),
 ("Snapshot isolation and write skew", "U9.17", "U15.22"),
 ("B+-tree, join algorithms, FD closure and BCNF, the relational engine", "U15.16, U15.17, U15.12 and U13.8", "U10.1"),
 ("Hardware and software reliability measures", "U22.14", "U9.13, U13.9"),
 ("UML notation and the analysis-and-design process", "U22.9", "U16.1"),
 ("Object-oriented programming, SOLID and test seams", "U16.1", "U22.9, U16.6, U23.2"),
 ("Git object model and merge, Git usage", "U22.4 (model), U1.2 (usage)", "none"),
 ("Reconciliation loop, lease and fencing, backoff", "U23.7", "U9.10, U9.15, U4.4, U13.3"),
 ("Testing theory (coverage, mutation, property-based, debugging)", "U22.10 to U22.12", "U16.6, U23.8"),
]
uids = {u.uid for u in ALL}
import re as _re
for _c, _o, _r in REG:
    for _x in _re.findall(r'U\d+\.\d+', _o + ' ' + _r):
        assert _x in uids, (_c, _x)
out.append("## Appendix G. Ownership register: one owner for every concept taught in more than one place\n")
out.append("Where two or more units touched a concept, one unit owns the definition, the derivation and the from-scratch build; the others keep their domain's increment and name the owner in their Build or Topics line. Go re-expressions (D23 and the Go track lines) reuse the Python result of the owner as their oracle.\n")
out.append("| Concept | Owner | Reused or pointed to by |")
out.append("|---|---|---|")
for _c, _o, _r in REG:
    out.append(f"| {_c} | {_o} | {_r} |")
out.append("")
out.extend(AM.appendix_g2())
_counts = dict(demand_units=len(DEMAND), demand_links=sum(len(v) for v in DEMAND.values()), callers=sum(1 for u in mu if u.lines and u.lines[0].startswith('Bridge for') and not u.uid.startswith('U13.')),
               audit_line=(open('/home/claude/work/cloud2/audit_summary.txt').read().strip() if os.path.exists('/home/claude/work/cloud2/audit_summary.txt') else 'not yet run'))
out.extend(AM.appendix_h(mu, ledger, residual, units, _counts))
doc = '\n'.join(out)
open(sys.argv[1], 'w').write(doc)
print('units', len(ALL), 'cloud', len(units), 'part G', len(mu), 'domains', len(domains), 'assignments', len(ASG) + len(ASG_ML), 'chars', len(doc), 'lines', doc.count('\n'))
