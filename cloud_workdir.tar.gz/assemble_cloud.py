#!/usr/bin/env python3
import re, glob, sys, collections
sys.path.insert(0, '/home/claude/work/cloud2')
import srclib as S
import build as B
import asg_lib

files = sorted(glob.glob('/home/claude/work/cloud2/units/*.md'))
units, domains, _ = B.load_units(files)
ORDER = ['D%d' % i for i in range(1, 10)] + ['D15', 'D10', 'D11', 'D12', 'D14', 'D13']
domains.sort(key=lambda d: ORDER.index(d['id']))
missing, miss_atoms, bad, cited = B.check(units, verbose=False)
assert not missing and not bad, (missing, bad)
ASG = asg_lib.load()

PARTS = {
    'D1': 'PART A. FOUNDATIONS: THE CLOUD, NETWORKS AND CLOUD COMPUTE',
    'D5': 'PART B. CRYPTOGRAPHY, SECURITY, RISK AND PRIVACY',
    'D9': 'PART C. DISTRIBUTED SYSTEMS, STORAGE AND DATABASES',
    'D11': 'PART D. BIG DATA, CLOUD OPERATIONS AND MACHINE LEARNING ON THE CLOUD',
    'D14': 'PART E. COMPUTER ARCHITECTURE AND PARALLEL HARDWARE',
    'D13': 'PART F. CAPSTONES',
}
PART_OF = {}
cur = None
for d in domains:
    if d['id'] in PARTS:
        cur = PARTS[d['id']]
    PART_OF[d['id']] = cur

# ---------- domain map ----------
def absorbs(d):
    cnt = collections.Counter()
    for u in d['units']:
        for k, c in u.src:
            cnt[k] += 1
    return ', '.join(k for k, v in cnt.most_common() if v >= 2) or ', '.join(k for k, _ in cnt.most_common(3)) or 'none (assembles all)'

dm = ["| Part | Domain | Units | Absorbs mainly |", "|---|---|---|---|"]
last = None
for d in domains:
    p = PART_OF[d['id']]
    pshort = p.split('. ', 1)[1].title() if p != last else ''
    pshort = {'Foundations: The Cloud, Networks And Cloud Compute': 'A. Foundations',
              'Cryptography, Security, Risk And Privacy': 'B. Cryptography and security',
              'Distributed Systems, Storage And Databases': 'C. Distributed systems and storage',
              'Big Data, Cloud Operations And Machine Learning On The Cloud': 'D. Big data and cloud operations',
              'Computer Architecture And Parallel Hardware': 'E. Computer architecture and parallel hardware',
              'Capstones': 'F. Capstones'}.get(pshort, pshort)
    last = p
    us = d['units']
    dm.append(f"| {pshort} | {d['id']} {d['title'].split(':')[0]} | {us[0].uid}–{us[-1].uid} | {absorbs(d)} |")
domain_map = '\n'.join(dm)

out = []
front = open('/home/claude/work/cloud2/front_cloud.md').read().replace('__DOMAIN_MAP__', domain_map)
out.append(front)

for d in domains:
    if d['id'] in PARTS:
        out.append(f"\n# {PARTS[d['id']]}\n")
    out.append(f"## {d['id']}. {d['title']}\n")
    intro = '\n'.join(d['intro']).strip()
    if intro:
        out.append(intro + '\n')
    for u in d['units']:
        out.append(f"### {u.uid} {u.title}")
        if u.src:
            out.append(f"**Sources:** {B.fmt_cells(u.src)}")
        elif u.uid.startswith('U13'):
            out.append("**Sources:** none (capstone; assembles earlier units)")
        elif u.lines and u.lines[0].startswith('Bridge for'):
            out.append("**Sources:** none (prerequisite bridge, added so that later units rest on taught ground)")
        else:
            out.append("**Sources:** none (gap-fill unit added from the references)")
        out.append('\n'.join(u.lines).strip() + '\n')
        if u.uid in ASG:
            out.append(ASG[u.uid])

# ---------------- appendices ----------------
out.append("\n---\n\n# APPENDICES\n")

out.append("## Appendix A. Source course index\n")
out.append("| Key | Course | Instructor / institution (course id) | Source file and lines | Cells |")
out.append("|---|---|---|---|---|")
for k, c in S.COURSES.items():
    allr = [x for v in c['cells'].values() for x in v]
    f = c.get('file') or 'cloud-computing.txt'; off = c.get('off') or 0
    out.append(f"| {k} | {c['title']} | {c['who']} | `{f}` {min(allr)-off}–{max(allr)-off} | {len(S.cell_ids(k))} |")
out.append("\nThe line numbers for FDB, DBD and IDB refer to `src3.txt`, a cleaned copy of `dbms.txt` (the letter-spaced text of Database Design modules 7 to 11 was re-joined by hand; see Appendix E.1), kept in the work archive. Nothing else in `dbms.txt` was altered.\n")

out.append("## Appendix B. Coverage matrix: every source cell and the units that teach it\n")
out.append("Each entry is `cell → units`. A cell may feed several units because one source week often spans several topics (for example, the CCDS and DS weeks on consensus feed the agreement, replication and coordination units).\n")
by_cell = collections.defaultdict(list)
for u in units:
    for c in u.src:
        if u.uid not in by_cell[c]:
            by_cell[c].append(u.uid)

def cell_sort(cid):
    if cid == 'o':
        return (-1, 0)
    m = re.match(r'W?(\d+)', cid)
    return (int(m.group(1)) if m else 99, cid)

n_cells = 0
for k in S.COURSES:
    parts = []
    for cid in sorted(S.cell_ids(k), key=cell_sort):
        us = by_cell.get((k, cid))
        assert us, (k, cid)
        n_cells += 1
        parts.append(f"{cid} → {', '.join(us)}")
    out.append(f"**{k}** ({S.COURSES[k]['title']}): " + '; '.join(parts) + '\n')
out.append(f"Total: {n_cells} cells, every one cited.\n")

# ---- Appendix C
out.append("## Appendix C. Prerequisite bridges and the prerequisites the sources state\n")
out.append("### C.1 Bridge units (each is taught immediately before the first unit that needs it)\n")
out.append("| Bridge | Concept taught | Needed by |")
out.append("|---|---|---|")
nb = 0
for u in units:
    if u.lines and u.lines[0].startswith('Bridge for'):
        nb += 1
        need = u.lines[0][len('Bridge for:'):].strip().rstrip('.')
        need = need.replace('|', '/')
        title = u.title.replace('Bridge: ', '')
        out.append(f"| {u.uid} | {title} | {need} |")
out.append(f"\n{nb} bridge units in all. Several other units (U5.2 modular arithmetic, U5.5 algebra, U9.1 models and the simulator, U9.2 tail bounds) also begin from first principles and carry source citations as well.\n")
out.append("### C.2 What the sources state as prerequisites, and where each is handled\n")
out.append("| Course | Prerequisite line(s) in the source | Handled in |")
out.append("|---|---|---|")
HANDLED = {
    'GCF': 'Basic IT assumed. One programming language: Python, with U1.2 as the toolbox. Shell scripting: U1.2. SQL: U10.1.',
    'ACN': 'Computer networks: D2 from first principles. Computer architecture: U4.1.',
    'PCS': 'Cyber-security fundamentals: D6 and D7 start from the basics. Operating systems and architecture: U4.1. Networking: D2. Programming: U1.2.',
    'CSP': 'Management information systems is desirable, not required: U8.1 to U8.10 introduce what is needed.',
    'EH': 'Programming: U1.2. Networking: D2.',
    'TPMC': 'Higher-secondary mathematics: U5.1, U5.2 and U5.5 start there; number theory is built in U5.12.',
    'FOC': 'Discrete mathematics, algorithms and theory of computation: probability and entropy U5.1, complexity and reductions U5.8, number theory U5.12.',
    'ADS': 'Data structures at second-year level is assumed and reinforced by the bridges U3.1 (lookup structures) and U2.7 (graph algorithms). Operating systems: U4.1.',
    'CCDS': 'Data structures and algorithms assumed as above. Computer architecture, OS, networking: U4.1 and D2. Programming: Python (U1.2).',
    'DS': 'Data structures and algorithms assumed as above. Networking: D2. OS concepts (processes, threads, synchronisation, file systems, scheduling): U4.1. The source asks for good C and C++; this curriculum uses Python throughout, so that requirement is replaced, not met (inferred; say if you want C ports).',
    'BDC': 'Data structures and algorithms assumed as above. Architecture and OS: U4.1. Database management systems: U10.1.',
    'MCA': 'Digital logic, microprocessors and computer organisation: U14.1 to U14.2.',
    'CAO': 'Digital circuit design: U14.1. C or C++: Python replaces C (inferred); small C programs appear in the Mac labs.',
    'CA': 'C programming: Python replaces C (inferred); small C programs appear in the Mac labs.',
    'ACA': 'Second-year computer architecture and data structures in Python or Java: U14.1 to U14.12; the data-structure prerequisites are assumed as above, and Python is the build language.',
    'PCA': 'The Computer Architecture and Organization course: U14.1 to U14.12.',
    'GPU': 'Programming and data structures, digital logic and computer architecture: U14.1 to U14.9.',
    'FDB': 'Data structures, algorithms and discrete mathematics: U15.3 (sets, relations and logic), U15.14 (external-memory model) and U15.19 (directed graphs) are bridges; programming: Python (U1.2).',
    'IDB': 'Discrete mathematics, data structures and programming: U15.3, U15.14 and U15.19, with U1.2 for Python.',
    'DBD': 'Data structures, basic discrete mathematics and an operating-systems course: U15.3, U15.14 and U15.19, with U4.1 for the operating-system background.',
}
for k, c in S.COURSES.items():
    if c['pre']:
        t = re.sub(r'\s+', ' ', ' '.join(S.SRC[i - 1].strip() for i in c['pre']))[:300].replace('|', '/')
        out.append(f"| {k} | {t} | {HANDLED.get(k, '')} |")
out.append("")

# ---- Appendix D
out.append("## Appendix D. Gap-fills, candidates not added, and decisions needed\n")
out.append("### D.1 What was added beyond the outlines (and why)\n")
out.append("- **Prerequisite bridges** (Appendix C.1): required by the instruction to wire prerequisites in just before the concept that demands them.")
out.append("- **U4.8** (cloud networking on Google Cloud): the thin GCF weeks 5 and 6 name networking products; the concepts underneath are derived from scratch so the product names are replaceable.")
out.append("- **GCF weeks with title-only outlines** are treated as *inferred*: the concepts under each product name are taught from first principles and the product lens sits next to the concept it implements (compute D4, networking U4.8, identity U7.7, storage U10.7, operations and analytics D12).")
out.append("- **Capstones** (D13) assemble the earlier units and are not sourced.\n")
out.append("### D.2 Gap candidates (not added; need your agreement per Master Rules 7.4)\n")
out.append("These are adjacent subjects that no outline names, or that a unit mentions only in passing. They are **not** in the structure above until you agree.\n")
out.append("| Candidate | Why it is adjacent | Would sit in |")
out.append("|---|---|---|")
for row in [
    ("Infrastructure as code and CI/CD pipelines", "Standard practice for the Google Cloud labs; not in any outline", "D12"),
    ("Serverless platforms in depth (functions, managed containers) and event-driven design", "Mentioned only in passing in the compute and operations units", "D4 or D12"),
    ("Service meshes and Kubernetes internals beyond the orchestration loop", "U4.4 and U11.2 teach the control loop; the rest is operations practice", "D4"),
    ("Formal specification and model checking of protocols (for example TLA+)", "Natural companion to D9; mentioned only in passing", "D9"),
    ("Full machine-learning course", "U11.8 is a compact bridge; the full treatment is in the earlier unified curriculum", "link to the earlier file"),
]:
    out.append(f"| {row[0]} | {row[1]} | {row[2]} |")
out.append("")
out.append("### D.3 Decisions I need from you\n")
out.append("1. **Labs list.** The GCF outline says the course has 26 labs on Qwiklabs but does not list them. The Build lines give a lab for each concept instead. If you can supply the list, I will map each lab to a unit.")
out.append("2. **Gap candidates** in D.2: add any, none or all.")
out.append("3. **Merging with the earlier file.** `unified_curriculum.md` (mathematics, machine learning, deep learning, LLMs) and this file share a method. Merge into one document, or keep two linked by U11.8, U9.2, U5.1 and U14.20? (The merge is planned as a separate, optional step and has not been done.)")
out.append("4. **Institution of the GCF course.** The file's header says IIT Guwahati while the course block names IIT Kharagpur (Appendix E). Which should the record carry?")
out.append("5. **Lab environment.** The architecture labs are based on your Apple silicon MacBook (decided 2026-11-04). The security units still assume an isolated host-only VM network you own: tell me the VM tool you use on the Mac and I will adjust those Build lines and cost tags.")
out.append("6. **C and C++ for DS.** The source asks for C or C++; the curriculum uses Python. Say if you want selected builds ported.")
out.append("7. **Tooling choices.** The from-scratch guideline leaves tools to the unit; each Build line names its choice. Tell me if any should change.")
out.append("8. **File name, recorded.** The architecture courses came from `cloud-computing2.txt`, a file whose name says cloud but which holds six computer-architecture courses; they are D14 here. Rename the file if you want the name to match its contents.\n")
out.append("9. **Database file, recorded (2026-11-05).** `dbms.txt` holds three database courses, now D15 (printed between D9 and D10). The garbled part of its text layer was re-joined by hand (Appendix E.1); say if you would rather supply a clean copy so the line numbers can point at the original.")
out.append("Resolved on 2026-11-04 and no longer open: the placement of the architecture courses (D14, printed before the capstones), the scope of the GPU labs (three tiers with a simulator fallback) and the assembly language (an AArch64 subset with a crosswalk to the MIPS-like and RISC-V-like forms).\n")

# ---- Appendix E
out.append("## Appendix E. Source anomalies, typos and residual flagged atoms\n")
out.append("### E.1 Anomalies in the sources (kept visible, not silently fixed)\n")
out.append("| Source | Issue | Handling |")
out.append("|---|---|---|")
rows = [
    ("GCF", "The file header attributes the course to IIT Guwahati; the course block names IIT Kharagpur. Lines 1–28 are repeated verbatim at lines 30–57", "Cited once; nothing double-counted. See D.3 item 4."),
    ("GCF", "26 Qwiklabs labs are mentioned but not listed; several weeks give only a title", "Thin weeks are marked *inferred* in the units that cite them (for example U1.3 and U4.7)."),
    ("CCDS", "Eight weeks in the source (the outline cells W1–W8)", "Taken as given."),
    ("CNS, TPMC, FOC", "Overlap heavily on number theory, public-key schemes and provable security", "Merged in D5; every week cited."),
    ("Typos taken from context", "'Christians algorithm', 'Berkley's', 'El Gamal', 'DEF3ND', 'Incidence response', 'Primarily Testing', 'Rabinson', 'physical inclinable functions', 'WTC'", "The unit text quotes the source spelling in parentheses where the check needs it and uses the standard name otherwise."),
    ("ADS (U9.13)", "'TLAs' appears without an expansion", "Left unexpanded in U9.13 rather than guessed."),
    ("File name", "`cloud-computing2.txt` holds computer-architecture courses, not cloud courses", "Treated as the architecture extension of the cloud curriculum (D14); see D.3 item 8."),
    ("MCA:W5 and GPU", "Multicore Week 5 covers GPU architectures, which the GPU course also covers", "Merged in U14.17 with both cited."),
    ("CAO:W11", "Titled 'Instruction Set Pipelining'; instruction pipelining is meant", "Taught in U14.6; the source wording is quoted."),
    ("PCA:W6, W7 and outline", "'muliprocessor', 'networkon-chip' and 'specically' (typos); an instructor biography at lines 190 to 201 of the architecture file is not course content", "Meaning taken from context; the source spelling is quoted where the check needs it; the biography is not cited as content."),
    ("CAO books", "'Morgan Koffman' for Morgan Kaufmann", "Spelled correctly in the units; source spelling noted here."),
    ("GPU:W11, W12 and ACA prerequisites", "The GPU course repeats one title for Weeks 11 and 12 ('Contd.'); the ACA course lists generic Python, Java and data-structures courses as prerequisites", "One unit (U14.20) cites both GPU weeks; the ACA prerequisites are mapped in C.2."),
    ("DBD (dbms.txt)", "The text layer of the Database Design outline from module 7 onward (raw lines 188 to 768) came out with one character per line", "Re-joined by hand into a cleaned copy (`src3.txt`); the cleaned lines are cited. Nothing else in `dbms.txt` was altered."),
    ("FDB", "Lecture titles are separated by stray numerals ('45.', '46.'), 'NoSQLSystems' is run together, and recap lectures appear at 13, 22, 32 and 48", "Recaps are cells and are cited; the numerals are ignored; 'Types of NoSQL Systems' is the title used."),
    ("IDB", "Week 8 pairs the Indexes Module with the Query Processing Module", "U15.16 to U15.18 cite Week 8 together."),
    ("CSP", "Weeks carry reading-list entries: labels R3 to R21, URLs, years and 'accessible at'", "Case titles and readings are treated as cases (the Target breach in U6.1, active defense in U7.1, the HBR case on Cheddar in U8.3); the labels and URLs are not content."),
]
for a, b, c in rows:
    out.append(f"| {a} | {b} | {c} |")
out.append("")
out.append("### E.2 Atoms the word-level check still flags, reviewed by hand\n")
NOISE = re.compile(r'^(continued?|examples?|cont…|cont|iii?|\d+|and|etc|contd)$', re.I)
seen = set(); flagged = []
n_o = 0
for c, a, us in miss_atoms + B.check.prose:
    if c[1] == 'o':
        n_o += 1
        continue
    if NOISE.match(a.strip()) or (c, a) in seen:
        continue
    seen.add((c, a)); flagged.append((c, a))
out.append(f"- **Outline-prose atoms flagged:** {n_o}. They are audience statements, marketing sentences and connective phrases (for example 'to practice the learning'); every topic named in an outline appears in the units that cite it, with the outline map sentences in U1.1, U2.2, U3.3, U5.3, U6.1, U8.1, U9.1, U11.1, U14.1, U14.2, U14.11, U14.13, U14.18 and U15.1 where an outline names many topics.")
out.append(f"- **Non-outline atoms flagged:** {len(flagged)}. All were reviewed one by one: URLs and URL fragments, years, reading labels (R11 to R21), the phrase 'accessible at', one section label ('Examples'), and the titles of cases or articles that are covered under their topic.\n")
out.append("<details><summary>Full list of non-outline flagged atoms</summary>\n")
for c, a in flagged:
    out.append(f"- `{c[0]}:{c[1]}` {a[:110]}")
out.append("\n</details>\n")

# ---- Appendix F
out.append("""## Appendix F. Verification register and safety notes

**Checked on the web during this work** (the unit that uses each says so):

| Fact | Source type | Where used |
|---|---|---|
| NIST published FIPS 203 (ML-KEM), FIPS 204 (ML-DSA) and FIPS 205 (SLH-DSA) on 13 August 2024; HQC was selected on 11 March 2025; FIPS 206 (FN-DSA) was still in development | NIST pages | U5.25 |
| OWASP Top 10:2025 | Secondary reports, not the OWASP page itself | U6.2, U6.7 |
| Digital Personal Data Protection Rules 2025 notified 13 November 2025 with phased commencement | Law-firm summaries, not the official gazette text | U8.9 |
| Qwiklabs history: acquired by Google in November 2016, became Google Cloud Skills Boost in October 2021, now part of Google Skills (announced October 2025) | Press and Google pages | U1.3 |
| Product renames (operations suite, Vertex AI, end of AI Platform access on 31 January 2025) | Google pages | U1.3 |
| IBM Db2 Community Edition is free, limited to 4 virtual cores and 16 GB of memory, for non-production use, with a Docker image for Linux, Windows and Mac (checked 2026-11-05) | IBM's Db2 Community Edition page | U15.10 |
| Db2 isolation levels UR, CS, RS and RR and which anomalies each permits (checked 2026-11-05) | IBM's Db2 documentation | U15.10, U15.20 |
| PyTorch's MPS backend needs a Mac with Apple silicon, macOS 14.0 or later and Python 3.10 or later, and Apple labels it beta (checked 2026-11-04) | Apple's page, `developer.apple.com/metal/pytorch` | Section 7 tiers in U14.17 to U14.20 |
| `PYTORCH_ENABLE_MPS_FALLBACK=1` runs operations missing on MPS on the CPU (checked 2026-11-04) | Hugging Face guide on training on Apple silicon | U14.18 to U14.20 |
| Colab's free tier gives a GPU, typically a T4, when available, with sessions up to 12 hours and no guaranteed availability (checked 2026-11-04) | Google's FAQ wording as quoted by a 2026 comparison, and secondary guides | U14.18 to U14.20 |
| Kaggle Notebooks: a weekly GPU quota commonly reported as about 30 hours and a 12-hour session limit; Kaggle's own documentation gives no quota number (checked 2026-11-04) | Secondary sources only | U14.18 to U14.20 |

**Everything else** that is a recalled reference, a benchmark title or a standard result is marked *recalled, not checked* where it appears. Everything listed as an Apple-silicon fact for the Mac labs of D14 (commands such as `sysctl hw.cachelinesize`, the 16 KB page size, MLX, the Metal vocabulary, `NUMBA_ENABLE_CUDASIM=1`) is recalled, not checked, and each lab begins by having you verify it on your Mac. Prices in U10.7 are illustrative numbers for an exercise, not current Google Cloud prices. Product names and limits change often: verify them in the console or the documentation before relying on them.

**Safety notes.** Nothing in this document asks you to scan, probe, attack or access a system you do not own. The ethical-hacking and security units use an isolated host-only lab, standard tools and Python models of the mechanisms; no exploit or malware is authored. The hardware-security work in U14.22 is a defensive model in simulation only, and free-GPU labs use a personal account with no secrets in the notebook. Cryptographic code built here is for learning and is never deployed. No assignment asks for credentials, keys or personal data; use synthetic data throughout.
""")

doc = '\n'.join(out)
open(sys.argv[1], 'w').write(doc)
print('units', len(units), 'domains', len(domains), 'with assignments', len(ASG), 'chars', len(doc), 'lines', doc.count('\n'))
