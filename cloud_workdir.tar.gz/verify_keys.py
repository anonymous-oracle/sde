#!/usr/bin/env python3
"""Independent recomputation of the Part G numeric keys that the audit cannot parse (127 of 153).
Each value is computed from the question text here, not read from the key. Output: verify_keys.out"""
import math, itertools, json, re, sys
import numpy as np
from math import comb, exp, log, sqrt, pi, factorial, erf, gamma
sg = lambda z: 1 / (1 + math.exp(-z))
def necklaces(n, k): return sum(k ** math.gcd(i, n) for i in range(n)) // n
def phi(n): return sum(1 for i in range(1, n + 1) if math.gcd(i, n) == 1)
def ent(p, n): a = p / (p + n); return -a * math.log2(a) - (1 - a) * math.log2(1 - a)
def maj(n, p): return sum(comb(n, k) * p ** k * (1 - p) ** (n - k) for k in range(n // 2 + 1, n + 1))
def kl_b(p, q): return p * log(p / q) + (1 - p) * log((1 - p) / (1 - q))
sc = np.array([[1, 1], [1, 1]])
def softmax(v): e = np.exp(v - max(v)); return e / e.sum()
def trap(f, a, b, n): h = (b - a) / n; xs = [a + i * h for i in range(n + 1)]; return h / 2 * (f(xs[0]) + 2 * sum(f(x) for x in xs[1:-1]) + f(xs[-1]))
def simp(f, a, b, n): h = (b - a) / n; xs = [a + i * h for i in range(n + 1)]; return h / 3 * (f(xs[0]) + 4 * sum(f(xs[i]) for i in range(1, n, 2)) + 2 * sum(f(xs[i]) for i in range(2, n - 1, 2)) + f(xs[-1]))
def auc(pos, neg): return sum((p > n) + .5 * (p == n) for p in pos for n in neg) / (len(pos) * len(neg))
A = np.array
def sd(P): # stationary distribution
    w, v = np.linalg.eig(np.array(P).T); i = np.argmin(abs(w - 1)); x = np.real(v[:, i]); return x / x.sum()
def windows(n, size, ov): s = size - ov; return len(range(0, n - ov, s)) if False else len([i for i in range(0, n, s) if i + ov < n])
def r2(y, p): y = A(y); p = A(p); return 1 - ((y - p) ** 2).sum() / ((y - y.mean()) ** 2).sum()
def bayes_post(a, b, h, n): return (a + h) / (a + b + n)
def lstsq_slope(x, y): return np.polyfit(x, y, 1)[0]
def idx(): pass
V = {
 'U24.2': sqrt(7*7 + 9*9 - 2*7*9*math.cos(math.radians(60))), 'U24.3': math.degrees(math.atan2(4, 3)), 'U24.4': ((1 + 1j) ** 8).real,
 'U24.5': abs(2 + 3 * np.exp(1j * pi / 3)), 'U25.1': 2 ** (2 ** 3), 'U25.3': 2 ** 3, 'U25.4': comb(8, 2), 'U25.5': phi(36), 'U25.6': necklaces(4, 2),
 'U26.1': 0.06 / 3, 'U26.3': trap(lambda x: x * x, 0, 1, 4), 'U26.5': gamma(2) * gamma(3) / gamma(5),
 'U27.1': float(np.dot([2 * 1 * 2, 1], [.6, .8])), 'U27.2': max(math.cos(t) * sqrt(2) + math.sin(t) * sqrt(2) for t in np.linspace(0, 2 * pi, 100001)),
 'U27.3': 2 * pi / 4, 'U27.4': 2 * 1 + 2 * 2 + 2 * 3, 'U27.5': float(((A([[2, 1], [0, 3]]) + A([[2, 1], [0, 3]]).T) @ A([1, 1])).sum()),
 'U28.1': float(np.sum(np.linalg.solve([[2, 1], [1, -1]], [5, 1]) ** 2)), 'U28.2': 3 + 4 - 2, 'U28.3': 6 - 2, 'U28.4': float(np.dot([1, 2, 2], [2, 2, 1]) / (3 * 3)),
 'U28.6': max(np.linalg.eigvalsh([[2, 1], [1, 2]])), 'U28.7': 2 - np.linalg.matrix_rank(np.array([[2, 1], [0, 2]]) - 2 * np.eye(2)),
 'U28.8': min(np.linalg.eigvalsh([[2, -1], [-1, 2]])), 'U28.9': sqrt(2 ** 2 + 1 ** 2), 'U28.10': lstsq_slope([0, 1, 2], [1, 2, 2]), 'U28.11': sd([[.9, .1], [.5, .5]])[0],
 'U29.2': np.var(range(1, 7)), 'U29.3': exp(-2) * 2 ** 3 / factorial(3), 'U29.4': erf(1 / sqrt(2)), 'U29.5': 3 / 4,
 'U29.6': .5 * 2 / 1 * 1, 'U29.7': 1 / 9, 'U29.8': (2 / 3) / (1 - 2 / 3), 'U29.9': 3 + np.mean(range(1, 7)),
 'U30.1': np.percentile(range(1, 9), 75) - np.percentile(range(1, 9), 25), 'U30.2': np.mean([2, 3, 4, 3]), 'U30.4': r2([1, 2, 3, 4], [1.1, 1.9, 3.2, 3.8]),
 'U30.5': bayes_post(2, 2, 7, 10), 'U30.6': 1 / (1 - .8 ** 2), 'U31.1': 3 * exp(-2), 'U31.2': simp(lambda x: x * x, 0, 2, 2), 'U31.3': 2 * pi,
 'U31.4': pi, 'U31.5': 1 / 2 ** 2, 'U31.6': 1 - 1 / 2.5, 'U31.7': exp(2),
 'U32.1': min(x * x + y * y - 2 * x - 4 * y for x in np.linspace(0, 2, 201) for y in np.linspace(0, 4, 201)), 'U32.2': 5 - 1, 'U32.3': 2,
 'U32.4': min(x ** 4 - 4 * x for x in np.linspace(-3, 3, 600001)), 'U32.5': 2 * 1, 'U32.6': min(3 * a + 2 * (4 - a) for a in np.linspace(0, 4, 401)),
 'U32.7': max(3 * x + 2 * y for x in np.linspace(0, 2, 201) for y in np.linspace(0, 4, 401) if x + y <= 4 + 1e-9), 'U32.8': 4 * (1 - .5) ** 3,
 'U32.9': 18 / 20, 'U32.10': 0.001, 'U32.11': max(x for x in np.linspace(0, 3, 3001) if min(np.linalg.eigvalsh([[1, x], [x, 1]])) >= -1e-12), 'U32.12': np.sign(2.5) * max(2.5 - 1, 0),
 'U32.13': 1, 'U32.14': sorted(np.linalg.eigvalsh([[1, -1, 0], [-1, 2, -1], [0, -1, 1]]))[1],
 'U32.15': min(2 + 4, 5 + 1, 2 + 1 + 1), 'U32.16': np.mean([2, 4, 6]), 'U32.17': 2 ** 2 * 1 / (2 * 2 - 1),
 'U33.0': 2 * (40 / 50) * (40 / 60) / (40 / 50 + 40 / 60), 'U33.1': .3, 'U33.2': auc([.9, .8, .4], [.7, .3]), 'U33.3': sg(1), 'U33.4': 3 / (3 + 3), 'U33.5': (2 / .5) ** 2,
 'U33.8': 2 / 3, 'U33.9': sum((x - c) ** 2 for g, c in (((1, 2), 1.5), ((10, 11), 10.5)) for x in g), 'U33.10': exp(-.5), 'U33.12': .3 / (.4 * .5), 'U33.14': ent(9, 5),
 'U34.1': log2 if False else math.log2(1024), 'U34.4': 1 / (1 - .9), 'U34.5': min(1.5 * 1, min(max(1.5, .8), 1.2) * 1), 'U34.6': .5 + .1 * (1 + .9 * .8 - .5),
 'U35.2': .25 ** 10, 'U35.3': 1 / .8, 'U35.4': 3 * 3 * 3 * 16 + 16, 'U35.8': 784 / 32, 'U36.1': exp(-log(1 / 8)), 'U36.3': softmax(A([2., 0.]))[0], 'U36.4': exp(2.0),
 'U36.5': 2 ** -0.076, 'U36.6': softmax(A([2., 1., 0.]))[0], 'U36.7': maj(5, .6), 'U36.8': sg(1 - 0), 'U36.10': 1000 / 250,
 'U37.1': kl_b(.5, .25), 'U37.2': abs(.2 - .7), 'U37.3': .6 / (.6 + .2), 'U37.4': 2 ** 2 / 2, 'U37.6': -(2 - 0) / 1, 'U37.7': (1 - .1) ** 3,
 'U37.8': -.5 * log(2 * pi) - log(2), 'U38.1': log(1000 / 10), 'U38.2': 3 / 4, 'U38.4': log(4), 'U38.5': windows(1000, 200, 50), 'U38.6': 512 / 16,
 'U38.7': 1 / (60 + 1) + 1 / (60 + 3), 'U38.9': .8 * .8, 'U38.11': 500 + 10 * 300, 'U38.12': 5 * 3, 'U38.13': 17 / 20, 'U38.14': 8 / 10, 'U38.15': .95 ** 3,
 'U39.1': 2 / 3, 'U39.2': (.85 - .5) / (1 - .5), 'U39.3': .7 - .4, 'U39.4': 12 / 50, 'U39.5': 1 / .1, 'U39.6': (1 - .7) ** 3,
 'U40.1': 2 * 1024 ** 3 / (3 * 1024 ** 2 * 4), 'U40.2': 2 * (8 - 1) / 8 * 1, 'U40.3': 2 * 32 * 32 * 128 * 2, 'U40.4': 2.54 / 127, 'U40.6': (1 * 100 + 3 * 300) / 400,
 'U41.1': 8 - 3, 'U41.2': sum(1 / i for i in range(1, 11)), 'U41.3': 2 - 1 / 4, 'U41.5': 7 / 8, 'U41.6': 14 / 7.5, 'U41.7': (pi / 3) / pi,
}
op = json.load(open('/tmp/open_keys.json')) if len(sys.argv) < 2 else json.load(open(sys.argv[1]))
txt = open(sys.argv[2] if len(sys.argv) > 2 else 'merged_test.md').read()
ok = 0; bad = []; missing = [u for u in op if u not in V]
for u in op:
    if u not in V: continue
    i = txt.index('**Assignment A' + u[1:] + '**'); k = re.search(r'- \*\*Q3:\*\*\s*(-?[\d.]+(?:e-?\d+)?)\s*(?:[a-zA-Z/ ]*)\(tolerance ±([\d.e-]+)\)', txt[i:])
    key = float(k.group(1)); tol = float(k.group(2)); v = float(V[u])
    if abs(v - key) <= max(tol, 1e-12) + 1e-12: ok += 1
    else: bad.append((u, key, round(v, 6), tol))
print(f'{ok} of {len(op)} keys recomputed independently and equal within the stated tolerance; mismatches {bad}; no independent value written for {missing}')
