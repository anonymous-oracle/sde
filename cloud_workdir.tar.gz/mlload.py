import re, glob, sys
sys.path.insert(0,'/home/claude/work/cloud2')
import build as B
class MUnit(B.Unit):
    def __init__(self,uid,title):
        super().__init__(uid,title); self.ml_src=[]; self.is_ml=True; self.src_note=''
def load_ml(files=None):
    files=files or sorted(glob.glob('/home/claude/work/cloud2/units_ml/*.md'))
    units=[]; domains=[]; dom=None; cur=None
    for f in files:
        for ln in open(f).read().split('\n'):
            m=re.match(r'^## (D\d+\+?)\. (.*)',ln)
            if m:
                dom=dict(id=m.group(1),title=m.group(2),intro=[],units=[]); domains.append(dom); cur=None; continue
            m=re.match(r'^### (U[\d.]+) (.*)',ln)
            if m:
                cur=MUnit(m.group(1),m.group(2)); cur.domain=dom['id'].rstrip('+'); dom['units'].append(cur); units.append(cur); continue
            if cur is None:
                dom['intro'].append(ln); continue
            m=re.match(r'^mlsrc:\s*(.*)',ln)
            if m:
                v=m.group(1).strip()
                if v.startswith('none'):
                    cur.src_note=v
                else:
                    for part in v.split('; '):
                        k,_,c=part.partition(':'); cur.ml_src.append((k.strip(),c.strip()))
                continue
            cur.lines.append(ln)
    return units,domains
