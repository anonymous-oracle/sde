#!/usr/bin/env python3
"""Word-level coverage of the 564 Part G source cells, run on the merged document.
usage: mlcheck.py MERGED.md [-v]"""
import sys, re, collections, json
sys.path.insert(0, '/home/claude/work/cloud2'); sys.path.insert(0, '/home/claude/work/ml')
import build as B, mlcheck_src as S, mlload, mlsrc
DOC = sys.argv[1]; L = open(DOC).read().split('\n')
app = next(i for i, l in enumerate(L) if l.startswith('# APPENDICES'))
txt = {}; cur = None
for l in L[:app]:
    m = re.match(r'^### (U\d+\.\d+) (.*)', l)
    if m: cur = m.group(1); txt[cur] = [m.group(2)]; continue
    if l.startswith('## ') or l.startswith('# PART'): cur = None; continue
    if cur: txt[cur].append(l)
def utext(u):
    t = '\n'.join(txt[u]); i = t.find('**Assignment A'); return t[:i] if i >= 0 else t
import json as _j
led = _j.load(open('merge_ledger.json'))
owners = collections.defaultdict(set)
for e in led['drops']: owners[e['ml_new']].add(e['owner'])
mu, _ = mlload.load_ml()
cited = collections.defaultdict(list)
for u in mu:
    for c in u.ml_src: cited[c].append(u.uid)
course_units = collections.defaultdict(set)
for (k, c), us in cited.items(): course_units[k] |= set(us)
total = missing = loose = 0; miss = []; fallback = collections.Counter(); per_course = collections.Counter()
for (k, c), us in sorted(cited.items()):
    t, how = S.text_of(k, c)
    if how == 'course' and k == 'ALAB' and c.startswith('P') and 'COURSE PLAN' in t: t = t[t.index('COURSE PLAN'):]
    if t is None: miss.append(((k, c), '(cell text not found)', us)); continue
    if how == 'course': us = sorted(course_units[k]); fallback[k] += 1
    union = ' '.join(utext(u) for u in us) + ' ' + ' '.join(utext(o) for u in us for o in owners.get(u, ()))
    ut = B.toks(union); uset = set(ut); ubig = {tuple(ut[i:i + 3]) for i in range(len(ut))}
    for a, tk in B.atoms(t):
        total += 1; per_course[k] += 1
        if len(tk) == 1: ok = tk[0] in uset; strict = ok
        else:
            allin = sum(1 for x in tk if x in uset); ok = allin >= max(1, int(len(tk) * 0.75 + 0.999))
            strict = tuple(tk[:3]) in ubig or (len(tk) == 2 and any(ut[i:i + 2] == tk for i in range(len(ut) - 1)))
        if not ok: miss.append(((k, c), a, us))
        elif not strict: loose += 1
NOISE = re.compile(r'^(continued?|examples?|cont…|cont|iii?|\d+|and|etc|contd|namely|however|therefore|finally|initially|specifically|key takeaways?.*|hands.on.*)$', re.I)
miss2 = [m for m in miss if not NOISE.match(m[1].strip())]
miss_o = [m for m in miss2 if m[0][1] == 'o']; miss2 = [m for m in miss2 if m[0][1] != 'o']
print(f'cells cited {len(cited)}; fallback to whole-course text {sum(fallback.values())} {dict(fallback)}; atoms checked {total}; missing {len(miss2)}; outline/about-text atoms not covered (audience, prerequisites, category, prose) {len(miss_o)}; loose-only {loose}')
json.dump([[list(m[0]), m[1], m[2]] for m in miss2], open('mlcheck_miss.json', 'w'), indent=1)
for m in miss2[:int(sys.argv[3]) if len(sys.argv) > 3 and sys.argv[2] == '-n' else 60]: print(m[0], '|', m[1][:90], '|', m[2][:4])

# ---- classify the remaining flags ----
GENERIC = set(B.toks('real world tasks particular covered detail many instance applications continue understanding working mechanism '
  'implementation strong conceptual foundation able apply powerful theory behind practical understand architecture modern effective '
  'progression boost performance techniques compare enhanced move visual patterns scratch focus turn start module discuss too permits '
  'see area like possible extensions allow develop beautiful mind deep learning models using')) | {'doe', 'not', 'them', 'conti', 'parti', 'cover', 'detai', 'insta', 'appli'}
TYPO = {'liner': 'linear', 'seida': 'seidel', 'grpah': 'graph', 'dula': 'dual', 'diine': 'dimension'}
allu = {u: set(B.toks(utext(u))) for u in txt}
tech = []; typo = []; gen = []
for cell, a, us in miss2:
    u = set().union(*[allu[x] for x in us]) | set().union(*[allu[o] for x in us for o in owners.get(x, ())])
    absent = [t for t in B.toks(a) if t not in u]
    rest = [t for t in absent if t not in GENERIC]
    if any(t in TYPO for t in rest):
        # a source typo: the correctly spelled word must be in the unit text
        ok = all(TYPO[t][:5] in u or TYPO[t][:4] in {x[:4] for x in u} for t in rest if t in TYPO)
        typo.append((cell, a[:60], ok))
        rest = [t for t in rest if t not in TYPO]
    if rest: tech.append((cell, a[:70], rest))
    elif not any(t in TYPO for t in absent): gen.append((cell, a[:60]))
print(f'classified: {len(gen)} generic prose fragments, {len(typo)} source typos (correct spelling present: {sum(1 for t in typo if t[2])}), {len(tech)} with an absent technical word')
for t in tech: print('TECH', t)
open('mlcheck_summary.txt', 'w').write(f'cells {len(cited)}; atoms {total}; flagged {len(miss2)} (generic prose {len(gen)}, source typos {len(typo)}, technical {len(tech)}); outline atoms not covered {len(miss_o)}; whole-course fallback cells {sum(fallback.values())}')
