#!/usr/bin/env python3
"""usage: audit_fold.py F_DOC X_DOC REPORT   -- independent audit of the fold (F: merged with a separate Part G; X: folded by subject)"""
import sys, re, json, collections, difflib
sys.path.insert(0, '/home/claude/work/cloud2')
import fold_core as C, fold_rw as W
from fold_text import GENERIC
Fp, Xp, REP = sys.argv[1:4]
IC = sys.argv[4] if len(sys.argv) > 4 else None; IM = sys.argv[5] if len(sys.argv) > 5 else None
F = open(Fp).read(); X = open(Xp).read()
R = []
def rec(sec, name, ok, detail=''): R.append((sec, name, 'PASS' if ok else 'FAIL', detail))
TOK = re.compile(r'(?<![@\w])([UAD])(\d+)(?:\.(\d+))?\b')
def mask(t):
    t = re.sub(r'S50 D\d+(?:[,–-] ?D\d+)*', 'S50 DX', t)
    return re.sub(r'\b([UA])\d+\.\d+\b', r'\1#', re.sub(r'\bD\d+\b', 'D#', t))
def split_units(doc):
    """returns {id: (title, domain id, text)} for every unit, and the list of domains in print order, parts"""
    units, doms, cur = {}, [], None
    L = doc.split('\n'); end = next(i for i, l in enumerate(L) if l.startswith('# APPENDICES'))
    cur_d = None; cur_u = None; parts = []
    for l in L[:end]:
        if l.startswith('# PART '): parts.append(l); cur_u = None
        m = re.match(r'## (D\d+)\. (.*)', l)
        if m: cur_d = m.group(1); doms.append((cur_d, m.group(2))); cur_u = None; continue
        m = re.match(r'### (U\d+\.\d+) (.*)', l)
        if m:
            cur_u = m.group(1); units[cur_u] = [m.group(2), cur_d, [l]]; continue
        if cur_u: units[cur_u][2].append(l)
    return {k: (v[0], v[1], re.sub(r'(\n+---)+$', '', '\n'.join(v[2]).rstrip()).rstrip()) for k, v in units.items()}, doms, parts
FU, FD, FP = split_units(F)
XU, XD, XP = split_units(X)
S1 = '1. Counts and structure'
rec(S1, 'unit counts equal (450 before and after)', len(FU) == len(XU) == 450, f'{len(FU)} -> {len(XU)}')
rec(S1, '33 domains D1-D33, each once, 7 parts', sorted(int(d[1:]) for d, _ in XD) == list(range(1, 34)) and len(XP) == 7, f'{len(XD)} domains, {len(XP)} parts')
bad = [u for u, (t, d, _) in XU.items() if u.split('.')[0][1:] != d[1:]]
rec(S1, 'every unit sits in the domain that its identifier names', not bad, str(bad[:5]))
nums = collections.defaultdict(list)
for u in XU: nums[XU[u][1]].append(int(u.split('.')[1]))
nc = [d for d, v in nums.items() if sorted(v) != list(range(min(v), min(v) + len(v)))]
rec(S1, 'unit numbers contiguous inside each domain (D26 starts at U26.0)', not nc and min(nums['D26']) == 0 and all(min(v) == 1 for d, v in nums.items() if d != 'D26'), str(nc))
nasg_F = len(re.findall(r'\*\*Assignment A\d+\.\d+\*\*', F)); nasg_X = len(re.findall(r'\*\*Assignment A\d+\.\d+\*\*', X))
rec(S1, '433 assignments before and after, 433 collapsed key blocks', nasg_F == nasg_X == 433 and X.count('<details><summary>Key for A') == 433, f'{nasg_F} -> {nasg_X}; key blocks {X.count("<details><summary>Key for A")}')
rec(S1, 'every assignment id equals its unit id', all(re.search(r'\*\*Assignment A%s\*\*' % re.escape(u[1:]), t) for u, (_, _, t) in XU.items() if not u.startswith('U13.') or int(u.split('.')[1]) <= 0 or True and ('**Assignment A' in t)), '')
caps = [u for u in XU if u.startswith('U13.')]
rec(S1, '17 capstones U13.1-U13.17, all in D13, no assignment', len(caps) == 17 and all('**Assignment' not in XU[u][2] for u in caps), f'{len(caps)}')

S2 = '2. The fold lost nothing and changed nothing but identifiers and wording'
# title pairing
ft = collections.defaultdict(list); xt = collections.defaultdict(list)
for u, (t, d, _) in FU.items(): ft[t].append(u)
for u, (t, d, _) in XU.items(): xt[t].append(u)
rec(S2, 'unit titles are unique in both documents, so a unit can be paired by title', all(len(v) == 1 for v in ft.values()) and all(len(v) == 1 for v in xt.values()) and set(ft) == set(xt), f'{len(ft)} / {len(xt)} distinct titles')
pair = {ft[t][0]: xt[t][0] for t in ft if t in xt}
# wording applied to the F side
def wording(t):
    for lst in (W.FRONT, W.BODY):
        for r in lst:
            if r['regex']: t = re.sub(r['old'], lambda m: r['new'], t, flags=r['flags'])
            elif r['old'] != r['new']: t = t.replace(r['old'], r['new'])
    for a, b in GENERIC: t = re.sub(a, b, t)
    t = re.sub(r'(U\d+\.\d+(?: and U\d+\.\d+)*) \(Part G\)', r'\1', t)
    return t
diff = []
for fu, xu in pair.items():
    a = mask(wording(FU[fu][2]).replace('@', '')); b = mask(XU[xu][2].replace('@', ''))
    a = re.sub(r'^### U#', '### U#', a); 
    if a != b: diff.append((fu, xu))
rec(S2, 'every unit (text, results, assignment and key) is identical before and after, up to identifiers and the listed rewording', not diff, f'{450-len(diff)} identical, {len(diff)} differ {diff[:4]}')
# derived map equals the formula
fm = {u: C.fid(u) for u in FU}
mm = [(u, pair[u], fm[u]) for u in FU if pair[u] != fm[u]]
rec(S2, 'the identifier map derived from the title pairing equals the stated scheme (offsets per old domain)', not mm, str(mm[:4]))
# every identifier token in the unit bodies is the mapped token
dmap = {}
for fu, xu in pair.items():
    dmap.setdefault(FU[fu][1], set()).add(XU[xu][1])
hostmerge = {d: v for d, v in dmap.items() if len(v) != 1}
rec(S2, 'each old (first-pass) domain lands in exactly one final domain', not hostmerge, str(hostmerge))
dm1 = {d: next(iter(v)) for d, v in dmap.items()}
def ids(t):
    t = re.sub(r'S50 D\d+(?:[,–-] ?D\d+)*', '', t)
    return [(m.group(1), m.group(2), m.group(3)) for m in TOK.finditer(t)]
def mapped(tok):
    k, a, b = tok
    if k == 'D': return 'D' + str(int(dm1.get('D' + a, 'D' + a)[1:])) if ('D' + a) in dm1 else 'D' + a
    return k + pair_u(k, a, b)
def pair_u(k, a, b):
    u = 'U%s.%s' % (a, b)
    if u in pair: return pair[u][1:]
    return '%s.%s' % (a, b)
badtok = []
rewritten = set()
for r in W.BODY + W.FRONT:
    pass
for fu, xu in pair.items():
    ftoks = [mapped(t) for t in ids(wording(FU[fu][2]).replace('@', ''))]
    xtoks = [k + a + (('.' + b) if b else '') for k, a, b in ids(XU[xu][2].replace('@', ''))]
    # assignment tokens A.. follow unit ids: use unit map
    ft2 = []
    for t in ids(wording(FU[fu][2]).replace('@', '')):
        k, a, b = t
        if k == 'A':
            u = 'U%s.%s' % (a, b); ft2.append('A' + (pair[u][1:] if u in pair else '%s.%s' % (a, b)))
        elif k == 'U':
            u = 'U%s.%s' % (a, b); ft2.append('U' + (pair[u][1:] if u in pair else '%s.%s' % (a, b)))
        else:
            ft2.append('D' + str(a) if ('D' + a) not in dm1 else dm1['D' + a])
    if ft2 != xtoks: badtok.append(fu)
# domain tokens that moved from a merged domain are checked by their (domain-level) meaning only; unit and assignment tokens are exact
badtok_ua = []
for fu, xu in pair.items():
    a = [t for t in ids(wording(FU[fu][2]).replace('@', '')) if t[0] in 'UA']; b = [t for t in ids(XU[xu][2].replace('@', '')) if t[0] in 'UA']
    ma = []
    for k, x, y in a:
        u = 'U%s.%s' % (x, y); ma.append((k, pair[u][1:].split('.')[0], pair[u][1:].split('.')[1]) if u in pair else (k, x, y))
    if ma != b: badtok_ua.append(fu)
rec(S2, 'every unit and assignment identifier inside a unit is the image of the old one under the derived map (token by token, in order)', not badtok_ua, f'{450-len(badtok_ua)} units exact; differ {badtok_ua[:5]}')
cloud = [u for u in FU if int(u.split('.')[0][1:]) <= 23 and not (u.startswith('U13.') and int(u.split('.')[1]) >= 11)]
cdiff = [u for u in cloud if mask(wording(FU[u][2])) != mask(XU[pair[u]][2])]
rec(S2, 'the 290 cloud units are unchanged apart from identifiers in pointer sentences and the Part G wording of those pointers', not cdiff and all(pair[u] == u for u in cloud) and len(cloud) == 290, f'{len(cloud)} cloud units, identifiers unchanged, text differences {cdiff[:4]}')
# word multiset over all unit bodies
def words(t): return collections.Counter(re.findall(r'[A-Za-z]{3,}', t))
wf = collections.Counter(); wx = collections.Counter()
for u in FU: wf += words(wording(FU[u][2]))
for u in XU: wx += words(XU[u][2])
lost = {w: n - wx[w] for w, n in wf.items() if wx[w] < n}
rec(S2, 'no word is lost: the multiset of words over all unit bodies is contained in the folded one', not lost, f'{sum(wf.values())} words before, {sum(wx.values())} after; lost {dict(list(lost.items())[:5])}')

S3 = '3. Old curriculum to final: end-to-end'
old = open('/home/claude/work/ml/ml_orig.md').read()
oldu = dict((m.group(1), m.group(2).strip()) for m in re.finditer(r'^### (U\d+\.\d+) (.*)$', old, re.M))
h2 = X[X.index('### H.2 '):X.index('### H.3 ')]
rows = [[c.strip() for c in l.strip('|').split('|', 2)] for l in h2.split('\n') if re.match(r'\| [UA]\d', l)]
rows = [r for r in rows if r[0].startswith('U')]
rec(S3, 'H.2 has one row for each of the 160 old units', len(rows) == 160 and len({r[0] for r in rows}) == 160, f'{len(rows)} rows')
bt = [(r[0], r[1]) for r in rows if r[1] not in XU or XU[r[1]][0].strip()[:60] != oldu.get(r[0], '')[:60]]
rec(S3, 'each H.2 row names a final unit whose title is the old unit title', not bt, str(bt[:5]))
newid = [r[1] for r in rows]
rec(S3, 'the 160 final identifiers are all different and 153 of them have an assignment, 7 are capstones', len(set(newid)) == 160 and sum(1 for n in newid if n.startswith('U13.')) == 7, '')
rec(S3, 'cloud unit identifiers never appear as targets of an old unit (no collision), except the capstones in D13', all(r[1].startswith('U13.') or (XU[r[1]][0] not in [FU[u][0] for u in cloud]) for r in rows), '')

S4 = '4. References and wording'
xs = X
allunits = set(XU); allasg = set('A' + u[1:] for u in XU if '**Assignment A%s**' % u[1:] in XU[u][2])
body_end = X.index('# APPENDICES')
h2_start = X.index('### H.2 '); h2_end = X.index('### H.3 ')
scan = X[:h2_start] + X[h2_end:]
scan = re.sub(r'S50 D\d+(?:[,–-] ?D\d+)*', '', scan)
unk_u = sorted({m.group(0) for m in re.finditer(r'\bU(\d+)\.(\d+)\b', scan) if m.group(0) not in allunits and not re.match(r'U\d+\.n', m.group(0))})
rec(S4, 'every unit identifier in the document resolves to a unit (H.2 old column excluded)', not unk_u, str(unk_u[:10]))
unk_a = sorted({m.group(0) for m in re.finditer(r'\bA(\d+)\.(\d+)\b', scan) if m.group(0) not in allasg})
rec(S4, 'every assignment identifier resolves to an assignment', not unk_a, str(unk_a[:10]))
scan_d = re.sub(r'D0 to D18', '', scan)
unk_d = sorted({m.group(0) for m in re.finditer(r'\bD(\d+)\b', scan_d) if not 1 <= int(m.group(1)) <= 33})
rec(S4, 'every domain identifier is D1-D33', not unk_d, str(unk_d[:10]))
def ctx(pat, flags=0): return [X[max(0, m.start() - 120):m.end() + 120].replace('\n', ' ') for m in re.finditer(pat, X, flags)]
pg = [c for c in ctx(r'Part G') if 'capstone' not in c.lower() and 'Integration unit (Part G)' not in c and 'retired' not in c and 'Part G. Capstones' not in c and 'PART G. CAPSTONES' not in c and 'Part G is the capstones' not in c and '(Part G), so all capstones' not in c]
rec(S4, 'the old "Part G" survives only as the capstone Part and in the note that its numbering is retired', not pg, str(pg[:3]))
rec(S4, 'no "Part H", "On demand (Part G)", "Eight parts", "41 domains", "18 domains" or "D24 to D41" wording', not re.search(r'Part H\b|On demand \(Part G\)|Eight parts|41 domains|18 domains|D24 to D41|D24–D41', X), '')
rec(S4, 'no stale statement that the merged units are a separate block ("printed after D14", "never read as a block" as for a Part)', 'printed after D14' not in X, '')
L2 = X.split('\n')
ladder_ok = []
for d in ('D17', 'D18', 'D19', 'D21'):
    m = re.search(r'## %s\. .*?\*\*Reading ladder\*\*[^:]*: (U[^\n]*?)\.\n' % d, X, re.S)
    lad = [t.strip().rstrip('*') for t in m.group(1).split(',')] if m else []
    printed = [u for u in XU if XU[u][1] == d]
    # order of printing: find positions
    pos = {u: X.index('\n### %s ' % u) for u in printed}
    po = sorted(printed, key=lambda u: pos[u])
    ladder_ok.append((d, lad == po))
rec(S4, 'the reading ladder printed in D17, D18, D19 and D21 is the order in which the units are printed', all(ok for _, ok in ladder_ok), str(ladder_ok))
# builds-on inside a domain precede
viol = []
for u, (t, d, txt) in XU.items():
    m = re.search(r'^Builds on ([^\n]*)', txt, re.M)
    if m:
        for p in re.findall(r'U\d+\.\d+', m.group(1)):
            if p in XU and XU[p][1] == d and X.index('\n### %s ' % p) > X.index('\n### %s ' % u): viol.append((u, p))
rec(S4, 'a unit that "Builds on" another unit of its own domain is printed after it', not viol, str(viol[:5]))
# merged units flagged
nofl = [u for u in XU if int(pair_inv[u].split('.')[0][1:]) >= 24 and not re.search(r'^(Bridge for|On demand|Integration unit)', XU[u][2].split('\n', 3)[2] if len(XU[u][2].split('\n')) > 2 else '', re.M)] if False else []
pair_inv = {v: k for k, v in pair.items()}
flag_bad = []
for u in XU:
    fu = pair_inv[u]
    if int(fu.split('.')[0][1:]) >= 24:
        if not re.search(r'^(Bridge for:|On demand:|Integration unit)', XU[u][2], re.M): flag_bad.append(u)
rec(S4, 'every merged unit (153 plus 7 capstones) carries its Bridge for / On demand / Integration line', not flag_bad, str(flag_bad[:5]))
S5 = '5. Coverage, domain map, ledger'
def appB(doc):
    sec = doc[doc.index('## Appendix B.'):doc.index('## Appendix C.')]
    out = {}
    for m in re.finditer(r'(?:^|; |\*\*[A-Z0-9]+\*\*[^:]*: )([A-Za-z0-9]+) → ([^;\n]+)', sec):
        pass
    return sec
secF, secX = appB(F), appB(X)
cells_F = re.findall(r'(\w+) → ((?:U\d+\.\d+(?:, )?)+)', secF); cells_X = re.findall(r'(\w+) → ((?:U\d+\.\d+(?:, )?)+)', secX)
rec(S5, 'Appendix B has the same number of cell entries before and after (1,042)', len(cells_F) == len(cells_X) == 1042, f'{len(cells_F)} -> {len(cells_X)}')
mapcell = lambda s: sorted(pair[u][1:] if False else pair[u] for u in s.split(', ')) 
okc = sum(1 for (a, b), (c, d) in zip(cells_F, cells_X) if a == c and sorted(pair[u] for u in b.split(', ')) == sorted(d.split(', ')))
rec(S5, 'every source cell is cited by the images of the units that cited it before', okc == 1042, f'{okc} of 1042 entries agree')
dmtab = X[X.index('## Domain map'):X.index('## Default order')]
rowsd = re.findall(r'\| (D\d+) [^|]*\| (U\d+\.\d+)–(U\d+\.\d+) \|', dmtab)
okd = 0
for d, a, b in rowsd:
    ns = sorted(int(u.split('.')[1]) for u in XU if XU[u][1] == d)
    okd += (a == 'U%s.%d' % (d[1:], ns[0]) and b == 'U%s.%d' % (d[1:], ns[-1]))
rec(S5, 'the domain map in the front matter lists all 33 domains with their true unit ranges', len(rowsd) == 33 and okd == 33, f'{len(rowsd)} rows, {okd} ranges correct')
led = json.load(open('/home/claude/work/cloud2/merge_ledger.json'))
nd = len(re.findall(r'^\| (?:U\d+\.\d+) \| ', X[X.index('### H.4 '):X.index('### H.5 ')], re.M))
rec(S5, 'the removal ledger H.4 still lists %d removed atoms with identifiers that resolve' % len(led['drops']), nd >= 1, f'{nd} rows')
dem = X[X.index('### H.3 '):X.index('### H.4 ')]
rows3 = re.findall(r'^\| (U\d+\.\d+) [^|]*\| ([^\n]*) \|$', dem, re.M)
rec(S5, 'H.3 lists 86 cloud units with their on-demand targets, all merged units', len(rows3) == 86 and all(all(t in XU for t in re.findall(r'U\d+\.\d+', r[1])) for r in rows3), f'{len(rows3)} rows')
# on-demand lines: each cloud unit's On demand line targets resolve and are merged units
od = re.findall(r'^- \*\*On demand:\*\* ([^\n]*)', X, re.M)
tg = [t for l in od for t in re.findall(r'U\d+\.\d+', l)]
rec(S5, 'the On demand lines of cloud units name %d units, all existing merged units' % len(tg), len(od) == 86 and all(t in XU and pair_inv[t].split('.')[0][1:].isdigit() and int(pair_inv[t].split('.')[0][1:]) >= 24 for t in tg), f'{len(od)} lines, {len(tg)} links')
S6 = '6. Size'
rec(S6, 'the folded document is within 1 % of the size of the document before the fold (folding does not delete)', abs(len(X) - len(F)) / len(F) < 0.01, f'{len(F)} -> {len(X)} bytes ({100*(len(X)-len(F))/len(F):+.2f} %)')

S7 = '7. Index files'
if IC and IM:
    ic = open(IC).read(); im = open(IM).read(); icb = ic[ic.index('\n# Part A'):]; imb = im[im.index('\n## '):]
    ilines = re.findall(r'^- (U\d+\.\d+) (.*)$', ic, re.M)
    printed = []
    for m in re.finditer(r'^### (U\d+\.\d+) ', X[:X.index('# APPENDICES')], re.M): printed.append(m.group(1))
    rec(S7, 'index_cloud.md lists the 450 units once each, in the order they are printed', [u for u, _ in ilines] == printed, f'{len(ilines)} lines')
    rec(S7, 'index_cloud.md titles equal the unit titles of the document', all(t.split(' (bridge)')[0].split(' (merged, on demand)')[0].split(' (capstone)')[0].split(' (old ')[0] == XU[u][0] for u, t in ilines), '')
    rec(S7, 'index_cloud.md marks 150 bridges, 153 merged units and 17 capstones', icb.count('(bridge)') == 150 and icb.count('(merged, on demand)') == 153 and icb.count('(capstone)') == 17, f'{icb.count("(bridge)")} bridges, {icb.count("(merged, on demand)")} merged, {icb.count("(capstone)")} capstones')
    rec(S7, 'index_cloud.md has the 33 domain headings and 7 part headings of the document', len(re.findall(r'^## D\d+\. ', ic, re.M)) == 33 and len(re.findall(r'^# Part ', ic, re.M)) == 7, '')
    mm = re.findall(r'(U\d+\.\d+) → (U\d+\.\d+) ([^\[;\n]*?)(?: \[called by [^\]]*\])?(?:;|$|\n)', imb)
    oldt = dict((m.group(1), m.group(2).strip()) for m in re.finditer(r'^### (U\d+\.\d+) (.*)$', open('/home/claude/work/ml/ml_orig.md').read(), re.M))
    okm = [(o, n) for o, n, t in mm if n in XU and XU[n][0].strip() == oldt[o]]
    rec(S7, 'unified_curriculum_index.md maps all 160 old units to final units with the same title', len(mm) == 160 and len(okm) == 160, f'{len(mm)} entries, {len(okm)} correct')
    h2 = X[X.index('### H.2 '):X.index('### H.3 ')]
    h2rows = dict(re.findall(r'^\| (U\d+\.\d+) \| (U\d+\.\d+) \|', h2, re.M))
    rec(S7, 'the old-to-final map of the ML index equals H.2 of the document', all(h2rows.get(o) == n for o, n, _ in mm) and len(h2rows) == 160, '')
    rec(S7, 'both index files contain no "Part G" except the capstone Part and the retired-numbering note, and no D34-D41', not re.search(r'\bD3[4-9]\b|\bD4[01]\b', ic + im) and 'On demand (Part G)' not in ic + im, '')
npass = sum(1 for r in R if r[2] == 'PASS')
summary = f'{len(R)} fold checks: {npass} pass, {len(R)-npass} fail'
out = ['# Fold audit', '', f'Folded document `{Xp}` against the audited merged document `{Fp}`. ' + summary, '']
cur = None
for s, n, st, d in R:
    if s != cur: out += ['', '## ' + s, '']; cur = s
    out.append(f'- **{st}**: {n}' + (f' ({d})' if d else ''))
open(REP, 'w').write('\n'.join(out) + '\n')
open('fold_audit_summary.txt', 'w').write(summary)
print(summary)
for s, n, st, d in R:
    if st != 'PASS': print(st, '|', n, '|', d[:300])
