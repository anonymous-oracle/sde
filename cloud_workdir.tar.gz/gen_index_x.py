#!/usr/bin/env python3
"""usage: gen_index_x.py X_DOC INDEX_CLOUD.md INDEX_ML.md  (indexes of the folded document)"""
import sys, re, json
sys.path.insert(0, '/home/claude/work/cloud2'); sys.path.insert(0, '/home/claude/work/ml')
import fold_core as C
Xp, IC, IM = sys.argv[1:4]
X = open(Xp).read()
led = json.load(open('/home/claude/work/cloud2/merge_ledger.json'))
OLD2F = {info['old']: f for f, info in led['units'].items()}
OLD2X = {o: C.fid(f) for o, f in OLD2F.items()}
X2OLD = {x: o for o, x in OLD2X.items()}
L = X.split('\n'); end = next(i for i, l in enumerate(L) if l.startswith('# APPENDICES'))
parts, cur_p, cur_d, units = [], None, None, {}
cur_u = None
for l in L[:end]:
    if l.startswith('# PART '): cur_p = dict(title=l[2:], doms=[]); parts.append(cur_p); continue
    m = re.match(r'## (D\d+)\. (.*)', l)
    if m: cur_d = dict(id=m.group(1), title=m.group(2), units=[]); cur_p['doms'].append(cur_d); cur_u = None; continue
    m = re.match(r'### (U\d+\.\d+) (.*)', l)
    if m: cur_u = dict(id=m.group(1), title=m.group(2), first=''); cur_d['units'].append(cur_u); units[cur_u['id']] = cur_u; continue
    if cur_u is not None and not cur_u['first'] and l.strip() and not l.startswith('**Sources:**'): cur_u['first'] = l
nunits = len(units); ndom = sum(len(p['doms']) for p in parts)
nasg = len(re.findall(r'\*\*Assignment A\d+\.\d+\*\*', X))
nbridge = sum(1 for u in units.values() if u['first'].startswith('Bridge for'))
ncap = sum(1 for u in units if u.startswith('U13.'))
PT = {'A': 'Part A. Foundations: the cloud, networks and cloud compute', 'B': 'Part B. Cryptography, security, risk and privacy', 'C': 'Part C. Distributed systems, storage and databases',
      'D': 'Part D. Mathematics and data science foundations: prerequisites, calculus, algorithms, linear algebra, statistics and optimization',
      'E': 'Part E. Machine learning and AI, big data, scalable data science, cloud operations and system design', 'F': 'Part F. Computer architecture and parallel hardware', 'G': 'Part G. Capstones'}
assert ndom == 33 and nunits == 450 and nasg == 433, (ndom, nunits, nasg)
out = ["# Unified Cloud Curriculum: index (merged with the machine-learning curriculum, folded by subject)", "",
 f"Index of `unified_cloud_curriculum.md`, the primary curriculum. Built from the cloud sources (`cloud-computing.txt`, `cloud-computing2.txt`, `dbms.txt`, the System Design Primer, python-patterns and the Gang of Four catalogue, `data-analytics.txt`, `software-engineering.txt`) on 2026-11-05 and 2026-11-06, and, on 2026-11-06, merged completely with the earlier machine-learning curriculum (`unified_curriculum.md`, from `nptel.txt` and `iit-genai.md`) and folded in by subject: its pre-calculus and discrete mathematics are inside D21, its algorithms and complexity inside D17, its linear algebra inside D18, its probability and statistics inside D19; calculus and analysis form D24, optimization D25, and machine learning, reinforcement learning, deep learning, language models, generative models, retrieval and agents, evaluation and safety, and ML systems are D26 to D33 at the start of Part E; its capstones are U13.11 to U13.17. {ndom} domains, {nunits} units, {nasg} assignments (A<d>.<n>, five questions, key collapsed), {nbridge} prerequisite bridges and on-demand units that other units call on, {ncap} capstones. All 1,042 source cells from 79 courses are cited (478 cloud, 564 machine-learning). The merged units are never read as a block: each cloud unit that needs one carries an *On demand* line, and each merged unit that is called on starts with a *Bridge for:* line (map in Appendix H.3 of the file). Cloud identifiers did not change. Where a domain holds both cloud and merged units, the units are printed on a reading ladder (in the domain introduction), so unit numbers inside such a domain are not in print order: D17, D18, D19 and D21 list their units below in the order printed. D15 (database systems) is printed between D9 and D10; D21, D24, D17, D23, D18, D19 and D25 between D10 and Part E; D26 to D33 before D11; D20 after D11; D22 and D16 after D12; D14 before the capstones (D13), which stay together at the end. The old identifiers of the merged units are shown as (old …); the full map is Appendix H.2.", "",
 "Bridge units are marked (bridge). Merged units are marked (merged, on demand). Capstones carry no assignment.", ""]
for p in parts:
    out += ['# ' + PT[re.match(r'PART (\w)\.', p['title']).group(1)], '']
    for d in p['doms']:
        out += [f"## {d['id']}. {d['title']}", '']
        for u in d['units']:
            tags = ''
            if u['first'].startswith('Bridge for'): tags += ' (bridge)'
            if u['id'].startswith('U13.'): tags += ' (capstone)'
            if u['id'] in X2OLD and not u['id'].startswith('U13.'): tags += ' (merged, on demand)'
            old = f" (old {X2OLD[u['id']]})" if u['id'] in X2OLD else ''
            out.append(f"- {u['id']} {u['title']}{tags}{old}")
        out.append('')
open(IC, 'w').write('\n'.join(out))

# ---- the machine-learning index: old structure -> final identifiers
import mlparse
ml = ["# Unified Curriculum: index and resume point (updated 2026-11-06: merged into `unified_cloud_curriculum.md`, folded by subject)", "",
 f"**Status: superseded.** `unified_curriculum.md` (the machine-learning curriculum) has been merged completely into `unified_cloud_curriculum.md`, which is now the primary curriculum; its index is `index_cloud.md`. Nothing was dropped: all 160 units, 153 assignments and 564 source cells are in the merged file, folded into the domains of their subject and entered on demand from the cloud units that need them; the capstones are U13.11 to U13.17. The identifiers changed; this file maps the old ones to the new. The old document, `unified_curriculum.md`, is kept for reference, unchanged apart from a banner at its top.", "",
 "**New identifiers:** old D0 (pre-calculus) and D1 (discrete mathematics) are units U21.7 to U21.18 of D21; old D2, D3 and D7 (calculus, multivariable calculus, differential equations and numerics) are D24 (U24.1 to U24.17); old D4 (linear algebra) is U18.14 to U18.24 of D18; old D5 and D6 (probability, statistics) are U19.18 to U19.32 of D19; old D17 (approximation algorithms and complexity) is U17.18 to U17.24 of D17; old D8 (optimization) is D25; old D9 to D16 (machine learning, bandits and reinforcement learning, deep learning, language models, generative models, retrieval and agents, evaluation and safety, ML systems) are D26 to D33; the capstones U18.1 to U18.7 are U13.11 to U13.17 in the cloud capstone domain D13. Assignments follow their units (A5.1 is A19.18). Where two units taught the same ground, the cloud unit owns it and the merged unit says so (Appendix H.4 lists the %d atoms removed, G.2 the pairs kept on purpose)." % len(led['drops']), "",
 "**Resume point:** U1.1 of the merged curriculum (the cloud curriculum's first unit); nothing has been taught yet. Merged units are opened only when a cloud unit's *On demand* line sends you there (for example U18.4 → U18.19 to U18.21 and U26.8), or when you choose to study a subject for its own sake along the reading ladder in the domain introduction or the order given in the default-order section of the merged file. **Open decisions:** Appendix D.3 of the merged file (items 17 to 21 carry the open decisions of this curriculum: official-assignment downloads, gap candidates, truncated sources, inferred titles).", "",
 "**Standing instructions recorded (nptel.txt and chat, 2026-11-03 and 2026-11-06):** (1) learn every technique from scratch in Python, with NumPy as the default toolbox; a guideline, not a prohibition. (2) NPTEL-style assignments for every unit; create them where NPTEL provides none. (3) \"add a pre calculus bridge to be taught on demand. I am a trigonometry and complex numbers noob\" (now U21.7 to U21.11). (4) 2026-11-06: \"The cloud curriculum is the primary curriculum. To it, merge the other ml curriculum completely ... whenever some concept is required from the other ml curriculum, it should be taught on demand. But ensure that topics are deduped and unified.\" (5) 2026-11-06, after the first merge: \"Fold by subject but in addition, ensure that all topics still remain in the file. The only requirement here is that the cloud curriculum file is the primary curriculum and the other file is taught on demand but is folded by subject.\" All five are recorded in the course profile of the merged file.", ""]
PARTSML = {}
for d in mlparse.domains: PARTSML.setdefault(d['part'], []).append(d)
dommap = {}
for part, ds in PARTSML.items():
    ml += [f"## {part.title() if part.isupper() else part}", '']
    for d in ds:
        items = []
        xs = set()
        for u in d['units']:
            x = OLD2X[u['id']]; xs.add(x.split('.')[0][1:])
            f = OLD2F[u['id']]; call = led['units'][f]['callers']
            items.append(f"{u['id']} → {x} {u['title']}" + (f" [called by {', '.join(call)}]" if call else ''))
        where = ', '.join('D' + s for s in sorted(xs, key=int))
        ml += [f"**{d['id']} → {where}. {d['title']}**", '; '.join(items), '']
open(IM, 'w').write('\n'.join(ml))
print(ndom, nunits, nasg, nbridge, ncap)
