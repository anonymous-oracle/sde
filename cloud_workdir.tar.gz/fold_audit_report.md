# Fold audit

Folded document `X_final.md` against the audited merged document `F_doc.md`. 41 fold checks: 41 pass, 0 fail


## 1. Counts and structure

- **PASS**: unit counts equal (450 before and after) (450 -> 450)
- **PASS**: 33 domains D1-D33, each once, 7 parts (33 domains, 7 parts)
- **PASS**: every unit sits in the domain that its identifier names ([])
- **PASS**: unit numbers contiguous inside each domain (D26 starts at U26.0) ([])
- **PASS**: 433 assignments before and after, 433 collapsed key blocks (433 -> 433; key blocks 433)
- **PASS**: every assignment id equals its unit id
- **PASS**: 17 capstones U13.1-U13.17, all in D13, no assignment (17)

## 2. The fold lost nothing and changed nothing but identifiers and wording

- **PASS**: unit titles are unique in both documents, so a unit can be paired by title (450 / 450 distinct titles)
- **PASS**: every unit (text, results, assignment and key) is identical before and after, up to identifiers and the listed rewording (450 identical, 0 differ [])
- **PASS**: the identifier map derived from the title pairing equals the stated scheme (offsets per old domain) ([])
- **PASS**: each old (first-pass) domain lands in exactly one final domain ({})
- **PASS**: every unit and assignment identifier inside a unit is the image of the old one under the derived map (token by token, in order) (450 units exact; differ [])
- **PASS**: the 290 cloud units are unchanged apart from identifiers in pointer sentences and the Part G wording of those pointers (290 cloud units, identifiers unchanged, text differences [])
- **PASS**: no word is lost: the multiset of words over all unit bodies is contained in the folded one (216110 words before, 216110 after; lost {})

## 3. Old curriculum to final: end-to-end

- **PASS**: H.2 has one row for each of the 160 old units (160 rows)
- **PASS**: each H.2 row names a final unit whose title is the old unit title ([])
- **PASS**: the 160 final identifiers are all different and 153 of them have an assignment, 7 are capstones
- **PASS**: cloud unit identifiers never appear as targets of an old unit (no collision), except the capstones in D13

## 4. References and wording

- **PASS**: every unit identifier in the document resolves to a unit (H.2 old column excluded) ([])
- **PASS**: every assignment identifier resolves to an assignment ([])
- **PASS**: every domain identifier is D1-D33 ([])
- **PASS**: the old "Part G" survives only as the capstone Part and in the note that its numbering is retired ([])
- **PASS**: no "Part H", "On demand (Part G)", "Eight parts", "41 domains", "18 domains" or "D24 to D41" wording
- **PASS**: no stale statement that the merged units are a separate block ("printed after D14", "never read as a block" as for a Part)
- **PASS**: the reading ladder printed in D17, D18, D19 and D21 is the order in which the units are printed ([('D17', True), ('D18', True), ('D19', True), ('D21', True)])
- **PASS**: a unit that "Builds on" another unit of its own domain is printed after it ([])
- **PASS**: every merged unit (153 plus 7 capstones) carries its Bridge for / On demand / Integration line ([])

## 5. Coverage, domain map, ledger

- **PASS**: Appendix B has the same number of cell entries before and after (1,042) (1042 -> 1042)
- **PASS**: every source cell is cited by the images of the units that cited it before (1042 of 1042 entries agree)
- **PASS**: the domain map in the front matter lists all 33 domains with their true unit ranges (33 rows, 33 ranges correct)
- **PASS**: the removal ledger H.4 still lists 76 removed atoms with identifiers that resolve (76 rows)
- **PASS**: H.3 lists 86 cloud units with their on-demand targets, all merged units (86 rows)
- **PASS**: the On demand lines of cloud units name 196 units, all existing merged units (86 lines, 196 links)

## 6. Size

- **PASS**: the folded document is within 1 % of the size of the document before the fold (folding does not delete) (2116432 -> 2123025 bytes (+0.31 %))

## 7. Index files

- **PASS**: index_cloud.md lists the 450 units once each, in the order they are printed (450 lines)
- **PASS**: index_cloud.md titles equal the unit titles of the document
- **PASS**: index_cloud.md marks 150 bridges, 153 merged units and 17 capstones (150 bridges, 153 merged, 17 capstones)
- **PASS**: index_cloud.md has the 33 domain headings and 7 part headings of the document
- **PASS**: unified_curriculum_index.md maps all 160 old units to final units with the same title (160 entries, 160 correct)
- **PASS**: the old-to-final map of the ML index equals H.2 of the document
- **PASS**: both index files contain no "Part G" except the capstone Part and the retired-numbering note, and no D34-D41
