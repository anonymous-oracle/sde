import re, collections
def dnew(k):
    return 'D%d' % (k + 24) if k <= 17 else 'D13'
def unew(a, b):
    return 'U%d.%d' % (a + 24, b) if a <= 17 else 'U13.%d' % (10 + b)
def anew(a, b):
    return 'A%d.%d' % (a + 24, b) if a <= 17 else 'A13.%d' % (10 + b)
PAT = re.compile(r'\b(U|A)(\d+)\.(\d+)\b|\bD(\d+)\b')
nrewrites = collections.Counter()
def remap(text):
    def f(m):
        if m.group(4) is not None:
            nrewrites['D'] += 1
            return dnew(int(m.group(4)))
        a, b = int(m.group(2)), int(m.group(3))
        nrewrites[m.group(1)] += 1
        return (unew if m.group(1) == 'U' else anew)(a, b)
    return PAT.sub(f, text)
