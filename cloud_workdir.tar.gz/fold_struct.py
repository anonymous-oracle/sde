"""Rearrangement of the parsed document by subject (all identifiers here are F-space; fx runs later)."""
import re, collections
LADDER = {
 'D21': ['U21.1','U21.2','U24.1','U24.2','U24.3','U24.4','U24.5','U21.3','U21.4','U25.1','U25.2','U25.3','U21.5','U25.4','U25.5','U25.6','U25.7','U21.6'],
 'D17': ['U17.%d' % i for i in range(1, 18)] + ['U41.%d' % i for i in range(1, 8)],
 'D18': ['U18.1','U28.1','U18.2','U18.3','U28.2','U28.3','U28.4','U28.5','U18.4','U28.6','U28.7','U28.8','U18.5','U28.9','U28.10','U18.6','U18.7','U18.8','U28.11','U18.9','U18.10','U18.11','U18.12','U18.13'],
 'D19': ['U19.1','U19.2','U30.1','U19.3'] + ['U29.%d' % i for i in range(1, 10)] + ['U19.4','U30.2','U19.5','U30.3','U19.6','U19.7','U30.4','U19.8','U19.9','U19.10','U19.11','U19.12','U19.13','U19.14','U30.5','U19.15','U19.16','U19.17','U30.6'],
}
# absorbed F domains per X domain (X domains are named by an F domain id while the model is in F space)
ABSORB = {'D21': ['D24', 'D25'], 'D17': ['D41'], 'D18': ['D28'], 'D19': ['D29', 'D30'], 'D26': ['D27', 'D31']}   # D26 stands for the new calculus domain D24 of the final numbering
# final part layout (F ids of the domains, in print order)
LAYOUT = [
 ('PART A. FOUNDATIONS: THE CLOUD, NETWORKS AND CLOUD COMPUTE', ['D1', 'D2', 'D3', 'D4']),
 ('PART B. CRYPTOGRAPHY, SECURITY, RISK AND PRIVACY', ['D5', 'D6', 'D7', 'D8']),
 ('PART C. DISTRIBUTED SYSTEMS, STORAGE AND DATABASES', ['D9', 'D15', 'D10']),
 ('PART D. MATHEMATICS AND DATA SCIENCE FOUNDATIONS: PREREQUISITES, CALCULUS, ALGORITHMS, LINEAR ALGEBRA, STATISTICS AND OPTIMIZATION', ['D21', 'D26', 'D17', 'D23', 'D18', 'D19', 'D32']),
 ('PART E. MACHINE LEARNING AND AI, BIG DATA, SCALABLE DATA SCIENCE, CLOUD OPERATIONS AND SYSTEM DESIGN', ['D33', 'D34', 'D35', 'D36', 'D37', 'D38', 'D39', 'D40', 'D11', 'D20', 'D12', 'D22', 'D16']),
 ('PART F. COMPUTER ARCHITECTURE AND PARALLEL HARDWARE', ['D14']),
 ('PART G. CAPSTONES', ['D13']),
]
def fold(parts, doms):
    unit = {u['id']: u for d in doms.values() for u in d['units']}
    newdoms = {}
    for fid, d in doms.items():
        newdoms[fid] = dict(id=fid, title=d['title'], intro=list(d['intro']), units=list(d['units']), absorbed=[])
    # hosts
    for host, absorbed in ABSORB.items():
        h = newdoms[host]
        for a in absorbed:
            h['absorbed'].append(dict(doms[a]))
        allu = list(h['units'])
        for a in absorbed: allu += doms[a]['units']
        if host in LADDER:
            ids = LADDER[host]
            assert sorted(ids) == sorted(u['id'] for u in allu), (host, set(ids) ^ {u['id'] for u in allu})
            h['units'] = [unit[i] for i in ids]
        else:   # new calculus domain: its own domain D26 plus D27 and D31 in that order
            h['units'] = list(doms['D26']['units']) + list(doms['D27']['units']) + list(doms['D31']['units'])
    gone = {a for ab in ABSORB.values() for a in ab}
    newparts = []
    seen = set()
    for title, ids in LAYOUT:
        p = dict(title=title, intro=[], doms=[])
        for i in ids:
            p['doms'].append(newdoms[i]); seen.add(i)
        newparts.append(p)
    assert seen | gone == set(doms), set(doms) - seen - gone
    return newparts, newdoms
