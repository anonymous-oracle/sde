"""Cell table for cloud-computing2.txt (6 computer-architecture course outlines)."""
SRC = open('/home/claude/work/cloud/src2.txt').read().split('\n')
def R(a, b=None): return list(range(a, (b or a) + 1))
COURSES = {}
def course(key, title, who, cells, pre=None, books=None, note=''):
    COURSES[key] = dict(title=title, who=who, cells=cells, pre=pre or [], books=books or [], note=note)
course('MCA', 'Multi-Core Computer Architecture', 'John Jose, IIT Guwahati (NPTEL 106103184)',
       {'o': R(18), **{f'W{i}': R(29 + i) for i in range(1, 13)}}, pre=R(23), books=R(43, 45))
course('CAO', 'Computer Architecture and Organization', 'Indranil Sengupta and Kamalika Datta, IIT Kharagpur (NPTEL 106105163)',
       {'o': R(64, 65), **{f'W{i}': R(76 + i) for i in range(1, 13)}}, pre=R(69), books=R(90, 94),
       note='Week 11 is titled "Instruction Set Pipelining" (instruction pipelining is meant)')
course('CA', 'Computer Architecture', 'Smruti Ranjan Sarangi, IIT Delhi (NPTEL 106102157)',
       {'o': R(113), **{f'W{i}': R(124 + i) for i in range(1, 13)}}, pre=R(117), books=R(138))
course('ACA', 'Advanced Computer Architecture', 'Smruti R. Sarangi, IIT Delhi',
       {'o': R(151, 156), **{f'W{i}': R(157 + i) for i in range(1, 13)}}, pre=R(144, 147))
course('PCA', 'Parallel Computer Architecture', 'Hemangee K. Kapoor, IIT Guwahati',
       {'o': R(179, 189), 'W1': R(203), 'W2': R(204), 'W3': R(205), 'W4': R(206), 'W5': R(207, 208), 'W6': R(209),
        'W7': R(210), 'W8': R(211), 'W9': R(212), 'W10': R(213), 'W11': R(214), 'W12': R(215)}, pre=R(175),
       note='lines 190-201 are an instructor biography, not course content')
course('GPU', 'GPU Architectures and Programming', 'Soumyajit Dey, IIT Kharagpur',
       {'o': R(225, 233), 'W1': R(235, 236), 'W2': R(237), 'W3': R(238), 'W4': R(239), 'W5': R(240), 'W6': R(241),
        'W7': R(242), 'W8': R(243), 'W9': R(244), 'W10': R(245), 'W11': R(246), 'W12': R(247)}, pre=R(221))
def cell_text(k, c): return ' '.join(SRC[i - 1].strip() for i in COURSES[k]['cells'][c])
if __name__ == '__main__':
    n = 0
    for k, c in COURSES.items():
        for cid in c['cells']:
            n += 1; print(f"{k}:{cid:4s} {cell_text(k, cid)[:95]}")
    print('cells', n)
