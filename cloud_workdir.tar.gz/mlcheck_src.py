"""Cell texts of the machine-learning source files (nptel.txt, iit-genai.md)."""
import re, sys
sys.path.insert(0, '/home/claude/work/ml')
import mlsrc
NP = open('/mnt/user-data/uploads/sde/nptel.txt').read().split('\n')
GN = open('/mnt/user-data/uploads/sde/iit-genai.md').read().split('\n')
def rng(k):
    s = mlsrc.COURSES[k]['lines'].replace('–', '-')
    a, _, b = s.partition('-'); a = int(a); b = int(b or a)
    return a, b
def course_text(k):
    a, b = rng(k)
    return '\n'.join((GN if k == 'GEN' else NP)[a - 1:b])
WK = re.compile(r'(?i)\b(?:week|wk)\s*[-:]?\s*0?(\d+)\s*(?:[:\-–.]|\t)?')
def split_weeks(k):
    t = course_text(k)
    ms = list(WK.finditer(t))
    cells = {}
    if ms: cells['o'] = t[:ms[0].start()]
    else: cells['o'] = t
    for i, m in enumerate(ms):
        end = ms[i + 1].start() if i + 1 < len(ms) else len(t)
        c = 'W' + m.group(1)
        cells[c] = cells.get(c, '') + '\n' + t[m.end():end]
    return cells
def gen_sections():
    cells = {}; cur = None
    for l in GN:
        m = re.match(r'^(\d+\.\d+) (.*)', l)
        if m: cur = m.group(1); cells[cur] = m.group(2); continue
        if re.match(r'^#+ ', l) or l.startswith('---'): cur = None if l.startswith('#') else cur; continue
        if cur and l.strip(): cells[cur] += '\n' + l
    return cells
GENC = gen_sections()
_cache = {}
def text_of(k, c):
    k = 'DM' if k == 'DMK' else k
    """returns (text, how) where how is 'cell' or 'course' (fallback)"""
    if k == 'GEN':
        return (GENC[c], 'cell') if c in GENC else (None, None)
    if k not in _cache: _cache[k] = split_weeks(k)
    d = _cache[k]
    if c in d and d[c].strip(): return d[c], 'cell'
    return course_text(k), 'course'

def _cvx():
    a, b = rng('CVX'); d = {}
    for l in NP[a - 1:b]:
        m = re.match(r'^(\d+)\s+(.*)', l)
        if m: d[int(m.group(1))] = m.group(2)
    return d
CVXL = _cvx()
def _s50():
    a, b = rng('S50'); d = {}; cur = None
    for l in NP[a - 1:b]:
        m = re.match(r'^\s*(\d+)\.\s+(.*)', l)
        if m: cur = 'D' + m.group(1); d[cur] = m.group(2); continue
        if cur and l.strip(): d[cur] += '\n' + l
    return d
S50D = _s50()
_old = text_of
def text_of(k, c):
    k = 'DM' if k == 'DMK' else k
    if k == 'CVX':
        m = re.fullmatch(r'L(\d+)-(\d+)', c)
        if m: return '\n'.join(CVXL[i] for i in range(int(m.group(1)), int(m.group(2)) + 1) if i in CVXL), 'cell'
    if k == 'S50' and c in S50D: return S50D[c], 'cell'
    if k == 'IM' and c == 'A':
        a, b = rng('IM'); return NP[b - 1], 'cell'
    return _old(k, c)
