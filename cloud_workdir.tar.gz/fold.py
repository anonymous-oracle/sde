#!/usr/bin/env python3
"""usage: fold.py F_DOC OUT_DOC
Folds the audited merged document (F space: cloud parts plus a separate Part G) into the final document, by subject."""
import sys, re, os, json, collections
sys.path.insert(0, '/home/claude/work/cloud2')
import fold_core as C, fold_struct as S, fold_rw as W
from fold_text import GENERIC
Fpath, OUT = sys.argv[1], sys.argv[2]
F = open(Fpath).read()
front, parts, doms, appx = C.parse(F)
newparts, newdoms = S.fold(parts, doms)

# ------------------------------------------------ titles and introductions of the merged domains (F space)
TITLE = {
 'D21': 'On-demand prerequisites: school mathematics, pre-calculus (functions, trigonometry, complex numbers), Python, scientific Python (in place of R), proofs, discrete mathematics, graph theory and probability from first principles',
 'D26': 'Calculus and analysis, taught on demand: single-variable and multivariable calculus, differential equations, dynamical systems, numerical methods, complex analysis and transforms',
 'D17': 'Algorithms and data structures, taught on demand: analysis, divide and conquer, sorting, hashing, trees, amortisation, greedy and dynamic programming, graph search, shortest paths, network flow, tries, B-trees, string matching, hard problems, NP-completeness and approximation algorithms',
 'D18': 'Linear algebra, core, abstract, numerical and applied: vectors, matrices, vector spaces, eigenvalues, canonical forms, the SVD, least squares, estimation, recommenders, the DFT and OFDM, dynamical systems, clustering, perceptrons, compressive sensing and Markov chains',
 'D19': 'Probability, statistics, data mining and Bayesian analysis: from probability, random variables and limit theorems to sampling, testing, regression, clustering, trees, association rules, classification, Bayesian inference, MCMC, model comparison and forecasting',
}
def rng(units):
    ids = [u['id'] for u in units]
    return '%s–%s' % (ids[0], ids[-1])
def block(host_title, d):
    txt = '\n'.join(d['intro']).strip()
    return '**%s (%s).** %s' % (host_title, rng(d['units']), txt)
for d in newdoms.values():
    if d['id'] in TITLE: d['title'] = TITLE[d['id']]
    if d['id'] == 'D26':
        names = [('Single-variable calculus and real analysis', doms['D26']), ('Multivariable and vector calculus', doms['D27']),
                 ('Differential equations, dynamical systems, numerical methods, complex analysis and transforms', doms['D31'])]
        d['intro'] = ['', 'Aim: the calculus and applied-analysis toolkit that optimization, probability, signal processing and learning theory use, folded from the earlier machine-learning curriculum into one domain by subject: single-variable calculus and real analysis, then calculus in several variables, then differential equations, numerical methods, complex analysis and transforms. It is **on demand**: a unit is opened from a Bridge for or On demand line, or when you choose to study the subject for its own sake; the units below keep their sources and benchmarks.', '']
        for t, dd in names:
            d['intro'] += [block(t, dd), '']
    elif d['absorbed']:
        ladder = ', '.join(u['id'] + ('*' if int(u['id'][1:].split('.')[0]) >= 24 else '') for u in d['units'])
        added = ' and '.join('%s (%s)' % (a['title'], rng(a['units'])) for a in d['absorbed'])
        d['intro'] = list(d['intro']) + ['', '**Merged units, folded in by subject.** This domain also holds the units of %s from the earlier machine-learning curriculum, marked * below. They are on demand: each begins with a **Bridge for:** or **On demand:** line, and the cloud unit owns every topic that both teach. **Reading ladder** (the order of study when you take the subject for its own sake; compact cloud units stand beside the merged units that go deeper): %s.' % (added, ladder), '']
        for a in d['absorbed']:
            d['intro'] += [block(a['title'], a), '']
for d in newdoms.values():
    if d['id'] in ('D26', ) or d['absorbed'] or True:
        d['intro'] = list(d['intro'])

# ------------------------------------------------ the front matter: new item 8, domain map placeholder
def apply(rws, text, name):
    for r in rws:
        if r['new'] == r['old'] and not r['regex']:   # anchor only
            continue
        if r['regex']:
            n = len(re.findall(r['old'], text, r['flags']))
            assert n == r['count'], (name, r['old'][:70], n)
            text = re.sub(r['old'], lambda m, r=r: r['new'], text, flags=r['flags'])
        else:
            n = text.count(r['old'])
            assert n == r['count'], (name, r['old'][:70], n)
            text = text.replace(r['old'], r['new'])
    return text
ITEM8 = ("8. **Merged units: how they are entered and who owns what.** The units folded in from the earlier machine-learning curriculum are on demand. A cloud unit that needs something from them carries an **On demand** line naming the units, and each such merged unit begins with a **Bridge for:** line naming the cloud units that call on it: take the named unit, then return to the exact point you left. A merged unit that no cloud unit calls on says so in its **On demand:** line and names the units it builds on. Where a merged unit and a cloud unit teach the same ground, the cloud unit owns it: the merged unit says which cloud units it shares ground with, lists the atoms removed because the cloud unit already teaches them, and keeps only what goes further (the proofs, the abstract setting, the extra cases). The same-subject pairs that remain on purpose, a compact or applied cloud unit with the full theory beside it, are declared in Appendix G.2 and Appendix H.5; every removal is in Appendix H.4.")
m = re.search(r'(7\. \*\*Honesty conventions\.\*\*[^\n]*\n)', front)
assert m
front = front.replace(m.group(1), m.group(1) + ITEM8 + '\n')
# domain map table in front -> placeholder
mt = re.search(r'(\| Part \| Domain \| Units \| Absorbs mainly \|\n(?:\|.*\n)+)', front)
assert mt
front = front.replace(mt.group(1), '__DOMAIN_MAP__\n')
front = apply(W.FRONT, front, 'front')

for p in newparts: p['intro'] = ['']
body, _ = C.emit('', newparts, '')
body = body.replace('\n# PART ', '\n\n# PART ')
body = apply(W.BODY, body, 'body')
# the F-space part title lines contain no ids; emit wrote '# PART ...'
# appendices: split H.2
a0 = appx.index('### H.2 '); a1 = appx.index('### H.3 ')
h2_old = appx[a0:a1]
appx = appx[:a0] + '__H2__\n\n' + appx[a1:]
appx = apply(W.APPX, appx, 'appx')

def generic(t):
    for a, b in GENERIC: t = re.sub(a, b, t)
    t = re.sub(r'(U\d+\.\d+(?: and U\d+\.\d+)*) \(Part G\)', r'\1', t)
    return t
front, body, appx = generic(front), generic(body), generic(appx)
front, body, appx = C.fx(front), C.fx(body), C.fx(appx)
front, body, appx = C.unat(front), C.unat(body), C.unat(appx)

# ------------------------------------------------ X-space generation: domain map
def srcs(d):
    cnt = collections.Counter()
    for u in d['units']:
        for l in u['lines']:
            if l.startswith('**Sources:**'):
                for it in l[len('**Sources:**'):].split(';'):
                    it = it.strip()
                    mk = re.match(r'([A-Z][A-Z0-9]+)\b', it)
                    if mk and not it.startswith('none'): cnt[mk.group(1)] += 1
    return cnt
SHORTP = ['A. Foundations', 'B. Cryptography and security', 'C. Distributed systems and storage', 'D. Mathematics and data science foundations', 'E. Machine learning and AI, big data, scalable data science, cloud operations and system design', 'F. Computer architecture and parallel hardware', 'G. Capstones']
dm = ['| Part | Domain | Units | Absorbs mainly |', '|---|---|---|---|']
for (t, _), p, sp in zip(S.LAYOUT, newparts, SHORTP):
    first = True
    for d in p['doms']:
        xid = 'D%d' % C.mapD(int(d['id'][1:]))
        us = sorted(d['units'], key=lambda u: (int(C.fid(u['id'])[1:].split('.')[0]), int(C.fid(u['id']).split('.')[1])))
        a, b = C.fid(us[0]['id']), C.fid(us[-1]['id'])
        cnt = srcs(d)
        for ab in d.get('absorbed', []):
            cnt += srcs(ab)
        if d['id'] in ('D13', 'D23'): ab_s = 'none (assembles all)'
        else:
            top = [k for k, v in cnt.most_common() if v >= 2] or [k for k, _ in cnt.most_common(3)]
            ab_s = ', '.join(top) or 'none (assembles all)'
            if d['id'] == 'D21': ab_s = 'none for the cloud bridges; ' + ', '.join(top) + ' for the merged units'
        short = d['title'].split(':')[0]
        dm.append('| %s | %s %s | %s–%s | %s |' % (sp if first else '', xid, short, a, b, ab_s)); first = False
domain_map = '\n'.join(dm)
front = front.replace('__DOMAIN_MAP__', domain_map)

# ------------------------------------------------ H.2: old -> final
rows = [l for l in h2_old.split('\n') if l.startswith('| U') or l.startswith('| A')]
H2 = ['### H.2 Identifier map: old (machine-learning curriculum) to final', '',
 'Cloud identifiers did not change. The units of the earlier machine-learning curriculum were folded into the domains of their subject; the capstones U18.n are U13.(10+n) in D13. Old domains: D0 → D21 (pre-calculus, U21.7 to U21.11), D1 → D21 (discrete mathematics, U21.12 to U21.18), D2 → D24 (U24.1 to U24.5), D3 → D24 (U24.6 to U24.10), D4 → D18 (U18.14 to U18.24), D5 → D19 (U19.18 to U19.26), D6 → D19 (U19.27 to U19.32), D7 → D24 (U24.11 to U24.17), D8 → D25, D9 → D26, D10 → D27, D11 → D28, D12 → D29, D13 → D30, D14 → D31, D15 → D32, D16 → D33, D17 → D17 (U17.18 to U17.24), D18 → D13 (capstones). Assignments follow their units (A5.1 is A19.18). An earlier printing of this merge, made the same day, put these units in a separate Part G numbered U24.x to U41.x; those identifiers are retired.', '',
 '| Old | New | Title |', '|---|---|---|']
for r in rows:
    c = [x.strip() for x in r.strip('|').split('|', 2)]
    if c[0] in ('Old', '---'): continue
    H2.append('| %s | %s | %s |' % (c[0], C.fx(c[1]), c[2]))
H2.append('')
appx = appx.replace('__H2__', '\n'.join(H2))

# H.1 new bullet, H.6
nb = ("- **Fold by subject.** In a second pass the same day, on standing instruction (17), the merged units were moved out of a separate Part into the domains of their subject, without removing a topic. Pre-calculus and discrete mathematics joined D21 (U21.7 to U21.18), approximation algorithms and complexity joined D17 (U17.18 to U17.24), linear algebra joined D18 (U18.14 to U18.24), probability and statistics joined D19 (U19.18 to U19.32); calculus, differential equations, numerical methods, complex analysis and transforms became D24 (U24.1 to U24.17), optimization became D25, and machine learning through ML systems became D26 to D33, at the start of Part E. Cloud identifiers did not change. Inside each host domain the units are printed on a reading ladder (given in the domain introduction) that sets each compact cloud unit beside the merged unit that goes deeper; unit numbers follow the order of merging, not the ladder. The document stays at about 2 MB because the two curricula overlap little (the largest wording overlap between any cloud unit and any merged unit is under 50 %, nearly all pairs are under 35 %): folding changes where a unit stands, not how much there is to teach.\n")
anchor = '- **On demand.**'
assert appx.count(anchor) == 1
appx = appx.replace(anchor, nb + anchor)
h6_0 = appx.index('### H.6 ')
fa = open('/home/claude/work/cloud2/fold_audit_summary.txt').read().strip() if os.path.exists('/home/claude/work/cloud2/fold_audit_summary.txt') else 'not yet run'
fs = open('/home/claude/work/cloud2/audit_summary.txt').read().strip()
H6 = ("### H.6 Audit\n\nThe audit of this merge is delivered as `merge_audit_report.md`. It has two parts. First, the 63 checks of the first merge (counts, identifier and reference checks, coverage, the dedupe ledger re-verified against the owners, the assignments, stale-wording scans and the limitations), run on the merged document before the fold: " + fs + ". Second, the fold audit, which pairs every unit before and after by title and checks that text, assignment and keys are identical apart from identifiers and the rewritten wording, that no unit or assignment was lost or duplicated, that every identifier resolves, that no wording of the old separate Part remains, and that the indexes agree: " + fa + ".\n")
appx = appx[:h6_0] + H6

# ------------------------------------------------ assemble
doc = front.rstrip('\n') + '\n\n' + body.lstrip('\n').rstrip('\n') + '\n\n---\n\n' + appx.lstrip('\n')
open(OUT, 'w').write(doc)
print('folded:', len(doc), 'bytes;', doc.count('\n### U'), 'units;', len(re.findall(r'^## D\d+\. ', doc, re.M)), 'domains')
