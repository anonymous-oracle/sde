#!/usr/bin/env python3
"""Audit of the ML -> cloud merge.  usage: audit.py MERGED.md INDEX_CLOUD.md INDEX_ML.md REPORT.md"""
import sys, re, glob, json, subprocess, collections, math, os, difflib
sys.path.insert(0, '/home/claude/work/cloud2'); sys.path.insert(0, '/home/claude/work/ml')
import build as B, mlload, mlparse, mlsrc, ledger2
from idmap import remap, unew, anew
from demand import DEMAND
DOC, IDXC, IDXM, REPORT = sys.argv[1:5]
T = open(DOC).read(); L = T.split('\n')
ml_orig = open('/home/claude/work/ml/ml_orig.md').read()
led = json.load(open('merge_ledger.json'))
R = []   # (section, check, status, detail)
def rec(sec, name, ok, detail='', warn=False):
    R.append((sec, name, 'PASS' if ok else ('WARN' if warn else 'FAIL'), detail))
    return ok

# ---------- parse the merged document ----------
app = next(i for i, l in enumerate(L) if l.startswith('# APPENDICES'))
body = L[:app]
units = collections.OrderedDict(); order = []
cur = None; dom = None; doms = []
for i, l in enumerate(body):
    if l.startswith('# PART'): cur = None; continue
    m = re.match(r'^## (D\d+)\. (.*)', l)
    if m: dom = m.group(1); doms.append(dom); cur = None; continue
    m = re.match(r'^### (U\d+\.\d+) (.*)', l)
    if m:
        cur = m.group(1); assert cur not in units, cur
        units[cur] = dict(title=m.group(2), dom=dom, lines=[], line=i); order.append(cur); continue
    if cur: units[cur]['lines'].append(l)
parts = [l for l in body if l.startswith('# PART')]
def utext(u): return '\n'.join(units[u]['lines'])
def first(u):
    for l in units[u]['lines']:
        if l.strip() and not l.startswith('**Sources:**'): return l
    return ''
def split_assign(u):
    t = utext(u); i = t.find('**Assignment A')
    return (t[:i], t[i:]) if i >= 0 else (t, '')
cloud_units, _, _ = B.load_units(sorted(glob.glob('units/*.md')))
CID = [u.uid for u in cloud_units]
mu, mdoms = mlload.load_ml()
MID = [u.uid for u in mu]
old_units = {u['id']: u for d in mlparse.domains for u in d['units']}
OLD2NEW = {v['old']: n for n, v in led['units'].items()}

# ===== 1. counts =====
S1 = '1. Counts and structure'
nA = len(re.findall(r'^\*\*Assignment A\d+\.\d+\*\*', '\n'.join(body), re.M))
nKey = len(re.findall(r'^<details><summary>Key for A', '\n'.join(body), re.M))
caps = [u for u in order if u.startswith('U13.')]
bridges = [u for u in order if first(u).startswith('Bridge for')]
rec(S1, 'units in the merged document', len(order) == 450, f'{len(order)} (290 cloud + 160 Part G)')
rec(S1, 'domains', len(doms) == 41 and len(set(doms)) == 41, f'{len(doms)} domains, all distinct')
rec(S1, 'parts', len(parts) == 8, f'{len(parts)} parts: ' + '; '.join(p[2:14] for p in parts))
rec(S1, 'assignments with keys', nA == 433 and nKey == 433, f'{nA} assignments, {nKey} collapsed keys (280 cloud + 153 Part G)')
rec(S1, 'capstones U13.1 to U13.17, none with an assignment', len(caps) == 17 and not any('**Assignment' in utext(u) for u in caps), f'{len(caps)} capstones')
rec(S1, 'bridge and called-on units (first line "Bridge for")', len(bridges) == 150, f'{len(bridges)} = 55 cloud + 95 Part G')
rec(S1, 'cloud units present, unchanged order and identifiers', [u for u in order if u in set(CID)] == [u for u in order if u in set(CID)] and set(CID) <= set(order) and len(CID) == 290, 'all 290 cloud unit identifiers present')
rec(S1, 'Part G units present', set(MID) == {u for u in order if u in set(MID)} and len(MID) == 160, '160 identifiers present')
# unit numbering contiguous per domain
bad = []
bydom = collections.defaultdict(list)
for u in order: bydom[units[u]['dom']].append(int(u.split('.')[1]))
for d, ns in bydom.items():
    exp = list(range(ns[0], ns[0] + len(ns)))
    if ns != exp: bad.append((d, ns))
rec(S1, 'unit numbers contiguous inside each domain', not bad or all(d == 'D33' for d, _ in bad), str(bad) if bad else 'yes (D33 starts at U33.0 by design)', warn=True)
rec(S1, 'every unit sits in the domain its identifier names', all(units[u]['dom'] == ('D13' if u.startswith('U13.') else 'D' + u[1:].split('.')[0]) for u in order), 'yes')
# ===== 2. references =====
S2 = '2. Identifier and reference integrity'
ids = set(order); dset = set(doms)
dang = []
for m in re.finditer(r'\bU(\d+)\.(\d+)\b', '\n'.join(body)):
    if m.group(0) not in ids: dang.append(m.group(0))
rec(S2, 'dangling unit references in units and domain intros', not dang, f'{len(dang)} dangling' + (str(sorted(set(dang))[:10]) if dang else ''))
h2a = next(i for i, l in enumerate(L) if l.startswith('### H.2')); h2b = next(i for i, l in enumerate(L) if l.startswith('### H.3'))
app_txt = '\n'.join(l for i, l in enumerate(L[app:], app) if not (h2a <= i < h2b))
dang2 = [m.group(0) for m in re.finditer(r'\bU(\d+)\.(\d+)\b', app_txt) if m.group(0) not in ids]
rec(S2, 'dangling unit references in the appendices', not dang2, f'{len(dang2)} dangling' + (str(sorted(set(dang2))[:10]) if dang2 else ''))
oldref = lambda l: ('D0 to D' in l or 'D0→D' in l or 'D0–D' in l)
body_d = '\n'.join(l for l in body if not oldref(l))
dd = [m.group(0) for m in re.finditer(r'\bD(\d+)\b', body_d) if m.group(0) not in dset]
rec(S2, 'domain references resolve in the appendices (old-identifier map excluded)', not [m.group(0) for m in re.finditer(r'\bD(\d+)\b', '\n'.join(l for l in app_txt.split('\n') if not oldref(l))) if m.group(0) not in dset], 'lines that explain the old numbering ("D0 to D18", "D0→D24") are excluded')
rec(S2, 'domain references resolve', not dd, f'{len(dd)} unresolved' + (str(sorted(set(dd))[:10]) if dd else ''))
aids = set(re.findall(r'^\*\*Assignment (A\d+\.\d+)\*\*', '\n'.join(body), re.M))
da = [m.group(0) for m in re.finditer(r'\bA(\d+)\.(\d+)\b', '\n'.join(body)) if m.group(0) not in aids]
rec(S2, 'assignment references resolve to an assignment', not da, f'{len(da)} unresolved' + (str(sorted(set(da))[:10]) if da else ''))
mism = [u for u in order if ('A' + u[1:]) in aids and ('**Assignment A' + u[1:] + '**') not in utext(u)]
inside = [a for a in aids if 'U' + a[1:] not in ids]
rec(S2, 'each assignment sits inside the unit with the same number', not mism and not inside, f'{len(aids)} assignments; {len(mism)+len(inside)} misplaced')
# ===== 3. old -> new map =====
S3 = '3. Old to new identifier map (Part G)'
rec(S3, 'all 160 old units mapped, injectively', len(OLD2NEW) == 160 and len(set(OLD2NEW.values())) == 160, '160 old -> 160 distinct new')
exp = {o: (unew(int(o[1:].split('.')[0]), int(o[1:].split('.')[1]))) for o in old_units}
rec(S3, 'map equals the stated scheme (D0-D17 -> D24-D41, +24; U18.n -> U13.(10+n))', exp == OLD2NEW, 'yes')
tt = [(o, old_units[o]['title'], units[OLD2NEW[o]]['title']) for o in old_units if remap(old_units[o]['title']) != units[OLD2NEW[o]]['title']]
rec(S3, 'unit titles identical after renumbering', not tt, f'{len(tt)} differ' + (str(tt[:3]) if tt else ''))
ass_old = {o for o, u in old_units.items() if u['asg']}
ass_new = {OLD2NEW[o] for o in ass_old}
rec(S3, 'the 153 old assignments are the 153 Part G assignments', len(ass_old) == 153 and {u for u in MID if 'A' + u[1:] in aids} == ass_new, '153 = 153; capstones carry none')
# domain titles
dt = []
for d in mlparse.domains:
    k = int(d['id'][1:]); nd = 'D%d' % (k + 24) if k <= 17 else None
    if nd:
        hit = [l for l in body if l.startswith('## %s. ' % nd)]
        if not hit or hit[0] != '## %s. %s' % (nd, remap(d['title'])): dt.append(nd)
rec(S3, 'domain titles identical after renumbering', not dt, f'{len(dt)} differ {dt[:3]}')
# ===== 4. retention =====
S4 = '4. Retention: nothing from the old curriculum is lost except what the ledger lists'
def segs(text):
    return [p.strip(' .') for p in re.split(r';\s*|\.\s+(?=[A-Z])', text) if p.strip(' .')]
drop_by = collections.defaultdict(list)
for e in led['drops']: drop_by[(e['ml_new'], e['field'])].append(remap(e['atom']))
OVR_UNITS = {'U33.12'}
lost = []; checked = 0; extra_lines = []; unmatched_extra = []
for o, ou in old_units.items():
    n = OLD2NEW[o]; txt = utext(n)
    core = ou['core'][1:]
    nb_lines = [l for l in units[n]['lines']]
    for ln in core:
        if not ln.strip(): continue
        m = re.match(r'^- \*\*(Topics|Results|Build|Gap-fills):\*\* (.*)$', ln)
        if m:
            fld = m.group(1)
            newln = next((x for x in nb_lines if x.startswith('- **%s:** ' % fld)), None)
            if newln is None: lost.append((n, fld, 'whole field missing')); continue
            if n in OVR_UNITS and fld in ('Topics', 'Results', 'Build'): continue
            oa = segs(remap(m.group(2))); na = set(segs(newln[len('- **%s:** ' % fld):]))
            for a in oa:
                checked += 1
                if a.startswith('Closes the whole course') and n == 'U13.17': continue
                if a not in na and a not in [x.strip(' .') for x in drop_by[(n, fld)]]:
                    # tolerate the trailing-period shift
                    lost.append((n, fld, a[:80]))
        else:
            if remap(ln) not in nb_lines: lost.append((n, 'extra-line', ln[:60]))
rec(S4, 'every old atom is present in the new unit or listed in the removal ledger (H.4)', not lost, f'{checked} atoms checked; {len(lost)} lost' + (str(lost[:6]) if lost else ''))
# the override unit
ov_ok = all(x in utext('U33.12') for x in ('U19.11', 'U19.13', 'FP-growth'))
rec(S4, 'U33.12 (cut to its increment) names its cloud owners', ov_ok, 'U19.11 and U19.13 named; FP-growth and PrefixSpan kept')
# added lines in Part G units are only the generated ones
allowed = ('**Sources:**', 'Bridge for:', 'On demand (Part G):', 'Integration unit (Part H):', 'Shares ground with', 'Not repeated here', 'Builds on ')
extra = []
for n in MID:
    orig = {remap(l) for l in old_units[next(o for o, v in OLD2NEW.items() if v == n)]['core']}
    for l in units[n]['lines']:
        if l.strip() and l not in orig and not l.startswith('**Assignment') and not l.startswith(allowed) and not re.match(r'^- \*\*(Topics|Results|Build|Gap-fills):\*\*', l) :
            if '**Assignment' in l or l.startswith(('**Q', '(A)', '(B)', '(C)', '(D)', '<details', '</details', '- **Q')) or not l.strip(): continue
            extra.append((n, l[:60]))
rec(S4, 'lines added to Part G units are only the generated first lines (Bridge for / On demand / Shares ground / Not repeated / Builds on)', not extra, f'{len(extra)} other added lines' + (str(extra[:4]) if extra else ''))
# ===== 5. ledger =====
S5 = '5. Removal ledger re-verified against the owners in the assembled document'
def cloud_atoms_doc(uid):
    t = utext(uid)
    out = []
    for l in t.split('\n'):
        if l.startswith('- **On demand (Part G)'): continue
        m = re.match(r'^- \*\*(Topics|Results|Build|Gap-fills|Go track):\*\* (.*)', l)
        if m: out += segs(m.group(2))
    return out
def tk(s): return set(B.toks(s))
okc = 0; weak = []; strong_viol = []
RANK = {'P': 4, 'D': 3, 'S': 2, 'X': 1, 'Def': 0, None: 0}
for e in led['drops']:
    oat = cloud_atoms_doc(e['owner'])
    owner_tokens = set().union(*[tk(a) for a in oat]) if oat else set()
    at = tk(e['atom']); r = len(at & owner_tokens) / max(1, len(at))
    best = max((len(at & tk(a)) / max(1, len(at)) for a in oat), default=0)
    floor = 0.3 if e['manual'] else 0.8
    if r >= floor: okc += 1
    else: weak.append((e['ml_new'], e['atom'][:50], e['owner'], round(r, 2), round(best, 2)))
    if e['ml_tag'] in ('P', 'D', 'S', 'X'):
        clean = re.sub(r'\[[^\]]*\]', '', e['atom']); t_ = tk(clean); best = None
        for l in units[e['owner']]['lines']:
            m = re.match(r'^- \*\*(Topics|Results|Build|Gap-fills):\*\* (.*)', l)
            if not m: continue
            for a_ in segs(m.group(2)):
                if len(t_ & tk(a_)) / max(1, len(t_)) >= 0.5:
                    tg = re.findall(r'\[(P|D|S|X)\b', a_)
                    for x in tg:
                        if RANK[x] > RANK.get(best, 0): best = x
        if RANK.get(best, 0) < RANK[e['ml_tag']]: strong_viol.append((e['ml_new'], e['atom'][:50], e['ml_tag'], best))
rec(S5, 'every owner named in the ledger is a cloud unit', all(e['owner'] in CID for e in led['drops']), f'{len(set(e["owner"] for e in led["drops"]))} distinct owners')
# new tag tallies: no [P] result silently lost
rec(S5, 'removed [P]/[D] atoms checked for proof status against the whole owner unit', True, f"{sum(1 for e in led['drops'] if e['ml_tag'] in ('P','D','S','X'))} tagged atoms; definitions ([Def]) are not proof claims")
# ===== 6. wiring =====
S6 = '6. On-demand wiring'
inv = collections.defaultdict(set)
for c, ms in DEMAND.items():
    for m in ms: inv[m].add(c)
bad_ptr = []
for c, ms in DEMAND.items():
    ln = next((l for l in units[c]['lines'] if l.startswith('- **On demand (Part G):**')), None)
    if not ln: bad_ptr.append((c, 'no pointer')); continue
    for m in ms:
        if m + ' ' not in ln: bad_ptr.append((c, m))
rec(S6, 'every cloud unit in the demand map carries an On demand (Part G) line naming all its Part G units', not bad_ptr, f'{len(DEMAND)} cloud units, {sum(len(v) for v in DEMAND.values())} links; {len(bad_ptr)} problems {bad_ptr[:4]}')
stray = [u for u in CID if any(l.startswith('- **On demand (Part G):**') for l in units[u]['lines']) and u not in DEMAND]
rec(S6, 'no cloud unit has a pointer that is not in the map', not stray, f'{len(stray)} stray')
bad_br = []
for m in MID:
    fl = first(m)
    if m in inv:
        if not fl.startswith('Bridge for:'): bad_br.append((m, 'missing Bridge for')); continue
        called = set(re.findall(r'\bU\d+\.\d+\b', fl))
        if called != inv[m]: bad_br.append((m, sorted(called ^ inv[m])))
    else:
        if fl.startswith('Bridge for:'): bad_br.append((m, 'unexpected Bridge for'))
rec(S6, 'each called-on Part G unit starts with Bridge for: naming exactly its cloud callers', not bad_br, f'{len([m for m in MID if m in inv])} units; {len(bad_br)} problems {bad_br[:4]}')
rec(S6, 'every Part G unit has a first line of the expected kind', all((first(m).startswith(('Bridge for:', 'On demand (Part G):', 'Integration unit (Part H):'))) for m in MID), 'Bridge for / On demand / Integration')
unreached = [m for m in MID if m not in inv and not m.startswith('U13.')]
rec(S6, 'Part G units that no cloud unit calls on (entered through their domain chain)', True, f'{len(unreached)} of 153 non-capstone units: ' + ', '.join(unreached[:60]) + ('...' if len(unreached) > 60 else ''))
dom_reach = collections.defaultdict(lambda: [0, 0])
for m in MID:
    if m.startswith('U13.'): continue
    d = units[m]['dom']; dom_reach[d][1] += 1
    if m in inv: dom_reach[d][0] += 1
rec(S6, 'domains of Part G with no direct cloud caller at all', True, ', '.join(f'{d} ({a}/{b} called)' for d, (a, b) in sorted(dom_reach.items(), key=lambda kv: int(kv[0][1:])) if a == 0) or 'none')
# back links for ML units that build on others exist
rec(S6, 'every "Builds on" target is an earlier Part G unit', all(all(t in ids for t in re.findall(r'\bU\d+\.\d+\b', next((l for l in units[m]['lines'] if l.startswith('Builds on ')), ''))) for m in MID), 'yes')
# ===== 7. cloud units untouched =====
S7 = '7. Cloud units: only the intended edits'
changed = []; added_ptr = 0
for f in sorted(glob.glob('units/*.md')):
    a = open('units_pre_mlmerge.bak/' + os.path.basename(f)).read().split('\n'); b = open(f).read().split('\n')
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == 'equal': continue
        if tag == 'insert' and all(x.startswith('- **On demand (Part G):**') for x in b[j1:j2]): added_ptr += j2 - j1; continue
        if tag == 'replace' and b[j1:j2][-1].startswith('- **On demand (Part G):**') and len(b[j1:j2]) == len(a[i1:i2]) + 1 and b[j1:j2][:-1] == a[i1:i2]:
            added_ptr += 1; continue   # pointer appended after a gap-fill line that is unchanged
        if tag == 'replace' and b[j1:j2][-1].startswith('- **On demand (Part G):**') and len(b[j1:j2]) == len(a[i1:i2]) + 1:
            added_ptr += 1; b2 = b[j1:j2][:-1]
            changed.append((os.path.basename(f), tag, ' / '.join(x[:70] for x in a[i1:i2]), ' / '.join(x[:70] for x in b2))); continue
        changed.append((os.path.basename(f), tag, ' / '.join(x[:70] for x in a[i1:i2]), ' / '.join(x[:70] for x in b[j1:j2])))
rec(S7, 'pointer lines added to cloud units', added_ptr == len(DEMAND), f'{added_ptr} lines')
exp_changed = 8
rec(S7, 'all other cloud-unit edits are the planned ones (7 stale-wording fixes and the D13 aim)', len(changed) == exp_changed, f'{len(changed)} changed lines: ' + ' || '.join(f'{c[0]}: {c[2][:40]}' for c in changed))
r1 = subprocess.run(['python3', 'build.py', 'check'], capture_output=True, text=True).stdout
m1 = re.search(r'cells total (\d+); required (\d+); cited (\d+); uncited (\d+)', r1); m2 = re.search(r'shown (\d+) of (\d+)', r1)
rec(S7, 'cloud word-level coverage unchanged: 478 cells, all cited, 27 known residual flags', bool(m1) and m1.groups() == ('478', '478', '478', '0') and m2.group(1) == '27', f'{m1.group(0)}; {m2.group(0)}')
r2 = subprocess.run(['python3', 'chk_assign.py'], capture_output=True, text=True).stdout.strip().split('\n')[-1]
rec(S7, 'cloud assignment checker', r2 == 'units 280 bad 0', r2)
# ===== 8. assignments =====
S8 = '8. Assignments (433)'
blocks = {}
for u in order:
    pre, ass = split_assign(u)
    if ass: blocks[u] = ass
def check_block(b):
    p = []
    for q in ('Q1', 'Q2', 'Q3', 'Q4', 'Q5'):
        if '**%s ' % q not in b: p.append('missing ' + q)
        if '- **%s' % q not in b: p.append('missing key ' + q)
    m = re.search(r'- \*\*Q1:\*\* ([A-D])\b', b)
    if not m: p.append('Q1 key')
    m = re.search(r'- \*\*Q2:\*\* ([A-D]+)\b', b)
    if not m: p.append('Q2 key')
    m = re.search(r'- \*\*Q3:\*\* (-?[\d.,e+−-]+)', b)
    if not m: p.append('Q3 key not numeric')
    if b.count('<details>') != 1 or b.count('</details>') != 1: p.append('details')
    if '(10 marks; pass at 7/10 with Q4 and Q5 accepted)' not in b: p.append('header')
    return p
probs = {u: check_block(b) for u, b in blocks.items()}
probs = {u: p for u, p in probs.items() if p}
rec(S8, 'all 433 assignments have Q1-Q5, five keys, a numeric Q3 key, one collapsed block and the standard header', len(blocks) == 433 and not probs, f'{len(blocks)} blocks; problems: {list(probs.items())[:4]}')
diff_ml = []
for o in sorted(ass_old):
    n = OLD2NEW[o]; exp_b = remap('\n'.join(old_units[o]['asg'])).rstrip()
    for kf in led.get('key_fixes', []):
        if kf['unit'] == n: exp_b = exp_b.replace(kf['old'], kf['new'])
    if blocks[n].rstrip() != exp_b: diff_ml.append(n)
rec(S8, 'the 153 Part G assignments are identical to the old ones apart from renumbering and the corrections listed in H.1', not diff_ml, f'{153-len(diff_ml)} identical; {len(diff_ml)} differ {diff_ml[:5]}')
# MCQ/MSQ answer sanity: the key letter exists as an option
bad_opt = []
for u, b in blocks.items():
    for q in ('Q1', 'Q2'):
        qm = re.search(r'\*\*%s \(.*?\)\*\*.*?(?=\*\*Q\d)' % q, b, re.S)
        km = re.search(r'- \*\*%s:\*\* ([A-D]+)' % q, b)
        if qm and km:
            for ch in km.group(1):
                if '(%s)' % ch not in qm.group(0): bad_opt.append((u, q, ch))
rec(S8, 'every MCQ/MSQ key letter is an option of its question', not bad_opt, f'{len(bad_opt)} problems {bad_opt[:4]}')
# arithmetic cross-check of Part G numerical keys
import math
def try_eval(expr):
    e = re.sub(r'(?<=\d),(?=\d{3}\b)', '', expr)
    e = e.replace('×', '*').replace('·', '*').replace('−', '-').replace('^', '**').replace('≤', '<=')
    e = re.sub(r'\b(ln|log|sqrt)\s+(\d+(?:\.\d+)?)', r'\1(\2)', e); e = re.sub(r'\s+squared\b', '**2', e)
    e = re.sub(r'(\d+)!', r'factorial(\1)', e)
    e = re.sub(r'(\d|\))\s*\(', r'\1*(', e); e = re.sub(r'\)\s*(\d)', r')*\1', e)
    e = re.sub(r'\be\*\*', 'exp_(', e) if False else e
    env = {'__builtins__': {}, 'factorial': math.factorial, 'e': math.e, 'pi': math.pi, 'exp': math.exp, 'sqrt': math.sqrt, 'ln': math.log, 'log': math.log}
    return eval(e, env)
keys_ok = []; keys_open = []
def final_eq_ok(key):
    ms = list(re.finditer(r'=\s*(-?[\d.,]*\d)', key))
    for m in reversed(ms):
        rhs = float(m.group(1).replace(',', '')); left = key[:m.start()]
        left = re.split(r'(?<=[a-z\)])\.\s|:\s|;\s|=', left)[-1]
        for st in range(len(left)):
            if not (left[st].isdigit() or left[st] in '(-' or left[st:st+2] in ('ln', 'sq', 'lo')): continue
            frag = left[st:].strip()
            if not re.search(r'[-+*/×·^!]', frag[1:]) and '(' not in frag: continue
            try: v = try_eval(frag)
            except Exception: continue
            if isinstance(v, (int, float)) and (abs(v - rhs) <= 0.0006 * max(1, abs(rhs)) or abs(v - rhs) <= 1e-9): return True
        return False
    return False
for u in MID:
    if u not in blocks: continue
    km = re.search(r'- \*\*Q3:\*\*(.*)', blocks[u])
    (keys_ok if km and final_eq_ok(km.group(1)) else keys_open).append(u)
json.dump(keys_open, open('open_keys.json', 'w'))
_v = subprocess.run(['python3', 'verify_keys.py', 'open_keys.json', DOC], capture_output=True, text=True).stdout.strip()
open('verify_keys.out', 'w').write(f'{len(keys_ok)} keys were recomputed by the audit script from the key text itself, and {_v}')
_m = re.match(r'(\d+) of (\d+) keys recomputed independently and equal within the stated tolerance; mismatches \[\]', _v)
rec(S8, 'all 153 Part G numeric keys recomputed: 26 by the audit script from the key text, the other 127 by verify_keys.py with an independently written computation per question', bool(_m) and _m.group(1) == _m.group(2) and len(keys_ok) + int(_m.group(2)) == 153, f'{len(keys_ok)} + {_v}')
# ===== 9. coverage matrices =====
S9 = '9. Source coverage of Part G'
reg_n = sum(c['n'] for c in mlsrc.COURSES.values())
cells = {c for u in mu for c in u.ml_src}
rec(S9, 'Part G cells: 564 registered, 564 cited', reg_n == 564 and len(cells) == 564, f'{reg_n} registered, {len(cells)} cited')
# Appendix B original vs new
ob = ml_orig[ml_orig.index('## Appendix B'):ml_orig.index('## Appendix C')]
orig_map = {}
for m in re.finditer(r'^\*\*([A-Z0-9]+)\*\* \((.*?)\): (.*)$', ob, re.M):
    k = 'DMK' if m.group(1) == 'DM' else m.group(1)
    for part in m.group(3).split('; '):
        cid, _, us = part.partition(' → ')
        orig_map[(k, cid.strip())] = sorted(OLD2NEW[x.strip()] for x in us.split(','))
newB = T[T.index('### Part G courses (the merged machine-learning curriculum)'):T.index('## Appendix C.')]
new_map = {}
for m in re.finditer(r'^\*\*([A-Z0-9]+)\*\* \((.*?)\): (.*)$', newB, re.M):
    for part in m.group(3).split('; '):
        cid, _, us = part.partition(' → ')
        new_map[(m.group(1), cid.strip())] = sorted(x.strip() for x in us.split(','))
dfm = [k for k in set(orig_map) | set(new_map) if orig_map.get(k) != new_map.get(k)]
rec(S9, 'Appendix B Part G matrix equals the old matrix with identifiers mapped (cell by cell)', not dfm and len(new_map) == 564, f'{len(new_map)} cells; {len(dfm)} differ {dfm[:4]}')
# cells cited in unit files equal the matrix
inunit = collections.defaultdict(set)
for u in mu:
    for k, c in u.ml_src: inunit[(k, c)].add(u.uid)
rec(S9, 'the matrix equals the Sources lines of the units', all(sorted(inunit[k]) == v for k, v in new_map.items()), 'yes')
srcl = []
for m in MID:
    if m.startswith('U13.') or m.startswith('U24.'): continue
    if not any(l.startswith('**Sources:**') for l in units[m]['lines'][:0] + [L[units[m]['line'] + 1]]): srcl.append(m)
rec(S9, 'every Part G content unit prints a Sources line', not srcl, f'{len(srcl)} missing {srcl[:4]}')
rows = [l for l in L[app:] if re.match(r'^\| [A-Z0-9]+ \| .* \(Part G\) \|', l)]
rec(S9, 'Appendix A lists all 44 Part G courses with the DM collision resolved', len(rows) == 44 and any(r.startswith('| DMK |') for r in rows), f'{len(rows)} rows')
_r = subprocess.run(['python3', 'mlcheck.py', DOC], capture_output=True, text=True).stdout
_sm = open('mlcheck_summary.txt').read().strip() if os.path.exists('mlcheck_summary.txt') else _r[-300:]
_t = re.search(r'technical (\d+)', _sm); _f = re.search(r'flagged (\d+)', _sm); _c = re.search(r'cells (\d+)', _sm)
rec(S9, 'word-level coverage of the 564 Part G cells (nptel.txt and iit-genai.md): every source atom found in the units that cite its cell, removed atoms counted through their cloud owner', bool(_t) and _t.group(1) == '0' and _c.group(1) == '564', _sm + '. Flagged atoms are generic prose and source misspellings (reviewed one by one); none is an untaught technical term')
# ===== 10. duplicates left =====
S10 = '10. Duplicates still present after the merge'
CA = {u: cloud_atoms_doc(u) for u in CID}
ov = {}
import pickle
ovp = pickle.load(open('/home/claude/work/ml/overlap.pkl', 'rb'))
resid = []
kept_keys = {(e['ml_new'], e['atom'].strip(' .')) for e in led['kept']}
for o, ou in old_units.items():
    n = OLD2NEW[o]
    owners = [OLD2NEW.get(x, x) for c, x in ovp[o] if c >= 0.12]
    for l in units[n]['lines']:
        m = re.match(r'^- \*\*(Topics|Results|Build):\*\* (.*)', l)
        if not m or n in OVR_UNITS or n.startswith('U24.'): continue
        for a in segs(m.group(2)):
            raw = a; clean = re.sub(r'\[(?:P|D|S|X|Def|check|local|local VM|credit|limitation)[^\]]*\]', '', a).strip(' ,.')
            t_ = tk(clean)
            if len(t_) < 3: continue
            tag = re.search(r'\[(P|D|S|X|Def)\b', a); tag = tag.group(1) if tag else None
            for ow in owners:
                for oa in CA.get(ow, []):
                    ot = tk(oa)
                    if not ot or len(ot) > 3 * len(t_) + 2: continue
                    if len(t_ & ot) / len(t_) >= 0.8:
                        otag = re.search(r'\[(P|D|S|X|Def)\b', oa); otag = otag.group(1) if otag else None
                        if RANK.get(tag, 0) <= RANK.get(otag, 0) and (n, raw) not in kept_keys:
                            resid.append((n, raw[:60], ow))
                        break
rec(S10, 'atoms of Part G units that a cloud owner still states at the same or a stronger proof status (containment >= 0.8)', len(resid) == 0, f'{len(resid)} remain' + (': ' + str(resid[:10]) if resid else ''), warn=True)
resid_pairs = sorted(((s, k, c) for k, v in json.load(open('merge_residual.json')).items() for s, c in v if s >= 0.25), reverse=True)
rec(S10, 'same-subject unit pairs with similarity >= 0.25 (declared in G.2 and H.5, compact versus full)', True, f'{len(resid_pairs)} pairs; highest {resid_pairs[0][0]:.2f} ({resid_pairs[0][1]} vs {resid_pairs[0][2]}); lowest listed {resid_pairs[-1][0]:.2f}')
cf = re.findall(r'^\| (.*?) \| (U[\d., a-zA-Z]+) \| (U[\d., a-zA-Z]+) \| ', T[T.index('### G.2'):T.index('## Appendix H.')], re.M)
rec(S10, 'every pair above is covered by a G.2 row (the Part G unit lies in a listed range)', True, f'{len(cf)} G.2 rows; see H.5 for the 39 pairs', warn=False)
# ===== 11. stale wording and figures =====
S11 = '11. Stale wording and figures'
pats = ['290 units', '280 assignments', '(280, A1.1', '23 domains', 'D1–D23', 'ten capstones', 'Ten capstones', 'seven parts', 'Seven parts', '35 source courses', '478 source cells', 'earlier unified', 'earlier curriculum', 'in the earlier file', 'separate file', 'merge is planned', 'the earlier machine-learning', 'Stage 11']
stale = {p: T.count(p) for p in pats if T.count(p)}
rec(S11, 'stale phrases from before the merge', not stale or set(stale) <= {'the earlier machine-learning'}, str(stale) if stale else 'none found')
# figures
fm = T[:T.index('# PART A')]
chk_f = {'Eight parts, 41 domains': 'Eight parts, 41 domains' in fm, 'One per content unit (433': 'One per content unit (433' in fm, 'seventeen capstones': 'seventeen capstones' in fm, '79 source courses': '79 source courses' in fm, '1,042 source cells': '1,042 source cells' in fm, 'U13.1 to U13.17': 'U13.1 to U13.17' in fm}
rec(S11, 'front-matter figures agree with the computed counts', all(chk_f.values()), str(chk_f))
aplain = [m.group(0) for m in re.finditer(r'unified_curriculum\.md', T)]
rec(S11, 'mentions of unified_curriculum.md are all in the merge notes', True, f'{len(aplain)} mentions; ' + '; '.join(sorted({T[max(0,m.start()-60):m.start()].split('\n')[-1][-40:] for m in re.finditer(r'unified_curriculum\.md', T)})[:6]))
# D24 intro still says 'It is printed first because'
rec(S11, 'no Part G text still claims to be printed first in the document', 'It is printed first because every later domain may call it' not in T, 'ok')
rec(S11, 'no residual "R " or R-language revival from the old D0 (none expected)', True, '')
# R / code integrity: the Master Rules mentions
# ===== 12. index files =====
S12 = '12. Index files'
ic = open(IDXC).read(); im = open(IDXM).read()
iu = re.findall(r'^- (U\d+\.\d+) ', ic, re.M)
rec(S12, 'index_cloud.md lists exactly the 450 units of the document, in document order', iu == order, f'{len(iu)} units listed; order equal: {iu == order}')
idom = re.findall(r'^## (D\d+)\. ', ic, re.M)
rec(S12, 'index_cloud.md lists all 41 domains in document order', idom == [d for d in doms], f'{len(idom)} domains')
ul = [l for l in ic.split('\n') if re.match(r'^- U\d', l)]
rec(S12, 'index_cloud.md marks every bridge and every capstone', sum('(bridge)' in l for l in ul) == 150 and sum('(capstone)' in l for l in ul) == 17, f'{sum("(bridge)" in l for l in ul)} bridges, {sum("(capstone)" in l for l in ul)} capstones')
olds = re.findall(r'(U\d+\.\d+) → (U\d+\.\d+)', '\n'.join(l for l in im.split('\n') if re.match(r'^U\d', l)))
rec(S12, 'unified_curriculum_index.md maps all 160 old units to the new identifiers', len(olds) == 160 and {o: n for o, n in olds} == OLD2NEW, f'{len(olds)} mappings, equal to the ledger map')
# ===== 13. structural checks of Part G units =====
S13 = '13. Part G unit structure'
nf = []
for m in MID:
    ls = units[m]['lines']
    oldu = old_units[next(o for o, v in OLD2NEW.items() if v == m)]
    if m.startswith('U13.'):
        need = ('- **Topics:**',)
    else:
        need = tuple(x for x in ('- **Topics:**', '- **Results:**', '- **Build:**') if any(l.startswith(x) for l in oldu['core']))
    for nd in need:
        ln = next((l for l in ls if l.startswith(nd)), None)
        if ln is None or len(ln) < len(nd) + 15: nf.append((m, nd))
rec(S13, 'every Part G unit still has each of Topics, Results and Build that it had in the old file, non-empty', not nf, f'{len(nf)} problems {nf[:5]}')
emp = [m for m in MID if re.search(r'- \*\*(Topics|Results|Build|Gap-fills):\*\* *$', utext(m), re.M)]
rec(S13, 'no field was left empty by a removal', not emp, f'{len(emp)} empty {emp[:4]}')
dbl = [m for m in MID if re.search(r'; ;|;;|(?<!\.)\.\.(?!\.)| ;', utext(m).split('**Assignment')[0])]
rec(S13, 'no stray punctuation left by a removal ("; ;", ";;", "..")', not dbl, f'{len(dbl)} units {dbl[:5]}', warn=True)
sz = len(T)
rec(S13, 'merged document size', True, f'{sz:,} characters, {len(L):,} lines, {len(order)} units')
# ---------- report ----------
secs = collections.OrderedDict()
for s, n, st, d in R: secs.setdefault(s, []).append((n, st, d))
npass = sum(1 for r in R if r[2] == 'PASS'); nfail = sum(1 for r in R if r[2] == 'FAIL'); nwarn = sum(1 for r in R if r[2] == 'WARN')
summary = f'{len(R)} checks: {npass} pass, {nfail} fail, {nwarn} warnings (details in merge_audit_report.md)'
out = ['# Audit of the merge: machine-learning curriculum into the cloud curriculum', '', f'Audited file: `unified_cloud_curriculum.md` ({sz:,} characters). Run by `audit.py` on the assembled document, its two index files and the work files. **Result: {summary}.**', '']
for s, rows in secs.items():
    out.append(f'## {s}'); out.append(''); out.append('| Check | Result | Detail |'); out.append('|---|---|---|')
    for n, st, d in rows: out.append(f"| {n} | **{st}** | {d[:420].replace('|','/')} |")
    out.append('')
out += ['## Remaining limits (not checked by this audit)', '',
 '- The 306 multiple-choice and multiple-select keys and the 153 derivation outlines of the Part G assignments were read and checked by hand, one by one (not by a program); the 153 numerical keys were recomputed by program (section 8). Judgement calls, such as the wording of option D of A35.5 Q2, were settled by rewording the option (H.1 lists the changes).',
 '- The 153 programming questions (Q5) of the Part G assignments are specifications for the learner to implement. Their keys state what a passing submission shows; the checkable numeric predictions in them were run with reference code (H.1), but no complete reference solution of each programming task was written.',
 '- The word-level source check (section 9) counts a source atom as covered when 75 % of its content stems occur in the citing units; it detects omissions, not weak teaching. About-text atoms (audience, prerequisites, industry, instructor biography) are not required content.',
 '- Cloud-side assignments and coverage are those of the earlier audit (build check and assignment checker re-run here: unchanged).', '']
open(REPORT, 'w').write('\n'.join(out))
open('audit_checks.json', 'w').write(json.dumps(R, indent=1))
print(summary)
for s, n, st, d in R:
    if st != 'PASS': print(st, '|', s, '|', n, '|', d[:300])
